Draco UDI-AVS Intetration Module
=========================================

Provides code needed to integrate the Draco UDI module with the
Draco AVS moudle.

Includes:

1.  ODT Encoding Job Queue config and fetcher.  Notifications that
   videos are ready to encode will be supplied via a 2nd ODT queue.
   A 2nd ODT listener is included in this moudle.
