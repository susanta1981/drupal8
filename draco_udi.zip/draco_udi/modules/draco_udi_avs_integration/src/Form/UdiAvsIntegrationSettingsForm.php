<?php

namespace Drupal\draco_udi_avs_integration\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure text display settings for Upstream Data Integration.
 *
 * @codeCoverageIgnore
 */
class UdiAvsIntegrationSettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'draco_udi_avs_integration.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'draco_udi_avs_integration.settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->configFactory->get('draco_udi_avs_integration.settings');

    $form['text'] = array(
      '#type' => 'markup',
      '#markup' => '<p>Please provide data for the AVS-ODT Job Notification Queue.<br> 
       This is the configuration for the ODT queue that will provide notifications that vidoes
        are ready for encoding.<br>Blank or invalid values will lead to failures.</p>',
    );

    // ODT settings.
    $form['odt_settings'] = array(
      '#type' => 'details',
      '#title' => 'ODT/AVS notification queue settings',
      '#open' => true,
    );


    $form['odt_settings']['odt_queue_host'] = array(
      '#type' => 'textfield',
      '#title' => t('ODT/AVS notification queue host name'),
      '#default_value' => $config->get('odt_settings.odt_queue_host'),
      '#description' => t('ODT/AVS notification queue host name'),
    );

    $form['odt_settings']['odt_queue_host_port'] = array(
      '#type' => 'textfield',
      '#title' => t('ODT/AVS notification queue host port number'),
      '#default_value' => $config->get('odt_settings.odt_queue_host_port'),
      '#description' => t('ODT/AVS notification queue host port number'),
    );

    $form['odt_settings']['odt_queue_name'] = array(
      '#type' => 'textfield',
      '#title' => t('ODT/AVS notification queue name'),
      '#default_value' => $config->get('odt_settings.odt_queue_name'),
      '#description' => t('ODT/AVS notification queue name'),
    );

    $form['odt_settings']['odt_queue_userid'] = array(
      '#type' => 'textfield',
      '#title' => t('ODT/AVS notification queue user id'),
      '#default_value' => $config->get('odt_settings.odt_queue_userid'),
      '#description' => t('ODT/AVS notification queue user id'),
    );

    $form['odt_settings']['odt_queue_pwd'] = array(
      '#type' => 'password',
      '#title' => t('ODT/AVS notification queue password'),
      '#attributes' => array('value' => $config->get('odt_settings.odt_queue_pwd')),
      '#description' => t('ODT/AVS notification queue password'),
    );

    $form['odt_settings']['odt_queue_vhost'] = array(
      '#type' => 'textfield',
      '#title' => t('ODT/AVS notification queue vhost'),
      '#default_value' => $config->get('odt_settings.odt_queue_vhost'),
      '#description' => t('ODT/AVS notification queue vhost'),
    );


    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    $values = $form_state->getValues();
    $this->config('draco_udi_avs_integration.settings')
      ->set('odt_settings.odt_queue_host', $values['odt_queue_host'])
      ->set('odt_settings.odt_queue_host_port', $values['odt_queue_host_port'])
      ->set('odt_settings.odt_queue_userid', $values['odt_queue_userid'])
      ->set('odt_settings.odt_queue_pwd', $values['odt_queue_pwd'])
      ->set('odt_settings.odt_queue_name', $values['odt_queue_name'])
      ->set('odt_settings.odt_queue_vhost', $values['odt_queue_vhost'])
      ->save();

    if (function_exists('drupal_set_message')) {
      parent::submitForm($form, $form_state);
    }
    else {
      return true;
    }
  }

}
