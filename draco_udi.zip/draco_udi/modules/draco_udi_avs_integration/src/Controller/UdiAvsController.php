<?php

namespace Drupal\draco_udi_avs_integration\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\draco_udi\Service\DataSource\Tve\TveClientInterface;
use Psr\Log\LoggerInterface;
use Drupal\draco_udi\Service\ContentFetchManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

/**
 * Class UdiAvsController.
 *
 * Controller to handle AVS testing.
 *
 * @package Drupal\draco_udi_avs_integration\Controller
 */
class UdiAvsController extends ControllerBase {


  /**
   * Content fetch manager.
   *
   * @var Drupal\draco_udi\Service\ContentFetchManagerInterface
   */
  protected $fetchManager;

  /**
   * Logger.
   *
   * @var Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * UdiTveController constructor.
   *
   * @param \Drupal\Core\Logger\LoggerInterface $logger_channel
   *   Logger.
   */
  public function __construct(ContentFetchManagerInterface $fetch_manager, LoggerInterface $logger_channel) {
    $this->fetchManager = $fetch_manager;
    $this->logger = $logger_channel;
  }

  /**
   * Create method.
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('draco_udi_avs_integration.content.fetch.manager'),
      $container->get('draco_udi.logger.channel')
    );
  }

  public function testAVS() {
    $status = Response::HTTP_CREATED;
    $msg = "Tve Content Created";
      $this->fetchManager->fetchOnDemandWorkOrders();
    return new Response($msg, $status);
  }



}
