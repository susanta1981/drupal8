<?php

namespace Drupal\draco_udi_demo\Plugin\Mapper;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\draco_udi\Service\DracoContentRepositoryInterface;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class SiteMovieMapper.
 *
 * This is a sample Mapper implementation shows how to map data from a Draco
 * ContentTitle entity to a Node entity of Movie type. Notice that this is
 * only one way to do the mapping. it is up to the site to choose a proper
 * way to do it.
 *
 * @package Drupal\draco_udi_demo\Plugin\Mapper
 *
 * @Mapper(id = "SiteMovieMapper")
 */
class SiteMovieMapper extends SiteMapperBase {

  /**
   * SiteMovieMapper constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityManagerInterface $entity_manager
   *   The entity manager.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *    Entity query factory for finding existing entities with same titleId.
   * @param \Psr\Log\LoggerInterface $logger
   *   A logger instance.
   * @param DracoContentRepositoryInterface $content_repository
   *   A service for accessing Draco contents.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      EntityManagerInterface $entity_manager,
      QueryFactory $query_factory,
      LoggerInterface $logger,
      DracoContentRepositoryInterface $content_repository
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entity_manager, $query_factory, $logger, $content_repository);
  }

  /**
   * Creates an instance of the plugin.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container to pull out services used in the plugin.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   *
   * @return static
   *   Returns an instance of this plugin.
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static($configuration, $plugin_id, $plugin_definition,
      $container->get('entity.manager'),
      $container->get('entity.query'),
      $container->get('logger.factory')->get('showcase_movie'),
      $container->get('draco_udi.content.repository')
    );
  }

  /**
   * Return machine name of content type.
   *
   * @return string
   *    Machine name of the target content type.
   */
  protected function getTargetContentType() {
    return 'showcase_movie';
  }

  /**
   * Return valid source content type values.
   *
   * @return array
   *    A list of valid type values in source content data items.
   */
  public function getSupportedTypes() {
    return array('Feature Film');
  }

  /**
   * Field-to-field mapping between ContentTitle and showcase_movie entity.
   *
   * {@inheritdoc}
   *
   * @return array
   *    mapping key/value list.
   */
  protected function getFieldMap() {
    $field_map = array(
      'titleId' => 'field_title_id',
      'titleType' => 'field_content_type',
      'name' => 'title',
      'externalStoryline' => 'body',
      'shortStoryline' => 'field_short_description',
      'ratings' => 'field_ratings',
      'participants' => 'field_participants',
      'tags' => 'field_content_tags',
      'lengthInSeconds' => 'field_length_in_seconds',
      'releaseYear' => 'field_release_year',
      'processedDatetimeUTC' => 'field_processed_datetime',
      'animationMode' => 'field_animation_mode',
      'genres' => 'field_genres',
      'keywords' => 'field_keywords',
    );

    return $field_map;
  }

  /**
   * {@inheritdoc}
   */
  public function updateExistingMappedEntity(NodeInterface $existing_entity, NodeInterface $new_entity) {
    $mapped_entity = NULL;

    // Update fields that are updatable per site.
    if ($existing_entity->field_title_id->value == $new_entity->field_title_id->value
        && $existing_entity->field_content_type->value == $new_entity->field_content_type->value) {

      $existing_entity->body->value = $new_entity->body->value;
      $existing_entity->title->value = $new_entity->title->value . 'WWW';

      if (isset($new_entity->field_short_description) && isset($existing_entity->field_short_description)) {
        $existing_entity->field_short_description->value = $new_entity->field_short_description->value;
      }
      if (isset($new_entity->field_keywords) && isset($existing_entity->field_keywords)) {
        $existing_entity->field_keywords->value = '[TW]';
      }
      if (isset($new_entity->field_content_tags) && isset($existing_entity->field_content_tags)) {
        $existing_entity->field_content_tags->value = $new_entity->field_content_tags->value;
      }
      if (isset($new_entity->field_processed_datetime) && isset($existing_entity->field_processed_datetime)) {
        $existing_entity->field_processed_datetime->value = $new_entity->field_processed_datetime->value;
      }
      if (isset($new_entity->field_participants) && isset($existing_entity->field_participants)) {
        $existing_entity->field_participants->value = $new_entity->field_participants->value;
      }

      $mapped_entity = $existing_entity;
    }

    return $mapped_entity;
  }

  /**
   * Associate on-demand schedule and linear schedule with a movie entity.
   *
   * As the UDI user guide indicates, a ContentOnDemandSchedule entity owns a
   * list of ContentOnDemandFlight references. When you load a
   * ContentOnDemandSchedule entity, you can simply call getFights() method to
   * get a list of ContentOnDemandFlight objects. Please reference the two
   * classes in UDI's Entity folder for its fields and relationships between
   * the two entities.
   *
   * This method shows how to get both on-demand schedules and linear schedules
   * for a movie using movie's title id. It also shows how to associate schedule
   * entities with a movie.
   *
   * @param NodeInterface $new_entity
   *    The mapped movie entity.
   */
  protected function updateReferences(NodeInterface $new_entity) {

    $this->updateOnDemandScheduleReferences($new_entity);

    $this->updateLinearScheduleReferences($new_entity);
  }

  /**
   * Demo how to look up related on-demand schedule entities and associate them.
   *
   * It also demonstrates how to access flights data on a
   * ContentOnDemandSchedule entity.
   *
   * @param NodeInterface $new_entity
   *   The new entity being mapped.
   */
  private function updateOnDemandScheduleReferences(NodeInterface $new_entity) {
    if ($new_entity->field_on_demand_schedules != NULL && $new_entity->field_on_demand_schedules->count() > 0) {
      // Reference to the on-demand schedules field exists and no need to update
      // it again. But, if you want to update it, don't do this checking.
      return;
    }

    $movie_title_id = $new_entity->field_title_id->value;

    // Use the service to fetch schedule by title id.
    $schedules = $this->contentRepository->getContentOnDemandSchedulesByTitleId($movie_title_id);

    if (!empty($schedules)) {
      /** @var \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface $schedule */
      $reference_ids = [];
      foreach ($schedules as $schedule) {
        $schedule_id = $schedule->id();
        $reference_ids[] = ['target_id' => $schedule_id];
      }

      $new_entity->set('field_on_demand_schedules', $reference_ids);

      // You can access on-demand schedule's fields as following.
      // Please get familar with the structure of ODT airing object so that
      // you know what data you need and how to access them.
      foreach ($schedules as $schedule) {
        $media_id = $schedule->getMediaId();
        $ad_breaks = $schedule->getAdBreaks();
        $assets = $schedule->getAssets();
        $files = $schedule->getFiles();
        $title_data = $schedule->getTitleData();
        $length_min = $schedule->getDisplayMinutes();
        $length_sec = $schedule->getLengthInSeconds();
        $airing_id = $schedule->getAiringId();
        $playlist = $schedule->getPlaylist();

        // Access flights on a schedule.
        $flights = $schedule->getFlights();

        // Access flight data. Please reference ContentOnDemandFlightInterface.
        // for a list of available fields.
        /** @var \Drupal\draco_udi\Entity\ContentOnDemandFlightInterface $flight */
        foreach ($flights as $flight) {
          $start = $flight->getStart();
          $end = $flight->getEnd();
          $destinations = $flight->getDestinations();
          $airing_id = $flight->getAiringId();
        }
      }
    }
  }

  /**
   * Demo how to look up related ContentLinearSchedule entities.
   *
   * It also demo how to associate a movie with its linear schedule entities.
   *
   * @param NodeInterface $new_entity
   *   The new entity being mapped.
   */
  private function updateLinearScheduleReferences(NodeInterface $new_entity) {
    if ($new_entity->field_linear_schedules != NULL && $new_entity->field_linear_schedules->count() > 0) {
      // Reference to the linear schedules field exists and no need to update it
      // again. But, if you want to update it, don't do this checking.
      return;
    }

    $movie_title_id = $new_entity->field_title_id->value;

    // Use the service to fetch schedule by title id.
    $schedules = $this->contentRepository->getContentLinearSchedulesByTitleId($movie_title_id);

    if (!empty($schedules)) {
      $reference_ids = [];
      foreach ($schedules as $schedule) {
        $schedule_id = $schedule->id();
        $reference_ids[] = ['target_id' => $schedule_id];
      }

      // Add references to movie.
      $new_entity->set('field_linear_schedules', $reference_ids);

      // You can access linear schedule properties like following. Please
      // reference ContentLinearScheduleInterface for list of fields.
      /** @var \Drupal\draco_udi\Entity\ContentLinearScheduleInterface $schedule */
      foreach ($schedules as $schedule) {
        $start = $schedule->getStartDate();
        $end = $schedule->getEndDate();
        $air_date = $schedule->getScheduleAirDate();
        $is_live = $schedule->getIsLive();
        $is_premiere = $schedule->getIsPremiere();
        $time_zone = $schedule->getTimeZone();
      }
    }
  }

}
