<?php

namespace Drupal\draco_udi_demo\Plugin\Mapper;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\draco_udi\Entity\ContentTitleInterface;
use Drupal\Component\Plugin\PluginBase;
use Drupal\draco_udi\Mapper\DracoMapperInterface;
use Drupal\draco_udi\Service\DracoContentRepositoryInterface;
use Drupal\node\Entity\NodeType;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;

/**
 * Abstract Class SiteMapperBase.
 *
 * This is the base class for the three mapper classes implemented in this
 * module, and it contains common code shared by the mapper classes.
 *
 * @package Drupal\draco_udi_demo\Plugin\Mapper
 */
abstract class SiteMapperBase extends PluginBase implements DracoMapperInterface {

  /**
   * The entity manager.
   *
   * @var \Drupal\Core\Entity\EntityManagerInterface
   */
  protected $entityManager;

  /**
   * The entity query factory.
   *
   * @var \Drupal\Core\Entity\Query\QueryFactory
   */
  protected $entityQuery;

  /**
   * The system logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * The Draco content repository.
   *
   * @var \Drupal\draco_udi\Service\DracoContentRepository
   */
  protected $contentRepository;

  /**
   * DracoMapperBase constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityManagerInterface $entity_manager
   *   The entity manager.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *    Entity query factory for finding existing entities with same titleId.
   * @param \Psr\Log\LoggerInterface $logger
   *   A logger instance.
   * @param DracoContentRepositoryInterface $content_repository
   *   A service for accessing Draco contents.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      EntityManagerInterface $entity_manager,
      QueryFactory $query_factory,
      LoggerInterface $logger,
      DracoContentRepositoryInterface $content_repository
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityManager = $entity_manager;
    $this->entityQuery = $query_factory;
    $this->logger = $logger;
    $this->contentRepository = $content_repository;
  }

  /**
   * Map a content data item to one or more entities of content type.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title_entity
   *    Content title entity.
   * @param array $existing_mapped_content_entities
   *    Array of existing mapped entities.
   *
   * @return array
   *    List of mapped entities of specific content type defined by site.
   */
  public function map(ContentTitleInterface $title_entity, array $existing_mapped_content_entities = NULL) {
    if ($this->validateForMapping($title_entity) == FALSE) {
      return NULL;
    }

    $field_data = array('type' => $this->getTargetContentType());

    foreach ($this->getFieldMap() as $key => $value) {
      $result = $this->getFieldValue($title_entity, $key);

      if ($result instanceof \stdClass || is_array($result)) {
        $field_data[$value] = json_encode($result);
      }
      elseif ($result instanceof \DateTime) {
        $field_data[$value] = $result->format('Y-m-d\TH:i:s');
      }
      else {
        $field_data[$value] = $result;
      }
    }

    $new_entity = $this->entityManager->getStorage('node')->create($field_data);
    $existing_mapped_content_entity = $this->getExistingEntityForThisMapper($existing_mapped_content_entities);

    if ($existing_mapped_content_entity != NULL) {
      $new_entity = $this->updateExistingMappedEntity($existing_mapped_content_entity, $new_entity);
    }

    // Set a valid user id (uid) to the node entity.
    // When running drush command outside Drupal, drush sets entity's uid to
    // default user to anonymous with uid of 0. That means, anyone can later
    // edit that entity by going to node/nid/edit. We need to dynamically set a
    // valid uid here to prevent that from happening.
    // It is up to the user to choose a valid uid like an admin user's uid.
    // In this demo site, we set to 1 (draco).
    $uid = \Drupal::currentUser()->id();

    if ($uid == 0) {
      $new_entity->set('uid', 1);
    }

    $entities = [$new_entity];

    if (!empty($dependencies)) {
      foreach ($dependencies as $dependency) {
        $entities[] = $dependency;
      }
    }

    return $entities;
  }

  /**
   * Find existing entity for this mapper.
   *
   * When a mapper is called it will receive an array of entities that are
   * currently mapped to the title.  The mapper must pick out the entity that it
   * is responsible for from the array.  This default method will look through
   * the array and find the element whose type matches the type defined in the
   * getTargetContentType method. If the mapper has another way of determining
   * the correct entity i should override this method.
   *
   * @param array $existing_mapped_content_entities
   *   Array of existing entities previously mapped.
   *
   * @return NodeInterface
   *   The object that this mapper has previously mapped.
   */
  protected function getExistingEntityForThisMapper(array $existing_mapped_content_entities) {
    $existing_entity = NULL;
    foreach ($existing_mapped_content_entities as $entity) {
      if ($entity->get('type')->getString() == $this->getTargetContentType()) {
        $existing_entity = $entity;
        break;
      }
    }
    return $existing_entity;
  }

  /**
   * If the content has been mapped in Drupal, update it or create a new one.
   *
   * Implemented by subclasses.
   *
   * @param NodeInterface $existing_entity
   *   The existing entity that has been previously mapped.
   * @param NodeInterface $new_entity
   *   The new entity that is being mapped.
   *
   * @return NodeInterface
   *    New or updated node entity of site defined type, e.g., episode.
   */
  abstract public function updateExistingMappedEntity(NodeInterface $existing_entity, NodeInterface $new_entity);

  /**
   * Validate passed item.
   *
   * It checks if the target content type is defined, and a field-to-field
   * mapping array is provided.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title_entity
   *    Content title entity.
   *
   * @return bool
   *    true if valid, otherwise false.
   */
  protected function validateForMapping(ContentTitleInterface $title_entity) {
    $valid = TRUE;
    $fields = $this->getFieldMap();

    if (empty($this->getTargetContentType())) {
      $this->logger->error('Target content type not defined in mapper', []);
      $valid = FALSE;
    }
    elseif (NodeType::load($this->getTargetContentType()) == NULL) {
      $this->logger->error('Target content type @type not found',
        ['@type' => $this->getTargetContentType()]);
      $valid = FALSE;
    }
    elseif (empty($fields)) {
      $this->logger->error('Target mapping fields not defined for mapping to content @type ',
        ['@type' => $this->getTargetContentType()]);
      $valid = FALSE;
    }

    return $valid;
  }

  /**
   * Return machine name of a content type. Implemented by subclasses.
   *
   * @return null
   *    A null value means not implemented.
   */
  protected function getTargetContentType() {
    return NULL;
  }

  /**
   * This method does the actual mapping.
   *
   * This method applies an algorithm that maps each target field machine name
   * with a corresponding property name of the source draco entity. The source
   * property name is the name of the corresponding get method without the 'get'
   * part. It doesn't matter if the first character of the property name is
   * in uppercase or not. Please check out SiteEpisodeMapper or SiteMovieMapper
   * for examples.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title_entity
   *    Source content data item.
   * @param string $property_name
   *    The key defined in fieldMap array with a possible nested structure.
   *
   * @return mixed
   *    Value of the mapped field.
   */
  public function getFieldValue(ContentTitleInterface $title_entity, $property_name) {
    $name_chains = explode(".", $property_name);
    $top_name = $name_chains[0];
    $method_name = "get" . ucfirst($top_name);
    $value = $title_entity->$method_name();
    $result = $value;

    // Map nested property value.
    if (!empty($value) && $value instanceof \stdClass) {
      if (count($name_chains) > 1) {
        for ($i = 1; $i <= count($name_chains) - 1; $i++) {
          $nested_name = $name_chains[$i];

          if (!empty($nested_name)) {
            if (!empty($value->$nested_name)) {
              $result = $value->$nested_name;
            }
            else {
              $result = NULL;
            }
          }
        }
      }
    }

    return $result;
  }

  /**
   * Implemented by subclasses.
   */
  public function getSupportedTypes() {
    return NULL;
  }

  /**
   * Return an array containing field level mapping.
   *
   * An item key is a name of property or nested property in the entity
   * class. Use dot notation for mapping nested property. An item value is the
   * machine name of a field defined in the target content type.
   *
   * Another way is to loop through the fields array of DracoCatalogItem. But
   * it will make mapping nested properties harder and may have to handle nested
   * properties individually.
   *
   * @return array
   *    An array of items, e.g., $fieldMap shown above.
   */
  protected function getFieldMap() {
    return NULL;
  }

}
