<?php

namespace Drupal\draco_udi_demo\Plugin\Mapper;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\draco_udi\Service\DracoContentRepositoryInterface;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class SiteEpisodeMapper.
 *
 * This is a sample Mapper implementation shows how to map data from a Draco
 * ContentTitle entity to a Node entity of Episode type. Notice that this is
 * only one way to do the mapping. it is up to the site to choose a proper
 * way to do it.
 *
 * @package Drupal\draco_udi_demo\Plugin\Mapper
 *
 * @Mapper(id = "SiteEpisodeMapper")
 */
class SiteEpisodeMapper extends SiteMapperBase {

  /**
   * SiteEpisodeMapper constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityManagerInterface $entity_manager
   *   The entity manager.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *    Entity query factory for finding existing entities with same titleId.
   * @param \Psr\Log\LoggerInterface $logger
   *   A logger instance.
   * @param DracoContentRepositoryInterface $content_repository
   *   A service for accessing Draco contents.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      EntityManagerInterface $entity_manager,
      QueryFactory $query_factory,
      LoggerInterface $logger,
      DracoContentRepositoryInterface $content_repository
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entity_manager, $query_factory, $logger, $content_repository);
  }

  /**
   * Creates an instance of the plugin.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container to pull out services used in the plugin.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   *
   * @return static
   *   Returns an instance of this plugin.
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static($configuration, $plugin_id, $plugin_definition,
      $container->get('entity.manager'),
      $container->get('entity.query'),
      $container->get('logger.factory')->get('showcase_episode'),
      $container->get('draco_udi.content.repository')
    );
  }

  /**
   * Returns Machine name of the content type.
   *
   * @return string
   *    Machine name of content type.
   */
  protected function getTargetContentType() {
    return 'showcase_episode';
  }

  /**
   * A list of source ContentTitle types.
   *
   * Site may want to map several types of titles to a specific content type.
   * In this mapper, the following two title types are mapped to
   * "showcase_episode".
   *
   * @return array
   *    A list of valid type values in source content data json objects.
   */
  public function getSupportedTypes() {
    return array('New Episode', 'Episode');
  }

  /**
   * Field-to-field mapping between ContentTitle and showcase_episode entity.
   *
   * {@inheritdoc}
   *
   * @return array
   *    mapping key/value list.
   */
  protected function getFieldMap() {
    $field_map = array(
      'titleId' => 'field_title_id',
      'titleType' => 'field_content_type',
      'name' => 'title',
      'externalStoryline' => 'body',
      'shortStoryline' => 'field_short_description',
      'ratings' => 'field_ratings',
      'participants' => 'field_participants',
      'tags' => 'field_content_tags',
      'lengthInSeconds' => 'field_length_in_seconds',
      'releaseYear' => 'field_release_year',
      'processedDatetimeUTC' => 'field_processed_datetime',
      'animationMode' => 'field_animation_mode',
      'genres' => 'field_genres',
      'keywords' => 'field_keywords',
      'seriesTitleId' => 'field_series_title_id',
      'seriesTitleName' => 'field_series_name',
      'seriesItemNumber' => 'field_series_number',
      'seasonNumber' => 'field_season_number',
      'seasonName' => 'field_season_name',
      'seasonEpisodeNumber' => 'field_episode_number',
    );

    return $field_map;
  }

  /**
   * {@inheritdoc}
   */
  public function updateExistingMappedEntity(NodeInterface $existing_entity, NodeInterface $new_entity) {
    $mapped_entity = NULL;

    if ($existing_entity->field_title_id->value == $new_entity->field_title_id->value
      && $existing_entity->field_content_type->value == $new_entity->field_content_type->value) {

      $existing_entity->body->value = $new_entity->body->value;
      $existing_entity->title->value = $new_entity->title->value;

      if (isset($new_entity->field_short_description) && isset($existing_entity->field_short_description)) {
        $existing_entity->field_short_description->value = $new_entity->field_short_description->value;
      }
      if (isset($new_entity->field_keywords) && isset($existing_entity->field_keywords)) {
        $existing_entity->field_keywords->value = $new_entity->field_keywords->value;
      }
      if (isset($new_entity->field_content_tags) && isset($existing_entity->field_content_tags)) {
        $existing_entity->field_content_tags->value = $new_entity->field_content_tags->value;
      }
      if (isset($new_entity->field_processed_datetime) && isset($existing_entity->field_processed_datetime)) {
        $existing_entity->field_processed_datetime->value = $new_entity->field_processed_datetime->value;
      }
      if (isset($new_entity->field_participants) && isset($existing_entity->field_participants)) {
        $existing_entity->field_participants->value = $new_entity->field_participants->value;
      }

      $mapped_entity = $existing_entity;
    }

    return $mapped_entity;
  }

  /**
   * Associate an episode with its parent series entity.
   *
   * @param NodeInterface $new_entity
   *   The new entity to set the parent reference on.
   */
  protected function updateReferences(NodeInterface $new_entity) {
    if ($new_entity->field_series_reference != NULL && $new_entity->field_series_reference->entity != NULL) {
      // Reference to the series exists and no need to associate again.
      // But if you want to update it, don't do this checking.
      return;
    }

    $series_title_id = $new_entity->field_series_title_id->value;
    $series = $this->loadSeriesEntity($series_title_id);

    if ($series != NULL) {
      $series_id = $series->id();

      $new_entity->set('field_series_reference', ['target_id' => $series_id]);
    }
  }

  /**
   * Search and load series entity as a node of $series_node_type type.
   *
   * Assume the node has a field field_title_id.
   *
   * @param string $series_title_id
   *   The title ID of the series.
   *
   * @return \Drupal\Core\Entity\EntityInterface|null
   *   The series entity, or NULL if one isn't found.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   *   Thrown when multiple series entries are found for the series title ID.
   *
   * @todo
   *   We should throw an exception instead of returning NULL here.
   */
  private function loadSeriesEntity($series_title_id) {
    $query = $this->entityQuery->get('node')->condition('field_title_id', $series_title_id);
    $ids = $query->execute();
    $series = NULL;

    if (count($ids) == 1) {
      $id = reset($ids);
      $series = $this->entityManager->getStorage('node')->load($id);
    }
    elseif (count($ids) > 1) {
      throw new EntityStorageException('Found more than one series entity in db with field ' . $series_title_id);
    }

    return $series;
  }

}
