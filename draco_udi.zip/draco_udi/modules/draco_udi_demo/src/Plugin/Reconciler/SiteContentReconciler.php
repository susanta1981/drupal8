<?php

namespace Drupal\draco_udi_demo\Plugin\Reconciler;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\draco_udi\Context;
use Drupal\draco_udi\Entity\ContentTitle;
use Drupal\draco_udi\Plugin\Reconciler\ContentReconcilerBase;

/**
 * Class SiteContentReconciler.
 *
 * This plugin is a sample showing the site how to use this plugin to reconcile
 * contents among several upstream sources, including titles, linear schedules,
 * and on-demand schedules. Currently we don't have business rules to implement
 * a real reconciliation plugin.
 *
 * @package Drupal\draco_udi\Plugin\Reconciler
 *
 * @ContentReconciler(id = "draco_demo_reconciler")
 */
class SiteContentReconciler extends ContentReconcilerBase implements ContainerFactoryPluginInterface {

  /**
   * Reconcile ContentTitle entities and schedules.
   *
   * This method shows how a reconciliation process works. It reconciles ratings
   * and storylines from ondemand and linear schedules with the ratings and
   * storylines and same them together in title, so that the site can easily
   * access different versions of ratings or storylines for different purposes
   * easily.
   *
   * {@inheritdoc}
   */
  public function reconcile(Context $context) {
    foreach ($this->getTitlesForReconciliation($context) as $title) {
      $this->title_changed = FALSE;
      $this->reconcileTitle($context, $title);
    }
  }

  /**
   * Reconcile the title object with schedules.
   *
   * @param \Drupal\draco_udi\Context $context
   *   The workflow context object.
   * @param \Drupal\draco_udi\Entity\ContentTitle $title
   *   The title being reconciled.
   */
  private function reconcileTitle(Context $context, ContentTitle $title) {
    // This do not do anything yet but will eventually perform some
    // reconciliation based on business rules.
    $this->reconcileStoryLines($context, $title);
    $this->reconcileRatings($context, $title);
    // Other reconciliation functions .........
  }

  /**
   * Reconcile all the storylines.
   *
   * @param \Drupal\draco_udi\Context $context
   *   The workflow context object.
   * @param \Drupal\draco_udi\Entity\ContentTitle $title
   *   The title being reconciled.
   */
  private function reconcileStoryLines(Context $context, ContentTitle $title) {

    // This is an example function. Once the business rules are defined it will
    // change. For now it initializes the $storyline variable to the current
    // value in title. This means the if statement below  will always be false
    // once the business rules are defined the line below will be uncommented
    // and the reconciled value will be in the $storylines variable.
    $storyLines = $title->getStorylines();
    // $storyLines = $this->getReconciledStoryLine($title,$linearSchedules,$ondemandSchedules);.
    if ($title->getStorylines() != $storyLines) {
      $title->setStorylines($storyLines);
      $this->addTitleToBeMapped($title, $context);
    }
  }

  /**
   * Reconcile the ratings.
   *
   * @param \Drupal\draco_udi\Context $context
   *   The workflow context object.
   * @param \Drupal\draco_udi\Entity\ContentTitle $title
   *   The title being reconciled.
   */
  private function reconcileRatings(Context $context, ContentTitle $title) {

    // This is an example function. Once the business rules are defined it will
    // change. For now it initializes the $ratings variable to the current
    // value in title. This means the if statement below  will always be false
    // once the business rules are defined the line below will be uncommented
    // and the reconciled value will be in the $ratings variable.
    $ratings = $title->getRatings();
    // $ratings = $this->getReconciledStoryLine($title,$linearSchedules,$ondemandSchedules);.
    if ($title->getRatings() != $ratings) {
      $title->setRatings($ratings);
      $this->addTitleToBeMapped($title, $context);
    }
  }

}
