<?php

namespace Drupal\draco_udi_testing\Controller;

use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\draco_udi\ContentDataImportWorkflowManager;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface;
use Drupal\draco_udi\Service\DataSource\OdtClientInterface;
use Drupal\draco_udi\Service\DataSource\Tve\TveClientInterface;
use Drupal\draco_udi\Service\DracoContentRepositoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\State\State;
use Drupal\Core\Logger\LoggerChannelFactory;
use Drupal\draco_udi\Service\DataSource\UdiChangeProcessor;

/**
 * Class UdiDemoController.
 *
 * It contains a set of methods for testing purposes.
 *
 * @package Drupal\draco_udi_testing\Controller
 */
class UdiDemoController extends ControllerBase {

  protected $flowClient;
  protected $odtClient;
  protected $tveClient;
  protected $importManager;
  protected $state;
  protected $logger;
  protected $fetchManager;
  protected $changeProcessor;
  protected $entityManager;
  protected $entityQuery;
  protected $contentRepository;

  /**
   * UdiDemoController constructor.
   *
   * @param \Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface $flow_client
   *    Flow client.
   * @param \Drupal\draco_udi\Service\DataSource\OdtClientInterface $odt_client
   *    ODT Client.
   * @param \Drupal\draco_udi\Service\DataSource\Tve\TveClientInterface $tve_client
   *    TVE Client.
   * @param \Drupal\draco_udi\ContentDataImportWorkflowManager $import_manager
   *    UDI import manager.
   * @param \Drupal\Core\State\State $state
   *    State instance.
   * @param \Drupal\Core\Logger\LoggerChannelFactory $channelFactory
   *    Logger factory.
   * @param \Drupal\draco_udi\Service\ContentFetchManager $fetch_manager
   *    Content fetch manager.
   * @param \Drupal\draco_udi\Service\DataSource\UdiChangeProcessor $change_processor
   *    Content change processor.
   * @param \Drupal\Core\Entity\EntityManagerInterface $entity_manager
   *    Drupal entity manager.
   * @param \Drupal\Core\Entity\Query\QueryFactory $entity_query
   *    Entity query factory.
   */
  public function __construct(
    FlowClientInterface $flow_client,
    OdtClientInterface $odt_client,
    TveClientInterface $tve_client,
    ContentDataImportWorkflowManager $import_manager,
    State $state,
    LoggerChannelFactory $channelFactory,
    ContentFetchManager $fetch_manager,
    UdiChangeProcessor $change_processor,
    EntityManagerInterface $entity_manager,
    QueryFactory $entity_query,
    DracoContentRepositoryInterface $content_repository
  ) {
    $this->flowClient = $flow_client;
    $this->odtClient = $odt_client;
    $this->tveClient = $tve_client;
    $this->importManager = $import_manager;
    $this->state = $state;
    $this->logger = $channelFactory->get('draco_udi');
    $this->fetchManager = $fetch_manager;
    $this->changeProcessor = $change_processor;
    $this->entityManager = $entity_manager;
    $this->entityQuery = $entity_query;
    $this->contentRepository = $content_repository;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get("draco_udi.flow.client"),
      $container->get("draco_udi.odt.http.client"),
      $container->get("draco_udi.tve.historical"),
      $container->get("draco_udi.content.import.workflow.manager"),
      $container->get("state"),
      $container->get('logger.factory'),
      $container->get('draco_udi.content.fetch.manager'),
      $container->get('draco_udi.workflow.processor'),
      $container->get('entity.manager'),
      $container->get('entity.query'),
      $container->get('draco_udi.content.repository')
    );
  }

  /**
   * Test import a TVE content in json format.
   *
   * @throws \Exception
   */
  public function testImportTveContent() {

    $udi_location = drupal_get_path('module', 'draco_udi');
    $file = "$udi_location/resources/tve/content.json";
    $contents = file_get_contents($file);

    if (!$contents) {
      return ['#markup' => "There was a problem reading file: $file"];
    }

    $tve_json = json_decode($contents);

    $items = array();

    if (!is_array($tve_json)) {
      $items[] = $tve_json;
    }
    else {
      $items = $tve_json;
    }

    foreach ($items as $i) {
      $this->importManager->import($i, 'TVE',ContentFetchManager::CONTENT_INSERT_ACTION_ACTION,ContentFetchManager::CONTENT_SOURCE_TVE);
    }

    return ['#markup' => 'Successfully imported a TVE content json.'];
  }

  /**
   * Test download historical TVE contents.
   *
   * @return array
   *   Render array.
   */
  public function testDownloadHistoricalTveContent() {
    $start = new \DateTime('2016-10-30T01:00:00Z');
    $end = new \DateTime('2016-11-01T01:00:00Z');
    $this->tveClient->postFiles($start, $end);

    return ['#markup' => 'Done with testDownloadHistoricalTveContent'];
  }

  /**
   * This method imports some titles.
   *
   * 773706, 852(feature film),
   * 610146,638935 (episode),
   * 581006,671985 (series),
   * 2083792 (special)
   *
   * @return array
   *   A list of catalog item json objects.
   */
  public function testImportTitles() {
    $titleIds = [343558];

    $items = $this->flowClient->getTitlesByTitleIds($titleIds);

    foreach ($items as $item) {
      $this->importManager->import($item, 'Title',ContentFetchManager::CONTENT_INSERT_ACTION,ContentFetchManager::CONTENT_SOURCE_FLOW);
    }

    return ['#items' => $titleIds];
  }

  /**
   * Simulate processing an ODT queue message.
   *
   * An ODT queue message has a structure as follows:
   *
   * {
   *    'AiringId' => TBSE1009281600033744,
   *    'Action' => 'Delete',
   * }
   *
   * Action codes include Delete and Modify.
   *
   * @param $airing_id
   *   Id of ODT airing object.
   * @param $action
   *   ODT action code.
   *
   * @return array
   *   Messages.
   */
  public function testPostOdtMessageIntoQueue($airing_id, $action) {
    $data = new \stdClass();
    $data->body = '"{\"AiringId\":\"' . $airing_id . '\",\"Action\":\"' . $action . '\"}"';

    $func = $this->fetchManager->processOdtQueueMsg(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);
    $func($data);

    return ['#message' => 'Dropped an ODT message with airing id ' . $airing_id . ' for ' . $action];
  }

  /**
   * This method import on ODT airing by id.
   *
   * CARE1004291600011102 has 3 flights.
   * TBSE1004221600031618 has 1 flight.
   * TBSE1004191600031573
   * RADS1006271600000833
   * TBSE1004281600000065 no type.
   *
   * @param string $id
   *   ODT airing id.
   *
   * @return array
   *    Render array.
   */
  public function testImportOnDemandScheduleById($id) {

    $airing_id = ($id) ? $id : 'TBSE1009121600000236';

    $airing_obj = $this->odtClient->getFullAiringContentById($airing_id);

    $this->importManager->import($airing_obj, 'OnDemandSchedule',ContentFetchManager::CONTENT_INSERT_ACTION,ContentFetchManager::CONTENT_SOURCE_ODT);

    return ['#message' => 'Imported on-demand schedule ' . $airing_id];
  }

  /**
   * Test import work order.
   *
   * @param string $id
   *    Id.
   * @return array
   *    Render array.
   */
  public function testImportWorkOrder($id) {

    $airing_obj = $this->odtClient->getFullAiringContentById($id);
    $this->importManager->import($airing_obj, 'OnDemandWorkOrder', "upsert", "OdtWorkOrder");

    return ['#message' => 'Imported work order ' . $id];
  }

  /**
   * Download a linear schedule object from Flow by ExternalId.
   *
   * @return array
   *    Render array.
   *
   * @throws \Exception
   */
  public function testImportLinearScheduleByExternalId() {

    $ids = ['4734161', '4733433', '10205660'];

    try {
      $airing_objects = $this->flowClient->getLinearSchedulesByExternalIds($ids);

      foreach ($airing_objects as $airing_obj) {
        $this->importManager->import($airing_obj, 'LinearSchedule',ContentFetchManager::CONTENT_INSERT_ACTION,ContentFetchManager::CONTENT_SOURCE_FLOW);
      }
    }
    catch (\Exception $ex) {
      throw $ex;
    }

    return ['#items' => $ids];
  }

  /**
   * Test get title by title id.
   *
   * @return array
   *    Render array.
   */
  public function testGetTitleContentByTitleId() {
    $title = $this->contentRepository->getContentTitleByTitleId(2031972);

    if ($title) {
      $changed = $title->getChangedTime();
      $lastUpdated = new \DateTime();
      $lastUpdated = $lastUpdated->setTimestamp($changed);
      $lastUpdated = $lastUpdated->format('Y-m-d H:i:s');

      $processed = $title->getProcessedDatetimeUTC();
      $processed = $processed->format('Y-m-d H:i:s');

      $this->logger->debug("Title's last upddated at @last and processed at @proc",
        ['@last' => $lastUpdated, '@proc' => $processed]);
    }

    return ['markup' => 'Got title '];
  }

  /**
   * Test query on linear schedule by title id.
   *
   * @return array
   *    Schedule entities.
   */
  public function testSearchLinearSchedulesByTitleId() {
    return $this->testQuerySchedulesByTitleId(2061453, 'content_linear_schedule');
  }

  /**
   * Test get on-demand schedules by title id.
   *
   * @return array
   *    Render array.
   */
  public function testSearchOnDemandSchedulesByTitleId() {
    $schedules = $this->testQuerySchedulesByTitleId(561007, 'content_on_demand_schedule');

    foreach (reset($schedules) as $schedule) {
      $flights = $schedule->getFlights();

      $this->contentRepository->sortOnDemandFlights($flights, 'StartDate');

      foreach ($flights as $flight) {
        $start = $flight->getStart();
        $end = $flight->getEnd();
      }
    }

    return ['#items' => 'testSearchOnDemandSchedulesByTitleId completed'];
  }

  /**
   * Test getMostRecentContentOnDemandScheduleByTitleId method.
   *
   * Note that a valid title id is needed for testing.
   *
   * @return array
   *    Render array.
   */
  public function testLoadMostRecentOnDemandScheduleByTitleId() {
    $title_id = 2011904; // 343558, 561007

    $schedule = $title = $this->contentRepository->getMostRecentContentOnDemandScheduleByTitleId($title_id);

    $flights = $schedule->getFlights();

    $this->contentRepository->sortOnDemandFlights($flights, 'StartDate');

    foreach ($flights as $flight) {
      $start = $flight->getStart();
      $end = $flight->getEnd();
    }

    return ['#items' => 'testLoadMostRecentOnDemandScheduleByTitleId completed.'];
  }

  /**
   * Test query schedule by title id and associate schedule entity with title.
   *
   * @param int $title_id
   *    Title id.
   * @param string $schedule_type
   *    Linear or on-demand.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   *
   * @return array
   *    Render array.
   */
  private function testQuerySchedulesByTitleId($title_id, $schedule_type) {
    $schedules = array();
    $title = $this->contentRepository->getContentTitleByTitleId($title_id);

    if ($schedule_type === 'content_on_demand_schedule') {
      $schedules = $this->contentRepository->getContentOnDemandSchedulesByTitleId($title_id);
    }
    elseif ($schedule_type === 'content_linear_schedule') {
      $schedules = $this->contentRepository->getContentLinearSchedulesByTitleId($title_id);
    }

    foreach ($schedules as $schedule) {
      $changed = $schedule->get('changed')->value;
      $lastUpdated = new \DateTime();
      $lastUpdated = $lastUpdated->setTimestamp($changed);
      $lastUpdated = $lastUpdated->format('Y-m-d H:i:s');

      $this->logger->debug('get schedule with last updated time = @lu' , ['@lu' => $lastUpdated]);

      $name = $schedule->get('label')->value;
      $schedule->set('label', $name . ' updated');
      $schedule->save();
    }

    // Associate schedule entity with title entity.
    if ($title) {
      foreach ($schedules as $schedule) {
        $schedule->addAssociatedTitle($title->id());
        $schedule->save();
      }
    }

    return ['#items' => $schedules];
  }

  /**
   * This method deletes the flow last changed key.
   *
   * @return array
   *   A list of catalog item json objects.
   */
  public function clearFlowStateKey() {

    $this->state->delete(ContentFetchManager::TITLES_LAST_UPDATED_KEY);
    $this->logger->debug("Flow State key has been deleted");
    return ['status' => 0];
  }

  /**
   * Test remove a linear schedule entity based on deleted-since messages.
   */
  public function testRemoveLinearSchedulesBasedOnMessages() {
    $message = new \stdClass();
    $message->id = '581cf0ff18bcda1208ea8254';
    $message->ExternalId = 10547836;
    $message->ProcessedDatetimeUTC = '2016-11-04T20:35:11.104Z';

    $this->importManager->remove($message, ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE, ContentFetchManager::CONTENT_SOURCE_FLOW);

    return ['#markup' => 'Compete testRemoveLinearSchedulesBasedOnMessages'];
  }

  /**
   * Test remove a on-demand schedule entity.
   *
   * Sample ODT delete message:
   * {
   *   "messageTimestamp": 1481060949,
   *   "type": "OnDemandSchedule",
   *   "source": "ODT",
   *   "attributes": { "fetchTimestamp": 1481060949 },
   *   "action": "delete",
   *   "data": {"AiringId":"123456","Action":"Delete"}
   * }
   */
  public function testRemoveOnDemandSchedule() {
    $message = new \stdClass();
    $message->action = 'delete';
    $message->type = 'OnDemandSchedule';

    $data = new \stdClass();
    $data->AiringId = 'TBSE1011291600034232';
    $data->Action = 'Delete';
    $message->data = $data;

    $this->importManager->remove($message, ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE, ContentFetchManager::CONTENT_SOURCE_ODT);

    return ['#markup' => 'Completed testRemoveOnDemandSchedule'];
  }

  /**
   * Test remove a on-demand work order entity.
   *
   * Sample ODT delete message:
   * {
   *   "messageTimestamp": 1481060949,
   *   "type": "OnDemandWorkOrder",
   *   "source": "ODT",
   *   "attributes": { "fetchTimestamp": 1481060949 },
   *   "action": "delete",
   *   "data": {"AiringId":"123456","Action":"Delete"}
   * }
   */
  public function testRemoveOnDemandWorkOrder() {
    $message = new \stdClass();
    $message->action = 'delete';
    $message->type = 'OnDemandWorkOrder';

    $data = new \stdClass();
    $data->AiringId = 'TBSE1011111600034216';
    $data->Action = 'Delete';
    $message->data = $data;

    $this->importManager->remove($message, ContentFetchManager::CONTENT_ONDEMAND_WORKORDER_TYPE, ContentFetchManager::CONTENT_SOURCE_ODT);

    return ['#markup' => 'Completed testRemoveOnDemandWorkOrder'];
  }

  /**
   * Test how to post a clip airing data to ODT and register it.
   *
   * The sample data defined in getOdtAiringData() and getOdtRegisterData()
   * methods can be used to create actual data to post to ODT.
   *
   * @return array
   *    Render array containing status messages.
   */
  public function testPostAiringToOdt() {
    $airing = $this->getOdtAiringData();
    $retry = 0;

    $response = $this->odtClient->postAiring($airing);
    $msg = $response->message;

    if ($this->needRetry($response->statusCode) || empty($response->mediaId)) {
      // Retry up to 5 times.
      while ($response->statusCode != 200 && $retry < 5) {
        $response = $this->odtClient->postAiring($airing);
        $retry++;
      }

      if ($response->statusCode != 200) {
        $msg .= ' Bosting airing failed after ' . $retry . ' retries: ' . $response->message;
      }
      else {
        $msg .= ' Bosting airing successful';
      }
    }
    else {
      $media_id = $response->mediaId;
      $airing_id = $response->airingId;
      $msg .= ' New airing airingId: ' . $airing_id . ';  mediaId: ' . $media_id;

      $register_data = $this->getOdtRegisterData($media_id);
      $response = $this->odtClient->postFiles($register_data, $airing);

      if ($this->needRetry($response->statusCode)) {
        $retry = 0;

        // Retry up to 5 times.
        while ($this->needRetry($response->statusCode) && $retry < 5) {
          $response = $this->odtClient->postFiles($register_data, $airing);
          $retry++;
        }

        if ($this->needRetry($response->statusCode)) {
          $msg .= ' But register media file failed after ' . $retry . ' retries. Message: ' . $response->message;
        }
        else {
          $msg .= '. The new airing is registered at ODT.';
        }
      }
      elseif ($response->statusCode == 200) {
        $msg .= '. The new airing is registered at ODT.';
      }
      else {
        $msg .= '. Failed to register clip airing ' . $airing_id;
      }
    }

    return ['#markup' => $msg];
  }

  /**
   * Choose several http codes as examples to decide if a retry is needed.
   * Site should decide if it wants a retry based on a list of error codes.
   *
   * 500: Internal Server Error
   * 503: Service Unavailable - may be temporary
   * 504: Gateway Timeout
   *
   * @param $status_code
   *
   * @return bool
   */
  private function needRetry($status_code) {
    return ($status_code == 400 || $status_code == 500 || $status_code == 503 || $status_code == 504)? TRUE : FALSE;
  }

  /**
   * Returns sample data for registering a posted airing with new media id.
   *
   * See inline comments what should be set from content values. Other values
   * are hard coded.
   *
   * @param string $media_id
   *    String of encoded array with media id returned from ODT.
   *
   * @return string
   *    String of encoded array.
   */
  private function getOdtRegisterData($media_id) {
    $register_data = new \stdClass();
    $register_data->video = TRUE;
    $register_data->mediaId = $media_id;

    $contents = [];
    $content = new \stdClass();
    // Content id same as sent to ODT.
    $content->name = "1333425";

    $media = [];
    $media_item = new \stdClass();
    $media_item->type = "clip";
    // Same as in the posted airing.
    $media_item->totalDuration = 120;

    $content_segments = [];
    $content_segment = new \stdClass();
    $content_segment->segmentIdx = 0;
    $content_segment->start = 0;
    // Same as totalDuration above.
    $content_segment->duration = 120;
    $content_segments[] = $content_segment;
    $media_item->contentSegments = $content_segments;

    $playlist = [];
    $playlist_item = new \stdClass();
    $playlist_item->name = "master_all";
    // This is the file extension for the HLS path.
    $playlist_item->type = "m3u8";

    $properties = new \stdClass();
    $properties->drmUnprotected = "true";
    $playlist_item->properties = $properties;

    $urls = [];
    $url = new \stdClass();

    // The 3 fields should come from the HLS asset path.
    $akamai_url = new \stdClass();
    $akamai_url->host = "tnt-vh.akamaihd.net";
    $akamai_url->path = "/i/Episode-Clips/2016/05/AK_NCM_2min_R_June1498c_511546_,416x240_400,640x360_800,640x360_1400,848x480_1700,960x540_2500,1280x720_3500,.mp4.csmil/";
    $akamai_url->fileName = "master.m3u8";

    $url->akamaiURL = $akamai_url;
    $urls[] = $url;
    $playlist_item->urls = $urls;

    $playlist[] = $playlist_item;
    $media_item->playlists = $playlist;

    $media[] = $media_item;
    $content->media = $media;
    $contents[] = $content;
    $register_data->contents = $contents;

    return json_encode([$register_data]);
  }

  /**
   * Return a working sample airing data.
   *
   * You can use the data in this method as sample to create an airing data
   * for posting.
   *
   * @return string
   *    String of airing object.
   */
  private function getOdtAiringData() {
    $airing = new \stdClass();
    $airing->Name = 'Animal Kingdom - NCM Trailer';
    $airing->Brand = 'TNT';

    $flags = new \stdClass();
    $flags->Hd = "true";
    $airing->Flags = $flags;

    $versions = [];
    $version = new \stdClass();
    $version->ContentId = "1333425";
    $versions[] = $version;
    $airing->Versions = $versions;

    $flights = [];
    $flight = new \stdClass();
    $flight->Start = '07/26/2016';
    $flight->End = '01/01/2040';
    $destinations = [];
    $destination = new \stdClass();
    $destination->Id = 42;
    $destination->Name = 'TNTW';
    $destinations[] = $destination;
    $flight->Destinations = $destinations;
    $flights[] = $flight;
    $airing->Flights = $flights;

    $airing->Platform = 'Broadband';
    $airing->ReleasedBy = 'cmasystem';

    $duration = new \stdClass();
    $duration->LengthInSeconds = 120;
    $airing->Duration = $duration;

    return json_encode($airing);
  }

}