# Draco Upstream Data Integration

[![Build Status](http://jenkins.draco.services.dmtio.net/buildStatus/icon?job=Draco%20UDI%20Master%20Tests)](http://jenkins.draco.services.dmtio.net/job/Draco%20UDI%20Master%20Tests/)

## Installation ##

Draco UDI depends on Draco Logging.  Verify that the Draco repo
is in your root composer.json:
```
"repositories": {
        "draco": {
            "type": "composer",
            "url": "satis.draco.services.dmtio.net"
        }
```

There are two ways to get the logging dependency.

1.  Use the Merge plugin.  Make sure your root composer.json contains
the following:

```
"require": {
        "wikimedia/composer-merge-plugin": "~1.3"
```
```
"extra": {
       "merge-plugin": {
            "include": [
                "core/composer.json",
                "[PATH TO]/draco_udi/composer.json"
```

2.  Or, add the dependency to your root composer.json

```
"require": {
        "turnercode/draco_logging" : "*"
```

Then run composer update.

## Views integration

Draco UDI defines three views to manage ingested entities, which are located
at `admin/structure/udi/content_title` or Admin > Structure > Draco content entities.

If a brand needs to tweak any of these views, the recommended procedure is to:

1. Clone the View.
2. Make the required changes and then save it.
3. Deactivate the original view through the Operations column at `admin/structure/views`. 
4. Add the cloned view to a module within the repository at its `config/install`
   directory. If the module is new, simply installing it will create the view
   in the site. If the module has been installed already, refer to draco_udi.install
   for how to write a database update to create the view.

## Example UDI Configuration and Mapper

The `draco_udi_demo` module contains example configuration and content types
showing how to import and map data into your own content model. The
configuration does not contain access keys for various upstream services; see
the Draco team for details on those. This module is *not for use on production
sites* and *will not contain update hooks*. Enable it on locals for learning
how UDI works, or as a base for functional tests, but leave it off anywhere
else.

Each developer needs their *own SQS queue* and *ODT queue* for local
development. Ask your project manager or the Draco team if you need help
setting them up. The settings exported by the demo module are suitable for
most developer testing. To override specific settings on your local so they are
preserved after a site install, use
[settings.php](https://www.drupal.org/docs/8/api/configuration-api/configuration-override-system).
This is especially useful for API keys and credentials.

```
<?php

$config['draco_udi.settings']['odt_settings']['odt_auth_key'] = 'MY-AUTH_KEY';
```

See the
[installed settings](modules/draco_udi_demo/config/install/draco_udi.settings.yml)
file for more settings you can override on locals or on production environments.

Help and Support
----------------

If you've got this far and still need help, here are some links to our UDI documentation on Confluence:

* [Upstream Data Integration module Confluence page](http://docs.turner.com/display/SASDCMS/Upstream+Data+Integration+Module)
* [Upstream Data Integration module User Guide](http://docs.turner.com/display/SASDCMS/Upstream+Data+Integration+Module+User+Guide)
* [Upstream Data Integraion module Docs for Dev team](http://docs.turner.com/display/SASDCMS/Upstream+Data+Integration+Docs+for+Draco+Team+Members)

If you need to contact the Draco team, please use
our JIRA project to send us bug reports, feature suggestions, and support
requests. This way, everyone involved gets a single place to keep track of
discussions, and it's easy to keep project managers up-to-date.

1. First,
   [search JIRA](http://tickets.turner.com/issues/?jql=project%20%3D%20DRACO%20AND%20component%20%3D%20%22Site%20Support%22)
   to see if someone else has asked the same question before. Be sure to
   comment on open questions that affect you so the Draco team knows who is
   interested in the answer.
1. If nothing already matches what you want to report, create a ticket at
   [tickets.turner.com](http://tickets.turner.com/) under the `Drupal
   Application Core (DRACO)` project.
1. Set the issue type to `User story`.
1. Set the component to `Site support`.
1. Fill in a summary of your request along with a description. Here's an example:

![Example support issue](docs/example-support.png)
