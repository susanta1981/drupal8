<?php

namespace Drupal\Tests\draco_udi\Unit\Plugin\Filter;

use Drupal\draco_udi\Plugin\Filter\TitleFilter;
use Drupal\Tests\UnitTestCase;

/**
 * Class TveContentFilterTest.
 *
 * @package Drupal\draco_udi\Tests\Unit\Plugin\Filter
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Plugin\Filter\TitleFilter
 */
class TitleFilterTest extends UnitTestCase {


  private $entity_manager;
  private $query_factory;
  private $logger;
  private $queryInterface;
  private $entityStorage;

  const TITLE_NON_EPISODE = '
  {
	"TitleId": 559485,
	"TitleName": "The Zodiac Killer",
	"TitleNameSortable": "Zodiac Killer, The",
	"LengthInSeconds": 5220,
	"TitleType": {
		"Name": "Feature Film",
		"TitleTypeId": 1,
		"TitleTypeCode": "FF"
	},
	"ProcessedDatetimeUTC": "2016-07-13T06:02:10.360Z",
	"Genres": [],
	"KeyGenres": [],
	"Keywords": [],
	"Tags": [],
	"TcmStoryline": "San Francisco police try to track down a vicious serial killer.\t",
	"TcmLength": "5220",
	"TcmGenre1": "Horror\/Science-Fiction",
	"TcmStars": "Hal Reed, Bob Jones, Ray Lynch.   ",
	"TcmDirectors": "Tom Hanson.",
	"TcmIsColor": "Yes"
}';

  const TITLE_EPISODE = '
  {
	"TitleId": 2031689,
	"TitleName": "Cell on the Verge Of Defeat! Krillin, Destroy Android 18!",
	"TitleNameSortable": "Cell on the Verge Of Defeat! Krillin, Destroy Android 18!",
	"TitleType": {
		"Name": "Episode",
		"TitleTypeId": 6,
		"TitleTypeCode": "EA"
	},
	"SeriesTitleId": 2031611,
	"SeriesTitleName": "Dragon Ball Z Kai",
	"SeriesTitleNameSortable": "Dragon Ball Z Kai",
	"SeasonNumber": 1,
	"SeasonName": "Season 1",
	"SeriesItemNumber": "78"
}';

  const TITLE_SERIES = '
  {
	"TitleId": 2031689,
	"TitleName": "Cell on the Verge Of Defeat! Krillin, Destroy Android 18!",
	"TitleNameSortable": "Cell on the Verge Of Defeat! Krillin, Destroy Android 18!",
	"TitleType": {
		"Name": "Episode",
		"TitleTypeId": 6,
		"TitleTypeCode": "EA"
	},
	"SeriesTitleId": 2031611,
	"SeriesTitleName": "Dragon Ball Z Kai",
	"SeriesTitleNameSortable": "Dragon Ball Z Kai",
	"SeasonNumber": 1,
	"SeasonName": "Season 1",
	"SeriesItemNumber": "78"
}';

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    parent::setUp();
    $this->entity_manager = $this->getMockBuilder('Drupal\Core\Entity\EntityManager')
      ->disableOriginalConstructor()
      ->getMock();
    $this->query_factory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->queryInterface = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->queryInterface->expects($this->any())->method('condition')->willReturn($this->queryInterface);

    $this->query_factory->expects($this->any())->method('get')->willReturn($this->queryInterface);
    $this->logger = $this->getMockBuilder('Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entityStorage = $this->getMockBuilder('Drupal\Core\Entity\EntityStorageInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entity_manager->expects($this->any())->method('getStorage')->willReturn($this->entityStorage);

  }

  /**
   * Tests  Filtering Non Episode which is in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeInWhiteList
   */
  public function testNonEpisodeInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new TitleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is not in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeNotInWhiteList
   */
  public function testNonEpisodeNotInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new TitleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /**
   * Tests  Filtering Non Episode for which there is no whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeNoWhiteList
   */
  public function testNonEpisodeNoWhitelist($content) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn([]);
    $titleFilter = new TitleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider episodeInWhiteList
   */
  public function testEpisodeInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new TitleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is not in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider episodeNotInWhiteList
   */
  public function testEpisodeNotInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new TitleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /**
   * Tests  Filtering Series  which is in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider seriesInWhiteList
   */
  public function testSeriesInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new TitleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Series which is not in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider seriesNotInWhiteList
   */
  public function testSeriesNotInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new TitleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /*   DATA PROVIDERS   */

  /**
   *
   */
  public function nonEpisodeInWhiteList() {
    $content = json_decode(self::TITLE_NON_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '559485');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhitelist')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function nonEpisodeNotInWhiteList() {
    $content = json_decode(self::TITLE_NON_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValues = array($whitelistValue1);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhitelist')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function nonEpisodeNoWhiteList() {
    $content = json_decode(self::TITLE_NON_EPISODE);

    return array(
      array($content),
    );
  }

  /**
   *
   */
  public function episodeInWhiteList() {
    $content = json_decode(self::TITLE_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '2031611');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhitelist')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function episodeNotInWhiteList() {
    $content = json_decode(self::TITLE_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '2031689');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhitelist')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function seriesInWhiteList() {
    $content = json_decode(self::TITLE_SERIES);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '2031611');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhitelist')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function seriesNotInWhiteList() {
    $content = json_decode(self::TITLE_SERIES);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '2031689');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhitelist')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

}
