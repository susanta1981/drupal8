<?php


namespace Drupal\Tests\draco_udi\Unit\Plugin\Filter;

use Drupal\draco_udi\Plugin\Filter\TveContentFilter;
use Drupal\Tests\UnitTestCase;

/**
 * Class TveContentFilterTest.
 *
 * @package Drupal\draco_udi\Tests\Unit\Plugin\Filter
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Plugin\Filter\TveContentFilter
 */
class TveContentFilterTest extends UnitTestCase {


  private $entity_manager;
  private $query_factory;
  private $logger;
  private $queryInterface;
  private $entityStorage;
  private $flowClient;

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    parent::setUp();
    $this->entity_manager = $this->getMockBuilder('Drupal\Core\Entity\EntityManager')
      ->disableOriginalConstructor()
      ->getMock();
    $this->query_factory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->queryInterface = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->queryInterface->expects($this->any())->method('condition')->willReturn($this->queryInterface);

    $this->query_factory->expects($this->any())->method('get')->willReturn($this->queryInterface);
    $this->logger = $this->getMockBuilder('Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entityStorage = $this->getMockBuilder('Drupal\Core\Entity\EntityStorageInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entity_manager->expects($this->any())->method('getStorage')->willReturn($this->entityStorage);

    $this->flowClient = $this->getMockBuilder('Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface')
      ->disableOriginalConstructor()
      ->getMock();

  }

  /**
   * Tests  isApproved method.
   *
   * @covers ::isApprovedContent
   * @covers ::isTveItem
   * @covers ::getTitleForTve
   *
   * @dataProvider tveInWhiteList
   */
  public function testIsApprovedWithTveDataInWhitelist($content, $whitelist_ids, $whitelist, $titles) {
    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $this->flowClient->expects($this->any())->method('getTitlesByTitleIds')->willReturn($titles);

    $tveContentFilter = new TveContentFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger, $this->flowClient);
    $isApproved = $tveContentFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  isApproved method.
   *
   * @covers ::isApprovedContent
   * @covers ::isTveItem
   * @covers ::getTitleForTve
   *
   * @dataProvider tveNotInWhiteList
   */
  public function testIsApprovedWithTveDataNotInWhitelist($content, $whitelist_ids, $whitelist, $titles) {
    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $this->flowClient->expects($this->any())->method('getTitlesByTitleIds')->willReturn($titles);

    $tveContentFilter = new TveContentFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger, $this->flowClient);
    $isApproved = $tveContentFilter->isApprovedContent($content);
    // TVE post no longer depends on whitelist filter.
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  isApproved method.
   *
   * @covers ::isApprovedContent
   * @covers ::isTveItem
   * @covers ::getTitleForTve
   *
   * @dataProvider notTveData
   */
  public function testisApprovedWithNonTveDta($content) {
    $tveContentFilter = new TveContentFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger, $this->flowClient);
    $isApproved = $tveContentFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /**
   *
   */
  public function tveInWhiteList() {
    $content = json_decode($this->tveItem);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '725092');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];
    $titles = json_decode($this->titles);
    return array(
          array($content, $whitelistIds, $whiteList, $titles),
    );
  }

  /**
   *
   */
  public function tveNotInWhiteList() {
    $content = json_decode($this->tveItem);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValues = array($whitelistValue1);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];
    $titles = json_decode($this->titles);
    return array(
          array($content, $whitelistIds, $whiteList, $titles),
    );
  }

  /**
   *
   */
  public function notTveData() {

    $content = json_decode($this->sbotTveData);
    return array(
      array($content),
    );
  }

  private $sbotTveData = '{
	"ArrayOfSuperBlockOfTime": {
		"SuperBlockOfTime": {
			"p2:type": "BroadbandBlockOfTime",
			"xmlns:p2": "http://www.w3.org/2001/XMLSchema-instance",
			"AssociatedBlockOfTimes": {
				"SuperBlockOfTime": [{
					"p2:type": "BroadbandBlockOfTime",
					"AssociatedBlockOfTimes": {},
					"BlockOfTimeMasterId": "3016130",
					"Comments": {
						"p2:nil": "true"
					},
					"CreatedBy": "Jjjackson",
					"CreatedDate": "6/23/2016 2:13:56 PM",
					"EndDate": "2016-08-21T05:59:59",
					"Feed": {
						"Id": "200",
						"Name": "AS.com Auth, AdultSwim",
						"Destinations": {
							"DestinationType": {
								"Name": "CMA"
							}
						}
					},
					"FlightDuration": "49",
					"Id": "3016131",
					"IsMaster": "false",
					"ModifiedBy": "Jjjackson",
					"ModifiedDate": "4/25/2016 4:51:27 PM",
					"Name": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
					"Network": "AdultSwim",
					"PostcloseScheduleItems": {},
					"PreopenScheduleItems": {},
					"ScheduleItems": {
						"ScheduleItemType": {
							"p2:type": "TitleScheduleItem",
							"BlockOfTimeId": "0",
							"Id": "6117612",
							"ItemId": "2083925",
							"MediaLength": "1275",
							"MediaName": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
							"OrderNumber": "1",
							"Version": {
								"Breaks": {
									"BreakType": {
										"BreakNumber": "1",
										"TimeCodeIn": "23588",
										"TimeCodeOut": "23678",
										"Length": "90"
									}
								},
								"ContentID": "2TG04",
								"DisplayMinutes": "30",
								"FormatAspectRatio": "0",
								"ID": "1508694",
								"IsClosedCaptioned": "true",
								"IsOrderVersion": "False",
								"MediaLength": "1275",
								"OrionVersionID": "680246",
								"ScheduleItemID": "0",
								"ScreenFormat": "0",
								"Segments": {
									"SegmentType": [{
										"MaterialID": "2TG04/01",
										"SegmentNumber": "1",
										"TimeCodeIn": "90",
										"TimeCodeOut": "23588",
										"Length": "23498",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "90",
										"SegmentCreditTimeCodeOut": "1646",
										"CreditTypeName": "Start"
									}, {
										"MaterialID": "2TG04/02",
										"SegmentNumber": "2",
										"TimeCodeIn": "23678",
										"TimeCodeOut": "38391",
										"Length": "14713",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "38288",
										"SegmentCreditTimeCodeOut": "38391",
										"CreditTypeName": "End"
									}]
								}
							},
							"Title": {
								"Actors": {},
								"ClipBlurb": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Descriptors": "L",
								"Directors": {},
								"Distributor": "FUNimation Productions",
								"ElementNumber": {},
								"EpisodeNumber": "346",
								"FranchiseId": "331646",
								"FriendlySeasonItemNumber": {},
								"IsActive": "False",
								"Keywords": "One Piece, CTN, Action",
								"LastAirDates": {
									"dateTime": "2016-05-15T02:30:00"
								},
								"LinearAiringDate": "2016-05-14T02:30:00",
								"LinearAiringId": "7946845",
								"LinearPremierDate": "2016-05-15T02:30:00",
								"Name": "The Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!",
								"Producers": {},
								"ReleaseYear": "2016",
								"SeasonNumber": "6",
								"SeriesId": "608007",
								"SeriesName": "One Piece",
								"Storyline": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Studio": {},
								"StudioName": {},
								"TVRatingCode": "TV-PG-L",
								"ExternalSeriesId": {},
								"ExternalEpisodeId": {},
								"ExternalTMSEpisodeId": "EP022740690010",
								"TitleId": "2083925",
								"TitleType": "Episode (Animated)",
								"Writers": {}
							}
						}
					},
					"StartDate": "2016-07-03T06:00:00",
					"State": "Released",
					"UniqueId": "8f5c4feb-692a-4508-ae13-0a119000b305",
					"DeviceExclusions": {},
					"WebFlags": {},
					"Elements": {
						"Element": [{
							"id": "2TG04/01",
							"Type": "MaterialID"
						}, {
							"id": "BLACK",
							"Type": "Trigger"
						}, {
							"id": "2TG04/02",
							"Type": "MaterialID"
						}]
					},
					"IsNonExpiring": "false",
					"Package": {
						"AssetId": "ASOE1004251600065731",
						"BlockOfTimeId": "0",
						"Categories": {},
						"Filename": "One Piece 346",
						"Genres": {
							"GenreType": {
								"Id": "1743561",
								"Name": "Action",
								"SubGenres": {}
							}
						},
						"GuideCategories": {},
						"Id": "2689105",
						"PackageName": "One Piece 346",
						"ProductCodes": {},
						"ProgramTypes": {},
						"ProviderContentTiers": {},
						"TitleBrief": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
						"TitleDigital": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The"
					},
					"FastForwardAllowed": "false",
					"ProgrammerBrandingReq": "false",
					"PgmBucket": "5",
					"C3Indicator": "None"
				}, {
					"p2:type": "BroadbandBlockOfTime",
					"AssociatedBlockOfTimes": {},
					"BlockOfTimeMasterId": "3016130",
					"Comments": {
						"p2:nil": "true"
					},
					"CreatedBy": "Jjjackson",
					"CreatedDate": "6/23/2016 2:13:56 PM",
					"EndDate": "2016-08-21T05:59:59",
					"Feed": {
						"Id": "259",
						"Name": "Xfinity Auth, AdultSwim",
						"Destinations": {
							"DestinationType": {
								"Name": "CIM"
							}
						}
					},
					"FlightDuration": "49",
					"Id": "3016132",
					"IsMaster": "false",
					"ModifiedBy": "Jjjackson",
					"ModifiedDate": "4/25/2016 4:51:27 PM",
					"Name": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
					"Network": "AdultSwim",
					"PostcloseScheduleItems": {},
					"PreopenScheduleItems": {},
					"ScheduleItems": {
						"ScheduleItemType": {
							"p2:type": "TitleScheduleItem",
							"BlockOfTimeId": "0",
							"Id": "6117612",
							"ItemId": "2083925",
							"MediaLength": "1275",
							"MediaName": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
							"OrderNumber": "1",
							"Version": {
								"Breaks": {
									"BreakType": {
										"BreakNumber": "1",
										"TimeCodeIn": "23588",
										"TimeCodeOut": "23678",
										"Length": "90"
									}
								},
								"ContentID": "2TG04",
								"DisplayMinutes": "30",
								"FormatAspectRatio": "0",
								"ID": "1508694",
								"IsClosedCaptioned": "true",
								"IsOrderVersion": "False",
								"MediaLength": "1275",
								"OrionVersionID": "680246",
								"ScheduleItemID": "0",
								"ScreenFormat": "0",
								"Segments": {
									"SegmentType": [{
										"MaterialID": "2TG04/01",
										"SegmentNumber": "1",
										"TimeCodeIn": "90",
										"TimeCodeOut": "23588",
										"Length": "23498",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "90",
										"SegmentCreditTimeCodeOut": "1646",
										"CreditTypeName": "Start"
									}, {
										"MaterialID": "2TG04/02",
										"SegmentNumber": "2",
										"TimeCodeIn": "23678",
										"TimeCodeOut": "38391",
										"Length": "14713",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "38288",
										"SegmentCreditTimeCodeOut": "38391",
										"CreditTypeName": "End"
									}]
								}
							},
							"Title": {
								"Actors": {},
								"ClipBlurb": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Descriptors": "L",
								"Directors": {},
								"Distributor": "FUNimation Productions",
								"ElementNumber": {},
								"EpisodeNumber": "346",
								"FranchiseId": "331646",
								"FriendlySeasonItemNumber": {},
								"IsActive": "False",
								"Keywords": "One Piece, CTN, Action",
								"LastAirDates": {
									"dateTime": "2016-05-15T02:30:00"
								},
								"LinearAiringDate": "2016-05-14T02:30:00",
								"LinearAiringId": "7946845",
								"LinearPremierDate": "2016-05-15T02:30:00",
								"Name": "The Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!",
								"Producers": {},
								"ReleaseYear": "2016",
								"SeasonNumber": "6",
								"SeriesId": "608007",
								"SeriesName": "One Piece",
								"Storyline": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Studio": {},
								"StudioName": {},
								"TVRatingCode": "TV-PG-L",
								"ExternalSeriesId": {},
								"ExternalEpisodeId": {},
								"ExternalTMSEpisodeId": "EP022740690010",
								"TitleId": "2083925",
								"TitleType": "Episode (Animated)",
								"Writers": {}
							}
						}
					},
					"StartDate": "2016-07-03T06:00:00",
					"State": "Released",
					"UniqueId": "fb5d1ff0-49e9-4766-8ecb-e9e2bf9e23c6",
					"DeviceExclusions": {},
					"WebFlags": {},
					"Elements": {
						"Element": [{
							"id": "2TG04/01",
							"Type": "MaterialID"
						}, {
							"id": "BLACK",
							"Type": "Trigger"
						}, {
							"id": "2TG04/02",
							"Type": "MaterialID"
						}]
					},
					"IsNonExpiring": "false",
					"Package": {
						"AssetId": "ASOE1004251600065731",
						"BlockOfTimeId": "0",
						"Categories": {},
						"Filename": "One Piece 346",
						"Genres": {
							"GenreType": {
								"Id": "1743562",
								"Name": "Action",
								"SubGenres": {}
							}
						},
						"GuideCategories": {},
						"Id": "2689106",
						"PackageName": "One Piece 346",
						"ProductCodes": {},
						"ProgramTypes": {},
						"ProviderContentTiers": {},
						"TitleBrief": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
						"TitleDigital": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The"
					},
					"FastForwardAllowed": "false",
					"ProgrammerBrandingReq": "false",
					"PgmBucket": "5",
					"C3Indicator": "None"
				}, {
					"p2:type": "BroadbandBlockOfTime",
					"AssociatedBlockOfTimes": {},
					"BlockOfTimeMasterId": "3016130",
					"Comments": {
						"p2:nil": "true"
					},
					"CreatedBy": "Jjjackson",
					"CreatedDate": "6/23/2016 2:13:56 PM",
					"EndDate": "2016-08-21T05:59:59",
					"Feed": {
						"Id": "289",
						"Name": "External Auth, AdultSwim",
						"Destinations": {
							"DestinationType": [{
								"Name": "DISHB"
							}, {
								"Name": "ATTB"
							}]
						}
					},
					"FlightDuration": "49",
					"Id": "3016133",
					"IsMaster": "false",
					"ModifiedBy": "Jjjackson",
					"ModifiedDate": "4/25/2016 4:51:27 PM",
					"Name": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
					"Network": "AdultSwim",
					"PostcloseScheduleItems": {},
					"PreopenScheduleItems": {},
					"ScheduleItems": {
						"ScheduleItemType": {
							"p2:type": "TitleScheduleItem",
							"BlockOfTimeId": "0",
							"Id": "6117612",
							"ItemId": "2083925",
							"MediaLength": "1275",
							"MediaName": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
							"OrderNumber": "1",
							"Version": {
								"Breaks": {
									"BreakType": {
										"BreakNumber": "1",
										"TimeCodeIn": "23588",
										"TimeCodeOut": "23678",
										"Length": "90"
									}
								},
								"ContentID": "2TG04",
								"DisplayMinutes": "30",
								"FormatAspectRatio": "0",
								"ID": "1508694",
								"IsClosedCaptioned": "true",
								"IsOrderVersion": "False",
								"MediaLength": "1275",
								"OrionVersionID": "680246",
								"ScheduleItemID": "0",
								"ScreenFormat": "0",
								"Segments": {
									"SegmentType": [{
										"MaterialID": "2TG04/01",
										"SegmentNumber": "1",
										"TimeCodeIn": "90",
										"TimeCodeOut": "23588",
										"Length": "23498",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "90",
										"SegmentCreditTimeCodeOut": "1646",
										"CreditTypeName": "Start"
									}, {
										"MaterialID": "2TG04/02",
										"SegmentNumber": "2",
										"TimeCodeIn": "23678",
										"TimeCodeOut": "38391",
										"Length": "14713",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "38288",
										"SegmentCreditTimeCodeOut": "38391",
										"CreditTypeName": "End"
									}]
								}
							},
							"Title": {
								"Actors": {},
								"ClipBlurb": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Descriptors": "L",
								"Directors": {},
								"Distributor": "FUNimation Productions",
								"ElementNumber": {},
								"EpisodeNumber": "346",
								"FranchiseId": "331646",
								"FriendlySeasonItemNumber": {},
								"IsActive": "False",
								"Keywords": "One Piece, CTN, Action",
								"LastAirDates": {
									"dateTime": "2016-05-15T02:30:00"
								},
								"LinearAiringDate": "2016-05-14T02:30:00",
								"LinearAiringId": "7946845",
								"LinearPremierDate": "2016-05-15T02:30:00",
								"Name": "The Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!",
								"Producers": {},
								"ReleaseYear": "2016",
								"SeasonNumber": "6",
								"SeriesId": "608007",
								"SeriesName": "One Piece",
								"Storyline": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Studio": {},
								"StudioName": {},
								"TVRatingCode": "TV-PG-L",
								"ExternalSeriesId": {},
								"ExternalEpisodeId": {},
								"ExternalTMSEpisodeId": "EP022740690010",
								"TitleId": "2083925",
								"TitleType": "Episode (Animated)",
								"Writers": {}
							}
						}
					},
					"StartDate": "2016-07-03T06:00:00",
					"State": "Released",
					"UniqueId": "e7bbc3e7-58cd-494d-b869-501472bb0c67",
					"DeviceExclusions": {},
					"WebFlags": {},
					"Elements": {
						"Element": [{
							"id": "2TG04/01",
							"Type": "MaterialID"
						}, {
							"id": "BLACK",
							"Type": "Trigger"
						}, {
							"id": "2TG04/02",
							"Type": "MaterialID"
						}]
					},
					"IsNonExpiring": "false",
					"Package": {
						"AssetId": "ASOE1004251600065731",
						"BlockOfTimeId": "0",
						"Categories": {},
						"Filename": "One Piece 346",
						"Genres": {
							"GenreType": {
								"Id": "1743563",
								"Name": "Action",
								"SubGenres": {}
							}
						},
						"GuideCategories": {},
						"Id": "2689107",
						"PackageName": "One Piece 346",
						"ProductCodes": {},
						"ProgramTypes": {},
						"ProviderContentTiers": {},
						"TitleBrief": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
						"TitleDigital": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The"
					},
					"FastForwardAllowed": "false",
					"ProgrammerBrandingReq": "false",
					"PgmBucket": "5",
					"C3Indicator": "None"
				}, {
					"p2:type": "BroadbandBlockOfTime",
					"AssociatedBlockOfTimes": {},
					"BlockOfTimeMasterId": "3016130",
					"Comments": {
						"p2:nil": "true"
					},
					"CreatedBy": "Jjjackson",
					"CreatedDate": "6/23/2016 2:13:56 PM",
					"EndDate": "2016-08-21T05:59:59",
					"Feed": {
						"Id": "401",
						"Name": "Verizon Auth, AdultSwim",
						"Destinations": {
							"DestinationType": {
								"Name": "VZN"
							}
						}
					},
					"FlightDuration": "49",
					"Id": "3016134",
					"IsMaster": "false",
					"ModifiedBy": "Jjjackson",
					"ModifiedDate": "4/25/2016 4:51:27 PM",
					"Name": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
					"Network": "AdultSwim",
					"PostcloseScheduleItems": {},
					"PreopenScheduleItems": {},
					"ScheduleItems": {
						"ScheduleItemType": {
							"p2:type": "TitleScheduleItem",
							"BlockOfTimeId": "0",
							"Id": "6117612",
							"ItemId": "2083925",
							"MediaLength": "1275",
							"MediaName": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
							"OrderNumber": "1",
							"Version": {
								"Breaks": {
									"BreakType": {
										"BreakNumber": "1",
										"TimeCodeIn": "23588",
										"TimeCodeOut": "23678",
										"Length": "90"
									}
								},
								"ContentID": "2TG04",
								"DisplayMinutes": "30",
								"FormatAspectRatio": "0",
								"ID": "1508694",
								"IsClosedCaptioned": "true",
								"IsOrderVersion": "False",
								"MediaLength": "1275",
								"OrionVersionID": "680246",
								"ScheduleItemID": "0",
								"ScreenFormat": "0",
								"Segments": {
									"SegmentType": [{
										"MaterialID": "2TG04/01",
										"SegmentNumber": "1",
										"TimeCodeIn": "90",
										"TimeCodeOut": "23588",
										"Length": "23498",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "90",
										"SegmentCreditTimeCodeOut": "1646",
										"CreditTypeName": "Start"
									}, {
										"MaterialID": "2TG04/02",
										"SegmentNumber": "2",
										"TimeCodeIn": "23678",
										"TimeCodeOut": "38391",
										"Length": "14713",
										"SegmentCreditLength": "0",
										"SegmentCreditTimeCodeIn": "38288",
										"SegmentCreditTimeCodeOut": "38391",
										"CreditTypeName": "End"
									}]
								}
							},
							"Title": {
								"Actors": {},
								"ClipBlurb": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Descriptors": "L",
								"Directors": {},
								"Distributor": "FUNimation Productions",
								"ElementNumber": {},
								"EpisodeNumber": "346",
								"FranchiseId": "331646",
								"FriendlySeasonItemNumber": {},
								"IsActive": "False",
								"Keywords": "One Piece, CTN, Action",
								"LastAirDates": {
									"dateTime": "2016-05-15T02:30:00"
								},
								"LinearAiringDate": "2016-05-14T02:30:00",
								"LinearAiringId": "7946845",
								"LinearPremierDate": "2016-05-15T02:30:00",
								"Name": "The Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!",
								"Producers": {},
								"ReleaseYear": "2016",
								"SeasonNumber": "6",
								"SeriesId": "608007",
								"SeriesName": "One Piece",
								"Storyline": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
								"Studio": {},
								"StudioName": {},
								"TVRatingCode": "TV-PG-L",
								"ExternalSeriesId": {},
								"ExternalEpisodeId": {},
								"ExternalTMSEpisodeId": "EP022740690010",
								"TitleId": "2083925",
								"TitleType": "Episode (Animated)",
								"Writers": {}
							}
						}
					},
					"StartDate": "2016-07-03T06:00:00",
					"State": "Released",
					"UniqueId": "6af1e903-b0dc-45cf-b867-e93c4411ef2a",
					"DeviceExclusions": {},
					"WebFlags": {},
					"Elements": {
						"Element": [{
							"id": "2TG04/01",
							"Type": "MaterialID"
						}, {
							"id": "BLACK",
							"Type": "Trigger"
						}, {
							"id": "2TG04/02",
							"Type": "MaterialID"
						}]
					},
					"IsNonExpiring": "false",
					"Package": {
						"AssetId": "ASOE1004251600065731",
						"BlockOfTimeId": "0",
						"Categories": {},
						"Filename": "One Piece 346",
						"Genres": {
							"GenreType": {
								"Id": "1743564",
								"Name": "Action",
								"SubGenres": {}
							}
						},
						"GuideCategories": {},
						"Id": "2689108",
						"PackageName": "One Piece 346",
						"ProductCodes": {},
						"ProgramTypes": {},
						"ProviderContentTiers": {},
						"TitleBrief": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
						"TitleDigital": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The"
					},
					"FastForwardAllowed": "false",
					"ProgrammerBrandingReq": "false",
					"PgmBucket": "5",
					"C3Indicator": "None"
				}]
			},
			"BlockOfTimeMasterId": {
				"p2:nil": "true"
			},
			"Comments": {
				"p2:nil": "true"
			},
			"CreatedBy": "Jjjackson",
			"CreatedDate": "6/23/2016 2:13:56 PM",
			"EndDate": "2016-08-21T05:59:59",
			"Feed": {
				"Id": "231",
				"Name": "Master",
				"Destinations": {}
			},
			"FlightDuration": "49",
			"Id": "3016130",
			"IsMaster": "true",
			"ModifiedBy": "Jjjackson",
			"ModifiedDate": "4/25/2016 4:51:27 PM",
			"Name": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
			"Network": "AdultSwim",
			"PostcloseScheduleItems": {},
			"PreopenScheduleItems": {},
			"ScheduleItems": {
				"ScheduleItemType": {
					"p2:type": "TitleScheduleItem",
					"BlockOfTimeId": "0",
					"Id": "6117612",
					"ItemId": "2083925",
					"MediaLength": "1275",
					"MediaName": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
					"OrderNumber": "1",
					"Version": {
						"Breaks": {
							"BreakType": {
								"BreakNumber": "1",
								"TimeCodeIn": "23588",
								"TimeCodeOut": "23678",
								"Length": "90"
							}
						},
						"ContentID": "2TG04",
						"DisplayMinutes": "30",
						"FormatAspectRatio": "0",
						"ID": "1508694",
						"IsClosedCaptioned": "true",
						"IsOrderVersion": "False",
						"MediaLength": "1275",
						"OrionVersionID": "680246",
						"ScheduleItemID": "0",
						"ScreenFormat": "0",
						"Segments": {
							"SegmentType": [{
								"MaterialID": "2TG04/01",
								"SegmentNumber": "1",
								"TimeCodeIn": "90",
								"TimeCodeOut": "23588",
								"Length": "23498",
								"SegmentCreditLength": "0",
								"SegmentCreditTimeCodeIn": "90",
								"SegmentCreditTimeCodeOut": "1646",
								"CreditTypeName": "Start"
							}, {
								"MaterialID": "2TG04/02",
								"SegmentNumber": "2",
								"TimeCodeIn": "23678",
								"TimeCodeOut": "38391",
								"Length": "14713",
								"SegmentCreditLength": "0",
								"SegmentCreditTimeCodeIn": "38288",
								"SegmentCreditTimeCodeOut": "38391",
								"CreditTypeName": "End"
							}]
						}
					},
					"Title": {
						"Actors": {},
						"ClipBlurb": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
						"Descriptors": "L",
						"Directors": {},
						"Distributor": "FUNimation Productions",
						"ElementNumber": {},
						"EpisodeNumber": "346",
						"FranchiseId": "331646",
						"FriendlySeasonItemNumber": {},
						"IsActive": "False",
						"Keywords": "One Piece, CTN, Action",
						"LastAirDates": {
							"dateTime": "2016-05-15T02:30:00"
						},
						"LinearAiringDate": "2016-05-14T02:30:00",
						"LinearAiringId": "7946845",
						"LinearPremierDate": "2016-05-15T02:30:00",
						"Name": "The Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!",
						"Producers": {},
						"ReleaseYear": "2016",
						"SeasonNumber": "6",
						"SeriesId": "608007",
						"SeriesName": "One Piece",
						"Storyline": "An undead warthog sets her sights on Nami, Zorro and Sanji vanish without a trace, Franky and Robin battle an unbeatable army, and Luffy gets captured!",
						"Studio": {},
						"StudioName": {},
						"TVRatingCode": "TV-PG-L",
						"ExternalSeriesId": {},
						"ExternalEpisodeId": {},
						"ExternalTMSEpisodeId": "EP022740690010",
						"TitleId": "2083925",
						"TitleType": "Episode (Animated)",
						"Writers": {}
					}
				}
			},
			"StartDate": "2016-07-03T06:00:00",
			"State": "Released",
			"UniqueId": "28f2b8c8-50d1-47b4-9e80-7fe64786bb77",
			"DeviceExclusions": {},
			"WebFlags": {},
			"Elements": {
				"Element": [{
					"id": "2TG04/01",
					"Type": "MaterialID"
				}, {
					"id": "BLACK",
					"Type": "Trigger"
				}, {
					"id": "2TG04/02",
					"Type": "MaterialID"
				}]
			},
			"IsNonExpiring": "false",
			"Package": {
				"AssetId": "ASOE1004251600065731",
				"BlockOfTimeId": "0",
				"Categories": {},
				"Filename": "One Piece 346",
				"Genres": {
					"GenreType": [{
						"Id": "0",
						"Name": "Action",
						"SubGenres": {}
					}, {
						"Id": "0",
						"Name": "Adventure",
						"SubGenres": {}
					}]
				},
				"GuideCategories": {},
				"Id": "2689104",
				"PackageName": "One Piece 346",
				"ProductCodes": {},
				"ProgramTypes": {},
				"ProviderContentTiers": {},
				"TitleBrief": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The",
				"TitleDigital": "Vanishing Straw Hat Crew! A Mysterious Swordsman Appears!, The"
			},
			"FastForwardAllowed": "false",
			"ProgrammerBrandingReq": "false",
			"PgmBucket": "5",
			"C3Indicator": "None"
		}
	}
}';


  private $tveItem = '{
	"TveItem": {
		"C3": "false",
		"Title": {
			"Id": "821566",
			"Type": "Episode (Non-Animated)",
			"Network": {
				"Net": "TBS"
			},
			"AssetId": "TBSE1005271600032087",
			"TitleName": "The Big Bang Theory 69",
			"Duration": {
				"ActualSeconds": "1228",
				"DisplayMinutes": "25"
			},
			"SearchName": "Big Bang Theory, The",
			"Released": {
				"Year": "2010"
			},
			"MetaKeywords": "Dating (Social custom), Dishonesty, Friendship, Sex, Sisters, Truth",
			"Genre": "Comedy",
			"TVRatingCode": "TV-PG-D",
			"StoryLine": "When Raj\'s sister has a one-day layover he forbids the others from hooking up with her, unaware she and Leonard already did long ago.",
			"StoryLineShort": "When Raj\'s sister has a one-day layover he forbids the others from hooking up with her, unaware she and Leonard already did long ago.",
			"Airings": {
				"Airing": [{
					"Date": "2016-09-08T21:30:00"
				}, {
					"Date": "2016-07-20T20:30:00"
				}, {
					"Date": "2016-05-29T21:30:00"
				}, {
					"Date": "2016-04-14T21:30:00"
				}, {
					"Date": "2016-03-23T22:30:00"
				}]
			},
			"OriginalPremierDate": {
				"Date": "2011-11-02"
			},
			"SeriesName": "The Big Bang Theory",
			"EpisodeNumber": "69",
			"SeasonNumber": "4",
			"EpisodeTitle": "Irish Pub Formulation, The",
			"Participants": {
				"Participant": [{
					"Name": "Kunal Nayyar"
				}, {
					"Name": "Jim Parsons"
				}, {
					"Name": "Simon Helberg"
				}, {
					"Name": "Johnny Galecki"
				}, {
					"Name": "Kaley Cuoco"
				}]
			},
			"ExternalIds": {
				"ExternalId": {
					"Source": "TMS",
					"Type": "Episode",
					"Value": "EP009311820073"
				}
			}
		},
		"Flights": {
			"Flight": {
				"Start": "2016-07-21T00:00:00",
				"End": "2016-07-27T23:59:59",
				"Auth": "Y"
			}
		},
		"AdBreaks": {
			"AdBreak": [{
				"Start": "00:02:34:22",
				"End": "00:02:37:22"
			}, {
				"Start": "00:10:49:27",
				"End": "00:10:52:27"
			}, {
				"Start": "00:19:38:22",
				"End": "00:19:41:22"
			}, {
				"Start": "00:20:19:26",
				"End": "00:20:22:26"
			}]
		},
		"ContentSegments": {
			"ContentSegment": [{
				"Start": "00:00:03:00",
				"End": "00:02:34:22"
			}, {
				"Start": "00:02:37:22",
				"End": "00:10:49:27"
			}, {
				"Start": "00:10:52:27",
				"End": "00:19:38:22"
			}, {
				"Start": "00:19:41:22",
				"End": "00:20:19:26"
			}, {
				"Start": "00:20:22:26",
				"End": "00:20:42:22"
			}]
		},
		"SqueezeCredits": {
			"Start": "00:20:22:26",
			"End": "00:20:42:22"
		},
		"Assets": {
			"Asset": [{
				"FileName": "TBSE1005271600032087_B9R2.mp4",
				"Bitrate": "600",
				"Width": "640",
				"Height": "360",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B12R6.mp4",
				"Bitrate": "2500",
				"Width": "960",
				"Height": "540",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B14R7.mp4",
				"Bitrate": "1900",
				"Width": "848",
				"Height": "480",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B4R1.mp4",
				"Bitrate": "5120",
				"Width": "1280",
				"Height": "720",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B5R2.mp4",
				"Bitrate": "1000",
				"Width": "640",
				"Height": "360",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B13R1.mp4",
				"Bitrate": "3500",
				"Width": "1280",
				"Height": "720",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B8R5.mp4",
				"Bitrate": "400",
				"Width": "416",
				"Height": "240",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B10R2.mp4",
				"Bitrate": "800",
				"Width": "640",
				"Height": "360",
				"AudioType": "Stereo"
			}, {
				"FileName": "TBSE1005271600032087_B11R2.mp4",
				"Bitrate": "1400",
				"Width": "640",
				"Height": "360",
				"AudioType": "Stereo"
			}]
		},
		"Thumbs": {
			"AltText": "Big Bang Theory, The",
			"Thumb": [{
				"Width": "96",
				"Height": "72",
				"ImageUrl": "TBSE1005271600032087_009_96x72.jpg"
			}, {
				"Width": "1280",
				"Height": "720",
				"ImageUrl": "TBSE1005271600032087_009_1280x720.png"
			}, {
				"Width": "1280",
				"Height": "720",
				"ImageUrl": "TBSE1005271600032087_009_1280x720.jpg"
			}, {
				"Width": "640",
				"Height": "360",
				"ImageUrl": "TBSE1005271600032087_009_640x360.jpg"
			}]
		},
		"Playback": {
			"FF": {
				"allowed": "false"
			},
			"ProgrammerBrandingReq": {
				"Required": "false"
			}
		},
		"Restrictions": {},
		"TurnerPrivate": {
			"Flights": {
				"Flight": [{
					"FeedId": "153",
					"Start": "2016-07-21T00:00:00",
					"End": "2016-07-27T23:59:59",
					"Auth": "Y"
				}, {
					"FeedId": "154",
					"Start": "2016-07-21T00:00:00",
					"End": "2016-07-27T23:59:59",
					"Auth": "Y"
				}, {
					"FeedId": "260",
					"Start": "2016-07-21T00:00:00",
					"End": "2016-07-27T23:59:59",
					"Auth": "Y"
				}, {
					"FeedId": "397",
					"Start": "2016-07-21T00:00:00",
					"End": "2016-07-27T23:59:59",
					"Auth": "Y"
				}]
			},
			"PgmBucket": {
				"Value": "5"
			},
			"PullOutAdv": {
				"Value": "false"
			},
			"CaptionsEncoded": "true",
			"ResearchCategory": "Full Episode Segment",
			"IsActive": "False",
			"FranchiseId": "392013",
			"SeriesId": "725092",
			"AdCategory": "episode",
			"Assets": {
				"Asset": [{
					"FileName": "TBSE1005271600032087_B9R2.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B9R2.mp4",
					"Bitrate": "600",
					"Width": "640",
					"Height": "360",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_B12R6.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B12R6.mp4",
					"Bitrate": "2500",
					"Width": "960",
					"Height": "540",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_B14R7.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B14R7.mp4",
					"Bitrate": "1900",
					"Width": "848",
					"Height": "480",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_B4R1.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B4R1.mp4",
					"Bitrate": "5120",
					"Width": "1280",
					"Height": "720",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_iphone_vod.m3u8",
					"mp4DrmArl": "/secure/tve/2016-07/TBSE1005271600032087_HLS/TBSE1005271600032087_iphone_vod.m3u8",
					"Type": "HLS"
				}, {
					"FileName": "TBSE1005271600032087_ipad_vod.m3u8",
					"mp4DrmArl": "/secure/tve/2016-07/TBSE1005271600032087_HLS/TBSE1005271600032087_ipad_vod.m3u8",
					"Type": "HLS"
				}, {
					"FileName": "set_TBSE1005271600032087.f4m",
					"mp4DrmArl": "/2016-07/TBSE1005271600032087/set_TBSE1005271600032087.f4m",
					"Bitrate": "SD",
					"Type": "HDS"
				}, {
					"FileName": "TBSE1005271600032087_B5R2.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B5R2.mp4",
					"Bitrate": "1000",
					"Width": "640",
					"Height": "360",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_B13R1.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B13R1.mp4",
					"Bitrate": "3500",
					"Width": "1280",
					"Height": "720",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_B8R5.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B8R5.mp4",
					"Bitrate": "400",
					"Width": "416",
					"Height": "240",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_B10R2.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B10R2.mp4",
					"Bitrate": "800",
					"Width": "640",
					"Height": "360",
					"AudioType": "Stereo"
				}, {
					"FileName": "TBSE1005271600032087_B11R2.mp4",
					"mp4DrmArl": "/mp4:flash/tveverywhere/2016-07/TBSE1005271600032087_B11R2.mp4",
					"Bitrate": "1400",
					"Width": "640",
					"Height": "360",
					"AudioType": "Stereo"
				}]
			},
			"WebFlags": {},
			"SeasonItemNumber": "6",
			"Thumbs": {
				"ThumbSet": [{
					"Name": "Thumbs1",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_009_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_009_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_009_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_009_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_009_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_009_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_009_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_009_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs2",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_006_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_006_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_006_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_006_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_006_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_006_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_006_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_006_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs3",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_007_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_007_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_007_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_007_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_007_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_007_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_007_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_007_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs4",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_008_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_008_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_008_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_008_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_008_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_008_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_008_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_008_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs5",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_010_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_010_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_010_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_010_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_010_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_010_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_010_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_010_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs6",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_011_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_011_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_011_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_011_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_011_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_011_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_011_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_011_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs7",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_012_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_012_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_012_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_012_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_012_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_012_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_012_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_012_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs8",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_013_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_013_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_013_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_013_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_013_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_013_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_013_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_013_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs9",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_014_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_014_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_014_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_014_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_014_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_014_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_014_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_014_640x360.jpg"
					}]
				}, {
					"Name": "Thumbs10",
					"AltText": "Big Bang Theory, The",
					"Thumb": [{
						"contentName": "TBSE1005271600032087_015_96x72.jpg",
						"Width": "96",
						"Height": "72",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_015_96x72.jpg"
					}, {
						"contentName": "TBSE1005271600032087_015_1280x720.png",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_015_1280x720.png"
					}, {
						"contentName": "TBSE1005271600032087_015_1280x720.jpg",
						"Width": "1280",
						"Height": "720",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_015_1280x720.jpg"
					}, {
						"contentName": "TBSE1005271600032087_015_640x360.jpg",
						"Width": "640",
						"Height": "360",
						"SrcUrl": "/home/ideutil/tveData/tbs/TBSE1005271600032087_015_640x360.jpg"
					}]
				}]
			}
		}
	}
}';


  private $titles = '[{
	"_id": "572ba22591504717482eb241",
	"TitleId": 821566,
	"TitleName": "The Irish Pub Formulation",
	"TitleNameSortable": "Irish Pub Formulation, The",
	"LengthInSeconds": 0,
	"TitleType": {
		"Name": "Episode",
		"TitleTypeId": 6,
		"TitleTypeCode": "E"
	},
	"Language": {
		"Name": "ENGLISH",
		"LanguageId": 13
	},
	"ReleaseYear": 2010,
	"PerformanceMode": {
		"Name": "Taped",
		"PerformanceModeId": 1
	},
	"AnimationMode": {
		"Name": "Non-Animated",
		"AnimationModeId": 1
	},
	"ProcessedDatetimeUTC": "2016-05-05T19:42:28.869Z",
	"Genres": [{
		"Name": "Comedy",
		"GenreId": 2
	}],
	"KeyGenres": [],
	"Keywords": [{
		"Name": "Betrayal",
		"KeywordId": 2241
	}, {
		"Name": "Cafeterias",
		"KeywordId": 1713
	}, {
		"Name": "Dating (Social custom)",
		"KeywordId": 98
	}, {
		"Name": "Dishonesty",
		"KeywordId": 2244
	}, {
		"Name": "Friendship",
		"KeywordId": 128
	}, {
		"Name": "Sex",
		"KeywordId": 105
	}, {
		"Name": "Sisters",
		"KeywordId": 53
	}, {
		"Name": "Truth",
		"KeywordId": 611
	}],
	"Tags": [],
	"Ratings": [{
		"RatingSystem": "US",
		"RatingSystemId": 1,
		"RatingDescriptors": [{
			"Rating": "TV-PG",
			"RatingId": 3,
			"Descriptors": ["D"]
		}]
	}],
	"OtherNames": [{
		"TitleName": "The Irish Pub Formulation",
		"TitleNameSortable": "Irish Pub Formulation, The",
		"TitleNameType": "Primary",
		"TitleNameLanguage": "ENGLISH",
		"TitleNameTypeId": 5,
		"TitleNameLanguageId": 13
	}],
	"Storylines": [{
		"Type": "Short (245 Characters)",
		"Language": "ENGLISH",
		"Description": "When Raj\'s sister has a one-day layover he forbids the others from hooking up with her, unaware she and Leonard already did long ago. ",
		"TypeId": 5,
		"LanguageId": 13
	}, {
		"Type": "Turner External",
		"Language": "ENGLISH",
		"Description": "When Raj\'s sister has a one-day layover he forbids the others from hooking up with her, unaware she and Leonard already did long ago. \r\n\r\n",
		"TypeId": 2,
		"LanguageId": 13
	}, {
		"Type": "Turner Internal",
		"Language": "ENGLISH",
		"Description": "When Raj\'s sister has a one-day layover he forbids the others from hooking up with her, unaware she and Leonard already did long ago. \r\n\r\n",
		"TypeId": 1,
		"LanguageId": 13
	}],
	"Participants": [{
		"ParticipantId": 11247796,
		"Name": "Melissa Rauch",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": true,
		"RoleType": "Actor",
		"RoleTypeId": 3,
		"IsKey": false
	}, {
		"ParticipantId": 1157197,
		"Name": "Chuck Lorre",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": false,
		"RoleType": "Executive Producer",
		"RoleTypeId": 13,
		"IsKey": true,
		"SortOrder": 1
	}, {
		"ParticipantId": 12756842,
		"Name": "Kunal Nayyar",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": true,
		"RoleType": "Actor",
		"RoleTypeId": 3,
		"IsKey": true,
		"SortOrder": 6
	}, {
		"ParticipantId": 1318760,
		"Name": "Bill Prady",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": false,
		"RoleType": "Executive Producer",
		"RoleTypeId": 13,
		"IsKey": false
	}, {
		"ParticipantId": 15798,
		"Name": "Mayim Bialik",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": true,
		"RoleType": "Actor",
		"RoleTypeId": 3,
		"IsKey": false
	}, {
		"ParticipantId": 2857507,
		"Name": "Jim Parsons",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": true,
		"RoleType": "Actor",
		"RoleTypeId": 3,
		"IsKey": true,
		"SortOrder": 4
	}, {
		"ParticipantId": 370272,
		"Name": "Simon Helberg",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": true,
		"RoleType": "Actor",
		"RoleTypeId": 3,
		"IsKey": true,
		"SortOrder": 5
	}, {
		"ParticipantId": 554698,
		"Name": "David Goetz",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": false,
		"RoleType": "Co-Executive Producer",
		"RoleTypeId": 401,
		"IsKey": false
	}, {
		"ParticipantId": 67640,
		"Name": "Johnny Galecki",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": true,
		"RoleType": "Actor",
		"RoleTypeId": 3,
		"IsKey": true,
		"SortOrder": 3
	}, {
		"ParticipantId": 850764,
		"Name": "Kaley Cuoco",
		"ParticipantType": "Person",
		"ParticipantTypeId": 1,
		"IsOnScreen": true,
		"RoleType": "Actor",
		"RoleTypeId": 3,
		"IsKey": true,
		"SortOrder": 2
	}],
	"SeriesTitleId": 725092,
	"SeriesTitleName": "The Big Bang Theory",
	"SeriesTitleNameSortable": "Big Bang Theory, The",
	"SeasonNumber": 4,
	"SeriesItemNumber": "69",
	"InternationalReferenceNumber": "3X6656",
	"ExternalSeriesItemNumber": "S4:E06",
	"SeasonEpisodeNumber": "6",
	"AiringSequenceNumber": 69,
	"NetworkLevels": [{
		"Name": "TBS",
		"NetworkId": 11
	}, {
		"Name": "WPCH",
		"NetworkId": 18
	}],
	"ExternalSources": [{
		"Name": "Tribune",
		"Key": "EP009311820073"
	}]
}]';

}
