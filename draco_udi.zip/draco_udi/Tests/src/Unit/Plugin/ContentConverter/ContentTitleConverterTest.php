<?php

namespace Drupal\Tests\draco_udi\Unit\Plugin\ContenConverter;

use Drupal\draco_udi\Entity\ContentTitle;
use Drupal\draco_udi\Entity\ContentTitleInterface;
use Drupal\draco_udi\Plugin\ContentConverter\ContentTitleConverter;
use Drupal\Tests\UnitTestCase;
use Drupal\draco_udi\Mocks\MockFieldDefinition;
use Drupal\draco_udi\Mocks\MockFieldItemList;
use Drupal\Core\DependencyInjection\ContainerBuilder;

/**
 * Class ContentTitleConverterTest.
 *
 * @package Drupal\draco_udi\Tests\Unit\Plugin\ContenConverter
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Plugin\ContentConverter\ContentTitleConverter
 */
class ContentTitleConverterTest extends UnitTestCase {

  protected $storage;
  protected $queryFactory;
  protected $logger;

  /**
   * Content Title Data.
   *
   * @var \Drupal\draco_udi\Entity\ContentTitle
   */
  protected $contentTitle;

  /**
   * Content Title Converter.
   *
   * @var \Drupal\draco_udi\Plugin\ContentConverter\ContentTitleConverter
   */
  protected $contentTitleConverter;

  /**
   * FieldType Plugin Manager.
   *
   * @var \Drupal\Core\Field\FieldTypePluginManagerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $fieldTypePluginManager;

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $entityTypeId = $this->randomMachineName();

    $this->storage = $this->getMockBuilder('\Drupal\Core\Entity\EntityStorageInterface')->getMock();

    $entityTypeId = $this->randomMachineName();

    $this->queryFactory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory = $this->getMockBuilder('\Drupal\Core\Logger\LoggerChannelFactoryInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory->expects($this->any())
      ->method('get')
      ->will($this->returnValue($this->logger));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();
    $entityType->expects($this->any())
      ->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
        'langcode' => 'langcode',
      )));

    $language = $this->getMockBuilder('Drupal\Core\Language\LanguageInterface')->getMock();
    $language->expects($this->any())
      ->method('getId')
      ->willReturn('en');

    $language_manager = $this->getMockBuilder('Drupal\Core\Language\LanguageManagerInterface')->getMock();
    $language_manager->expects($this->any())
      ->method('getCurrentLanguage')
      ->will($this->returnValue($language));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();
    $entityType->expects($this->any())
      ->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
        'langcode' => 'langcode',
      )));

    $typed_data_manager = $this->getMockBuilder('Drupal\Core\TypedData\TypedDataManagerInterface')->getMock();

    $this->fieldTypePluginManager = $this->getMockBuilder('Drupal\Core\Field\FieldTypePluginManagerInterface')->getMock();

    $this->entityManager = $this->getMockBuilder('\Drupal\Core\Entity\EntityManagerInterface')->getMock();
    $this->entityManager->expects($this->any())
      ->method('getDefinition')
      ->with($entityTypeId)
      ->will($this->returnValue($entityType));

    $this->entityManager->expects($this->any())
      ->method('getFieldDefinitions')
      ->with($entityTypeId)
      ->will($this->returnValue($this->fieldDefinitions()));

    $this->entityManager->expects($this->any())
      ->method('getStorage')
      ->willReturn($this->storage);

    $uuid = $this->getMockBuilder('\Drupal\Component\Uuid\UuidInterface')->getMock();

    $container = new ContainerBuilder();
    $container->set('entity.manager', $this->entityManager);
    $container->set('uuid', $uuid);
    $container->set("plugin.manager.field.field_type", $this->fieldTypePluginManager);
    $container->set("logger.factory", $logger_factory);
    $container->set("language_manager", $language_manager);
    $container->set("language", $language);
    $container->set('typed_data_manager', $typed_data_manager);

    \Drupal::setContainer($container);

    $this->contentTitleConverter = new ContentTitleConverter([], 'foo', 'foo',
      $this->entityManager, $this->queryFactory, $logger_factory);

    $values = array(
      'id' => '1234',
      'label' => 'test ContentLinearSchedule',
      'uuid' => '3bb9ee60-bea5-4622-b89b-a63319d10b3a',
      'langcode' => 'en',
    );

    $this->contentTitle = new ContentTitle($values, $entityTypeId);

    $this->storage->expects($this->any())
      ->method('create')
      ->willReturn($this->contentTitle);
  }

  /**
   * Tests getMappedEntityType method.
   *
   * @covers ::getMappedEntityType
   */
  public function testGetMappedEntityType() {
    $this->assertNotNull($this->contentTitleConverter);

    $target_type = $this->contentTitleConverter->getMappedEntityType();

    $this->assertEquals($target_type, 'content_title');
  }

  /**
   * Tests convert method.
   *
   * @covers ::convert
   * @covers ::mapFields
   */
  public function testConvert() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'title_id')));

    $content_data = $this->getContentData();

    $draco_entity_set = $this->contentTitleConverter->convert($content_data);
    $draco_entity = $draco_entity_set->getConvertedEntity();

    $this->assertNotNull($draco_entity);
    $this->assertNotNull($draco_entity->getFields()['title_id']);
    $this->assertTrue($draco_entity instanceof ContentTitleInterface);
  }

  /**
   * Create testing data.
   *
   * @return \stdClass
   *    Content Data.
   */
  private function getContentData() {
    $title_data = new \stdClass();

    $title_data->TitleId = 12345;
    $title_data->TitleName = 'Pilot';
    $title_data->TitleNameSortable = 'Pilot';
    $title_data->ReleaseYear = 2015;

    $title_type = new \stdClass();
    $title_type->Name = 'Episode';
    $title_data->TitleType = $title_type;

    $performance_mode = new \stdClass();
    $performance_mode->Name = 'Taped';
    $title_data->PerformanceMode = $performance_mode;

    $animation_mode = new \stdClass();
    $animation_mode->Name = 'Animated';
    $title_data->AnimationMode = $animation_mode;

    $title_data->ProcessedDatetimeUTC = "2015-01-13T21:51:11.936Z";

    $genres = new \stdClass();
    $genres->Name = 'Comedy';
    $title_data->Genres = [$genres];

    $title_data->KeyGenres = [];
    $title_data->Tags = [];
    $title_data->Keywords = [];

    $rating = new \stdClass();
    $desc = new \stdClass();
    $desc->Rating = 'TV-PG';
    $desc->Descriptors = ['V', 'D'];
    $rating->RatingDescriptors = [$desc];
    $title_data->Ratings = [$rating];

    $external_storyline = new \stdClass();
    $external_storyline->Type = 'Turner External';
    $external_storyline->Description = 'Steve runs for school president to pick up girls';
    $short_storyline = new \stdClass();
    $short_storyline->Type = 'Short (245 Characters)';
    $short_storyline->Description = 'Steve runs for school president to pick up girls';
    $title_data->Storylines = [$external_storyline, $short_storyline];

    $title_data->Participants = [];

    $title_data->SeriesTitleId = 54321;
    $title_data->SeriesTitleName = 'American Dad';
    $title_data->SeriesTitleNameSortable = 'American Dad';
    $title_data->SeasonNumber = 1;
    $title_data->SeriesItemNumber = '101';
    $title_data->SeasonEpisodeNumber = '1';

    return $title_data;
  }

  /**
   * Get FieldItemList.
   *
   * @param string $type
   *   Field Type.
   * @param string $name
   *   Field name.
   * @param string $label
   *   Field Label.
   *
   * @return \Drupal\draco_udi\Mocks\MockFieldItemList
   *   A Mock Field List.
   */
  private function getFieldItemList($type, $name, $label = '') {
    $field_definition = new MockFieldDefinition(array(), $type, $name, $label);
    $field_list = new MockFieldItemList($field_definition, array(), $name);
    return $field_list;
  }

  /**
   * Field Definitions.
   *
   * @return array
   *    List of field definitions.
   */
  private function fieldDefinitions() {
    return array(
      'sortable_title_name' => $this->getFieldItemList('string', 'sortable_title_name'),
      'uuid' => $this->getFieldItemList('string', 'uuid'),
      'label' => $this->getFieldItemList('string', 'label'),
      'changed' => $this->getFieldItemList('changed', 'changed'),
      'imported' => $this->getFieldItemList('created', 'imported'),
      'network' => $this->getFieldItemList('created', 'imported'),
      'title_id' => $this->getFieldItemList('integer', 'title_id'),
      'title_type' => $this->getFieldItemList('string', 'title_type'),
      'length_in_seconds' => $this->getFieldItemList('integer', 'length_in_seconds'),
      'release_year' => $this->getFieldItemList('integer', 'release_year'),
      'processed_datetime' => $this->getFieldItemList('datetime', 'processed_datetime'),
      'animation_mode' => $this->getFieldItemList('datetime', 'animation_mode'),
      'performance_mode' => $this->getFieldItemList('string', 'performance_mode'),
      'external_storyline' => $this->getFieldItemList('string', 'external_storyline'),
      'short_storyline' => $this->getFieldItemList('string', 'short_storyline'),
      'storylines' => $this->getFieldItemList('string_long', 'storylines'),
      'genres' => $this->getFieldItemList('string', 'genres'),
      'key_genres' => $this->getFieldItemList('string', 'key_genres'),
      'tags' => $this->getFieldItemList('string_long', 'tags'),
      'keywords' => $this->getFieldItemList('string', 'keywords'),
      'ratings' => $this->getFieldItemList('string_long', 'ratings'),
      'participants' => $this->getFieldItemList('string_long', 'participants'),
      'series_title_id' => $this->getFieldItemList('integer', 'series_title_id'),
      'series_title_name' => $this->getFieldItemList('string', 'series_title_name'),
      'sortable_series_title_name' => $this->getFieldItemList('string', 'sortable_series_title_name'),
      'series_item_number' => $this->getFieldItemList('string', 'series_item_number'),
      'external_series_item_number' => $this->getFieldItemList('string', 'external_series_item_number'),
      'season_number' => $this->getFieldItemList('integer', 'season_number'),
      'season_name' => $this->getFieldItemList('string', 'season_name'),
      'season_episode_number' => $this->getFieldItemList('string', 'season_episode_number'),
      'seasons' => $this->getFieldItemList('string_long', 'seasons'),
      'series_items' => $this->getFieldItemList('string_long', 'series_items'),
      'content_json' => $this->getFieldItemList('string_long', 'content_json'),
    );
  }

}
