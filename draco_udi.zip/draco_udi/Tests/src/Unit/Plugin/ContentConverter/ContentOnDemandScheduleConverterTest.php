<?php


namespace Drupal\Tests\draco_udi\Unit\Plugin\ContenConverter;

use Drupal\draco_udi\Entity\ContentOnDemandSchedule;
use Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface;
use Drupal\draco_udi\Plugin\ContentConverter\ContentOnDemandScheduleConverter;
use Drupal\Tests\UnitTestCase;
use Drupal\draco_udi\Mocks\MockFieldDefinition;
use Drupal\draco_udi\Mocks\MockFieldItemList;
use Drupal\Core\DependencyInjection\ContainerBuilder;

/**
 * Class ContentOnDemandScheduleConverterTest.
 *
 * @package Drupal\Tests\draco_udi\Unit\Plugin\ContenConverter
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Plugin\ContentConverter\ContentLinearScheduleConverter
 */
class ContentOnDemandScheduleConverterTest extends UnitTestCase {

  protected $storage;
  protected $queryFactory;
  protected $logger;

  /**
   * ContentOnDemandSchedule.
   *
   * @var \Drupal\draco_udi\Entity\ContentOnDemandSchedule
   */
  protected $contentOnDemandSchedule;

  /**
   * Content Converter.
   *
   * @var \Drupal\draco_udi\Plugin\ContentConverter\ContentOnDemandScheduleConverter
   */
  protected $contentOnDemandScheduleConverter;

  /**
   * Field Type Plugin Manager.
   *
   * @var \Drupal\Core\Field\FieldTypePluginManagerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $fieldTypePluginManager;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    $this->storage = $this->getMockBuilder('\Drupal\Core\Entity\EntityStorageInterface')->getMock();;
    $entityTypeId = $this->randomMachineName();

    $this->queryFactory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory = $this->getMockBuilder('\Drupal\Core\Logger\LoggerChannelFactoryInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory->expects($this->any())
      ->method('get')
      ->will($this->returnValue($this->logger));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();;
    $entityType->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
        'langcode' => 'langcode',
      )));

    $language = $this->getMockBuilder('Drupal\Core\Language\LanguageInterface')->getMock();;
    $language->expects($this->any())
      ->method('getId')
      ->willReturn('en');

    $language_manager = $this->getMockBuilder('Drupal\Core\Language\LanguageManagerInterface')->getMock();;
    $language_manager->expects($this->any())
      ->method('getCurrentLanguage')
      ->will($this->returnValue($language));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();;
    $entityType->expects($this->any())
      ->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
        'langcode' => 'langcode',
      )));

    $typed_data_manager = $this->getMockBuilder('Drupal\Core\TypedData\TypedDataManagerInterface')->getMock();;

    $this->fieldTypePluginManager = $this->getMockBuilder('Drupal\Core\Field\FieldTypePluginManagerInterface')->getMock();;

    $this->entityManager = $this->getMockBuilder('\Drupal\Core\Entity\EntityManagerInterface')->getMock();
    $this->entityManager->expects($this->any())
      ->method('getDefinition')
      ->with($entityTypeId)
      ->will($this->returnValue($entityType));

    $this->entityManager->expects($this->any())
      ->method('getFieldDefinitions')
      ->with($entityTypeId)
      ->will($this->returnValue($this->fieldDefinitions()));

    $this->entityManager->expects($this->any())
      ->method('getStorage')
      ->willReturn($this->storage);

    $uuid = $this->getMockBuilder('\Drupal\Component\Uuid\UuidInterface')->getMock();;

    $container = new ContainerBuilder();
    $container->set('entity.manager', $this->entityManager);
    $container->set('uuid', $uuid);
    $container->set("plugin.manager.field.field_type", $this->fieldTypePluginManager);
    $container->set("logger.factory", $logger_factory);
    $container->set("language_manager", $language_manager);
    $container->set("language", $language);
    $container->set('typed_data_manager', $typed_data_manager);

    \Drupal::setContainer($container);

    $this->contentOnDemandScheduleConverter = new ContentOnDemandScheduleConverter([], 'foo', 'foo',
      $this->entityManager, $this->queryFactory, $logger_factory);

    $values = array(
      'id' => '1234',
      'label' => 'test ContentOnDemandSchedule',
      'uuid' => '3bb9ee60-bea5-4622-b89b-a63319d10b3a',
      'langcode' => 'en',
    );

    $this->contentOnDemandSchedule = new ContentOnDemandSchedule($values, $entityTypeId);

    $this->storage->expects($this->any())
      ->method('create')
      ->willReturn($this->contentOnDemandSchedule);
  }

  /**
   * Tests getMappedEntityType method.
   *
   * @covers ::getMappedEntityType
   */
  public function testGetMappedEntityType() {
    $this->assertNotNull($this->contentOnDemandScheduleConverter);

    $target_type = $this->contentOnDemandScheduleConverter->getMappedEntityType();

    $this->assertEquals($target_type, 'content_on_demand_schedule');
  }

  /**
   * Tests convert method throws exception.
   *
   * @covers ::convert
   * @covers ::update
   */
  public function testConvertWithInvalidDataType() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'airing_id')));
    $draco_entity_set = NULL;

    try {
      $draco_entity_set = $this->contentOnDemandScheduleConverter->convert(NULL);
    }
    catch (\Exception $ex) {
      $this->assertNull($draco_entity_set);
      $this->assertTrue($ex instanceof \InvalidArgumentException);
      $this->assertEquals($ex->getMessage(), 'Failed converting source content to Draco entity. The content data is either null or not a stdClass object.');
    }

  }

  /**
   * Tests convert method.
   *
   * @covers ::convert
   * @covers ::update
   * @covers ::setTitleIds
   */
  public function testConvert() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'airing_id')));

    $content_data = $this->getContentData();

    $draco_entity_set = $this->contentOnDemandScheduleConverter->convert($content_data);
    $draco_entity = $draco_entity_set->getConvertedEntity();

    $this->assertNotNull($draco_entity);
    $this->assertNotNull($draco_entity->getFields()['airing_id']);
    $this->assertTrue($draco_entity instanceof ContentOnDemandScheduleInterface);
  }

  /**
   * Create testing data.
   *
   * @return \stdClass
   *   Schedule Content Data.
   */
  private function getContentData() {
    $schedule_obj = new \stdClass();

    $schedule_obj->airingId = 'TBS12345';
    $schedule_obj->mediaId = 'MEDIA12345';
    $schedule_obj->name = 'On Demand Test';
    $schedule_obj->type = 'Episode';
    $schedule_obj->brand = 'TBS';
    $schedule_obj->platform = 'Digital';
    $schedule_obj->duration = new \stdClass();
    $schedule_obj->duration->lengthInSeconds = 1800;
    $schedule_obj->duration->displayMinutes = 30;
    $schedule_obj->versions = [];
    $schedule_obj->platlist = [];
    $schedule_obj->options = new \stdClass();
    $schedule_obj->options->files = [];

    $title = new \stdClass();

    $titleIds = [];
    $title_1 = new \stdClass();
    $title_1->authority = 'Turner';
    $title_1->value = '12345';
    $titleIds[] = $title_1;

    $title_2 = new \stdClass();
    $title_2->authority = 'Turner';
    $title_2->value = '67890';
    $titleIds[] = $title_2;

    $title->titleIds = $titleIds;

    $storyline = new \stdClass();
    $storyline->long = 'long storyline';
    $storyline->short = 'long storyline';
    $title->storyline = $storyline;

    $rating = new \stdClass();
    $rating->code = 'TV-PG';
    $rating->description = 'D,V';
    $title->rating = $rating;

    $schedule_obj->title = $title;

    $flight = new \stdClass();
    $flight->start = '2016-07-23T07:00:00Z';
    $flight->end = '2016-07-30T07:00:00Z';
    $flight->destinations = new \stdClass();
    $schedule_obj->flights = [];

    return $schedule_obj;
  }

  /**
   * Create a MockFieldItemList based on a MockFieldDefinition for a field.
   */
  private function getFieldItemList($type, $name, $label = '') {
    $field_definition = new MockFieldDefinition(array(), $type, $name, $label);
    $field_list = new MockFieldItemList($field_definition, array(), $name);
    return $field_list;
  }

  /**
   * Field Definitions.
   *
   * @return array
   *    List of field definitions.
   */
  private function fieldDefinitions() {
    return array(
      'airing_id' => $this->getFieldItemList('string', 'airing_id'),
      'uuid' => $this->getFieldItemList('string', 'uuid'),
      'label' => $this->getFieldItemList('string', 'label'),
      'changed' => $this->getFieldItemList('changed', 'changed'),
      'imported' => $this->getFieldItemList('created', 'imported'),
      'media_id' => $this->getFieldItemList('created', 'imported'),
      'brand' => $this->getFieldItemList('string', 'brand'),
      'type' => $this->getFieldItemList('string', 'type'),
      'length_in_seconds' => $this->getFieldItemList('integer', 'length_in_seconds'),
      'display_minutes' => $this->getFieldItemList('integer', 'display_minutes'),
      'files' => $this->getFieldItemList('string_long', 'files'),
      'versions' => $this->getFieldItemList('string_long', 'versions'),
      'ratings' => $this->getFieldItemList('string_long', 'ratings'),
      'playlist' => $this->getFieldItemList('string_long', 'platlist'),
      'content_json' => $this->getFieldItemList('string_long', 'content_json'),
      'title_ids' => $this->getFieldItemList('string_long', 'title_ids'),
      'title_data' => $this->getFieldItemList('string_long', 'title_data'),
      'flights' => $this->getFieldItemList('string_long', 'flights'),
    );
  }

}
