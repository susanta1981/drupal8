<?php

namespace Drupal\Tests\draco_udi\Unit\Plugin\ContenConverter;

use Drupal\draco_udi\Entity\ContentLinearSchedule;
use Drupal\draco_udi\Entity\ContentLinearScheduleInterface;
use Drupal\draco_udi\Plugin\ContentConverter\ContentLinearScheduleConverter;
use Drupal\Tests\UnitTestCase;
use Drupal\draco_udi\Mocks\MockFieldDefinition;
use Drupal\draco_udi\Mocks\MockFieldItemList;
use Drupal\Core\DependencyInjection\ContainerBuilder;

/**
 * Class ContentLinearScheduleConverterTest.
 *
 * @package Drupal\Tests\draco_udi\Unit\Plugin\ContenConverter
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Plugin\ContentConverter\ContentLinearScheduleConverter
 */
class ContentLinearScheduleConverterTest extends UnitTestCase {

  protected $storage;
  protected $queryFactory;
  protected $logger;

  /**
   * ContentLinearSchedule.
   *
   * @var \Drupal\draco_udi\Entity\ContentLinearSchedule
   */
  protected $contentLinearSchedule;

  /**
   * Content Converter.
   *
   * @var \Drupal\draco_udi\Plugin\ContentConverter\ContentLinearScheduleConverter
   */
  protected $contentLinearScheduleConverter;

  /**
   * Field Type Plugin Manager.
   *
   * @var \Drupal\Core\Field\FieldTypePluginManagerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $fieldTypePluginManager;

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $entityTypeId = $this->randomMachineName();

    $this->storage = $this->getMockBuilder('\Drupal\Core\Entity\EntityStorageInterface')->getMock();

    $entityTypeId = $this->randomMachineName();

    $this->queryFactory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory = $this->getMockBuilder('\Drupal\Core\Logger\LoggerChannelFactoryInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory->expects($this->any())
      ->method('get')
      ->will($this->returnValue($this->logger));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();
    $entityType->expects($this->any())
      ->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
        'langcode' => 'langcode',
      )));

    $language = $this->getMockBuilder('Drupal\Core\Language\LanguageInterface')->getMock();
    $language->expects($this->any())
      ->method('getId')
      ->willReturn('en');

    $language_manager = $this->getMockBuilder('Drupal\Core\Language\LanguageManagerInterface')->getMock();
    $language_manager->expects($this->any())
      ->method('getCurrentLanguage')
      ->will($this->returnValue($language));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();
    $entityType->expects($this->any())
      ->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
        'langcode' => 'langcode',
      )));

    $typed_data_manager = $this->getMockBuilder('Drupal\Core\TypedData\TypedDataManagerInterface')->getMock();

    $this->fieldTypePluginManager = $this->getMockBuilder('Drupal\Core\Field\FieldTypePluginManagerInterface')->getMock();

    $this->entityManager = $this->getMockBuilder('\Drupal\Core\Entity\EntityManagerInterface')->getMock();
    $this->entityManager->expects($this->any())
      ->method('getDefinition')
      ->with($entityTypeId)
      ->will($this->returnValue($entityType));

    $this->entityManager->expects($this->any())
      ->method('getFieldDefinitions')
      ->with($entityTypeId)
      ->will($this->returnValue($this->fieldDefinitions()));

    $this->entityManager->expects($this->any())
      ->method('getStorage')
      ->willReturn($this->storage);

    $uuid = $this->getMockBuilder('\Drupal\Component\Uuid\UuidInterface')->getMock();

    $container = new ContainerBuilder();
    $container->set('entity.manager', $this->entityManager);
    $container->set('uuid', $uuid);
    $container->set("plugin.manager.field.field_type", $this->fieldTypePluginManager);
    $container->set("logger.factory", $logger_factory);
    $container->set("language_manager", $language_manager);
    $container->set("language", $language);
    $container->set('typed_data_manager', $typed_data_manager);

    \Drupal::setContainer($container);

    $this->contentLinearScheduleConverter = new ContentLinearScheduleConverter([], 'foo', 'foo',
      $this->entityManager, $this->queryFactory, $logger_factory);

    $values = array(
      'id' => '1234',
      'label' => 'test ContentLinearSchedule',
      'uuid' => '3bb9ee60-bea5-4622-b89b-a63319d10b3a',
      'langcode' => 'en',
    );

    $this->contentLinearSchedule = new ContentLinearSchedule($values, $entityTypeId);

    $this->storage->expects($this->any())
      ->method('create')
      ->willReturn($this->contentLinearSchedule);
  }

  /**
   * Tests getMappedEntityType method.
   *
   * @covers ::getMappedEntityType
   */
  public function testGetMappedEntityType() {
    $this->assertNotNull($this->contentLinearScheduleConverter);

    $target_type = $this->contentLinearScheduleConverter->getMappedEntityType();

    $this->assertEquals($target_type, 'content_linear_schedule');
  }

  /**
   * Tests convert method throws exception.
   *
   * @covers ::convert
   * @covers ::update
   */
  public function testConvertWithInvalidDataType() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'external_id')));
    $draco_entity_set = NULL;

    try {
      $draco_entity_set = $this->contentLinearScheduleConverter->convert(NULL);
    }
    catch (\Exception $ex) {
      $this->assertNull($draco_entity_set);
      $this->assertTrue($ex instanceof \InvalidArgumentException);
      $this->assertEquals($ex->getMessage(), 'Failed converting source content to Draco entity. The content data is either null or not a stdClass object.');
    }
  }

  /**
   * Tests convert method.
   *
   * @covers ::convert
   * @covers ::update
   */
  public function testConvert() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'external_id')));

    $content_data = $this->getContentData();

    $draco_entity_set = $this->contentLinearScheduleConverter->convert($content_data);
    $draco_entity = $draco_entity_set->getConvertedEntity();

    $this->assertNotNull($draco_entity);
    $this->assertNotNull($draco_entity->getFields()['external_id']);
    $this->assertTrue($draco_entity instanceof ContentLinearScheduleInterface);
  }

  /**
   * Create testing data.
   *
   * @return \stdClass
   *   Schedule Content Data.
   */
  private function getContentData() {
    $schedule_obj = new \stdClass();

    $schedule_obj->ExternalId = 12345;
    $schedule_obj->StartDate = '2016-02-09T03:30:00.000Z';
    $schedule_obj->EndDate = '2016-02-10T03:30:00.000Z';
    $schedule_obj->Network = 'TBS';
    $schedule_obj->Name = 'Test';
    $schedule_obj->type = 'LinearSchedule';
    $schedule_obj->ScheduleAirDate = '2016-02-08T05:00:00.000Z';
    $schedule_obj->Source = 'TBS';
    $schedule_obj->Platform = 'Linear';
    $schedule_obj->FranchiseName = 'TBS';
    $schedule_obj->TimeZone = 'Eastern Standard Time';
    $schedule_obj->FranchiseDuration = 1234;
    $schedule_obj->FranchiseId = '123';
    $schedule_obj->IsPremiere = TRUE;
    $schedule_obj->IsLive = TRUE;
    $schedule_obj->ScheduleAiringStartTime = '1234';
    $schedule_obj->NetworkFeedCode = '1';
    $schedule_obj->NewsUpdate = 'n';
    $schedule_obj->CC = 'closed captions';
    $schedule_obj->PreText = 'pre';

    $title = new \stdClass();
    $title->TitleId = 54321;

    $schedule_obj->titles = [$title];

    return $schedule_obj;
  }

  /**
   * Create a MockFieldItemList based on a MockFieldDefinition for a field.
   */
  private function getFieldItemList($type, $name, $label = '') {
    $field_definition = new MockFieldDefinition(array(), $type, $name, $label);
    $field_list = new MockFieldItemList($field_definition, array(), $name);
    return $field_list;
  }

  /**
   * Field Definitions.
   *
   * @return array
   *    List of field definitions.
   */
  private function fieldDefinitions() {

    $field_externalId = $this->getFieldItemList('integer', 'external_id');
    $field_uuid = $this->getFieldItemList('string', 'uuid');
    $field_label = $this->getFieldItemList('string', 'label');
    $field_changed = $this->getFieldItemList('changed', 'changed');
    $field_imported = $this->getFieldItemList('created', 'imported');
    $field_network = $this->getFieldItemList('string', 'network');
    $field_splatform = $this->getFieldItemList('string', 'platform');
    $field_source = $this->getFieldItemList('string', 'source');
    $field_startDate = $this->getFieldItemList('datetime', 'start_date');
    $field_endDate = $this->getFieldItemList('datetime', 'end_date');
    $field_preText = $this->getFieldItemList('string', 'pre_text');
    $field_timeZone = $this->getFieldItemList('string', 'time_zone');
    $field_isLive = $this->getFieldItemList('string', 'is_live');
    $field_isPremiere = $this->getFieldItemList('string', 'is_premiere');
    $field_franchiseName = $this->getFieldItemList('string', 'franchise_name');
    $field_franchiseId = $this->getFieldItemList('integer', 'franchise_id');
    $field_franchiseDuration = $this->getFieldItemList('integer', 'franchise_duration');
    $field_networkFeedCode = $this->getFieldItemList('string', 'network_feed_code');
    $field_scheduleAirDate = $this->getFieldItemList('datetime', 'schedule_air_date');
    $field_scheduleAiringStartTime = $this->getFieldItemList('integer', 'schedule_airing_start_time');
    $field_cc = $this->getFieldItemList('string', 'cc');
    $field_newsUpdate = $this->getFieldItemList('string', 'news_update');
    $field_contentJson = $this->getFieldItemList('string_long', 'content_json');
    $field_title_ids = $this->getFieldItemList('string_long', 'title_ids');

    return array(
      'external_id' => $field_externalId,
      'uuid' => $field_uuid,
      'label' => $field_label,
      'changed' => $field_changed,
      'imported' => $field_imported,
      'network' => $field_network,
      'platform' => $field_splatform,
      'source' => $field_source,
      'start_date' => $field_startDate,
      'end_date' => $field_endDate,
      'pre_text' => $field_preText,
      'time_zone' => $field_timeZone,
      'is_live' => $field_isLive,
      'is_premiere' => $field_isPremiere,
      'franchise_name' => $field_franchiseName,
      'franchise_id' => $field_franchiseId,
      'franchise_duration' => $field_franchiseDuration,
      'network_feed_code' => $field_networkFeedCode,
      'schedule_air_date' => $field_scheduleAirDate,
      'schedule_airing_start_time' => $field_scheduleAiringStartTime,
      'cc' => $field_cc,
      'news_update' => $field_newsUpdate,
      'content_json' => $field_contentJson,
      'title_ids' => $field_title_ids,
    );
  }

}
