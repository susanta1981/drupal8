<?php

namespace Drupal\Tests\draco_udi\Unit\Plugin\ContentRemover;

use Drupal\Tests\UnitTestCase;
use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\draco_udi\Plugin\ContentRemover\LinearScheduleRemover;
use Drupal\draco_udi\Entity\ContentLinearSchedule;
use Drupal\Core\Entity\EntityStorageException;

/**
 * Class LinearScheduleRemoverTest.
 *
 * @package Drupal\draco_udi\Tests\Unit\Plugin\ContenRemover
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Plugin\ContentRemover\LinearScheduleRemover
 */
class LinearScheduleRemoverTest extends UnitTestCase {

  /**
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * @var \Drupal\draco_udi\Plugin\ContentRemover\LinearScheduleRemover
   */
  protected $linearScheduleRemover;

  /**
   * @var \Drupal\draco_udi\Entity\ContentLinearSchedule
   */
  protected $linearSchedule;

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $this->logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory = $this->getMockBuilder('\Drupal\Core\Logger\LoggerChannelFactoryInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory->expects($this->any())
      ->method('get')
      ->will($this->returnValue($this->logger));

    $container = new ContainerBuilder();
    $container->set("logger.factory", $logger_factory);

    \Drupal::setContainer($container);

    $this->linearScheduleRemover = new LinearScheduleRemover([], 'foo', 'foo', $logger_factory);

    $this->linearSchedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentLinearSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $this->linearSchedule->expects($this->exactly(1))->method('createDuplicate')->willReturnSelf();
    $this->linearSchedule->expects($this->exactly(1))->method('delete');
    $this->linearSchedule->expects($this->exactly(1))->method('id')->willReturn(1);
  }

  /**
   * Test remove (no titles).
   *
   * @covers ::remove
   */
  public function testRemoveWithNoAssociatedTitles() {
    $this->linearSchedule->expects($this->exactly(1))->method('getTitleIds')->willReturn([]);
    $this->logger->expects($this->exactly(1))->method('info');

    $deleted_entities = $this->linearScheduleRemover->remove($this->linearSchedule);

    $this->assertEquals(count($deleted_entities), 1);

    $this->assertEquals($deleted_entities[\Drupal\draco_udi\Service\ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE], $this->linearSchedule);

  }

  /**
   * Test remove (with titles).
   *
   * @covers ::remove
   */
  public function testRemoveWithAssociatedTitles() {
    $this->linearSchedule->expects($this->exactly(1))->method('getTitleIds')->willReturn([123456]);
    $this->linearSchedule->expects($this->exactly(1))->method('setTitleIds')->withAnyParameters();
    $this->linearSchedule->expects($this->exactly(1))->method('set')->withAnyParameters();
    $this->linearSchedule->expects($this->exactly(1))->method('save');
    $this->logger->expects($this->exactly(1))->method('info');

    $deleted_entities = $this->linearScheduleRemover->remove($this->linearSchedule);

    $this->assertEquals(count($deleted_entities), 1);

    $this->assertEquals($deleted_entities[\Drupal\draco_udi\Service\ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE], $this->linearSchedule);
  }

  /**
   * Test remove (exception)
   *
   * @covers ::remove
   *
   * @expectedException \Drupal\Core\Entity\EntityStorageException
   */
  public function testRemoveWithException() {

    $this->linearSchedule->expects($this->exactly(1))->method('delete')->willThrowException(new EntityStorageException('test'));
    $this->logger->expects($this->exactly(1))->method('error');

    $this->linearScheduleRemover->remove($this->linearSchedule);
  }

}