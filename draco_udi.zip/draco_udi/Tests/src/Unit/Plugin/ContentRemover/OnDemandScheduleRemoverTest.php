<?php

namespace Drupal\Tests\draco_udi\Unit\Plugin\ContentRemover;

use Drupal\Tests\UnitTestCase;
use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\draco_udi\Plugin\ContentRemover\OnDemandScheduleRemover;
use Drupal\draco_udi\Entity\ContentOnDemandSchedule;
use Drupal\Core\Entity\EntityStorageException;

/**
 * Class OnDemandScheduleRemoverTest.
 *
 * @package Drupal\draco_udi\Tests\Unit\Plugin\ContenRemover
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Plugin\ContentRemover\LinearScheduleRemover
 */
class OnDemandScheduleRemoverTest extends UnitTestCase {

  /**
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * @var \Drupal\draco_udi\Plugin\ContentRemover\OnDemandScheduleRemover
   */
  protected $onDemandScheduleRemover;

  /**
   * @var \Drupal\draco_udi\Entity\ContentOnDemandSchedule
   */
  protected $onDemandSchedule;

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $this->logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory = $this->getMockBuilder('\Drupal\Core\Logger\LoggerChannelFactoryInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $logger_factory->expects($this->any())
      ->method('get')
      ->will($this->returnValue($this->logger));

    $container = new ContainerBuilder();
    $container->set("logger.factory", $logger_factory);

    \Drupal::setContainer($container);

    $this->onDemandScheduleRemover = new OnDemandScheduleRemover([], 'foo', 'foo', $logger_factory);

    $this->onDemandScheduleSchedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('createDuplicate')->willReturnSelf();
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('delete');
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('id')->willReturn(1);
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('getAiringId')->willReturn(111);
  }

  /**
   * Test remove (no flights).
   *
   * @covers ::remove
   */
  public function testRemoveWithNoAssociatedFlights() {
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('getFlights')->willReturn([]);
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('getTitleIds')->willReturn([123456]);
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('setTitleIds')->withAnyParameters();
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('set')->withAnyParameters();
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('save');
    $this->logger->expects($this->exactly(1))->method('info');

    $deleted_entities = $this->onDemandScheduleRemover->remove($this->onDemandScheduleSchedule);

    $this->assertEquals(count($deleted_entities), 2);
    $this->assertEquals(count($deleted_entities[\Drupal\draco_udi\Service\ContentFetchManager::CONTENT_ONDEMAND_FLIGHT_TYPE]), 0);
    $this->assertEquals(count($deleted_entities[\Drupal\draco_udi\Service\ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE]), 1);
  }

  /**
   * Test remove (with flights).
   *
   * @covers ::remove
   */
  public function testRemoveWithAssociatedFlights() {
    $flight = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandFlight')
      ->disableOriginalConstructor()
      ->getMock();

    $flight->expects($this->exactly(1))->method('createDuplicate')->willReturnSelf();
    $flight->expects($this->exactly(1))->method('delete');
    $flight->expects($this->exactly(1))->method('id')->willReturn(11);

    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('getFlights')->willReturn([$flight]);
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('removeFlight');
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('getTitleIds')->willReturn([123456]);
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('setTitleIds')->withAnyParameters();
    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('set')->withAnyParameters();
    $this->onDemandScheduleSchedule->expects($this->exactly(2))->method('save');
    $this->logger->expects($this->exactly(2))->method('info');

    $deleted_entities = $this->onDemandScheduleRemover->remove($this->onDemandScheduleSchedule);

    $this->assertEquals(count($deleted_entities), 2);
    $this->assertEquals(count($deleted_entities[\Drupal\draco_udi\Service\ContentFetchManager::CONTENT_ONDEMAND_FLIGHT_TYPE]), 1);
    $this->assertEquals(count($deleted_entities[\Drupal\draco_udi\Service\ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE]), 1);

  }

  /**
   * Test remove (exception).
   *
   * @covers ::remove
   *
   * @expectedException \Drupal\Core\Entity\EntityStorageException
   */
  public function testRemoveWithException() {

    $flight = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandFlight')
      ->disableOriginalConstructor()
      ->getMock();

    $flight->expects($this->exactly(1))->method('createDuplicate')->willReturnSelf();
    $flight->expects($this->exactly(1))->method('delete');
    $flight->expects($this->exactly(1))->method('id')->willReturn(11);

    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('getFlights')->willReturn([$flight]);

    $this->onDemandScheduleSchedule->expects($this->exactly(1))->method('delete')->willThrowException(new EntityStorageException('test'));
    $this->logger->expects($this->exactly(1))->method('error');

    $this->onDemandScheduleRemover->remove($this->onDemandScheduleSchedule);
  }

}