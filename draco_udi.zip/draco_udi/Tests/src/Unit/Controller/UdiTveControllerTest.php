<?php

namespace Drupal\tests\Unit\Controller;

use Drupal\draco_udi\Controller\UdiTveController;
use Drupal\Tests\UnitTestCase;

/**
 * Class UdiTveControllerTest.
 *
 * @package Drupal\tests\draco_udi\Controller
 *
 * @group draco_udi
 *
 * @coversDefaultClass Drupal\draco_udi\Controller\UdiTveController
 */
class UdiTveControllerTest extends UnitTestCase {


  protected $fetchManager;

  protected $controller;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    Parent::setUp();

    $this->fetchManager = $this->getMockBuilder('Drupal\draco_udi\Service\ContentFetchManager')
      ->disableOriginalConstructor()
      ->getMock();

    $logger = $this->getMockBuilder('Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $tveClient = $this->getMockBuilder('Drupal\draco_udi\Service\DataSource\Tve\TveClientInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->controller = new UdiTveController($this->fetchManager, $logger, $tveClient);

  }

  /**
   * Tests postTveJson.
   *
   * @covers ::__construct
   * @covers ::postTveJson
   */
  public function testPostTveJson() {
    $request = $this->getMockBuilder('Symfony\Component\HttpFoundation\Request')
      ->disableOriginalConstructor()
      ->getMock();
    $this->fetchManager->expects($this->once())->method('postTveJson')->willReturn(NULL);
    $response = $this->controller->postTveJson('123', $request);
    $this->assertEquals($response->getStatusCode(), 201);

  }

  /**
   * Tests postTveJson.
   *
   * @covers ::__construct
   * @covers ::postTveJson
   */
  public function testPostTveJsonWithException() {
    $request = $this->getMockBuilder('Symfony\Component\HttpFoundation\Request')
      ->disableOriginalConstructor()
      ->getMock();
    $this->fetchManager->expects($this->once())->method('postTveJson')->will($this->throwException(new \Exception("test Message")));
    $response = $this->controller->postTveJson('123', $request);
    $this->assertEquals($response->getStatusCode(), 500);
    $this->assertEquals($response->getContent(), "test Message");

  }

}
