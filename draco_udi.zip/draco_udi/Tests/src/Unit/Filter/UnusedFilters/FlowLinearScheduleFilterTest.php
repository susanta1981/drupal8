<?php

namespace Drupal\Tests\draco_udi\Unit\Filter\UnusedFilters;

use Drupal\draco_udi\Filter\UnusedFilters\FlowLinearScheduleFilter;
use Drupal\Tests\UnitTestCase;

/**
 * Class FlowLinearScheduleFilterTest.
 *
 * @package Drupal\draco_udi\Tests\Unit\Plugin\Filter
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Filter\UnusedFilters\FlowLinearScheduleFilter
 */
class FlowLinearScheduleFilterTest extends UnitTestCase {


  private $entity_manager;
  private $query_factory;
  private $logger;
  private $queryInterface;
  private $entityStorage;

  const SCHEDULE_NON_EPISODE = '
  {
	"_id": "578695ae18bcda09f41e5bb5",
	"ExternalId": "10061195",
	"StartDate": "2016-08-20T05:00:00.000Z",
	"EndDate": "2016-08-20T07:15:00.000Z",
	"Network": "TBS",
	"Titles": [{
		"TitleId": 19368,
		"ExternalAiringId": "8019628",
		"Name": "Kindergarten Cop",
		"SeriesTitleId": 0,
		"SeriesName": "",
		"ReleaseYear": 1990,
		"Rating": "TV-PG",
		"Type": "FF",
		"ReferenceNum": "",
		"SeasonNum": 0,
		"Storyline": "An undercover policeman poses as a pre-school teacher to protect a child from his at-large parolled father.",
		"Length": 110,
		"Descriptors": ["V", "L"],
		"StartOverAllowed": true,
		"TitleAvailWinId": 1287354,
		"VersionId": 675078
	}],
	"Platform": "Linear",
	"Source": "Linear",
	"Name": "Movie",
	"IsPremiere": "N",
	"IsLive": "T",
	"PreText": "97m",
	"FranchiseName": "Movie",
	"TimeZone": "Eastern Standard Time",
	"NetworkFeedCode": "E",
	"BreakStructure": "",
	"Sponsor": "",
	"FranchiseDuration": 135,
	"FranchiseId": 321362,
	"ScheduleAirDate": "2016-08-19T04:00:00.000Z",
	"ScheduleAiringStartTime": 90000,
	"CC": "Y",
	"NewsUpdate": 0,
	"ProcessedDatetimeUTC": "2016-07-13T19:25:34.830Z",
	"IsViewable": true
}';

  const SCHEDULE_EPISODE = '
  {
	"_id": "578695ae18bcda09f41e5ba9",
	"ExternalId": "10205734",
	"StartDate": "2016-07-19T02:30:00.000Z",
	"EndDate": "2016-07-19T03:00:00.000Z",
	"Network": "TBS",
	"Titles": [{
		"TitleId": 2061470,
		"ExternalAiringId": "7911022",
		"Name": "Cleveland",
		"SeriesTitleId": 2061452,
		"SeriesName": "Full Frontal with Samantha Bee",
		"ReleaseYear": 2016,
		"Rating": "TV-MA",
		"Type": "E",
		"ReferenceNum": "1018",
		"SeasonNum": 1,
		"Storyline": "Full Frontal visits Cleveland to see how the city is preparing for the Republican National Convention.",
		"Length": 0,
		"Descriptors": ["L"],
		"StartOverAllowed": true,
		"TitleAvailWinId": 1294293,
		"VersionId": 684966
	}],
	"Platform": "Linear",
	"Source": "Linear",
	"Name": "Full Frontal with Samantha Bee",
	"IsPremiere": "Y",
	"IsLive": "T",
	"PostText": "18 of 39",
	"FranchiseName": "Full Frontal with Samantha Bee",
	"TimeZone": "Eastern Standard Time",
	"NetworkFeedCode": "E",
	"BreakStructure": "",
	"Sponsor": "",
	"FranchiseDuration": 30,
	"FranchiseId": 416952,
	"ScheduleAirDate": "2016-07-18T04:00:00.000Z",
	"ScheduleAiringStartTime": 81000,
	"CC": "Y",
	"NewsUpdate": 0,
	"ProcessedDatetimeUTC": "2016-07-13T19:25:34.471Z",
	"IsViewable": true
}';

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    parent::setUp();
    $this->entity_manager = $this->getMockBuilder('Drupal\Core\Entity\EntityManager')
      ->disableOriginalConstructor()
      ->getMock();
    $this->query_factory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->queryInterface = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->queryInterface->expects($this->any())->method('condition')->willReturn($this->queryInterface);

    $this->query_factory->expects($this->any())->method('get')->willReturn($this->queryInterface);
    $this->logger = $this->getMockBuilder('Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entityStorage = $this->getMockBuilder('Drupal\Core\Entity\EntityStorageInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entity_manager->expects($this->any())->method('getStorage')->willReturn($this->entityStorage);

  }

  /**
   * Tests  Filtering Linear Schedule which is in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeInWhiteList
   */
  public function testNonEpisodeInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new FlowLinearScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is not in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeNotInWhiteList
   */
  public function testNonEpisodeNotInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new FlowLinearScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /**
   * Tests  Filtering Non Episode for which there is no whitelist.
   *
   * @covers ::isApprovedContent
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeNoWhiteList
   */
  public function testNonEpisodeNoWhitelist($content) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn([]);
    $titleFilter = new FlowLinearScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::belongsToSeries
   * @covers ::seriesOrEpisodeInWhiteList
   * @covers ::getSeriesTitleId
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider episodeInWhiteList
   */
  public function testEpisodeInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new FlowLinearScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is not in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider episodeNotInWhiteList
   */
  public function testEpisodeNotInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new FlowLinearScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /*   DATA PROVIDERS   */

  /**
   *
   */
  public function nonEpisodeInWhiteList() {
    $content = json_decode(self::SCHEDULE_NON_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '19368');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function nonEpisodeNotInWhiteList() {
    $content = json_decode(self::SCHEDULE_NON_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValues = array($whitelistValue1);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function nonEpisodeNoWhiteList() {
    $content = json_decode(self::SCHEDULE_NON_EPISODE);

    return array(
      array($content),
    );
  }

  /**
   *
   */
  public function episodeInWhiteList() {
    $content = json_decode(self::SCHEDULE_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '2061452');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function episodeNotInWhiteList() {
    $content = json_decode(self::SCHEDULE_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '10205734');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

}
