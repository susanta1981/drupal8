<?php

namespace Drupal\Tests\draco_udi\Unit\Filter\UnusedFilters;

use Drupal\draco_udi\Filter\UnusedFilters\OnDemandScheduleFilter;
use Drupal\Tests\UnitTestCase;

/**
 * Class FlowLinearScheduleFilterTest.
 *
 * @package Drupal\draco_udi\Tests\Unit\Plugin\Filter
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Filter\UnusedFilters\OnDemandScheduleFilter
 */
class OnDemandScheduleFilterTest extends UnitTestCase {


  private $entity_manager;
  private $query_factory;
  private $logger;
  private $queryInterface;
  private $entityStorage;

  const SCHEDULE_NON_EPISODE = '
  {
	"airingId": "CARE1006241600011998",
	"mediaId": "f04728aa8e72d15803de644eb1c5287a7c7ab980",
	"name": "Stack of Baby Bears",
	"type": "Special (Animated)",
	"brand": "Cartoon",
	"platform": "Broadband",
	"airings": [{
		"airingId": 0,
		"linked": false
	}],
	"deviceExclusions": [],
	"webFlags": [],
	"releasedOn": "2016-07-07T16:56:29.791Z",
	"releasedBy": "CRivard",
	"options": {
		"titles": [{
			"titleId": 2092936,
			"seasonNumber": 0,
			"releaseYear": 2016,
			"titleName": "Stack of Baby Bears",
			"titleNameSortable": "Stack of Baby Bears",
			"titleType": "{\"Name\":\"Special\",\"TitleTypeId\":15,\"TitleTypeCode\":\"PA\"}",
			"episodeNumber": ""
		}],
		"series": [],
		"changes": []
	},
	"properties": {}
}';

  const SCHEDULE_EPISODE = '
  {
	"airingId": "TBSE1006011600032147",
	"mediaId": "f6e7f652d0e8bdd14eb4a5ac2efb90a7e47d00e0",
	"name": "One Where Rachel Finds Out, The",
	"type": "Episode (Non-Animated)",
	"brand": "TBS",
	"platform": "Broadband",
	"airings": [{
		"date": "2016-07-09T19:30:00Z",
		"airingId": 7972981,
		"linked": true
	}],
	"deviceExclusions": [],
	"webFlags": [],
	"releasedOn": "2016-06-03T15:16:18.154Z",
	"releasedBy": "Ecolbert",
	"options": {
		"titles": [{
			"titleId": 338631,
			"seriesTitleId": 322296,
			"seasonNumber": 1,
			"releaseYear": 1994,
			"titleName": "The One Where Rachel Finds Out",
			"titleNameSortable": "One Where Rachel Finds Out, The",
			"titleType": "{\"Name\":\"Episode\",\"TitleTypeId\":6,\"TitleTypeCode\":\"E\"}",
			"seriesTitleName": "Friends",
			"seriesTitleNameSortable": "Friends",
			"episodeNumber": "24"
		}],
		"series": [],
		"changes": []
	},
	"properties": {}
}';

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    parent::setUp();
    $this->entity_manager = $this->getMockBuilder('Drupal\Core\Entity\EntityManager')
      ->disableOriginalConstructor()
      ->getMock();
    $this->query_factory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->queryInterface = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->queryInterface->expects($this->any())->method('condition')->willReturn($this->queryInterface);

    $this->query_factory->expects($this->any())->method('get')->willReturn($this->queryInterface);
    $this->logger = $this->getMockBuilder('Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entityStorage = $this->getMockBuilder('Drupal\Core\Entity\EntityStorageInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entity_manager->expects($this->any())->method('getStorage')->willReturn($this->entityStorage);

  }

  /**
   * Tests  Filtering ODT Schedule which is in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::getTitleId
   * @covers ::getContentType
   * @covers ::getSeriesTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeInWhiteList
   */
  public function testNonEpisodeInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new OnDemandScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is not in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::getTitleId
   * @covers ::getContentType
   * @covers ::getSeriesTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeNotInWhiteList
   */
  public function testNonEpisodeNotInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new OnDemandScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /**
   * Tests  Filtering Non Episode for which there is no whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::getTitleId
   * @covers ::getContentType
   * @covers ::getSeriesTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider nonEpisodeNoWhiteList
   */
  public function testNonEpisodeNoWhitelist($content) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn([]);
    $titleFilter = new OnDemandScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::getSeriesId
   * @covers ::checkTitles
   * @covers ::getTitleId
   * @covers ::getContentType
   * @covers ::getSeriesTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider episodeInWhiteList
   */
  public function testEpisodeInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new OnDemandScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertTrue($isApproved);
  }

  /**
   * Tests  Filtering Non Episode which is not in the whitelist.
   *
   * @covers ::isApprovedContent
   * @covers ::getTitleId
   * @covers ::getContentType
   * @covers ::getSeriesTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::contentInWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getTitleId
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getContentType
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::getWhiteList
   * @covers \Drupal\draco_udi\Plugin\Filter\WhitelistFilter::isTitleidInArray
   *
   * @dataProvider episodeNotInWhiteList
   */
  public function testEpisodeNotInWhitelist($content, $whitelist_ids, $whitelist) {

    $this->queryInterface->expects($this->any())->method('execute')->willReturn($whitelist_ids);
    $this->entityStorage->expects($this->any())->method('load')->willReturn($whitelist);
    $titleFilter = new OnDemandScheduleFilter([], 'foo', 'foo', $this->query_factory, $this->entity_manager, $this->logger);
    $isApproved = $titleFilter->isApprovedContent($content);
    $this->assertFalse($isApproved);
  }

  /*   DATA PROVIDERS   */

  /**
   *
   */
  public function nonEpisodeInWhiteList() {
    $content = json_decode(self::SCHEDULE_NON_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '2092936');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function nonEpisodeNotInWhiteList() {
    $content = json_decode(self::SCHEDULE_NON_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValues = array($whitelistValue1);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function nonEpisodeNoWhiteList() {
    $content = json_decode(self::SCHEDULE_NON_EPISODE);

    return array(
      array($content),
    );
  }

  /**
   *
   */
  public function episodeInWhiteList() {
    $content = json_decode(self::SCHEDULE_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '322296');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

  /**
   *
   */
  public function episodeNotInWhiteList() {
    $content = json_decode(self::SCHEDULE_EPISODE);
    $whitelistValue1 = array('id' => 'foo');
    $whitelistValue2 = array('id' => '338631');
    $whitelistValues = array($whitelistValue1, $whitelistValue2);
    $whiteList = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentWhiteList')
      ->disableOriginalConstructor()
      ->getMock();

    $whiteList->expects($this->any())->method('getTitleIds')->willReturn($whitelistValues);
    $whitelistIds = ['foo'];

    return array(
      array($content, $whitelistIds, $whiteList),
    );
  }

}
