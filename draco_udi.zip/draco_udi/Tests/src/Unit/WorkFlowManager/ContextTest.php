<?php

namespace Drupal\Tests\draco_udi\Unit\WorkFlowManager;

use Drupal\draco_udi\Context;
use Drupal\draco_udi\DataChange\DataChangeDecision;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\Tests\UnitTestCase;

/**
 * Class ContextTest.
 *
 * @package Drupal\Tests\draco_udi\Unit\WorkFlowManager
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Context
 *
 */
class ContextTest extends UnitTestCase {

  /**
   * Test getters/setters.
   *
   * @covers ::getAction
   * @covers ::setAction
   * @covers ::getEntityType
   * @covers ::setEntityType
   * @covers ::getSourceContent
   * @covers ::setSourceContent
   * @covers ::getExistingEntity
   * @covers ::setExistingEntity
   * @covers ::getCurrentEntity
   * @covers ::setCurrentEntity
   * @covers ::getEntityToSave
   * @covers ::setEntityToSave
   * @covers ::addDeletedEntity
   * @covers ::setDeletedEntities
   * @covers ::getDeletedEntities
   * @covers ::getRelatedData
   * @covers ::setRelatedData
   */
  public function testGettersAndSetters() {
    $context = new Context();

    $deleted_entity = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentLinearSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $context->addDeletedEntity($deleted_entity);

    $this->assertEquals(count($context->getDeletedEntities()), 1);

    $context->setDeletedEntities([$deleted_entity]);

    $this->assertEquals(count($context->getDeletedEntities()), 1);

    $context->setAction(ContentFetchManager::CONTENT_UPSERT_ACTION);
    $this->assertEquals($context->getAction(), ContentFetchManager::CONTENT_UPSERT_ACTION);

    $content = new \stdClass();
    $content->Type = 'Episode';

    $context->setSourceContent($content);
    $this->assertEquals($context->getSourceContent(), $content);

    $context->setEntitySource(ContentFetchManager::CONTENT_SOURCE_ODT);
    $this->assertEquals($context->getEntitySource(), ContentFetchManager::CONTENT_SOURCE_ODT);

    $entity = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $context->setExistingEntity($entity);
    $context->setCurrentEntity($entity);
    $context->setEntityToSave($entity);
    $this->assertEquals($context->getExistingEntity(), $entity);
    $this->assertEquals($context->getCurrentEntity(), $entity);
    $this->assertEquals($context->getEntityToSave(), $entity);

    $context->setEntityType(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);
    $this->assertEquals($context->getEntityType(), ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);

    $decision = new DataChangeDecision();
    $context->setDataChangeDecision($decision);
    $this->assertEquals($context->getDataChangeDecision(), $decision);

    $context->setRelatedData([$entity]);
    $this->assertEquals($this->count($context->getRelatedData()), 1);

  }
}