<?php

namespace Drupal\Tests\draco_udi\Unit\WorkFlowManager;

use Drupal\draco_udi\ContentDataImportWorkflowManager;
use Drupal\draco_udi\Context;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Exception\UdiContentNotFoundException;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\WorkflowReport;
use Drupal\Tests\UnitTestCase;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;

/**
 * Class WorkFlowManagerTest.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\ContentDataImportWorkflowManager
 */
class ContentDataImportWorkflowManagerTest extends UnitTestCase {

  protected $workFlowManager;
  protected $converterManager;
  protected $mapperManager;
  protected $changeApprover;
  protected $decisionProcessor;
  protected $dataPreparer;
  protected $contentRemoverManager;
  protected $contentRemover;
  protected $logger;
  protected $mapper;
  protected $eventDispatcher;

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $this->logger = $this->getMockBuilder('Drupal\draco_logging\Diagnostic\DiagnosticLoggerChannelFactory')
      ->disableOriginalConstructor()
      ->getMock();
    $loggerchannel = $this->getMockBuilder('Drupal\draco_logging\Diagnostic\DiagnosticLoggerChannel')
      ->disableOriginalConstructor()
      ->getMock();

    $this->logger->expects($this->any())->method('get')->willReturn($loggerchannel);

    $this->converterManager = $this->getMockBuilder('Drupal\draco_udi\Service\ContentConverter\ContentConverterManager')
      ->disableOriginalConstructor()
      ->getMock();

    $this->mapperManager = $this->getMockBuilder('Drupal\draco_udi\Mapper\DracoDataMapperManager')
      ->disableOriginalConstructor()
      ->getMock();
    $this->mapper = $this->getMockBuilder('Drupal\draco_udi\Mapper\DracoMapperInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->mapperManager->expects($this->any())->method('getMappers')->willReturn([$this->mapper]);

    $this->changeApprover = $this->getMockBuilder('Drupal\draco_udi\DataChange\DataChangeDecisionStrategyManager')
      ->disableOriginalConstructor()
      ->getMock();
    $approver = $this->getMockBuilder('Drupal\draco_udi\DataChange\DataChangeDecisionStrategyInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $definitions = array('foodef' => 'fooapprover');
    $decision  = $this->getMockBuilder('Drupal\draco_udi\DataChange\DataChangeDecision')
      ->disableOriginalConstructor()
      ->getMock();

    $approver->expects($this->any())->method('decide')->willReturn($decision);
    $this->changeApprover->expects($this->any())->method('getDefinitions')->willReturn($definitions);
    $this->changeApprover->expects($this->any())->method('createInstance')->willReturn($approver);
    $this->decisionProcessor = $this->getMockBuilder('Drupal\draco_udi\DataChange\DataChangeDecisionProcessor')
      ->disableOriginalConstructor()
      ->getMock();

    $this->dataPreparer = $this->getMockBuilder('Drupal\draco_udi\Service\Preparation\DataChangePreparerInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->contentRemoverManager = $this->getMockBuilder('Drupal\draco_udi\Service\ContentRemover\ContentRemoverManager')
      ->disableOriginalConstructor()
      ->getMock();

    $this->contentRemover = $this->getMockBuilder('Drupal\draco_udi\Service\ContentRemover\ContentRemoverInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->contentRemover->expects($this->any())->method('remove');
    $this->contentRemoverManager->expects($this->any())->method('getRemover')->willReturn([$this->contentRemover]);

    $this->eventDispatcher = $this->getMockBuilder('\Symfony\Component\EventDispatcher\EventDispatcherInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->eventDispatcher->expects($this->any())->method('dispatch');
  }

  /**
   * Test importing a title.
   *
   * @covers ::__construct
   * @covers ::import
   * @covers ::convertContentDataToDracoEntity
   * @covers ::mapToContentEntity
   * @covers ::evaluateContentEntities
   * @covers ::getWorkflowReport
   *
   * @dataProvider titleData
   */
  public function testImportTitle($newTitle, $existingTitle, $mappedEntities) {

    $converter = $this->getMockBuilder('Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $entitySet = new ConvertedEntitySet($newTitle, $existingTitle, $existingTitle);
    $converter->expects($this->once())->method('findExistingEntity')->willReturn($existingTitle);
    $converter->expects($this->once())->method('convert')->willReturn($entitySet);

    $this->converterManager->expects($this->any())->method('getConverters')->willReturn([$converter]);
    $relatedData = array(
      CONTEXT::RELATED_TO_BE_MAPPED_KEY => [$existingTitle],

    );

    $existingTitle->expects($this->any())->method('id')->willReturn('titlefoo');
    $existingTitle->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $existingTitle->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);

    $this->mapper->expects($this->once())->method('map')->willReturn($mappedEntities);
    $context = new Context();
    $context->setEntityToSave($existingTitle);
    $context->setCurrentEntity($existingTitle);
    $context->setExistingEntity($existingTitle);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_TITLE_TYPE);
    $context->setEntitySource(ContentFetchManager::CONTENT_SOURCE_FLOW);

    $this->dataPreparer->expects($this->once())->method('prepareContext')->willReturn($context);

    $this->decisionProcessor->expects($this->once())->method('process')->willReturn($context);

    $workFlowManager = new ContentDataImportWorkflowManager($this->logger, $this->converterManager, $this->mapperManager,
      $this->changeApprover, $this->decisionProcessor, $this->dataPreparer, $this->eventDispatcher);
    $reports = $workFlowManager->import($newTitle, ContentFetchManager::CONTENT_TITLE_TYPE, ContentFetchManager::CONTENT_UPSERT_ACTION);

    $this->assertEquals($context->getAction(), ContentFetchManager::CONTENT_UPSERT_ACTION);

    $this->assertEquals($this->count($reports), 1);

    $report = reset($reports);

    $this->assertTrue($report instanceof WorkflowReport);

    /** @var WorkflowReport $report */
    $this->assertEquals($report->getAction(), ContentFetchManager::CONTENT_UPSERT_ACTION);
    $this->assertEquals($report->getContentSource(), ContentFetchManager::CONTENT_SOURCE_FLOW);
    $this->assertEquals($report->getContentType(), ContentFetchManager::CONTENT_TITLE_TYPE);
    $this->assertEquals($report->getStatus(), WorkflowReport::COMPLETE);

  }

  /**
   * Test removing a ContentLinearSchedule entity.
   *
   * @covers ::__construct
   * @covers ::remove
   * @covers ::evaluateContentEntities
   * @covers ::loadExistingEntity
   * @covers ::getWorkflowReport
   */
  public function testRemoveLinearSchedule() {
    $linear_schedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentLinearSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $converter = $this->getMockBuilder('Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->converterManager->expects($this->any())->method('getConverters')->willReturn([$converter]);
    $converter->expects($this->once())->method('findExistingEntity')->willReturn($linear_schedule);

    $context = $this->getTestContextForRemove($linear_schedule,
      ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE,
      ContentFetchManager::CONTENT_SOURCE_FLOW);

    $this->dataPreparer->expects($this->once())->method('prepareContextForRemoveEntity')->willReturn($context);

    $this->decisionProcessor->expects($this->once())->method('process')->willReturn($context);

    $workFlowManager = new ContentDataImportWorkflowManager($this->logger, $this->converterManager, $this->mapperManager,
      $this->changeApprover, $this->decisionProcessor, $this->dataPreparer, $this->eventDispatcher);

    $reports = $workFlowManager->remove($this->getDeletedMessage(), ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE, ContentFetchManager::CONTENT_DELETE_ACTION);

    $this->assertEquals($context->getAction(), ContentFetchManager::CONTENT_DELETE_ACTION);

    $this->assertEquals($this->count($reports), 1);

    $report = reset($reports);

    $this->assertTrue($report instanceof WorkflowReport);

    $this->assertEquals($report->getAction(), ContentFetchManager::CONTENT_DELETE_ACTION);
    $this->assertEquals($report->getContentSource(), ContentFetchManager::CONTENT_SOURCE_FLOW);
    $this->assertEquals($report->getContentType(), ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE);
    $this->assertEquals($report->getStatus(), WorkflowReport::COMPLETE);
  }

  /**
   * Test removing a ContentLinearSchedule entity.
   *
   * @covers ::__construct
   * @covers ::remove
   * @covers ::evaluateContentEntities
   * @covers ::loadExistingEntity
   * @covers ::getWorkflowReport
   */
  public function testRemoveOnDemandSchedule() {
    $ondemand_schedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $converter = $this->getMockBuilder('Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->converterManager->expects($this->any())->method('getConverters')->willReturn([$converter]);
    $converter->expects($this->once())->method('findExistingEntity')->willReturn($ondemand_schedule);

    $context = $this->getTestContextForRemove($ondemand_schedule,
      ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE,
      ContentFetchManager::CONTENT_SOURCE_ODT);

    $this->dataPreparer->expects($this->once())->method('prepareContextForRemoveEntity')->willReturn($context);

    $this->decisionProcessor->expects($this->once())->method('process')->willReturn($context);

    $workFlowManager = new ContentDataImportWorkflowManager($this->logger, $this->converterManager, $this->mapperManager,
      $this->changeApprover, $this->decisionProcessor, $this->dataPreparer, $this->eventDispatcher);

    $reports = $workFlowManager->remove($this->getDeletedMessage(),
      ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE,
      ContentFetchManager::CONTENT_DELETE_ACTION);

    $this->assertEquals($context->getAction(), ContentFetchManager::CONTENT_DELETE_ACTION);

    $this->assertEquals($this->count($reports), 1);

    $report = reset($reports);

    $this->assertTrue($report instanceof WorkflowReport);

    $this->assertEquals($report->getAction(), ContentFetchManager::CONTENT_DELETE_ACTION);
    $this->assertEquals($report->getContentSource(), ContentFetchManager::CONTENT_SOURCE_ODT);
    $this->assertEquals($report->getContentType(), ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);
    $this->assertEquals($report->getStatus(), WorkflowReport::COMPLETE);
  }

  /**
   * Test removing a ContentLinearSchedule entity but not found in db.
   *
   * @covers ::__construct
   * @covers ::remove
   * @covers ::loadExistingEntity
   * @covers ::getWorkflowReport
   *
   * @expectedException \Drupal\draco_udi\Exception\UdiContentNotFoundException
   */
  public function testRemoveWithNoEntityFound() {
    $converter = $this->getMockBuilder('Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->converterManager->expects($this->any())->method('getConverters')->willReturn([$converter]);
    $converter->expects($this->once())->method('findExistingEntity')->willReturn(NULL);

    $this->dataPreparer->expects($this->never())->method('prepareContextForRemoveEntity');
    $this->decisionProcessor->expects($this->never())->method('process');

    $workFlowManager = new ContentDataImportWorkflowManager($this->logger, $this->converterManager, $this->mapperManager,
      $this->changeApprover, $this->decisionProcessor, $this->dataPreparer, $this->eventDispatcher);

    $reports = $workFlowManager->remove(
      $this->getDeletedMessage(),
      ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE,
      ContentFetchManager::CONTENT_DELETE_ACTION);
  }

  /**
   * Test removing a ContentLinearSchedule entity but not found in db.
   *
   * @covers ::__construct
   * @covers ::remove
   *
   * @expectedException \Exception
   */
  public function testRemoveWithProcessException() {
    $linear_schedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentLinearSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $context = $this->getTestContextForRemove($linear_schedule,
      ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE,
      ContentFetchManager::CONTENT_SOURCE_FLOW);

    $converter = $this->getMockBuilder('Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->converterManager->expects($this->once())->method('getConverters')->willReturn([$converter]);
    $converter->expects($this->once())->method('findExistingEntity')->willReturn($linear_schedule);

    $this->dataPreparer->expects($this->once())->method('prepareContextForRemoveEntity')->willReturn($context);
    $this->decisionProcessor->expects($this->once())->method('process')->willThrowException(new \Exception('process error'));

    $workFlowManager = new ContentDataImportWorkflowManager($this->logger, $this->converterManager, $this->mapperManager,
      $this->changeApprover, $this->decisionProcessor, $this->dataPreparer, $this->eventDispatcher);

    $workFlowManager->remove($this->getDeletedMessage(),
      ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE,
      ContentFetchManager::CONTENT_DELETE_ACTION);
  }

  /**
   * Title Data.
   */
  public function titleData() {

    $newTitle = new \stdClass();

    $existingTitle = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mappedEntities = [$mapped1, $mapped2];
    return array(
      array($newTitle, $existingTitle, $mappedEntities),
    );
  }

  /**
   * Return an entity to be removed.
   *
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $entity
   *    Draco entity.
   * @param string $type
   *   Content type.
   * @param string $source
   *   Content source.
   *
   * @return \Drupal\draco_udi\Context
   *   Draco context.
   */
  private function getTestContextForRemove(DracoContentInterface $entity, $type, $source) {
    $context = new Context();
    $context->setCurrentEntity($entity);
    $context->setExistingEntity($entity);
    $context->setEntityType($type);
    $context->setEntitySource($source);

    return $context;
  }

  /**
   * Return a sample json deleted-since message.
   *
   * @return \stdClass
   *    Message downloaded from Flow.
   */
  private function getDeletedMessage() {
    $message = new \stdClass();
    $message->id = '581cf0ff18bcda1208ea8254';
    $message->ExternalId = 10329567;
    $message->ProcessedDatetimeUTC = '2016-11-04T20:35:11.104Z';
    return $message;
  }

}
