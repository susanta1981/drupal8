<?php

namespace Drupal\Tests\draco_udi\Unit\Service\Tools;
use Drupal\draco_udi\Service\Tools\DracoIdTools;
use Drupal\Tests\UnitTestCase;
use \org\bovigo\vfs\vfsStream;

/**
 * Tests The DracoIdTools class.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\Tools\DracoIdTools
 */
class DracoIdToolsTest extends UnitTestCase {

  protected $dirRoot;
  protected $titleTools;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    $logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->titleTools = new DracoIdTools($logger);
  }

  /**
   * @covers ::__construct
   * @covers ::getIdsFromFile
   *
   */
  public function testGetIdsFromFile() {
    $this->dirRoot = vfsStream::setup('uditest');
    file_put_contents(vfsStream::url('uditest/filewithids.txt'),"12345\n76655\n876654");
    $titleIds = $this->titleTools->getIdsFromFile(vfsStream::url('uditest/filewithids.txt'));
    $this->assertEquals(3,count($titleIds));
    $this->assertEquals('12345',$titleIds[0]);
    $this->assertEquals('876654',$titleIds[2]);
  }

  /**
   * @covers ::__construct
   * @covers ::getIdsFromFile
   *
   */
  public function testGetIdsFromEmptyFile() {
    $this->dirRoot = vfsStream::setup('uditest');
    file_put_contents(vfsStream::url('uditest/filewithids.txt'),"");
    $titleIds = $this->titleTools->getIdsFromFile(vfsStream::url('uditest/filewithids.txt'));
    $this->assertEquals(0,count($titleIds));
  }

  /**
   * @covers ::__construct
   * @covers ::getIdsFromFile
   *
   */
  public function testGetIdsFromMissingFile() {
    $this->dirRoot = vfsStream::setup('uditest');
    $titleIds = $this->titleTools->getIdsFromFile(vfsStream::url('uditest/filewithids.txt'));
    $this->assertEquals(0,count($titleIds));
  }


  /**
   * @covers ::__construct
   * @covers ::getIdsFromDrushArgs
   *
   */
  public function testGetIdsFromDrushArgs() {
    $args = [];
    $args[0] = 'foo';
    $args[1] = '12345';
    $args[2] = '76655';
    $args[3] = '876654';

    $titleIds = $this->titleTools->getIdsFromDrushArgs($args);
    $this->assertEquals(3,count($titleIds));
    $this->assertEquals('12345',$titleIds[0]);
    $this->assertEquals('876654',$titleIds[2]);
  }

  /**
   * @covers ::__construct
   * @covers ::getIdsFromDrushArgs
   *
   */
  public function testGetIdsFromDrushArgsWithNoargs() {
    $args = [];
    $args[0] = 'foo';

    $titleIds = $this->titleTools->getIdsFromDrushArgs($args);
    $this->assertEquals(0,count($titleIds));
  }

  /**
   * @covers ::__construct
   * @covers ::getIdsFromDrushArgs
   *
   */
  public function testGetIdsFromDrushArgsWithEmpty() {
    $args = [];

    $titleIds = $this->titleTools->getIdsFromDrushArgs($args);
    $this->assertEquals(0,count($titleIds));
  }
}