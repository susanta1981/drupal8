<?php

namespace Drupal\Tests\draco_ddc\Unit\Service\DataSource\Flow;

use Drupal\Tests\UnitTestCase;
use Drupal\draco_udi\Service\DataSource\Flow\FlowObjectIdGenerator;

/**
 * Class FlowObjectIdGenerator.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\DataSource\Flow\FlowObjectIdGenerator
 */
class FlowObjectIdGeneratorTest extends UnitTestCase {

  /**
   * Test generating Flow Id.
   *
   * @covers ::generate
   */
  public function testGenerate() {

    $dateTime = \DateTime::createFromFormat('Y-m-d H:i:s', '2013-05-23 00:00:00');

    $flowObjectIdGenerator = new FlowObjectIdGenerator(1);

    $objectId = $flowObjectIdGenerator->generate($dateTime, 'fooHost', 123);

    $this->assertEquals('519CCF60393830007B000001', $objectId, 'Incorrect object id');
  }

  /**
   * Test extracting timestamp from flow id.
   *
   * @covers ::getTimeStampFromFlowObjectId
   */
  public function testTimeStampFromFlowObjectId() {

    $dateTime = \DateTime::createFromFormat('Y-m-d H:i:s', '2013-05-23 00:00:00');
    $orginalTs = $dateTime->getTimestamp();

    $flowObjectIdGenerator = new FlowObjectIdGenerator(1);

    $objectId = $flowObjectIdGenerator->generate($dateTime, 'fooHost', 123);
    $newTs = $flowObjectIdGenerator->getTimeStampFromFlowObjectId($objectId);

    $this->assertEquals($orginalTs, $newTs, 'Timestamps do not match');
  }

}
