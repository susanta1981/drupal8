<?php

namespace Drupal\Tests\draco_udi\Unit\Service\DataSource\Flow;

use Drupal\draco_udi\Service\DataSource\Flow\FlowClient;
use Drupal\Tests\UnitTestCase;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use Psr\Http\Message\RequestInterface;

/**
 * Tests The FlowClient class.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\DataSource\Flow\FlowClient
 */
class FlowClientTest extends UnitTestCase {

  protected $config;

  protected $logger;

  /**
   * The flow client under test.
   *
   * @var \Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface
   */
  protected $flowClient;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    $this->config = $this->getConfigFactoryStub($this->getConfigData(TRUE, TRUE));
    $this->logger = $this->getMockLogger();
  }

  /**
   * Test that an exception is thrown when the root path is not defined.
   *
   * @covers ::__construct
   *
   * @expectedException \Drupal\Core\Config\ConfigException
   *
   * @expectedExceptionMessage Flow root path is not defined.
   */
  public function testCreateWithRootPathNotSetException() {
    $client = $this->getClient();
    /** @var \Drupal\Core\Config\ConfigFactoryInterface $config */
    $config = $this->getConfigFactoryStub($this->getConfigData(FALSE, TRUE));

    $this->flowClient = new FlowClient($config, $this->logger, $client);
  }

  /**
   * Test that an exception is thrown when credentials are missing.
   *
   * @covers ::__construct
   *
   * @expectedException \Drupal\Core\Config\ConfigException
   *
   * @expectedExceptionMessage Flow auth key is not defined.
   */
  public function testCreateWithAuthKeyNotSetException() {
    $client = $this->getClient();
    /** @var \Drupal\Core\Config\ConfigFactoryInterface $config */
    $config = $this->getConfigFactoryStub($this->getConfigData(TRUE, FALSE));

    $this->flowClient = new FlowClient($config, $this->logger, $client);
  }

  /**
   * Tests response from bad http request.
   *
   * @covers ::getLinearSchedulesByExternalIds
   * @covers ::__construct
   */
  public function testGetLinearSchedulesByExternalIds() {
    $externalIds = ['10000'];
    $client = $this->getClient();
    $this->flowClient = new FlowClient($this->config, $this->logger, $client);

    $this->assertNotNull($this->flowClient);

    $obj = $this->flowClient->getLinearSchedulesByExternalIds($externalIds);
    $this->assertNotNull($obj);

  }

  /**
   * Tests response from bad http request.
   *
   * @covers ::getLinearSchedulesByExternalIds
   * @covers ::__construct
   */
  public function testGetLinearSchedulesByExternalIdsWithNoIdPassed() {
    $ids = [];
    $client = $this->getClient();
    $this->flowClient = new FlowClient($this->config, $this->logger, $client);

    $this->assertNotNull($this->flowClient);

    try {
      $this->flowClient->getLinearSchedulesByExternalIds($ids);
    }
    catch (\InvalidArgumentException $ex) {
      $this->assertTrue($ex instanceof \InvalidArgumentException);
      $this->assertEquals($ex->getMessage(), 'No external ids are passed in. At least one is required.');
    }
  }

  /**
   * Tests response from bad http request.
   *
   * @covers ::getLinearSchedulesByExternalIds
   * @covers ::__construct
   */
  public function testGetLinearSchedulesByExternalIdsWithMoreThan25IdsPassed() {
    $ids = [];
    $count = 0;

    while ($count < 27) {
      $ids[] = $count;
      $count++;
    }
    $client = $this->getClient();
    $this->flowClient = new FlowClient($this->config, $this->logger, $client);

    $this->assertNotNull($this->flowClient);

    try {
      $this->flowClient->getLinearSchedulesByExternalIds($ids);
    }
    catch (\InvalidArgumentException $ex) {
      $this->assertTrue($ex instanceof \InvalidArgumentException);
      $this->assertEquals($ex->getMessage(), 'More than 25 external ids passed in. Only 25 is allowed.');
    }
  }

  /**
   * Test getting updated titles since a given date.
   *
   * @covers ::getTitlesUpdatedSince
   */
  public function testGetTitlesUpdatedSince() {
    // Since the title ID is dependent on the current time, we have to use
    // pattern matching.
    $mock = new MockHandler([
      function (RequestInterface $request, $options) {
        $this->assertStringMatchesFormat('http://test.flow.linear.schedule/v2/title/since/%s?api_key=key123', (string) $request->getUri());
        return new Response(200, [], '{}');
      },
    ]);
    $client = new Client(['handler' => $mock]);

    $logger = $this->getMockLogger();
    $logger->expects($this->once())
      ->method('debug');

    $flow_client = new FlowClient($this->config, $logger, $client);
    $since = new \DateTime();
    $titles = $flow_client->getTitlesUpdatedSince($since);
    $this->assertInstanceOf(\stdClass::class, $titles);
  }

  /**
   * Test getting updated titles for a given network ID.
   *
   * @covers ::getTitlesUpdatedSince
   */
  public function testGetTitlesUpdatedSinceNetworkId() {
    $mock = new MockHandler([
      function (RequestInterface $request, $options) {
        $this->assertStringMatchesFormat('http://test.flow.linear.schedule/v2/title/since/%s/kitten-tv?api_key=key123', (string) $request->getUri());
        return new Response(200, [], '{}');
      },
    ]);
    $client = new Client(['handler' => $mock]);

    $defaults = $this->getConfigData(TRUE, TRUE);
    $defaults['draco_udi.settings']['flow_settings.flow_network_id'] = 'kitten-tv';
    /** @var \Drupal\Core\Config\ConfigFactoryInterface $config */
    $config = $this->getConfigFactoryStub($defaults);

    $logger = $this->getMockLogger();
    $logger->expects($this->once())
      ->method('debug');
    $flow_client = new FlowClient($config, $logger, $client);

    $since = new \DateTime();
    $titles = $flow_client->getTitlesUpdatedSince($since);
    $this->assertInstanceOf(\stdClass::class, $titles);
  }

  /**
   * Test get BSON ID From Flow for a provided start date.
   *
   * @covers ::getBSONIdFromFlow
   */
  public function testGetBSONIdFromFlow() {
    $client = $this->getClient(FALSE);
    $this->flowClient = new FlowClient($this->config, $this->logger, $client);

    $date = new \DateTime();
    $bson_id = $this->flowClient->getBSONIdFromFlow($date);

    $this->assertEquals($bson_id, json_decode($this->getBSONIdData())[0]->_id);
  }

  /**
   * Create a mock http client.
   *
   * @param bool $is_content
   *   Flag indicating if return a content data or BSON ID.
   *
   * @return \GuzzleHttp\Client
   *   The mock HTTP client.
   */
  private function getClient($is_content = TRUE) {

    if ($is_content) {
      $mock = new MockHandler([
        new Response(200, [], $this->getScheduleData()),
      ]);
    }
    else {
      $mock = new MockHandler([
        new Response(200, [], $this->getBSONIdData()),
      ]);
    }

    $handler = HandlerStack::create($mock);
    $client = new Client(['handler' => $handler]);

    return $client;
  }

  /**
   * Create schedule data object and encode it to a json string.
   *
   * @return string
   *   A json string of schedule data.
   */
  private function getScheduleData() {
    $data = new \stdClass();
    $data->ExternalId = '10000';
    $data->StartDate = '2009-11-21T02:00:00.000Z';
    $data->EndDate = '2009-11-21T02:00:00.000Z';
    $data->Network = 'TBS';

    $titles = [];
    $title = new \stdClass();
    $title->TitleId = '755285';
    $title->Name = 'CNN Larry King Live  # 209';
    $titles[] = $title;

    $data->Titles = $titles;

    return json_encode($data);
  }

  /**
   * Return a BSON ID data.
   *
   * @return string
   *    A json string of BSON id data.
   */
  private function getBSONIdData() {
    $data = new \stdClass();
    $data->_id = '58546a002cfc5f1a98ddaa1c';
    $data->ExternalId = '10408215';
    $data->ProcessedDatetimeUTC = '2016-12-16T22:26:08.919Z';

    return json_encode([$data]);
  }

  /**
   * Create config data.
   *
   * @param bool $setRoot
   *   Set to TRUE to set the flow_root configuration setting.
   * @param bool $setKey
   *   Set to TRUE to set the flow_auth_key configuration setting.
   *
   * @return array
   *   An array of configuration settings.
   */
  private function getConfigData($setRoot, $setKey) {
    $settings = array(
      "flow_settings.flow_root" => "",
      "flow_settings.flow_auth_key" => "",
    );

    if ($setRoot && $setKey) {
      $settings = array(
        "flow_settings.flow_root" => "http://test.flow.linear.schedule",
        "flow_settings.flow_auth_key" => "key123",
      );
    }
    elseif ($setRoot && !$setKey) {
      $settings = array(
        "flow_settings.flow_root" => "http://test.flow.linear.schedule",
        "flow_settings.flow_auth_key" => "",
      );
    }

    return array("draco_udi.settings" => $settings);
  }

  /**
   * Return a mock logger.
   *
   * @return \Psr\Log\LoggerInterface|\PHPUnit_Framework_MockObject_MockObject
   *   The mock logger, with no expectations set.
   */
  private function getMockLogger() {
    $logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();
    return $logger;
  }

}
