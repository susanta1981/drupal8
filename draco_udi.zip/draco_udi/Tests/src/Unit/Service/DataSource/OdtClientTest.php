<?php

namespace Drupal\Tests\draco_udi\Unit\Service\DataSource;

use Drupal\draco_udi\Service\DataSource\OdtClient;
use Drupal\Tests\UnitTestCase;
use GuzzleHttp\Client;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;

/**
 * Tests The OdtClient class.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\DataSource\OdtClient
 */
class OdtClientTest extends UnitTestCase {

  protected $config;

  protected $logger;

  protected $eventDispatcher;

  /**
   * @var \Drupal\draco_udi\Service\DataSource\OdtClientInterface
   */
  protected $odtClient;

  private static $airingId = 'AIRING12345';

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $this->config = $this->getConfigFactoryStub($this->getConfigData(TRUE, TRUE));
    $this->logger = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannelInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->eventDispatcher = $this->getMockBuilder('Symfony\Component\EventDispatcher\EventDispatcherInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->eventDispatcher->method('dispatch');

  }

  /**
   * @covers ::__construct
   *
   * @expectedException \Drupal\Core\Config\ConfigException
   *
   * @expectedExceptionMessage ODT root path is not defined.
   */
  public function testCreateWithRootPathNotSetException() {
    $client = $this->getClient(TRUE);
    $config = $this->getConfigFactoryStub($this->getConfigData(FALSE, TRUE));

    $this->odtClient = new OdtClient($config, $this->logger, $client, $this->eventDispatcher);
  }

  /**
   * @covers ::__construct
   *
   * @expectedException \Drupal\Core\Config\ConfigException
   *
   * @expectedExceptionMessage ODT auth key is not defined.
   */
  public function testCreateWithAuthKeyNotSetException() {
    $client = $this->getClient(TRUE);
    $config = $this->getConfigFactoryStub($this->getConfigData(TRUE, FALSE));

    $this->odtClient = new OdtClient($config, $this->logger, $client, $this->eventDispatcher);
  }

  /**
   * Tests response from bad http request.
   *
   * @covers ::getFullAiringContentById
   * @covers ::__construct
   */
  public function testGetFullAiringObjectById() {

    $client = $this->getClient(TRUE);
    $this->odtClient = new OdtClient($this->config, $this->logger, $client, $this->eventDispatcher);

    $this->assertNotNull($this->odtClient);

    $obj = $this->odtClient->getFullAiringContentById(self::$airingId);
    $this->assertNotNull($obj);
    $this->assertNotNull($obj->options);
    $this->assertNotNull($obj->options->files);
    $this->assertNotNull($obj->options->titles);
    $this->assertNotNull($obj->options->destinations);

    $files = $obj->options->files;
    $titles = $obj->options->titles;
    $destinations = $obj->options->destinations;

    $this->assertEquals($obj->airingId, self::$airingId);
    $this->assertTrue(count($files) == 3);
    $this->assertTrue(count($titles) == 3);
    $this->assertTrue(count($destinations) == 3);

  }

  /**
   * Tests response from bad http request.
   *
   * @covers ::getAiringContentById
   * @covers ::__construct
   */
  public function testGetAiringObjectById() {

    $client = $this->getClient(FALSE);
    $this->odtClient = new OdtClient($this->config, $this->logger, $client, $this->eventDispatcher);

    $this->assertNotNull($this->odtClient);

    $obj = $this->odtClient->getAiringContentById(self::$airingId);
    $this->assertNotNull($obj);
    $this->assertNotNull($obj->options);
    $this->assertNotNull($obj->options->files);
    $this->assertNotNull($obj->options->titles);
    $this->assertNotNull($obj->options->destinations);

    $files = $obj->options->files;
    $titles = $obj->options->titles;
    $destinations = $obj->options->destinations;

    $this->assertTrue($obj->airingId == self::$airingId);
    $this->assertTrue(count($files) == 0);
    $this->assertTrue(count($titles) == 0);
    $this->assertTrue(count($destinations) == 0);
  }

  /**
   * Test successful case.
   *
   * @covers ::postAiring
   * @covers ::__construct
   */
  public function testPostAiring() {
    $client = $this->getClient(FALSE, 'POST');
    $this->odtClient = new OdtClient($this->config, $this->logger, $client, $this->eventDispatcher);

    $response = $this->odtClient->postAiring('');

    $this->assertNotNull($response);
    $this->assertEquals($response->statusCode, 200);
    $this->assertEquals($response->status, 'SUCCESSFUL');
  }

  /**
   * Test response's body having no mediaId.
   *
   * @covers ::postAiring
   * @covers ::__construct
   */
  public function testPostAiringWithErrorInResponse() {
    $client = $this->getClient(FALSE, 'POST', FALSE);
    $this->odtClient = new OdtClient($this->config, $this->logger, $client, $this->eventDispatcher);

    $response = $this->odtClient->postAiring('');

    $this->assertNotNull($response);
    $this->assertNotEquals($response->statusCode, 200);
    $this->assertEquals($response->status, 'ERROR');
  }

  /**
   * Test register media file data successful.
   *
   * @covers ::postFiles
   * @covers ::__construct
   */
  public function testPostFiles() {
    $client = $this->getClient(FALSE, 'REGISTER');
    $this->odtClient = new OdtClient($this->config, $this->logger, $client, $this->eventDispatcher);

    $response = $this->odtClient->postFiles('', '');

    $this->assertNotNull($response);
    $this->assertEquals($response->statusCode, 200);
    $this->assertEquals($response->status, 'SUCCESSFUL');
  }

  /**
   * Tests register media file data failed with error.
   *
   * @covers ::postFiles
   * @covers ::__construct
   */
  public function testPostFilesWithErrorInResponse() {
    $client = $this->getClient(FALSE, 'REGISTER', FALSE);
    $this->odtClient = new OdtClient($this->config, $this->logger, $client, $this->eventDispatcher);

    $response = $this->odtClient->postFiles('', '');

    $this->assertNotNull($response);
    $this->assertNotEquals($response->statusCode, 200);
    $this->assertEquals($response->status, 'ERROR');
  }

  /**
   * @param bool $options_in_response
   *    Indicate if options are set in response.
   * @param string $for_get
   *    Indicate the response is for get or post.
   * @param bool $success
   *    Indicate if success or error.
   * @param bool $missing_media_id
   *    Indicate if mediaid not returned.
   *
   * @return \GuzzleHttp\Client
   *    Mock client.
   */
  private function getClient($options_in_response, $for_get = 'GET', $success = TRUE, $missing_media_id = FALSE) {
    $response = NULL;

    $status = ($success) ? 200 : 500;

    if ($for_get == 'GET') {
      $response = new Response($status, [], $this->getAiringData(self::$airingId, $options_in_response));
    }
    elseif ($for_get == 'POST') {
      $response = new Response($status, [], $this->getPostResponseBody($missing_media_id));
    }
    elseif ($for_get == 'REGISTER') {
      $response = new Response($status, [], '');
    }

    $mock = new MockHandler([
      $response,
    ]);

    $handler = HandlerStack::create($mock);
    $client = new Client(['handler' => $handler]);

    return $client;
  }

  /**
   * Return data for testing ODT.
   *
   * @param $id
   *   Airing id.
   * @param bool $include_options
   *   Include options in response.
   *
   * @return string
   */
  private function getAiringData($id, $include_options) {
    $data = new \stdClass();
    $data->airingId = $id;

    $options = new \stdClass();

    if ($include_options == TRUE) {
      $options->files = array('file1', 'file2', 'file3');
      $options->titles = array('title1', 'title2', 'title3');
      $options->destinations = array('dest1', 'dest2', 'dest3');
    }
    else {
      $options->files = array();
      $options->titles = array();
      $options->destinations = array();
    }

    $data->options = $options;

    return json_encode($data);
  }

  /**
   *
   */
  private function getPostResponseBody($missing_media_id) {
    $response = new \stdClass();
    $response->mediaId = '12345qwert98765mnbvc';

    if ($missing_media_id == TRUE) {
      $response->mediaId = NULL;
    }

    $response->airingId = 'TBSE12345';
    return json_encode($response);
  }

  /**
   * Return testing config data.
   *
   * @param bool $setRoot
   *    Flag indicating if root needs to be set.
   * @param bool $setKey
   *    Flag indicating if auth key needs to be set.
   *
   * @return array
   *    Config data.
   */
  private function getConfigData($setRoot, $setKey) {
    $settings = array(
      "odt_settings.odt_root" => "",
      "odt_settings.odt_auth_key" => "",
      "odt_settings.odt_airing_id_prefix" => "",
    );

    if ($setRoot && $setKey) {
      $settings = array(
        "odt_settings.odt_root" => "http://test.odt",
        "odt_settings.odt_auth_key" => "key123",
        "odt_settings.odt_airing_id_prefix" => "TBSE",
      );
    }
    elseif ($setRoot && !$setKey) {
      $settings = array(
        "odt_settings.odt_root" => "http://test.odt",
        "odt_settings.odt_auth_key" => "",
        "odt_settings.odt_airing_id_prefix" => "TBSE",
      );
    }

    return array("draco_udi.settings" => $settings);
  }

}
