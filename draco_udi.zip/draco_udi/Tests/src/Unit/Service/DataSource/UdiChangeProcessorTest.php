<?php

namespace Drupal\Tests\draco_udi\Unit\Service\DataSource;

use Drupal\draco_udi\DataChange\DataChangeDecision;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\WorkflowReport;
use Drupal\draco_udi\Service\DataSource\UdiChangeProcessor;
use Drupal\Tests\UnitTestCase;

/**
 * Class UdiChangeProcessorTest.
 *
 * @package Drupal\Tests\draco_udi\Unit\Service
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\DataSource\UdiChangeProcessor
 */
class UdiChangeProcessorTest extends UnitTestCase {

  protected $changeProcessor;
  protected $workflowManager;
  protected $loggerchannel;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();
    $queueClient = $this->getMockBuilder('Drupal\draco_udi\Service\Queue\UdiQueueClientInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->workflowManager = $this->getMockBuilder('Drupal\draco_udi\ContentDataImportWorkflowManager')
      ->disableOriginalConstructor()
      ->getMock();
    $loggerFactory = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannelFactory')->getMock();
    $this->loggerchannel = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannelInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $loggerFactory->expects($this->any())->method('get')->willReturn($this->loggerchannel);

    $this->changeProcessor = new UdiChangeProcessor($queueClient, $this->workflowManager, $loggerFactory);

  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::getProcessFunction
   * @covers ::__construct
   * @covers ::logReport
   *
   * @dataProvider titleMessageFromQueue
   */
  public function testProcessMessageWithTitle($msg) {
    $this->workflowManager->expects($this->once())->method('import')->willReturn($this->getImportReport());
    $this->loggerchannel->expects($this->once())->method('info');

    $func = $this->changeProcessor->getProcessFunction();
    $func($msg);

  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::getProcessFunction
   * @covers ::__construct
   * @covers ::logReport
   *
   * @dataProvider titleMessageFromQueue
   */
  public function testProcessTitleMessageWithError($msg) {
    $this->workflowManager->expects($this->once())->method('import')->willReturn($this->getImportReport(FALSE));
    $this->loggerchannel->expects($this->once())->method('error');

    $func = $this->changeProcessor->getProcessFunction();
    $func($msg);
  }

  /**
   * Test fetching ondemand_schedule from upstream.
   *
   * @covers ::getProcessFunction
   * @covers ::__construct
   * @covers ::logReport
   *
   * @dataProvider ondemandMessageFromQueue
   */
  public function testProcessMessageWithOnDemand($msg) {
    $this->workflowManager->expects($this->once())->method('import')->willReturn($this->getImportReport());;
    $this->loggerchannel->expects($this->once())->method('info');

    $func = $this->changeProcessor->getProcessFunction();
    $func($msg);

  }

  /**
   * Test fetching linear_schedule from upstream.
   *
   * @covers ::getProcessFunction
   * @covers ::__construct
   * @covers ::logReport
   *
   * @dataProvider linearMessageFromQueue
   */
  public function testProcessMessageWithLinear($msg) {
    $this->workflowManager->expects($this->once())->method('import')->willReturn($this->getImportReport());;
    $this->loggerchannel->expects($this->once())->method('info');

    $func = $this->changeProcessor->getProcessFunction();
    $func($msg);
  }

  /**
   * Test fetching unknown from upstream.
   *
   * @covers ::getProcessFunction
   * @covers ::__construct
   * @covers ::logReport
   *
   * @dataProvider unknownMessageFromQueue
   */
  public function testProcessMessageWithUnknwon($msg) {
    $this->workflowManager->expects($this->never())->method('import');
    $this->loggerchannel->expects($this->once())->method('error');

    $func = $this->changeProcessor->getProcessFunction();
    $func($msg);
  }

  /**
   * Test fetching Title with exception.
   *
   * @covers ::getProcessFunction
   * @covers ::__construct
   * @covers ::logReport
   *
   * @expectedException \Exception
   *
   * @dataProvider titleMessageFromQueue
   */
  public function testProcessMessageWithException($msg) {
    $this->workflowManager->expects($this->once())->method('import')->willThrowException(new \Exception());
    $this->loggerchannel->expects($this->once())->method('error');

    $func = $this->changeProcessor->getProcessFunction();
    $func($msg);
  }

  /**
   * Return mock report data.
   *
   * @param bool $complete
   *    Flag for different data.
   *
   * @return array
   *    Report data objects.
   */
  private function getImportReport($complete = TRUE) {
    $report = [];
    $msg = new WorkflowReport();

    if ($complete) {
      $msg->setStatus(WorkflowReport::COMPLETE);
      $msg->setEntityId(1);
      $msg->setContentType('title');
      $msg->setContentSource('flow');
      $msg->setAction('insert');
    }
    else {
      $msg->setStatus(WorkflowReport::ERROR);
      $msg->setMessage('error');
    }

    $report[] = $msg;

    return $report;
  }

  /**
   * Unknown message from queue.
   */
  public function titleMessageFromQueue() {

    $titleMsg = '  
         {
            "type": "Title",
            "action":"foo action",
            "source" : "foo source",
            "data" : {}
         }
     ';
    return array(
      array($titleMsg),
    );
  }

  /**
   * On demand message from queue.
   */
  public function ondemandMessageFromQueue() {

    $titleMsg = '  
         {
            "type": "OnDemandSchedule",
            "action":"foo action",
            "source" : "foo source",
            "data" : {}
         }
     ';
    return array(
      array($titleMsg),
    );
  }

  /**
   * On demand message from queue.
   */
  public function linearMessageFromQueue() {

    $titleMsg = '  
         {
            "type": "LinearSchedule",
            "action":"foo action",
            "source" : "foo source",
            "data" : {}
         }
     ';
    return array(
      array($titleMsg),
    );
  }

  /**
   * Unknown message from queue.
   */
  public function unknownMessageFromQueue() {

    $titleMsg = '  
         {
            "type": "Unknown",
            "action":"foo action",
            "source" : "foo source",
            "data" : {}
         }
     ';
    return array(
      array($titleMsg),
    );
  }

}
