<?php

namespace Drupal\Tests\draco_udi\Unit\Service;

use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\Tests\UnitTestCase;

/**
 * Class ContentFetchManagerTest.
 *
 * @group draco_udi
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\ContentFetchManager
 */
class ContentFetchManagerTest extends UnitTestCase {

  protected $contentFetchManager;

  protected $queueClient;

  protected $flowClient;

  protected $state;

  protected $logger;

  protected $odtClient;

  protected $odtQueueClient;

  protected $contentFilterManager;

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $this->logger = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannelFactory')->getMock();

    $this->queueClient = $this->getMockBuilder('Drupal\draco_udi\Service\Queue\UdiQueueClientInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->odtQueueClient = $this->getMockBuilder('Drupal\draco_udi\Service\Queue\UdiQueueClientInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->contentFilterManager = $this->getMockBuilder('Drupal\draco_udi\Filter\ContentFilterManager')
      ->disableOriginalConstructor()
      ->getMock();
    $this->state = $this->getMockBuilder('Drupal\Core\State\State')
      ->disableOriginalConstructor()
      ->getMock();
    $logger_channel = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannelInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->odtClient = $this->getMockBuilder('Drupal\draco_udi\Service\DataSource\OdtClient')
      ->disableOriginalConstructor()
      ->getMock();

    $this->flowClient = $this->getMockBuilder('Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->logger->expects($this->any())->method('get')->willReturn($logger_channel);
    $this->contentFilterManager->expects($this->any())->method('getFilters')->willReturn([]);

    $this->contentFetchManager = new ContentFetchManager(
      $this->logger,
      $this->flowClient,
      $this->odtQueueClient,
      $this->odtClient,
      $this->queueClient,
      $this->contentFilterManager,
      $this->state
    );
  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchTitles
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::getIdFromFlowUpdate
   * @covers ::buildMsg
   * @covers ::__construct
   *
   * @dataProvider titleData
   */
  public function testFetchTitles($titlesarray, $title) {

    $titleSinceData = [json_decode($titlesarray), json_decode('[]')];
    $titleData = json_decode($title);

    $this->state->expects($this->any())->method('get')->willReturn(new \DateTime());
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getUpdatedSince')
      ->willReturnOnConsecutiveCalls($titleSinceData[0], $titleSinceData[1]);
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getTitlesByTitleIds')
      ->willReturn($titleData);
    $this->queueClient
      ->expects($this->exactly(2))
      ->method('postJsonMessage');

    $this->contentFetchManager->fetchTitles(new \DateTime());
  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchLinearSchedules
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::getIdFromFlowUpdate
   * @covers ::buildMsg
   * @covers ::__construct
   *
   * @dataProvider linearData
   */
//  public function testFetchLinearSchedules($lineararray, $schedule) {
//    $linearSinceData = [json_decode($lineararray), json_decode('[]')];
//    $linearData = json_decode($schedule);
//    $date = new \DateTime();
//
//    $this->state->expects($this->any())->method('get')->willReturn($date);
//    $this->flowClient
//      ->expects($this->exactly(2))
//      ->method('getUpdatedSince')
//      ->willReturnOnConsecutiveCalls($linearSinceData[0], $linearSinceData[1]);
//    $this->flowClient
//      ->expects($this->exactly(2))
//      ->method('getLinearSchedulesByExternalIds')
//      ->willReturn($linearData);
//    $this->queueClient
//      ->expects($this->exactly(2))
//      ->method('postJsonMessage');
//
//    $this->contentFetchManager->fetchLinearSchedules();
//  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchLinearSchedules
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::getIdFromFlowUpdate
   * @covers ::buildMsg
   * @covers ::__construct
   *
   * @expectedException \Drupal\draco_udi\Exception\LastUpdatedDateNotFoundException
   *
   * @dataProvider linearData
   */
  public function testFetchLinearSchedulesWithoutLastUpdatedDate($lineararray, $schedule) {
    $linearSinceData = [json_decode($lineararray), json_decode('[]')];
    $linearData = [json_decode($schedule)];

    $this->state->expects($this->any())->method('get')->willReturn(NULL);

    $this->contentFetchManager->fetchLinearSchedules();
  }

  /**
   * Test sync linear schedules.
   *
   * @covers ::syncLinearSchedules
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::getIdFromFlowUpdate
   * @covers ::buildMsg
   * @covers ::__construct
   *
   * @dataProvider linearData
   */
  public function testSyncLinearSchedules($lineararray, $schedule) {
    $linearSinceData = [json_decode($lineararray), json_decode('[]')];
    $linearData = json_decode($schedule);
    $date = new \DateTime();
    $ts = $date->getTimestamp();

    $this->state->expects($this->any())->method('get')->willReturn($date);
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getUpdatedSince')
      ->willReturnOnConsecutiveCalls($linearSinceData[0], $linearSinceData[1]);
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getLinearSchedulesByExternalIds')
      ->willReturn($linearData);
    $this->flowClient
      ->expects($this->exactly(1))
      ->method('getTimeStampFromFlowObjectId')
      ->willReturn($ts);
    $this->flowClient
      ->expects($this->exactly(1))
      ->method('getBSONIdFromFlow')
      ->willReturn($ts);
    $this->queueClient
      ->expects($this->exactly(2))
      ->method('postJsonMessage');

    // Start date is earlier than the end date of the schedule in $linearData.
    $this->contentFetchManager->syncLinearSchedules(new \DateTime('2017-01-01T16:30:00.000Z'));
  }

  /**
   * Test sync linear schedules.
   *
   * @covers ::syncLinearSchedules
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::getIdFromFlowUpdate
   * @covers ::buildMsg
   * @covers ::__construct
   *
   * @dataProvider linearData
   */
  public function testSyncLinearSchedulesWithExpiredSchedules($lineararray, $schedule) {
    $linearSinceData = [json_decode($lineararray), json_decode('[]')];
    $linearData = json_decode($schedule);
    $date = new \DateTime();
    $ts = $date->getTimestamp();

    $this->state->expects($this->any())->method('get')->willReturn($date);
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getUpdatedSince')
      ->willReturnOnConsecutiveCalls($linearSinceData[0], $linearSinceData[1]);
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getLinearSchedulesByExternalIds')
      ->willReturn($linearData);
    $this->flowClient
      ->expects($this->exactly(1))
      ->method('getTimeStampFromFlowObjectId')
      ->willReturn($ts);
    $this->flowClient
      ->expects($this->exactly(1))
      ->method('getBSONIdFromFlow')
      ->willReturn($ts);
    $this->queueClient
      ->expects($this->exactly(0))
      ->method('postJsonMessage');

    // Start date is later than the end date of the schedule in $linearData.
    $this->contentFetchManager->syncLinearSchedules(new \DateTime());
  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchTitles
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::getIdFromFlowUpdate
   * @covers ::buildMsg
   * @covers ::postToQueue
   * @covers ::__construct
   *
   * @expectedException \Exception
   */
  public function testFetchTitlesWithException() {

    $this->flowClient
      ->expects($this->once())
      ->method('getUpdatedSince')
      ->willThrowException(new \Exception());
    $this->flowClient
      ->expects($this->never())
      ->method('getTitlesByTitleIds');
    $this->queueClient
      ->expects($this->exactly(0))
      ->method('postJsonMessage');

    $this->contentFetchManager->fetchTitles(new \DateTime());
  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchTitles
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::getIdFromFlowUpdate
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::buildMsg
   * @covers ::postToQueue
   * @covers ::__construct
   *
   * @dataProvider titleDataEmptyTitle
   */
  public function testFetchTitlesEmptyTitle($titlesarray, $title) {

    $titleSinceData = [json_decode($titlesarray), json_decode('[]')];
    $titleData = [json_decode($title)];
    $this->state->expects($this->any())->method('get')->willReturn(new \DateTime());
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getUpdatedSince')
      ->willReturnOnConsecutiveCalls($titleSinceData[0], $titleSinceData[1]);
    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getTitlesByTitleIds')
      ->willReturn($titleData);
    $this->queueClient
      ->expects($this->exactly(0))
      ->method('postJsonMessage');

    $this->contentFetchManager->fetchTitles(new \DateTime());

  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchTitles
   * @covers ::getLastUpdatedDate
   * @covers ::setLastUpdatedDate
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getIdFromFlowUpdate
   * @covers ::getProcessedDate
   * @covers ::getDataFromFlow
   * @covers ::postToQueue
   * @covers ::buildMsg
   * @covers ::__construct
   *
   * @dataProvider titleDataEmpty
   */
  public function testFetchTitlesEmptyData($titlesarray, $title) {
    $this->state->expects($this->any())->method('get')->willReturn(new \DateTime());
    $this->flowClient
      ->expects($this->once())
      ->method('getUpdatedSince')
      ->willReturn([]);
    $this->flowClient
      ->expects($this->never())
      ->method('getTitlesByTitleIds');
    $this->flowClient
      ->expects($this->never())
      ->method('getTimeStampFromFlowObjectId')
      ->willReturn(NULL);
    $this->queueClient
      ->expects($this->never())
      ->method('postJsonMessage');
    $this->queueClient
      ->expects($this->never())
      ->method('postJsonMessage');

    $this->contentFetchManager->fetchTitles(new \DateTime());
  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::processOdtQueueMsg
   * @covers ::getOnDemandSchedule
   * @covers ::postToQueue
   * @covers ::fetchUpdateSinceDataFromFlow
   * @covers ::processFlowData
   * @covers ::getProcessedDate
   * @covers ::getIdFromFlowUpdate
   * @covers ::getDataFromFlow
   * @covers ::buildMsg
   * @covers ::postToQueue
   * @covers ::__construct
   *
   * @dataProvider onDemandData
   */
  public function testFetchOnDemand($airingjson) {

    $msg = new \stdClass();
    $msg->body = '"{\"AiringId\":\"CARE1011021500007419\",\"Action\":\"Modify\"}"';
    $this->odtClient->expects($this->once())->method('getFullAiringContentById')->willReturn(json_decode($airingjson)[0]);
    $this->queueClient
      ->expects($this->exactly(1))
      ->method('postJsonMessage');

    $channel = $this->getMockBuilder('PhpAmqpLib\Channel\AMQPChannel')
      ->disableOriginalConstructor()
      ->getMock();

    $delivery_info = array('channel' => $channel, 'delivery_tag' => NULL);

    $channel->expects($this->once())->method('basic_ack')->willReturn(NULL);
    $msg->delivery_info = $delivery_info;
    /** @var callable $func */
    $func = $this->contentFetchManager->processOdtQueueMsg(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE, ContentFetchManager::CONTENT_SOURCE_ODT);
    $func($msg);

  }

  /**
   * Test fetching titles from upstream with Null Data.
   *
   * @covers ::processOdtQueueMsg
   * @covers ::__construct
   */
  public function testFetchOnDemandNullData() {

    $msg = new \stdClass();
    $msg->body = NULL;
    $this->odtClient->expects($this->never())->method('getFullAiringContentById');
    $channel = $this->getMockBuilder('PhpAmqpLib\Channel\AMQPChannel')
      ->disableOriginalConstructor()
      ->getMock();

    $delivery_info = array('channel' => $channel, 'delivery_tag' => NULL);

    $channel->expects($this->once())->method('basic_ack')->willReturn(NULL);
    $msg->delivery_info = $delivery_info;

    $func = $this->contentFetchManager->processOdtQueueMsg(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE, ContentFetchManager::CONTENT_SOURCE_ODT);
    /** @var callable $func */
    $func($msg);

  }

  /**
   * Test fetching tve data from upstream.
   *
   * @covers ::postTveJson
   * @covers ::shouldProceed
   *
   * @dataProvider tveData
   */
  public function testPostTveJson($data) {

    $this->queueClient
      ->expects($this->exactly(1))
      ->method('postJsonMessage');
    $this->contentFetchManager->postTveJson($data, ContentFetchManager::CONTENT_SOURCE_TVE);

  }

  /**
   * TitleData.
   */
  public function titleData() {
    $titlesjson = '   
       [
         {
            "_id":"572086d6bc02840b8cc3f005",
            "TitleId":2075800,
            "ProcessedDatetimeUTC":"2016-04-27T09:31:02.012Z"
         },
         {
            "_id":"572086d6bc02840b8cc3f006",
            "TitleId":2075816,
            "ProcessedDatetimeUTC":"2016-04-27T09:31:02.012Z"
         }
       ]
     ';
    $titledata = '   
       [
         {
            "_id":"foo_title",
            "TitleId":2075800
         }
       ]
     ';
    return array(
      array($titlesjson, $titledata),
    );
  }

  /**
   * Linear Data.
   */
  public function linearData() {
    $linearjson = '   
       [
         {
            "_id":"572086d6bc02840b8cc3f005",
            "ExternalId":2075800,
            "ProcessedDatetimeUTC":"2016-04-27T09:31:02.012Z"
         },
         {
            "_id":"572086d6bc02840b8cc3f006",
            "ExternalId":2075816,
            "ProcessedDatetimeUTC":"2016-04-27T09:31:02.012Z"
         }
       ]
     ';
    $schedule = '   
       [
         {
            "_id":"foo_title",
            "TitleId":2075800,
            "StartDate" : "2017-02-27T16:30:00.000Z",
            "EndDate" : "2017-02-28T16:30:00.000Z"
         }
       ]
     ';
    return array(
      array($linearjson, $schedule),
    );
  }

  /**
   * On demand data.
   */
  public function onDemandData() {
    $ondemanddata = '   
       [
         {
            "AiringId":"foo_schedule",
            "TitleId":2075800
         }
       ]
     ';
    return array(
      array($ondemanddata),
    );
  }

  /**
   * TVE data.
   */
  public function tveData() {
    $tvedata = '{
	"TveItem": {
		"C3": "false",
		"Title": {}
	}
   }';
    return array(
      array($tvedata),
    );
  }

  /**
   * Empty Title Data.
   */
  public function titleDataEmpty() {
    $titlesjson = '   
       [
         
       ]
     ';
    $titledata = '   
       [
         
       ]
     ';
    return array(
      array($titlesjson, $titledata),
    );
  }

  /**
   * Title Data.
   */
  public function titleDataEmptyTitle() {
    $titlesjson = '   
       [
         {
            "_id":"572086d6bc02840b8cc3f005",
            "TitleId":2075800,
            "ProcessedDatetimeUTC":"2016-04-27T09:31:02.012Z",
            "TitleType" :{"Name" :"Series"}
         },
         {
            "_id":"572086d6bc02840b8cc3f006",
            "TitleId":2075816,
            "ProcessedDatetimeUTC":"2016-04-27T09:31:02.012Z",
            "TitleType" :{"Name" :"Series"}
         }
       ]
     ';
    $titledata = '   
       [
       ]
     ';
    return array(
      array($titlesjson, $titledata),
    );
  }

}
