<?php

namespace Drupal\Tests\draco_udi\Unit\Service\Preparation;

use Drupal\Tests\UnitTestCase;

use Drupal\draco_udi\Service\Preparation\DataChangePreparer;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\Core\Entity\Query\QueryInterface;

/**
 *
 */
class DataChangePreparerTest extends UnitTestCase {
  protected $loggerChannelFactory;

  protected $entityManager;

  protected $queryFactory;

  protected $dataChangePreparer;

  protected $titleEntityStorage;

  protected $linearScheduleEntityStorage;

  protected $odScheduleEntityStorage;

  protected $queryInterface;

  protected $reconciler;

  /**
   *
   */
  public function setUp() {

    $this->loggerChannelFactory = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannelFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->titleEntityStorage = $this->getMockBuilder('Drupal\Core\Entity\EntityStorageInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->linearScheduleEntityStorage = $this->getMockBuilder('Drupal\Core\Entity\EntityStorageInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->odScheduleEntityStorage = $this->getMockBuilder('Drupal\Core\Entity\EntityStorageInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $getStorageReturnValueMap = [['content_title', $this->titleEntityStorage], ['content_on_demand_schedule', $this->odScheduleEntityStorage], ['content_linear_schedule', $this->linearScheduleEntityStorage]];

    $this->entityManager = $this->getMockBuilder('Drupal\Core\Entity\EntityManagerInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->entityManager->method('getStorage')->will($this->returnValueMap($getStorageReturnValueMap));

    $this->queryInterface = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->queryInterface->expects($this->any())->method('condition')->willReturn($this->queryInterface);

    $this->queryFactory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();
    $this->queryFactory->expects($this->any())->method('get')->willReturn($this->queryInterface);

    $this->reconciler = $this->getMockBuilder('Drupal\draco_udi\Reconciler\DracoReconcilerManager')
      ->disableOriginalConstructor()
      ->getMock();

    $this->reconciler->expects($this->any())->method('getDefinitions')->willReturn([]);
    $this->dataChangePreparer = new DataChangePreparer($this->loggerChannelFactory, $this->entityManager, $this->queryFactory, $this->reconciler);
  }

  /**
   *
   */
  public function testPrepareContextWithExistingTitle() {

    $input = json_decode('{"foo":"bar"}');

    // TITLE STUFF.
    $title = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentTitleInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $title->expects($this->any())->method('getTitleId')->willReturn('foo1');

    $existingTitle = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentTitleInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $titleStorageReturnValues = [[[1], array(1 => $existingTitle)]];
    $this->titleEntityStorage->method('loadMultiple')->will($this->returnValueMap($titleStorageReturnValues));

    $this->queryInterface->expects($this->any())->method('execute')->willReturn([1]);

    // SCHEDULE STUFF.
    $relatedLinearSchedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentLinearScheduleInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->linearScheduleEntityStorage->method('loadMultiple')->willReturn([$relatedLinearSchedule]);

    $relatedOdSchedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->odScheduleEntityStorage->method('loadMultiple')->willReturn([$relatedOdSchedule]);

    // END SCHEDULE STUFF.
    $convertedEntitySet = new ConvertedEntitySet($input, ContentFetchManager::CONTENT_TITLE_TYPE, $title);

    $context = $this->dataChangePreparer->prepareContext($convertedEntitySet, ContentFetchManager::CONTENT_TITLE_TYPE,ContentFetchManager::CONTENT_SOURCE_FLOW);

    $this->assertNotNull($context->getCurrentEntity());
    $this->assertNotNull($context->getExistingEntity());
    $this->assertEquals(ContentFetchManager::CONTENT_SOURCE_FLOW,$context->getEntitySource());
    $this->assertEquals(1, count($context->getRelatedData()['linearSchedules']));
    $this->assertEquals(1, count($context->getRelatedData()['odSchedules']));
    $this->assertEquals(1, count($context->getRelatedData()['entitiesToBeMapped']));
    $this->assertEquals(ContentFetchManager::CONTENT_TITLE_TYPE, $context->getEntityType());

  }

  /**
   *
   */
  public function testPrepareContextWithNewLinearSchedule() {
    $input = json_decode('{"foo":"bar"}');

    $schedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentLinearScheduleInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $schedule->expects($this->any())->method('getTitleIdList')->willReturn([]);
    $convertedEntitySet = new ConvertedEntitySet($input, ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE, $schedule);

    $context = $this->dataChangePreparer->prepareContext($convertedEntitySet, ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE,ContentFetchManager::CONTENT_SOURCE_FLOW);

    $this->assertNotNull($context->getCurrentEntity());
    $this->assertEquals(ContentFetchManager::CONTENT_SOURCE_FLOW, $context->getEntitySource());
  }

  /**
   *
   */
  public function testPrepareContextWithNewODSchedule() {
    $input = json_decode('{"foo":"bar"}');

    $schedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $schedule->expects($this->any())->method('getTitleIdList')->willReturn([]);
    $flight = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $convertedEntitySet = new ConvertedEntitySet($input, ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE, $schedule, NULL, [$flight]);

    $context = $this->dataChangePreparer->prepareContext($convertedEntitySet, ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE,ContentFetchManager::CONTENT_SOURCE_FLOW);

    $this->assertNotNull($context->getCurrentEntity());
    $this->assertEquals(ContentFetchManager::CONTENT_SOURCE_FLOW, $context->getEntitySource());
    $this->assertEquals(1, count($context->getRelatedData()['flights']));
    $this->assertEquals(0, count($context->getRelatedData()['titles']));
  }

  /**
   *
   */
  public function testPrepareContextWithNewODScheduleWithAssociatedTitles() {
    $input = json_decode('{"foo":"bar"}');

    $schedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $schedule->expects($this->any())->method('getTitleIdList')->willReturn(["1"]);
    $flight = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $convertedEntitySet = new ConvertedEntitySet($input, ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE, $schedule, NULL, [$flight]);

    $this->queryInterface->expects($this->any())->method('execute')->willReturn([1]);
    $existingTitle = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentTitleInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $titleStorageReturnValues = [[[1], array(1 => $existingTitle)]];
    $this->titleEntityStorage->method('loadMultiple')->will($this->returnValueMap($titleStorageReturnValues));
    $context = $this->dataChangePreparer->prepareContext($convertedEntitySet, ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE,ContentFetchManager::CONTENT_SOURCE_ODT);

    $this->assertNotNull($context->getCurrentEntity());
    $this->assertEquals(ContentFetchManager::CONTENT_SOURCE_ODT, $context->getEntitySource());
    $this->assertEquals(1, count($context->getRelatedData()['flights']));
    $this->assertEquals(1, count($context->getRelatedData()['titles']));
  }

  /**
   *
   */
  public function testPrepareContextWithNewLinearScheduleWithAssociatedTitles() {
    $input = json_decode('{"foo":"bar"}');

    $schedule = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentLinearScheduleInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $schedule->expects($this->any())->method('getTitleIdList')->willReturn(["1"]);
    $convertedEntitySet = new ConvertedEntitySet($input, 'Title', $schedule);

    $this->queryInterface->expects($this->any())->method('execute')->willReturn([1]);
    $existingTitle = $this->getMockBuilder('Drupal\draco_udi\Entity\ContentTitleInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $titleStorageReturnValues = [[[1], array(1 => $existingTitle)]];
    $this->titleEntityStorage->method('loadMultiple')->will($this->returnValueMap($titleStorageReturnValues));
    $context = $this->dataChangePreparer->prepareContext($convertedEntitySet, ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE,ContentFetchManager::CONTENT_SOURCE_FLOW);

    $this->assertNotNull($context->getCurrentEntity());
    $this->assertEquals(ContentFetchManager::CONTENT_SOURCE_FLOW, $context->getEntitySource());
    $this->assertEquals(1, count($context->getRelatedData()['titles']));
  }

}
