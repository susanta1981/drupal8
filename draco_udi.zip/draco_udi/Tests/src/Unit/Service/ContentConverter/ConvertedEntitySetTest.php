<?php

namespace Drupal\Tests\draco_udi\Unit\Service\ContentConverter;

use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;
use Drupal\Tests\UnitTestCase;

/**
 * Class ConvertedEntitySetTest.
 *
 * @group draco_udi
 *
 * @package Drupal\draco_udi\tests\Unit\Service\ContentConverter
 */
class ConvertedEntitySetTest extends UnitTestCase {

  /**
   * Test create instance of ConvertedEntitySet.
   */
  public function testCreate() {

    $item = $this->getMockBuilder('Drupal\draco_udi\Entity\DracoContentInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $existing_item = $this->getMockBuilder('Drupal\draco_udi\Entity\DracoContentInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $source_json = new \stdClass();
    $source_json->name = 'A title from Flow';
    $source_json->type = 'Title';

    $entity_set = new ConvertedEntitySet($source_json, $source_json->type, $item, $existing_item, array());

    $this->assertNotNull($entity_set);
    $this->assertNotNull($entity_set->getSourceJson());
    $this->assertTrue($entity_set->getConvertedEntity() instanceof DracoContentInterface);
    $this->assertTrue($entity_set->getConvertedEntityExistingCopy() instanceof DracoContentInterface);
    $this->assertTrue(empty($entity_set->getAssociatedEntities()));

    $entity_set->setAssociatedEntities(array($item));

    $this->assertFalse(empty($entity_set->getAssociatedEntities()));
    $this->assertEquals(count($entity_set->getAssociatedEntities()), 1);

  }

}
