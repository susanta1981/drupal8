<?php

namespace Drupal\Tests\draco_udi\Unit\Service;

use Drupal\draco_udi\Service\FilterBasedContentFetchManager;
use Drupal\draco_udi\Events\UdiSeriesEvent;

/**
 * Class FilteredBasedContentFetchManagerTest.
 *
 * @group draco_udi
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\FilterBasedContentFetchManager
 */
class FilteredBasedContentFetchManagerTest extends ContentFetchManagerTest {

  protected $queryFactory;

  protected $query;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();

    $this->queryFactory = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryFactory')
      ->disableOriginalConstructor()
      ->getMock();

    $this->query = $this->getMockBuilder('Drupal\Core\Entity\Query\QueryInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $this->query->expects($this->any())->method('execute')->willReturn([]);
    $this->query->expects($this->any())->method('condition')->willReturn($this->query);
    $this->query->expects($this->any())->method('count')->willReturn($this->query);
    $this->queryFactory->expects($this->any())->method('get')->willReturn($this->query);

  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchTitlesByIds
   * @covers ::titleExists
   * @covers ::getDataFromFlow
   * @covers ::__construct
   */
  public function testFetchTitlesByIds() {
    $title_ids = ['10000', '20000'];

    $title_data = new \stdClass();
    $title_data->TitlleId = '10000';
    $type = new \stdClass();
    $type->Name = 'Series';
    $title_data->TitleType = $type;
    $titles = [$title_data];

    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getTitlesByTitleIds')
      ->willReturnOnConsecutiveCalls($titles, NULL);
    $this->queueClient
      ->expects($this->exactly(1))
      ->method('postJsonMessage');
    $this->contentFetchManager = new FilterBasedContentFetchManager($this->logger,
      $this->flowClient, $this->odtQueueClient, $this->odtClient, $this->queueClient,
      $this->contentFilterManager, $this->state, $this->queryFactory);
    $this->contentFetchManager->fetchTitlesByIds($title_ids, ['Series']);
  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchTitlesByIds
   * @covers ::titleExists
   * @covers ::getDataFromFlow
   * @covers ::__construct
   */
  public function testFetchTitlesByIdsWithMultipleTypes() {
    $title_ids = ['10000', '20000'];

    $title_data = new \stdClass();
    $title_data->TitlleId = '10000';
    $type = new \stdClass();
    $type->Name = 'Episode';
    $title_data->TitleType = $type;
    $title_data2 = new \stdClass();
    $title_data2->TitlleId = '20000';
    $type2 = new \stdClass();
    $type2->Name = 'Element';
    $title_data2->TitleType = $type2;
    $titles = [$title_data];
    $titles2 = [$title_data2];

    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getTitlesByTitleIds')
      ->willReturnOnConsecutiveCalls($titles, $titles2);
    $this->queueClient
      ->expects($this->exactly(2))
      ->method('postJsonMessage');
    $this->contentFetchManager = new FilterBasedContentFetchManager($this->logger,
      $this->flowClient, $this->odtQueueClient, $this->odtClient, $this->queueClient,
      $this->contentFilterManager, $this->state, $this->queryFactory);
    $this->contentFetchManager->fetchTitlesByIds($title_ids, ['Episode', 'Element']);
  }

  /**
   * Test fetching titles from upstream.
   *
   * @covers ::fetchTitlesByIds
   * @covers ::titleExists
   * @covers ::getDataFromFlow
   * @covers ::__construct
   */
  public function testFetchTitlesByIdsWithInvalidTitleType() {
    $title_ids = ['10000', '20000'];

    $title_data = new \stdClass();
    $title_data->TitlleId = '10000';
    $type = new \stdClass();
    $type->Name = 'Episode';
    $title_data->TitleType = $type;
    $title_data2 = new \stdClass();
    $title_data2->TitlleId = '20000';
    $type2 = new \stdClass();
    $type2->Name = 'INVALIDTYPE';
    $title_data2->TitleType = $type2;
    $titles = [$title_data];
    $titles2 = [$title_data2];

    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getTitlesByTitleIds')
      ->willReturnOnConsecutiveCalls($titles, $titles2);
    $this->queueClient
      ->expects($this->exactly(1))
      ->method('postJsonMessage');
    $this->contentFetchManager = new FilterBasedContentFetchManager($this->logger,
      $this->flowClient, $this->odtQueueClient, $this->odtClient, $this->queueClient,
      $this->contentFilterManager, $this->state, $this->queryFactory);
    $this->contentFetchManager->fetchTitlesByIds($title_ids, ['Episode', 'Element']);
  }

  /**
   * Test onTitleContentImportComplete method.
   *
   * @covers ::onSeriesContentImportComplete
   * @covers ::getChildItemTitleIds
   * @covers ::getChildItemTypes
   * @covers ::__construct
   */
  public function testOnTitleContentImportComplete() {
    $title_data_1 = new \stdClass();
    $title_data_1->TitleId = '10001';
    $type = new \stdClass();
    $type->Name = 'Episode';
    $title_data_1->TitleType = $type;

    $title_data_2 = new \stdClass();
    $title_data_2->TitleId = '10002';
    $type = new \stdClass();
    $type->Name = 'Episode';
    $title_data_2->TitleType = $type;

    $titles1 = [$title_data_1];
    $titles2 = [$title_data_2];

    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getTitlesByTitleIds')
      ->willReturnOnConsecutiveCalls($titles1, $titles2);
    $this->queueClient
      ->expects($this->exactly(2))
      ->method('postJsonMessage');
    $this->contentFetchManager = new FilterBasedContentFetchManager($this->logger,
      $this->flowClient, $this->odtQueueClient, $this->odtClient, $this->queueClient,
      $this->contentFilterManager, $this->state, $this->queryFactory);

    // Create test event.
    $data = array();
    $data['contentType'] = 'Title';

    $source_json = new \stdClass();
    $source_json->TitleId = '10000';
    $source_json->TitleName = 'test';
    $type = new \stdClass();
    $type->Name = 'Series';
    $source_json->TitleType = $type;

    $item_1 = new \stdClass();
    $item_1->TitleId = '10001';
    // $type_1 = new \stdClass();
    // $type_1->Name = 'Episode';.
    $item_1->TitleType = 'Episode';
    $item_2 = new \stdClass();
    $item_2->TitleId = '10002';
    // $type_2 = new \stdClass();
    // $type_2->Name = 'Episode';.
    $item_2->TitleType = 'Episode';
    $source_json->SeriesItems = [$item_1, $item_2];

    $data['sourceContent'] = $source_json;
    $event = new UdiSeriesEvent($data);

    $this->contentFetchManager->onSeriesContentImportComplete($event);
  }

  /**
   * Test onTitleContentImportComplete method.
   *
   * @covers ::onSeriesContentImportComplete
   * @covers ::getChildItemTitleIds
   * @covers ::getChildItemTypes
   * @covers ::__construct
   */
  public function testOnTitleContentImportCompleteWithDifferentChildTypes() {
    $title_data_1 = new \stdClass();
    $title_data_1->TitleId = '10001';
    $type = new \stdClass();
    $type->Name = 'Episode';
    $title_data_1->TitleType = $type;

    $title_data_2 = new \stdClass();
    $title_data_2->TitleId = '10002';
    $type = new \stdClass();
    $type->Name = 'Element';
    $title_data_2->TitleType = $type;

    $titles1 = [$title_data_1];
    $titles2 = [$title_data_2];

    $this->flowClient
      ->expects($this->exactly(2))
      ->method('getTitlesByTitleIds')
      ->willReturnOnConsecutiveCalls($titles1, $titles2);
    $this->queueClient
      ->expects($this->exactly(2))
      ->method('postJsonMessage');
    $this->contentFetchManager = new FilterBasedContentFetchManager($this->logger,
      $this->flowClient, $this->odtQueueClient, $this->odtClient, $this->queueClient,
      $this->contentFilterManager, $this->state, $this->queryFactory);

    // Create test event.
    $data = array();
    $data['contentType'] = 'Title';

    $source_json = new \stdClass();
    $source_json->TitleId = '10000';
    $source_json->TitleName = 'test';
    $type = new \stdClass();
    $type->Name = 'Series';
    $source_json->TitleType = $type;

    $item_1 = new \stdClass();
    $item_1->TitleId = '10001';
    // $type_1 = new \stdClass();
    // $type_1->Name = 'Episode';.
    $item_1->TitleType = 'Episode';
    $item_2 = new \stdClass();
    $item_2->TitleId = '10002';
    // $type_2 = new \stdClass();
    // $type_2->Name = 'Episode';.
    $item_2->TitleType = 'Element';
    $source_json->SeriesItems = [$item_1, $item_2];

    $data['sourceContent'] = $source_json;
    $event = new UdiSeriesEvent($data);

    $this->contentFetchManager->onSeriesContentImportComplete($event);
  }

}

