<?php

namespace Drupal\Tests\draco_udi\Unit\Service;

use Drupal\draco_udi\Context;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\DracoPersistenceService;
use Drupal\Tests\UnitTestCase;

/**
 * Tests The DracoPersistenceService.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Service\DracoPersistenceService
 */
class DracoPersistenceServiceTest extends UnitTestCase {

  private $logger;
  /**
   * The DracoService used for testing.
   */
  protected $dracoPersistenceService;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    $loggerchannel = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannelInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $this->dracoPersistenceService = new DracoPersistenceService($loggerchannel);
  }

  /**
   * Tests saving a Title Entity.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoTitle
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSaveTitle() {
    $titleEntity = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->any())->method('id')->willReturn('foo');
    $titleEntity->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity->expects($this->any())->method('isEntityToBeSavedPending')->willReturn(FALSE);
    $titleEntity->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->once())
      ->method('save');
    $titleEntity->expects($this->exactly(2))
      ->method('addMappedContent');
    $mapped1->expects($this->once())
      ->method('save');
    $mapped2->expects($this->once())
      ->method('save');
    $mappedEntities = [$mapped1, $mapped2];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('foo' => $mappedEntities),
    );

    $context = new Context();
    $context->setEntityToSave($titleEntity);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_TITLE_TYPE);
    $this->dracoPersistenceService->save($context);
  }

  /**
   * Tests saving a Title With schedules.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoTitle
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSaveTitleWithSchedules() {
    $titleEntity = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->any())->method('id')->willReturn('foo');
    $titleEntity->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);

    $linearSchedule = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentLinearSchedule')
      ->disableOriginalConstructor()
      ->getMock();
    $linearSchedule->expects($this->any())->method('isAssociatedTitle')->willReturn(FALSE);
    $linearSchedule->expects($this->once())
      ->method('addAssociatedTitle');
    $ondemandSchedule = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandSchedule')
      ->disableOriginalConstructor()
      ->getMock();
    $ondemandSchedule->expects($this->any())->method('isAssociatedTitle')->willReturn(FALSE);
    $ondemandSchedule->expects($this->once())
      ->method('addAssociatedTitle');

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->once())
      ->method('save');
    $titleEntity->expects($this->exactly(2))
      ->method('addMappedContent');
    $mapped1->expects($this->once())
      ->method('save');
    $mapped2->expects($this->once())
      ->method('save');
    $linearSchedule->expects($this->once())
      ->method('save');
    $ondemandSchedule->expects($this->once())
      ->method('save');
    $mappedEntities = [$mapped1, $mapped2];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('foo' => $mappedEntities),
      CONTEXT::RELATED_LINEAR_SCHEDULE_KEY => [$linearSchedule],
      CONTEXT::RELATED_ONDEMAND_SCHEDULE_KEY => [$ondemandSchedule],
    );

    $context = new Context();
    $context->setEntityToSave($titleEntity);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_TITLE_TYPE);
    $this->dracoPersistenceService->save($context);
  }

  /**
   * Tests saving a Title With schedules.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoTitle
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSaveTitleWithSchedulesAlreadyLinked() {
    $titleEntity = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->any())->method('id')->willReturn('foo');
    $titleEntity->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);

    $linearSchedule = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentLinearSchedule')
      ->disableOriginalConstructor()
      ->getMock();
    $linearSchedule->expects($this->any())->method('isAssociatedTitle')->willReturn(TRUE);
    $linearSchedule->expects($this->never())
      ->method('addAssociatedTitle');
    $ondemandSchedule = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandSchedule')
      ->disableOriginalConstructor()
      ->getMock();
    $ondemandSchedule->expects($this->any())->method('isAssociatedTitle')->willReturn(TRUE);
    $ondemandSchedule->expects($this->never())
      ->method('addAssociatedTitle');

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->once())
      ->method('save');
    $titleEntity->expects($this->exactly(2))
      ->method('addMappedContent');
    $mapped1->expects($this->once())
      ->method('save');
    $mapped2->expects($this->once())
      ->method('save');
    $linearSchedule->expects($this->once())
      ->method('save');
    $ondemandSchedule->expects($this->once())
      ->method('save');
    $mappedEntities = [$mapped1, $mapped2];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('foo' => $mappedEntities),
      CONTEXT::RELATED_LINEAR_SCHEDULE_KEY => [$linearSchedule],
      CONTEXT::RELATED_ONDEMAND_SCHEDULE_KEY => [$ondemandSchedule],
    );

    $context = new Context();
    $context->setEntityToSave($titleEntity);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_TITLE_TYPE);
    $this->dracoPersistenceService->save($context);
  }

  /**
   * Tests saving a Title Entity.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoLinearSchedule
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSaveLinearSchedule() {

    $linearSchedule = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentLinearSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $linearSchedule->expects($this->any())->method('id')->willReturn('linearfoo');
    $linearSchedule->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE);

    $titleEntity1 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity1->expects($this->any())->method('id')->willReturn('titlefoo');
    $titleEntity1->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity1->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);
    $titleEntity2 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity2->expects($this->any())->method('id')->willReturn('titlebar');
    $titleEntity2->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity2->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped3 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped4 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity1->expects($this->once())
      ->method('save');
    $titleEntity1->expects($this->exactly(2))
      ->method('addMappedContent');
    $titleEntity2->expects($this->once())
      ->method('save');
    $titleEntity2->expects($this->exactly(2))
      ->method('addMappedContent');
    $mapped1->expects($this->once())
      ->method('save');
    $mapped2->expects($this->once())
      ->method('save');
    $mapped3->expects($this->once())
      ->method('save');
    $mapped4->expects($this->once())
      ->method('save');
    $mappedEntitiesfoo = [$mapped1, $mapped2];
    $mappedEntitiesbar = [$mapped3, $mapped4];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('titlefoo' => $mappedEntitiesfoo, 'titlebar' => $mappedEntitiesbar),
      CONTEXT::RELATED_TO_BE_MAPPED_KEY => array($titleEntity1, $titleEntity2),
    );

    $context = new Context();
    $context->setEntityToSave($linearSchedule);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE);
    $this->dracoPersistenceService->save($context);
  }

  /**
   * Tests saving a OnDemand Schedule Entity.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoOndemandSchedule
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSaveOndemandSchedule() {

    $ondemandSchedule = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $ondemandSchedule->expects($this->any())->method('id')->willReturn('ondemandfoo');
    $ondemandSchedule->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);

    $titleEntity1 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity1->expects($this->any())->method('id')->willReturn('titlefoo');
    $titleEntity1->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity1->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);
    $titleEntity2 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity2->expects($this->any())->method('id')->willReturn('titlebar');
    $titleEntity2->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity2->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped3 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped4 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $flight1 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $flight2 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $flight1->expects($this->any())->method('id')->willReturn('flightfoo');
    $flight2->expects($this->any())->method('id')->willReturn('flightbar');
    $ondemandSchedule->expects($this->exactly(2))
      ->method('addFlight');
    $titleEntity1->expects($this->once())
      ->method('save');
    $titleEntity1->expects($this->exactly(2))
      ->method('addMappedContent');
    $titleEntity2->expects($this->once())
      ->method('save');
    $titleEntity2->expects($this->exactly(2))
      ->method('addMappedContent');
    $mapped1->expects($this->once())
      ->method('save');
    $mapped2->expects($this->once())
      ->method('save');
    $mapped3->expects($this->once())
      ->method('save');
    $mapped4->expects($this->once())
      ->method('save');
    $flight1->expects($this->once())
      ->method('save');
    $flight2->expects($this->once())
      ->method('save');

    $mappedEntitiesfoo = [$mapped1, $mapped2];
    $mappedEntitiesbar = [$mapped3, $mapped4];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('titlefoo' => $mappedEntitiesfoo, 'titlebar' => $mappedEntitiesbar),
      CONTEXT::RELATED_TO_BE_MAPPED_KEY => [$titleEntity1, $titleEntity2],
      CONTEXT::RELATED_FLIGHTS_KEY => [$flight1, $flight2],
    );

    $context = new Context();
    $context->setEntityToSave($ondemandSchedule);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);
    $this->dracoPersistenceService->save($context);
  }

  /**
   * Tests saving a OnDemand Schdule Entity.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoOndemandSchedule
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSaveOndemandScheduleWithExistingFlights() {

    $ondemandSchedule = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandSchedule')
      ->disableOriginalConstructor()
      ->getMock();

    $ondemandSchedule->expects($this->any())->method('id')->willReturn('ondemandfoo');
    $ondemandSchedule->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);

    $titleEntity1 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity1->expects($this->any())->method('id')->willReturn('titlefoo');
    $titleEntity1->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity1->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);
    $titleEntity2 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity2->expects($this->any())->method('id')->willReturn('titlebar');
    $titleEntity2->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity2->expects($this->any())->method('getEntityTypeId')->willReturn(ContentFetchManager::CONTENT_TITLE_TYPE);

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped3 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped4 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $flight1 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $flight2 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $flight3 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $flight4 = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentOnDemandFlightInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $flight1->expects($this->any())->method('id')->willReturn('flightfoo');
    $flight2->expects($this->any())->method('id')->willReturn('flightbar');
    $ondemandSchedule->expects($this->any())->method('getFlights')->willReturn([$flight1, $flight2]);

    $flight3->expects($this->any())->method('id')->willReturn('flightfoo2');
    $flight4->expects($this->any())->method('id')->willReturn('flightbar2');
    $mappedEntitiesfoo = [$mapped1, $mapped2];
    $mappedEntitiesbar = [$mapped3, $mapped4];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('titlefoo' => $mappedEntitiesfoo, 'titlebar' => $mappedEntitiesbar),
      CONTEXT::RELATED_TO_BE_MAPPED_KEY => [$titleEntity1, $titleEntity2],
      CONTEXT::RELATED_FLIGHTS_KEY => [$flight3, $flight4],
    );

    $flight1->expects($this->once())
      ->method('delete');
    $flight2->expects($this->once())
      ->method('delete');
    $flight3->expects($this->once())
      ->method('save');
    $flight4->expects($this->once())
      ->method('save');

    $context = new Context();
    $context->setEntityToSave($ondemandSchedule);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE);
    $this->dracoPersistenceService->save($context);
  }

  /**
   * Tests saving a Pending Entity.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoTitle
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSavePending() {
    $titleEntity = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->any())->method('id')->willReturn('foo');
    $titleEntity->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity->expects($this->any())->method('getEntityTypeId')->willReturn('pending_content_entity');

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->once())
      ->method('save');
    $titleEntity->expects($this->never())
      ->method('addMappedContent');
    $mapped1->expects($this->never())
      ->method('save');
    $mapped2->expects($this->never())
      ->method('save');
    $mappedEntities = [$mapped1, $mapped2];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('foo' => $mappedEntities),
    );

    $context = new Context();
    $context->setEntityToSave($titleEntity);
    $context->setRelatedData($relatedData);
    $context->setEntityType(ContentFetchManager::CONTENT_TITLE_TYPE);
    $this->dracoPersistenceService->save($context);
  }

  /**
   * Tests saving a Pending Entity.
   *
   * @covers ::__construct
   * @covers ::save
   * @covers ::saveTitleContext
   * @covers ::saveDracoTitle
   * @covers ::saveRelatedTitles
   * @covers ::saveTitleEntity
   * @covers ::saveContent
   * @covers ::addMappedContentToTitle
   * @covers ::addTitlesToSchedule
   * @covers ::addFlightsToOndemandSchedule
   * @covers ::removeExistingFlights
   * @covers ::saveSchedulesForTitle
   * @covers ::isEntityToBeSavedPending
   * @covers ::getValueFromArray
   */
  public function testSaveUnknown() {
    $titleEntity = $this->getMockBuilder('\Drupal\draco_udi\Entity\ContentTitle')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->any())->method('id')->willReturn('foo');
    $titleEntity->expects($this->any())->method('getmappedContentIds')->willReturn([]);
    $titleEntity->expects($this->any())->method('getEntityTypeId')->willReturn('unknown');

    $mapped1 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();
    $mapped2 = $this->getMockBuilder('\Drupal\Core\Entity\EntityInterface')
      ->disableOriginalConstructor()
      ->getMock();

    $titleEntity->expects($this->never())
      ->method('save');
    $titleEntity->expects($this->never())
      ->method('addMappedContent');
    $mapped1->expects($this->never())
      ->method('save');
    $mapped2->expects($this->never())
      ->method('save');
    $mappedEntities = [$mapped1, $mapped2];
    $relatedData = array(
      CONTEXT::RELATED_MAPPED_CONTENT_KEY => array('foo' => $mappedEntities),
    );

    $context = new Context();
    $context->setEntityToSave($titleEntity);
    $context->setRelatedData($relatedData);
    $context->setEntityType('UNKNOWN');
    $this->dracoPersistenceService->save($context);
  }

}
