<?php

namespace Drupal\Tests\draco_udi\Unit\Entity;

use Drupal\draco_udi\Mocks\MockFieldDefinition;
use Drupal\draco_udi\Mocks\MockFieldItemList;
use Drupal\draco_udi\Entity\ContentTitle;
use Drupal\Tests\UnitTestCase;
use Drupal\Core\DependencyInjection\ContainerBuilder;

/**
 * Tests The ContentTitle class.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Entity\ContentTitle
 */
class ContentTitleTest extends UnitTestCase {


  /**
   * The entity manager service.
   *
   * @var \Drupal\Core\Entity\EntityManagerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $entityManager;

  /**
   * @var \Drupal\draco_udi\Entity\ContentTitle|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $contentTitle;

  /**
   * @var \Drupal\Core\Field\FieldTypePluginManagerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $fieldTypePluginManager;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    $id = 1;
    $values = array(
      'id' => $id,
      'label' => 'test ContentLinearSchedule',
      'uuid' => '3bb9ee60-bea5-4622-b89b-a63319d10b3a',
    );
    $entityTypeId = $this->randomMachineName();
    $this->bundle = $this->randomMachineName();

    $language = $this->getMockBuilder('Drupal\Core\Language\LanguageInterface')->getMock();
    $language->method('getId')
      ->willReturn('us');

    $language_manager = $this->getMockBuilder('Drupal\Core\Language\LanguageManagerInterface')->getMock();
    $language_manager->method('getCurrentLanguage')
      ->will($this->returnValue($language));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();
    $entityType->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
        'langcode' => 'langcode',
      )));

    $this->fieldTypePluginManager = $this->getMockBuilder('Drupal\Core\Field\FieldTypePluginManagerInterface')->getMock();

    $this->entityManager = $this->getMockBuilder('\Drupal\Core\Entity\EntityManagerInterface')->getMock();
    $this->entityManager->method('getDefinition')
      ->with($entityTypeId)
      ->will($this->returnValue($entityType));

    $this->entityManager->method('getFieldDefinitions')
      ->with($entityTypeId)
      ->will($this->returnValue($this->fieldDefinitions()));

    $uuid = $this->getMockBuilder('\Drupal\Component\Uuid\UuidInterface')->getMock();
    $container = new ContainerBuilder();
    $container->set('entity.manager', $this->entityManager);
    $container->set('uuid', $uuid);
    $container->set("plugin.manager.field.field_type", $this->fieldTypePluginManager);
    $container->set("language_manager", $language_manager);
    $container->set("language", $language);
    \Drupal::setContainer($container);

    $this->contentTitle = new ContentTitle($values, $entityTypeId);
  }

  /**
   * @covers ::setRatings
   * @covers ::getRatings
   * @covers ::getRatingCodeAndDescriptorsByNetwork
   */
  public function testSetGetRatings() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'ratings')));

    $desc = new \stdClass();
    $desc->Rating = 'TV-PG';
    $descriptors = ['V', 'D', 'L'];
    $desc->Descriptors = $descriptors;
    $rating = new \stdClass();
    $rating->RatingDescriptors = [$desc];
    $ratings = [$rating];

    $return = $this->contentTitle->setRatings($ratings);
    $this->assertEquals($return, $this->contentTitle);
    $val = $this->contentTitle->getRatings();

    $this->assertEquals($val, $ratings);

    // Network code not set.
    $rating_and_desc = $this->contentTitle->getRatingCodeAndDescriptorsByNetwork('TBS');

    // NetworkCode not set.
    $this->assertNull($rating_and_desc);

    // Network code is set.
    $desc->NetworkCode = 'TBS';
    $return = $this->contentTitle->setRatings($ratings);
    $rating_and_desc = $this->contentTitle->getRatingCodeAndDescriptorsByNetwork('TBS');

    // NetworkCode set.
    $this->assertNotNull($rating_and_desc);
    $this->assertEquals($rating_and_desc->rating, 'TV-PG');
    $this->assertEquals($rating_and_desc->descriptors, $descriptors);
  }

  /**
   * @covers ::setProcessedDatetimeUTC
   * @covers ::getProcessedDatetimeUTC
   */
  public function testSetGetProcessedDatetimeUTC() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('datetime', 'processed_datetime')));

    $time_zone = new \DateTimeZone('UTC');
    $date = new \DateTime('2016-04-12T00:00:00', $time_zone);

    $return = $this->contentTitle->setProcessedDatetimeUTC($date);

    $this->assertEquals($return, $this->contentTitle);

    $val = $this->contentTitle->getProcessedDatetimeUTC();

    $this->assertEquals($val, $date);
  }

  /**
   * @covers ::setName
   * @covers ::getName
   * @covers ::setTitleId
   * @covers ::getTitleId
   * @covers ::setSortableTitleName
   * @covers ::getSortableTitleName
   * @covers ::setTitleType
   * @covers ::getTitleType
   * @covers ::setAnimationMode
   * @covers ::getAnimationMode
   */
  public function testSetGetTitleIdAndName() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('integer', 'label')));

    $return = $this->contentTitle->setName('title');
    $this->assertEquals($return, $this->contentTitle);
    $name = $this->contentTitle->getName();

    $this->assertEquals('title', $name);

    // Title id.
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('integer', 'title_id')));

    $return = $this->contentTitle->setTitleId(12345);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getTitleId();

    $this->assertEquals(12345, $value);

    // Title sortable name.
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('integer', 'title_name')));

    $return = $this->contentTitle->setSortableTitleName('sortable name');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSortableTitleName();

    $this->assertEquals('sortable name', $value);

    // Title type.
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('integer', 'title_type')));

    $return = $this->contentTitle->setTitleType('Feature Film');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getTitleType();

    $this->assertEquals('Feature Film', $value);

    // Animation mode.
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('integer', 'animation_mode')));

    $return = $this->contentTitle->setAnimationMode('Animated');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getAnimationMode();

    $this->assertEquals('Animated', $value);

    $return = $this->contentTitle->setAnimationMode('Non-Animated');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getAnimationMode();

    $this->assertEquals('Non-Animated', $value);

  }

  /**
   * @covers ::setExternalStoryline
   * @covers ::getExternalStoryline
   * @covers ::setShortStoryline
   * @covers ::getShortStoryline
   * @covers ::setStorylines
   * @covers ::getStorylines
   */
  public function testSetGetStorylinesFields() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('datetime', 'external_storyline')));

    $external_story_lines = 'This is external storyline, or long storyline';
    $return = $this->contentTitle->setExternalStoryline($external_story_lines);
    $this->assertEquals($return, $this->contentTitle);
    $sd = $this->contentTitle->getExternalStoryline();

    $this->assertEquals($sd, $external_story_lines);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('datetime', 'short_storyline')));

    $short_story_lines = 'This is short storyline';
    $return = $this->contentTitle->setShortStoryline($short_story_lines);
    $this->assertEquals($return, $this->contentTitle);
    $sd = $this->contentTitle->getShortStoryline();

    $this->assertEquals($sd, $short_story_lines);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('datetime', 'storylines')));

    $external_story_lines = new \stdClass();
    $external_story_lines->Type = 'Turner External';
    $external_story_lines->Description = $external_story_lines;

    $short_story_lines = new \stdClass();
    $short_story_lines->Type = 'Short (245 Characters)';
    $short_story_lines->Description = $short_story_lines;

    $story_lines = [$external_story_lines, $short_story_lines];

    $return = $this->contentTitle->setShortStoryline($story_lines);
    $this->assertEquals($return, $this->contentTitle);

    $sd = $this->contentTitle->getShortStoryline();

    $this->assertEquals($sd, $story_lines);
    $this->assertEquals(count($sd), 2);

  }

  /**
   * @covers ::setSeriesTitleId
   * @covers ::getSeriesTitleId
   * @covers ::setSeriesTitleName
   * @covers ::getSeriesTitleName
   * @covers ::setSortableSeriesTitleName
   * @covers ::getSortableSeriesTitleName
   * @covers ::setSeriesItemNumber
   * @covers ::getSeriesItemNumber
   * @covers ::setExternalSeriesItemNumber
   * @covers ::getExternalSeriesItemNumber
   * @covers ::setSeasonName
   * @covers ::getSeasonName
   * @covers ::setSeasonEpisodeNumber
   * @covers ::getSeasonEpisodeNumber
   * @covers ::setSeasons
   * @covers ::getSeasons
   * @covers ::setSeriesItems
   * @covers ::getSeriesItems
   */
  public function testSetGetSeriesRelatedFields() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'series_title_id')));

    $return = $this->contentTitle->setSeriesTitleId(12345);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeriesTitleId();

    $this->assertEquals($value, 12345);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'series_title_name')));

    $return = $this->contentTitle->setSeriesTitleName('title name');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeriesTitleName();

    $this->assertEquals($value, 'title name');

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'sortable_series_title_name')));

    $return = $this->contentTitle->setSortableSeriesTitleName('title name');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSortableSeriesTitleName();

    $this->assertEquals($value, 'title name');

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'series_item_number')));

    $return = $this->contentTitle->setSeriesItemNumber('N123');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeriesItemNumber();

    $this->assertEquals($value, 'N123');

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'external_series_item_number')));

    $return = $this->contentTitle->setExternalSeriesItemNumber('N123');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getExternalSeriesItemNumber();

    $this->assertEquals($value, 'N123');

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'season_number')));

    $return = $this->contentTitle->setSeasonNumber(1);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeasonNumber();

    $this->assertEquals($value, 1);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'season_name')));

    $return = $this->contentTitle->setSeasonName('Season 1');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeasonName();

    $this->assertEquals($value, 'Season 1');

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'season_episode_number')));

    $return = $this->contentTitle->setSeasonEpisodeNumber('1');
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeasonEpisodeNumber();

    $this->assertEquals($value, '1');

    // Seasons array.
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'seasons')));

    $seasons = [];
    $s = new \stdClass();
    $s->SeasonNumber = 1;
    $seasons[] = $s;

    $s = new \stdClass();
    $s->SeasonNumber = 2;
    $seasons[] = $s;

    $s = new \stdClass();
    $s->SeasonNumber = 3;
    $seasons[] = $s;

    $return = $this->contentTitle->setSeasons($seasons);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeasons();

    $this->assertEquals($value, $seasons);
    $this->assertEquals(3, count($seasons));

    // series_items.
    $series_items = [];
    $item = new \stdClass();
    $item->SeasonNumber = 1;
    $item->TitleId = 10000;
    $item->TitleName = 'episode 1';
    $item->TitleType = 'Episode';

    $series_items[] = $item;

    $item = new \stdClass();
    $item->SeasonNumber = 2;
    $item->TitleId = 20000;
    $item->TitleName = 'episode 2';
    $item->TitleType = 'Episode';

    $series_items[] = $item;

    $item = new \stdClass();
    $item->SeasonNumber = 3;
    $item->TitleId = 30000;
    $item->TitleName = 'episode 3';
    $item->TitleType = 'Episode';

    $series_items[] = $item;

    $return = $this->contentTitle->setSeriesItems($series_items);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getSeriesItems();

    $this->assertEquals($value, $series_items);
    $this->assertEquals(3, count($series_items));

  }

  /**
   * @covers ::setReleaseYear
   * @covers ::getReleaseYear
   * @covers ::getTags
   * @covers ::setTags
   * @covers ::setGenres
   * @covers ::getGenres
   * @covers ::setKeywords
   * @covers ::getKeywords
   */
  public function testSetGetMiscellanousFields() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'release_year')));

    $return = $this->contentTitle->setReleaseYear(2016);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getReleaseYear();

    $this->assertEquals($value, 2016);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'length_in_seconds')));

    $return = $this->contentTitle->setLengthInSeconds(1000);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getLengthInSeconds();

    $this->assertEquals($value, 1000);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'tags')));

    $tags = ['tag1', 'tag2'];

    $return = $this->contentTitle->setTags($tags);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getTags();

    $this->assertEquals($value, $tags);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'genres')));

    $genre = new \stdClass();
    $genre->Name = 'Comedy';
    $genre->GenreId = 2;
    $genres = [$genre];

    $return = $this->contentTitle->setGenres($genres);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getGenres();

    $this->assertEquals($value, $genres);

    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'keywords')));

    $keywords = [];

    $keyword = new \stdClass();
    $keyword->Name = 'stuff';
    $keyword->KeywordId = 1;
    $keywords[] = $keyword;

    $keyword = new \stdClass();
    $keyword->Name = 'Helicopters';
    $keyword->KeywordId = 2;
    $keywords[] = $keyword;

    $keyword = new \stdClass();
    $keyword->Name = 'test';
    $keyword->KeywordId = 3;
    $keywords[] = $keyword;

    $return = $this->contentTitle->setKeywords($keywords);
    $this->assertEquals($return, $this->contentTitle);
    $value = $this->contentTitle->getKeywords();

    $this->assertEquals($value, $keywords);
  }

  /**
   * @covers ::getLanguageName
   */
  public function testGetLanguageName() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'content_json')));

    $data = new \stdClass();

    $language = new \stdClass();
    $language->Name = 'ENGLISH';
    $language->LanguageId = 13;
    $data->Language = $language;

    $this->contentTitle->setContentJson($data);

    $this->assertEquals($this->contentTitle->getLanguageName(), 'ENGLISH');

    $data->Language = NULL;
    $this->contentTitle->setContentJson($data);

    $this->assertEquals($this->contentTitle->getLanguageName(), NULL);

    $data->Language = new \stdClass();
    $this->contentTitle->setContentJson($data);

    $this->assertEquals($this->contentTitle->getLanguageName(), NULL);
  }

  /**
   * @covers ::getChangedTime
   * @covers ::setChangedTime
   */
  public function testSetGetChangedTime() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
    // Extended property.
      ->will($this->returnValue($this->getFieldItemList('string', 'changed', 'changed Time')));

    $return = $this->contentTitle->setChangedTime("123");
    $this->assertEquals($return, $this->contentTitle);
    $sname = $this->contentTitle->getChangedTime();

    $this->assertEquals($sname, "123");
  }

  /**
   * @covers ::getImportedTime
   * @covers ::setImportedTime
   */
  public function testSetGetImportedTime() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
    // Extended property.
      ->will($this->returnValue($this->getFieldItemList('string', 'changed', 'changed Time')));

    $return = $this->contentTitle->setImportedTime("20160210");
    $this->assertEquals($return, $this->contentTitle);
    $sname = $this->contentTitle->getImportedTime();

    $this->assertEquals($sname, "20160210");
  }

  /**
   * @covers ::getContentJson
   * @covers ::setContentJson
   */
  public function testSetGetContentJson() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'content_json')));

    $data = new \stdClass();
    $data->TitleName = 'title';
    $data->TitleNameSortable = 'title';
    $data->TitleId = 11111;

    $return = $this->contentTitle->setContentJson($data);

    $this->assertEquals($return, $this->contentTitle);

    $json = $this->contentTitle->getContentJson();

    $this->assertEquals($json, $data);
  }

  /**
   * @covers ::getStringKeywords
   * @covers ::getStringGenres
   * @covers ::getStringKeyGenres
   */
  public function testGetStringValuesFromGenresAndKeywordsArray() {
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->will($this->returnValue($this->getFieldItemList('string', 'content_json')));

    // Keywords.
    $keywords = [];

    $keyword1 = new \stdClass();
    $keyword1->Name = 'keyword1';
    $keyword1->KeywordId = 1;
    $keywords[] = $keyword1;

    $keyword2 = new \stdClass();
    $keyword2->Name = 'keyword2';
    $keyword2->KeywordId = 2;
    $keywords[] = $keyword2;

    $this->contentTitle->setKeywords($keywords);

    $this->assertEquals(count($this->contentTitle->getKeywords()), 2);

    $string_keywords = $this->contentTitle->getStringKeywords();
    $this->assertEquals(count($string_keywords), 2);

    $this->assertEquals($string_keywords[0], 'keyword1');
    $this->assertEquals($string_keywords[1], 'keyword2');

    // Genres.
    $genres = [];

    $genre1 = new \stdClass();
    $genre1->Name = 'Comedy';
    $genre1->GenreId = 1;
    $genres[] = $genre1;

    $genre2 = new \stdClass();
    $genre2->Name = 'Advanture';
    $genre2->GenreId = 2;
    $genres[] = $genre2;

    $this->contentTitle->setGenres($genres);

    $this->assertEquals(count($this->contentTitle->getGenres()), 2);

    $string_genres = $this->contentTitle->getStringGenres();
    $this->assertEquals(count($string_genres), 2);

    $this->assertEquals($string_genres[0], 'Comedy');
    $this->assertEquals($string_genres[1], 'Advanture');

    // key_genres.
    $key_genres = [];

    $key_genre1 = new \stdClass();
    $key_genre1->Name = 'Comedy';
    $key_genre1->GenreId = 1;
    $key_genres[] = $key_genre1;

    $key_genre2 = new \stdClass();
    $key_genre2->Name = 'Advanture';
    $key_genre2->GenreId = 2;
    $key_genres[] = $key_genre2;

    $this->contentTitle->setKeyGenres($key_genres);

    $this->assertEquals(count($this->contentTitle->getKeyGenres()), 2);

    $string_key_genres = $this->contentTitle->getStringKeyGenres();
    $this->assertEquals(count($string_key_genres), 2);

    $this->assertEquals($string_key_genres[0], 'Comedy');
    $this->assertEquals($string_key_genres[1], 'Advanture');

  }

  /**
   * Create a MockFieldItemList based on a MockFieldDefinition for a field.
   */
  private function getFieldItemList($type, $name, $label = '') {
    $field_definition = new MockFieldDefinition(array(), $type, $name, $label);
    $field_list = new MockFieldItemList($field_definition, array(), $name);
    return $field_list;
  }

  /**
   * @return array
   *    List of field definitions.
   */
  private function fieldDefinitions() {

    return array(
      'sortable_title_name' => $this->getFieldItemList('string', 'sortable_title_name'),
      'uuid' => $this->getFieldItemList('string', 'uuid'),
      'label' => $this->getFieldItemList('string', 'label'),
      'changed' => $this->getFieldItemList('changed', 'changed'),
      'imported' => $this->getFieldItemList('created', 'imported'),
      'network' => $this->getFieldItemList('created', 'imported'),
      'title_id' => $this->getFieldItemList('integer', 'title_id'),
      'title_type' => $this->getFieldItemList('string', 'title_type'),
      'length_in_seconds' => $this->getFieldItemList('integer', 'length_in_seconds'),
      'release_year' => $this->getFieldItemList('integer', 'release_year'),
      'processed_datetime' => $this->getFieldItemList('datetime', 'processed_datetime'),
      'animation_mode' => $this->getFieldItemList('datetime', 'animation_mode'),
      'performance_mode' => $this->getFieldItemList('string', 'performance_mode'),
      'external_storyline' => $this->getFieldItemList('string', 'external_storyline'),
      'short_storyline' => $this->getFieldItemList('string', 'short_storyline'),
      'storylines' => $this->getFieldItemList('string_long', 'storylines'),
      'genres' => $this->getFieldItemList('string', 'genres'),
      'key_genres' => $this->getFieldItemList('string', 'key_genres'),
      'tags' => $this->getFieldItemList('string_long', 'tags'),
      'keywords' => $this->getFieldItemList('string', 'keywords'),
      'ratings' => $this->getFieldItemList('string_long', 'ratings'),
      'participants' => $this->getFieldItemList('string_long', 'participants'),
      'series_title_id' => $this->getFieldItemList('integer', 'series_title_id'),
      'series_title_name' => $this->getFieldItemList('string', 'series_title_name'),
      'sortable_series_title_name' => $this->getFieldItemList('string', 'sortable_series_title_name'),
      'series_item_number' => $this->getFieldItemList('string', 'series_item_number'),
      'external_series_item_number' => $this->getFieldItemList('string', 'external_series_item_number'),
      'season_number' => $this->getFieldItemList('integer', 'season_number'),
      'season_name' => $this->getFieldItemList('string', 'season_name'),
      'season_episode_number' => $this->getFieldItemList('string', 'season_episode_number'),
      'seasons' => $this->getFieldItemList('string_long', 'seasons'),
      'series_items' => $this->getFieldItemList('string_long', 'series_items'),
      'content_json' => $this->getFieldItemList('string_long', 'content_json'),
    );
  }

}
