<?php

namespace Drupal\Tests\draco_udi\Unit\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\draco_udi\Entity\ContentOnDemandSchedule;

/**
 * Class ContentOnDemandScheduleTest.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Entity\ContentOnDemandSchedule
 */
class ContentOnDemandScheduleTest extends DracoContentEntityTestBase {

  /**
   * The ContentOnDemandSchedule under test.
   *
   * @var \Drupal\draco_udi\Entity\ContentOnDemandSchedule|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $onDemandSchedule;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();
    $id = 1;
    $values = array(
      'id' => $id,
      'label' => 'test ContentOnDemandSchedule',
      'uuid' => '3bb9ee60-bea5-4622-b89b-a63319d10b3a',
    );

    $this->onDemandSchedule = new ContentOnDemandSchedule($values, $this->getEntityTypeId());
  }

  /**
   * Test basic get / set methods.
   *
   * @param string $field_name
   *   The field name to test.
   * @param mixed $value
   *   The value to save in the field.
   * @param mixed|null $stored
   *   (optional) If the value to save is not stored directly as $value, use
   *   this value instead.
   * @param string|null $method_template
   *   (optional) A template to use for get / set methods, such as
   *   'ChangedTime'.
   *
   * @dataProvider getSetData
   *
   * @covers ::setMediaId
   * @covers ::getMediaId
   * @covers ::setAiringId
   * @covers ::getAiringId
   * @covers ::setBrand
   * @covers ::getBrand
   * @covers ::getLengthInSeconds
   * @covers ::setLengthInSeconds
   * @covers ::getDisplayMinutes
   * @covers ::getDisplayMinutes
   * @covers ::getChangedTime
   * @covers ::setChangedTime
   * @covers ::getImportedTime
   * @covers ::setImportedTime
   * @covers ::getContentJson
   * @covers ::setContentJson
   * @covers ::getVersions
   * @covers ::setVersions
   * @covers ::getPlaylist
   * @covers ::setPlaylist
   * @covers ::getFiles
   * @covers ::setFiles
   * @covers ::getTitleData
   * @covers ::setTitleData
   * @covers ::getTveContent
   * @covers ::setTveContent
   * @covers ::getAssets
   * @covers ::setAssets
   * @covers ::getThumbs
   * @covers ::setThumbs
   * @covers ::getAdBreaks
   * @covers ::setAdBreaks
   * @covers ::getContentSegments
   * @covers ::setContentSegments
   */
  public function testGetSetMethods($field_name, $value, $stored = NULL, $method_template = NULL) {
    $this->assertGetSetMethod($this->onDemandSchedule, $field_name, $value, $stored, $method_template);
  }

  /**
   * Data to test setter and getter methods.
   *
   * @return array
   *   An array of data used in testGetSetMethods. Each array item contains:
   *    - The field name, corresponding to a get method on the linear schedule.
   *    - The value to use save and validate.
   *    - (optional) The expected value to be saved in the entity itself as a
   *      scalar. If omitted, the value is used.
   *    - (optional) A method template to use for get / set methods, such as
   *      'ChangedTime'.
   */
  public function getSetData() {
    return [
      ['brand', 'TBS'],
      ['type', 'Episode'],
      ['length_in_seconds', 2000],
      ['display_minutes', 30],
      ['changed', "123", NULL, 'ChangedTime'],
      ['imported', "20160210", NULL, 'ImportedTime'],
      [
        'content_json',
        $this->getVideoStatusData(),
        json_encode($this->getVideoStatusData()),
      ],
      [
        'versions',
        $this->getVersionsData(),
        json_encode($this->getVersionsData()),
      ],
      [
        'playlist',
        $this->getPlaylistData(),
        json_encode($this->getPlaylistData()),
      ],
      ['files', ['file/1', 'file/2'], json_encode(['file/1', 'file/2'])],
      ['title_data', $this->getTitleData(), json_encode($this->getTitleData())],
      ['media_id', 'mediaId1000'],
      ['airing_id', 'tbs1000'],
      [
        'tve_content',
        $this->getTveItemData(),
        json_encode($this->getTveItemData()),
      ],
      [
        'assets',
        $this->getTveItemData()->TveItem->Assets,
        json_encode($this->getTveItemData()->TveItem->Assets),
      ],
      [
        'thumbs',
        $this->getTveItemData()->TveItem->Thumbs,
        json_encode($this->getTveItemData()->TveItem->Thumbs),
      ],
      [
        'ad_breaks',
        $this->getTveItemData()->TveItem->AdBreaks,
        json_encode($this->getTveItemData()->TveItem->AdBreaks),
      ],
      [
        'content_segments',
        $this->getTveItemData()->TveItem->ContentSegments,
        json_encode($this->getTveItemData()->TveItem->ContentSegments),
      ],
    ];
  }

  /**
   * Test TVE content related properties.
   *
   * @covers ::getTurnerPrivate
   * @covers ::getTveTitleData
   */
  public function testGetSetTveProperties() {
    $this->setMockFieldItemList('tve_content', json_encode($this->getTveItemData()));
    $this->onDemandSchedule->setTveContent($this->getTveItemData());
    $tve_content = $this->onDemandSchedule->getTveContent();
    $this->assertEquals($tve_content->TveItem->Title, $this->onDemandSchedule->getTveTitleData());
    $this->assertEquals($tve_content->TveItem->TurnerPrivate, $this->onDemandSchedule->getTurnerPrivate());
  }

  /**
   * Test get primary title id.
   *
   * @covers ::getPrimaryTitleId
   */
  public function testGetPrimaryTitleId() {
    $data = new \stdClass();
    $data->mediaId = 'mediaId12345';
    $data->airingId = 'airing12345';

    $title1 = new \stdClass();
    $title1->titleId = 10000;
    $title2 = new \stdClass();
    $title2->titleId = 10001;

    $titles = [$title1, $title2];

    $data->options = new \stdClass();
    $data->options->titles = $titles;

    $title = new \stdClass();
    $title->storyline = new \stdClass();
    $title->rating = new \stdClass();

    $title_id1 = new \stdClass();
    $title_id1->type = 'Episode';
    $title_id1->value = '10000';
    $title_id1->primary = TRUE;
    $title_id2 = new \stdClass();
    $title_id2->type = 'Clip';
    $title_id2->value = '10001';
    $title_id2->primary = FALSE;
    $title->titleIds = [$title_id1, $title_id2];
    $data->title = $title;
    $this->setMockFieldItemList('content_json', json_encode($data));
    $this->onDemandSchedule->setContentJson($data);
    $primaryId = $this->onDemandSchedule->getPrimaryTitleId();
    $this->assertEquals('10000', $primaryId);

  }

  /**
   * Test get content ids.
   *
   * @covers ::getContentIds
   */
  public function testGetContentIds() {

    $this->setMockFieldItemList('versions', json_encode($this->getVersionsData()));
    $this->onDemandSchedule->setVersions($this->getVersionsData());
    $content_ids = $this->onDemandSchedule->getContentIds();

    $this->assertEquals(2, count($content_ids));
    $this->assertEquals('12345', $content_ids[0]);
    $this->assertEquals('6789', $content_ids[1]);

  }

  /**
   * Test get content ids with Empty Versions array.
   *
   * @covers ::getContentIds
   */
  public function testGetContentIdsWithEmptyVersions() {

    $this->setMockFieldItemList('versions', json_encode([]));
    $this->onDemandSchedule->setVersions([]);
    $content_ids = $this->onDemandSchedule->getContentIds();

    $this->assertEquals(0, count($content_ids));

  }

  /**
   * @covers ::getVideoStatus
   */
  public function testGetVideoStatus() {
    $this->setMockFieldItemList('content_json', json_encode($this->getVideoStatusData()));
    $data = $this->getVideoStatusData();
    $this->onDemandSchedule->setContentJson($data);
    $status = $this->onDemandSchedule->getVideoStatus();
    $this->assertTrue($status);
  }

  /**
   * @covers ::getVideoStatus
   */
  public function testGetVideoStatusNoOptions() {
    $data = new \stdClass();
    $data->options = new \stdClass();
    $this->setMockFieldItemList('content_json', json_encode($data));
    $this->onDemandSchedule->setContentJson($data);
    $status = $this->onDemandSchedule->getVideoStatus();
    $this->assertFalse($status);
  }

  /**
   * {@inheritdoc}
   */
  protected function getFieldDefinitions() {
    return array(
      'media_id' => BaseFieldDefinition::create('string'),
      'uuid' => BaseFieldDefinition::create('string'),
      'label' => BaseFieldDefinition::create('string'),
      'changed' => BaseFieldDefinition::create('changed'),
      'imported' => BaseFieldDefinition::create('created'),
      'network' => BaseFieldDefinition::create('created'),
      'airing_id' => BaseFieldDefinition::create('string'),
      'brand' => BaseFieldDefinition::create('string'),
      'type' => BaseFieldDefinition::create('string'),
      'length_in_seconds' => BaseFieldDefinition::create('integer'),
      'display_minutes' => BaseFieldDefinition::create('integer'),
      'playlist' => BaseFieldDefinition::create('string_long'),
      'versions' => BaseFieldDefinition::create('string_long'),
      'files' => BaseFieldDefinition::create('string_long'),
      'title_data' => BaseFieldDefinition::create('string_long'),
      'content_json' => BaseFieldDefinition::create('string_long'),
      'tve_content' => BaseFieldDefinition::create('string_long'),
      'assets' => BaseFieldDefinition::create('string_long'),
      'ad_breaks' => BaseFieldDefinition::create('string_long'),
      'content_segments' => BaseFieldDefinition::create('string_long'),
      'thumbs' => BaseFieldDefinition::create('string_long'),
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getEntityTypeId() {
    return 'content_on_demand_schedule';
  }

  /**
   * Return an object with a video and options attribute.
   *
   * @return \stdClass
   *   The object with the video and options attributes set.
   */
  protected function getVideoStatusData() {
    $data = new \stdClass();
    $data->options = new \stdClass();
    $status = new \stdClass();
    $status->video = TRUE;
    $data->options->status = $status;
    return $data;
  }

  /**
   * Return an array of versions data objects.
   *
   * @return array
   *   An array of versions data.
   */
  protected function getVersionsData() {
    $version1 = new \stdClass();
    $version1->contentId = '12345';
    $version1->closedCaptioning = new \stdClass();
    $version2 = new \stdClass();
    $version2->contentId = '6789';
    $version2->closedCaptioning = new \stdClass();
    return [$version1, $version2];
  }

  /**
   * Return an array of playlist data objects.
   *
   * @return array
   *   The array of playlist data.
   */
  protected function getPlaylistData() {
    $play_1 = new \stdClass();
    $play_1->position = 1;
    $play_1->id = '1';
    $play_1->itemType = 'Segment';

    $play_2 = new \stdClass();
    $play_2->position = 2;
    $play_2->id = '2';
    $play_2->itemType = 'Trigger';

    $play_3 = new \stdClass();
    $play_3->position = 3;
    $play_3->id = '3';
    $play_3->itemType = 'Segment';

    $playlist = [$play_1, $play_2, $play_3];
    return $playlist;
  }

  /**
   * Return a title data object.
   *
   * @return \stdClass
   *   The title data object.
   */
  protected function getTitleData() {
    $title = new \stdClass();
    $title->storyline = new \stdClass();
    $title->rating = new \stdClass();

    $title_id = new \stdClass();
    $title_id->type = 'Episode';
    $title_id->value = '12345';
    $title->titleIds = [$title_id];
    return $title;
  }

  /**
   * Return an object with a TveItem attribute.
   *
   * @return \stdClass
   *   The data object.
   */
  protected function getTveItemData() {
    $data = new \stdClass();
    $data->TveItem = new \stdClass();
    $data->TveItem->Title = new \stdClass();
    $data->TveItem->Title->Id = 736356;
    $data->TveItem->Title->Type = 'Feature Film';
    $data->TveItem->Title->TVRatingCode = 'TV-14-DLSV';

    $data->TveItem->Assets = new \stdClass();
    $assets = [new \stdClass()];
    $data->TveItem->Assets->Asset = $assets;

    $data->TveItem->Thumbs = new \stdClass();
    $thumbs = [new \stdClass()];
    $data->TveItem->Thumbs->Thumb = $thumbs;

    $data->TveItem->AdBreaks = new \stdClass();
    $abs = [new \stdClass()];
    $data->TveItem->AdBreaks->AdBreak = $abs;

    $data->TveItem->ContentSegments = new \stdClass();
    $css = [new \stdClass()];
    $data->TveItem->ContentSegments->ContentSegment = $css;

    $data->TveItem->TurnerPrivate = new \stdClass();
    $data->TveItem->TurnerPrivate->FranchiseId = '346985';
    $data->TveItem->TurnerPrivate->IsActive = 'False';
    return $data;
  }

}
