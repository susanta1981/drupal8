<?php

namespace Drupal\Tests\draco_udi\Unit\Entity;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Tests\UnitTestCase;
use Symfony\Component\DependencyInjection\Container;

/**
 * Base class for UDI entity tests.
 */
abstract class DracoContentEntityTestBase extends UnitTestCase {
  /**
   * The mock entity manager service.
   *
   * @var \Drupal\Core\Entity\EntityManagerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $entityManager;

  /**
   * The mock field type plugin manager.
   *
   * @var \Drupal\Core\Field\FieldTypePluginManagerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $fieldTypePluginManager;

  /**
   * Return the entity type ID under test, such as 'content_linear_schedule'.
   *
   * @return string
   *   The entity type ID.
   */
  abstract protected function getEntityTypeId();

  /**
   * Return the field definitions for the linear schedule entity.
   *
   * We have to mock these as baseFieldDefinitions() is static so it can't
   * use StringTranslationTrait for field labels.
   *
   * @return array
   *    List of field definitions.
   */
  abstract protected function getFieldDefinitions();

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    $language = $this->getMockBuilder('Drupal\Core\Language\LanguageInterface')->getMock();
    $language->method('getId')
      ->willReturn('us');

    $language_manager = $this->getMockBuilder('Drupal\Core\Language\LanguageManagerInterface')->getMock();
    $language_manager->method('getCurrentLanguage')
      ->will($this->returnValue($language));

    $entityType = $this->getMockBuilder('\Drupal\Core\Entity\EntityTypeInterface')->getMock();
    $entityType->method('getKeys')
      ->will($this->returnValue(array(
        'id' => 'id',
        'label' => 'label',
        'uuid' => 'uuid',
      )));

    $this->fieldTypePluginManager = $this->getMockBuilder('Drupal\Core\Field\FieldTypePluginManagerInterface')->getMock();
    $this->fieldTypePluginManager->method('getDefaultFieldSettings')
      ->willReturn(array());
    $this->fieldTypePluginManager->method('getDefaultStorageSettings')
      ->willReturn(array());

    $this->entityManager = $this->getMockBuilder('\Drupal\Core\Entity\EntityManagerInterface')->getMock();
    $this->entityManager->method('getDefinition')
      ->with($this->getEntityTypeId())
      ->will($this->returnValue($entityType));

    $uuid = $this->getMockBuilder('\Drupal\Component\Uuid\UuidInterface')->getMock();
    $container = new ContainerBuilder();
    $container->set('entity.manager', $this->entityManager);
    $container->set('uuid', $uuid);
    $container->set("plugin.manager.field.field_type", $this->fieldTypePluginManager);
    $container->set("language_manager", $language_manager);
    $container->set("language", $language);
    \Drupal::setContainer($container);

    $this->entityManager->expects($this->any())
      ->method('getFieldDefinitions')
      ->with($this->getEntityTypeId(), $this->getEntityTypeId())
      ->will($this->returnValue($this->getFieldDefinitions()));

  }

  /**
   * Set a field item list that returns a value.
   *
   * @param string $field_name
   *   The name of the field to set, such as 'franchise_id'.
   * @param mixed $value
   *   The value to return, as a scalar.
   */
  protected function setMockFieldItemList($field_name, $value) {
    $field_item_list = $this->getMock(FieldItemListInterface::class);
    $field_item_list->expects($this->once())
      ->method('setValue')
      ->with($value);
    $field_item_list->expects($this->atLeastOnce())
      ->method('__get')
      ->willReturn($value);
    $this->fieldTypePluginManager->expects($this->any())
      ->method('createFieldItemList')
      ->with($this->anything(), $field_name, $this->anything())
      ->will($this->returnValue($field_item_list));
  }

  /**
   * Assert a simple get / set method.
   *
   * This method isn't a test method so we can specify coverage within each test
   * class.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity to assert the methods on.
   * @param string $field_name
   *   The field name to test.
   * @param mixed $value
   *   The value to save in the field.
   * @param mixed|null $stored
   *   (optional) If the value to save is not stored directly as $value, use
   *   this value instead.
   */
  protected function assertGetSetMethod(EntityInterface $entity, $field_name, $value, $stored = NULL, $method_template = NULL) {
    if (!$method_template) {
      $method_template = Container::camelize($field_name);
    }
    $get_method = 'get' . $method_template;
    $set_method = 'set' . $method_template;

    $stored = $stored ?: $value;
    $this->setMockFieldItemList($field_name, $stored);
    $return = $entity->{$set_method}($value);
    $this->assertEquals($return, $entity);
    $this->assertEquals($value, $entity->{$get_method}());
  }

}
