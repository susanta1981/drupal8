<?php

namespace Drupal\Tests\draco_udi\Unit\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\draco_udi\Entity\ContentLinearSchedule;

/**
 * Tests The ContentLinearSchedule class.
 *
 * @group draco_udi
 *
 * @coversDefaultClass \Drupal\draco_udi\Entity\ContentLinearSchedule
 */
class ContentLinearScheduleTest extends DracoContentEntityTestBase {

  /**
   * The linear schedule entity under test.
   *
   * @var \Drupal\draco_udi\Entity\ContentLinearSchedule|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $linearSchedule;

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();

    $values = array(
      'id' => 1,
      'label' => 'test ContentLinearSchedule',
      'uuid' => '3bb9ee60-bea5-4622-b89b-a63319d10b3a',
    );

    $this->linearSchedule = new ContentLinearSchedule($values, $this->getEntityTypeId());
  }

  /**
   * Test basic get / set methods.
   *
   * @param string $field_name
   *   The field name to test.
   * @param mixed $value
   *   The value to save in the field.
   * @param mixed|null $stored
   *   (optional) If the value to save is not stored directly as $value, use
   *   this value instead.
   * @param string|null $method_template
   *   (optional) A template to use for get / set methods, such as
   *   'ChangedTime'.
   *
   * @dataProvider getSetData
   *
   * @covers ::setNetwork
   * @covers ::getNetwork
   * @covers ::setPlatform
   * @covers ::getPlatform
   * @covers ::setSource
   * @covers ::getSource
   * @covers ::setStartDate
   * @covers ::getStartDate
   * @covers ::setEndDate
   * @covers ::getEndDate
   * @covers ::getUTCDateTime
   * @covers ::setDateTimeAsUTCString
   * @covers ::setIsLive
   * @covers ::getIsLive
   * @covers ::setIsPremiere
   * @covers ::getIsPremiere
   * @covers ::setFranchiseId
   * @covers ::getFranchiseId
   * @covers ::setFranchiseName
   * @covers ::getFranchiseName
   * @covers ::setFranchiseDuration
   * @covers ::getFranchiseDuration
   * @covers ::setTimeZone
   * @covers ::getTimeZone
   * @covers ::setPreText
   * @covers ::getPreText
   * @covers ::setNewsUpdate
   * @covers ::getNewsUpdate
   * @covers ::setNetworkFeedCode
   * @covers ::getNetworkFeedCode
   * @covers ::setExternalId
   * @covers ::getExternalId
   * @covers ::setClosedCaptions
   * @covers ::getClosedCaptions
   * @covers ::getChangedTime
   * @covers ::setChangedTime
   * @covers ::getImportedTime
   * @covers ::setImportedTime
   * @covers ::getContentJson
   * @covers ::setContentJson
   * @covers ::getTitleIdList
   */
  public function testGetSetMethods($field_name, $value, $stored = NULL, $method_template = NULL) {
    $this->assertGetSetMethod($this->linearSchedule, $field_name, $value, $stored, $method_template);
  }

  /**
   * Data to test setter and getter methods.
   *
   * @return array
   *   An array of data used in testGetSetMethods. Each array item contains:
   *    - The field name, corresponding to a get method on the linear schedule.
   *    - The value to use save and validate.
   *    - (optional) The expected value to be saved in the entity itself as a
   *      scalar. If omitted, the value is used.
   *    - (optional) A method template to use for get / set methods, such as
   *      'ChangedTime'.
   */
  public function getSetData() {
    return [
      ['network', 'TBS'],
      ['platform', 'linear'],
      ['source', 'linear'],
      [
        'start_date',
        new \DateTime('2016-04-12T00:00:00Z'),
        '2016-04-12T00:00:00',
      ],
      [
        'end_date',
        new \DateTime('2016-04-12T00:00:00Z'),
        '2016-04-12T00:00:00',
      ],
      [
        'schedule_air_date',
        new \DateTime('2016-04-12T00:00:00Z'),
        '2016-04-12T00:00:00',
      ],
      [
        'schedule_airing_start_time',
        101,
      ],
      ['is_live', 'T'],
      ['is_premiere', 'Y'],
      ['franchise_id', 111],
      ['franchise_name', 'Movie'],
      ['franchise_duration', 100],
      ['time_zone', 'Eastern'],
      ['pre_text', 'pre stuff'],
      ['news_update', 'test'],
      ['network_feed_code', 'C'],
      ['external_id', 54321],
      ['cc', 'cc', NULL, 'ClosedCaptions'],
      ['changed', '123', NULL, 'ChangedTime'],
      ['imported', '20160210', NULL, 'ImportedTime'],
      [
        'content_json',
        $this->linearScheduleData(),
        json_encode($this->linearScheduleData()),
      ],
    ];
  }

  /**
   * Test setting title IDs.
   *
   * This test is separate as the return value doesn't match the value that is
   * set.
   *
   * @covers ::getTitleIds
   * @covers ::setTitleIds
   */
  public function testGetSetTitleIds() {
    $ids = [12345, 67890];
    $this->setMockFieldItemList('title_ids', $ids);

    $this->linearSchedule->setTitleIds($ids);
    $field = $this->linearSchedule->getTitleIds();
    $this->assertInstanceOf(FieldItemListInterface::class, $field);
    $this->assertArrayEquals($ids, $field->value);
  }

  /**
   * Test getting the value of the title IDs field.
   *
   * This test is separate as the set method name doesn't match the get method.
   *
   * @covers ::getTitleIdsValue
   */
  public function testGetTitleIdsValue() {
    $ids = [12345, 67890];
    $this->setMockFieldItemList('title_ids', $ids);

    $this->linearSchedule->setTitleIds($ids);
    $this->assertArrayEquals($ids, $this->linearSchedule->getTitleIdsValue());
  }

  /**
   * {@inheritdoc}
   */
  protected function getFieldDefinitions() {

    $field_externalId = BaseFieldDefinition::create('integer');
    $field_uuid = BaseFieldDefinition::create('uuid');
    $field_label = BaseFieldDefinition::create('string');
    $field_changed = BaseFieldDefinition::create('changed');
    $field_imported = BaseFieldDefinition::create('created');
    $field_network = BaseFieldDefinition::create('string');
    $field_platform = BaseFieldDefinition::create('string');
    $field_source = BaseFieldDefinition::create('string');
    $field_startDate = BaseFieldDefinition::create('datetime');
    $field_endDate = BaseFieldDefinition::create('datetime');
    $field_preText = BaseFieldDefinition::create('string');
    $field_timeZone = BaseFieldDefinition::create('string');
    $field_isLive = BaseFieldDefinition::create('string');
    $field_isPremiere = BaseFieldDefinition::create('string');
    $field_franchiseName = BaseFieldDefinition::create('string');
    $field_franchiseId = BaseFieldDefinition::create('integer');
    $field_franchiseDuration = BaseFieldDefinition::create('string');
    $field_networkFeedCode = BaseFieldDefinition::create('string');
    $field_scheduleAirDate = BaseFieldDefinition::create('datetime');
    $field_scheduleAiringStartTime = BaseFieldDefinition::create('datetime');
    $field_cc = BaseFieldDefinition::create('string');
    $field_newsUpdate = BaseFieldDefinition::create('string');
    $field_contentJson = BaseFieldDefinition::create('string_long');
    $field_title_ids = BaseFieldDefinition::create('integer');

    return array(
      'external_id' => $field_externalId,
      'uuid' => $field_uuid,
      'label' => $field_label,
      'changed' => $field_changed,
      'imported' => $field_imported,
      'network' => $field_network,
      'platform' => $field_platform,
      'source' => $field_source,
      'start_date' => $field_startDate,
      'end_date' => $field_endDate,
      'pre_text' => $field_preText,
      'time_zone' => $field_timeZone,
      'is_live' => $field_isLive,
      'is_premiere' => $field_isPremiere,
      'franchise_name' => $field_franchiseName,
      'franchise_id' => $field_franchiseId,
      'franchise_duration' => $field_franchiseDuration,
      'network_feed_code' => $field_networkFeedCode,
      'schedule_air_date' => $field_scheduleAirDate,
      'schedule_airing_start_time' => $field_scheduleAiringStartTime,
      'cc' => $field_cc,
      'news_update' => $field_newsUpdate,
      'content_json' => $field_contentJson,
      'title_ids' => $field_title_ids,
    );
  }

  /**
   * Return a linear schedule data object.
   *
   * @return \stdClass
   *   The linear schedule data.
   */
  private function linearScheduleData() {
    $data = new \stdClass();
    $data->name = 'linear schedule';
    $data->network = 'TBS';
    $data->start_date = '2016-04-01T00:00:00';
    $data->end_date = '2016-04-30T00:00:00';

    $title = new \stdClass();
    $title->TitleId = 1000;
    $title->Name = 'this is title';
    $data->Titles = [$title];
    return $data;
  }

  /**
   * {@inheritdoc}
   */
  protected function getEntityTypeId() {
    return 'content_linear_schedule';
  }

}
