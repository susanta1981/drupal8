<?php

namespace Drupal\Tests\draco_udi\FunctionalJavascript\Entity;

use Drupal\draco_udi\Entity\ContentTitle;
use Drupal\FunctionalJavascriptTests\JavascriptTestBase;

/**
 * @class ContentTitleTest
 * @package Drupal\Tests\draco_udi\Functional\Entity
 * @group draco_udi
 */
class ContentTitleTest extends JavascriptTestBase {

  public static $modules = [
    'draco_udi',
  ];

  public function testContentTitleDelete() {
    $values = array(
      'label' => 'test ContentTitle',
    );

    $content_title = ContentTitle::create($values);
    $content_title->save();
    $id = $content_title->id();

    $this->drupalLogin($this->rootUser);
    $this->drupalGet('admin/structure/udi/content_title/' . $id . '/delete');
    $this->submitForm([], t('Delete'));
    $this->assertEquals(200, $this->getSession()->getStatusCode());

    $content_title = \Drupal::entityTypeManager()->getStorage('content_title')
      ->load($id);
    $this->assertFalse($content_title);
  }

}
