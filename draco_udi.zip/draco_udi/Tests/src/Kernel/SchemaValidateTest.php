<?php

namespace Drupal\Tests\draco_udi\Kernel;

use Drupal\KernelTests\KernelTestBase;

/**
 * Tests the schema by saving data into it.
 *
 * If the schema validation fails, the test will throw an error.
 *
 * @group draco_udi.
 */
class SchemaValidateTest extends KernelTestBase {

  /**
   * {@inheritdoc}
   */
  public static $modules = [
    'datetime',
    'user',
    'system',
    'filter',
    'field',
    'text',
    'views',
    'draco_udi',
  ];

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();
    $this->installSchema('system', 'sequences');
    $this->installEntitySchema('user');
    $this->installConfig('draco_udi');
  }

  /**
   * Tests saving configuration to validate the schema.
   */
  public function testSaveConfig() {
    $settings = \Drupal::configFactory()->getEditable('draco_udi.settings');

    $workflow_settings = $settings->get('workflow_settings');
    $workflow_settings['processing_runtime_limit'] = 30;
    $settings->set('workflow_settings', $workflow_settings);

    $filter_settings = $settings->get('filter_settings');
    $filter_settings['active_filters'] = [];
    $settings->set('filter_settings', $filter_settings);

    $settings->save();
  }

}
