<?php

namespace Drupal\Tests\draco_udi\Functional;

use Drupal\Tests\BrowserTestBase;

/**
 * Tests the admin settings form
 *
 * @group draco_udi
 */
class UdiSettingsFormTest extends BrowserTestBase {

  public static $modules = ['draco_udi'];

  /**
   * {@inheritdoc}
   */
  public function setUp() {
    parent::setUp();

    $user = $this->drupalCreateUser([
      'administer draco udi',
    ]);
    $this->drupalLogin($user);
  }

  /**
   * Opens the settings form and attempts to set and save values.
   */
  public function testSettingsForm() {
    $this->drupalPostForm('/admin/config/media/udi', [
      'processing_runtime_limit' => 30,
    ], 'Save configuration');
    $this->assertContains('The configuration options have been saved.', $this->getSession()->getPage()->getText());
  }

}