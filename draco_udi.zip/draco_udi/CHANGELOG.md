# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [0.6.1] - 2017-05-18

### Added

### Changed

### Fixed

* [DRACO-2457](http://tickets.turner.com/browse/DRACO-2457) Fixed a bug
  causing fetched ODT delete messages not processed.

## [0.6.0] - 2017-05-02

### Added

* [DRACO-2365](http://tickets.turner.com/browse/DRACO-2365) Integrate
  Draco Logging to UDI
  Draco UDI now depends on Draco Logging.  Verify that the Draco repo
  is in your root composer.json:
  ```
  "repositories": {
          "draco": {
              "type": "composer",
              "url": "https://satis.draco.services.dmtio.net"
          }
  ```
  
  There are two ways to get the logging dependency.
  
  1.  Use the Merge plugin.  Make sure your root composer.json contains
  the following:
  
  ```
  "require": {
          "wikimedia/composer-merge-plugin": "~1.3"
  ```
  ```
  "extra": {
         "merge-plugin": {
              "include": [
                  "core/composer.json",
                  "[PATH TO]/draco_udi/composer.json"
  ```
  
  2.  Or, add the dependency to your root composer.json
  
  ```
  "require": {
          "turnercode/draco_logging" : "*"
  ```
  
  Then run composer update.
  

### Changed

### Fixed

* [DRACO-2383](http://tickets.turner.com/browse/DRACO-2383) Fixed a bug 
  causing error logging and handling to fail when an exception is thrown 
  by a Draco entity converter. 
   
## [0.5.7] - 2017-03-10

### Added

* [DRACO-2189](http://tickets.turner.com/browse/DRACO-2189) Dispatch error
  event when import content fails

* [DRACO-2175](http://tickets.turner.com/browse/DRACO-2175) add a new drush
  command to sync linear schedules based on BSON ID

* [DRACO-2249](http://tickets.turner.com/browse/DRACO-2249) add title and
  linear schedule import successful events; modified event properties

### Changed

* [DRACO-1278](http://tickets.turner.com/browse/DRACO-1278) Clean up stale
  composer configs

### Fixed

* [DRACO-2181](http://tickets.turner.com/browse/DRACO-2181) Fix schema settigs
  and a warning in the settings form.

## [0.5.6] - 2017-02-08

* Fixed the configuration schema definitions for udi.settings. This requires
  developers to run database updates when upgrading to this version. There are
  still a few schema configuration errors, which we will fix in future releases.

### Added

* [DRACO-2175](http://tickets.turner.com/browse/DRACO-2175) Added a drush command udi-sync-linear-schedules that 
  synchronizes linear schedules by a specified start date.
  [DRACO-2189](http://tickets.turner.com/browse/DRACO-2189) Allowed UDI to dispatch import error events for all content 
  types.
  [DRACO-2249](http://tickets.turner.com/browse/DRACO-2249) Added import successful event types for title and linear 
  schedules.

### Changed

* [DRACO-2175](http://tickets.turner.com/browse/DRACO-2175) Modified drush command udi-linear-schedule-fetcher by
  removing the "since" parameter.
* [DRACO-2249](http://tickets.turner.com/browse/DRACO-2249) Modified on-demand import successful event by adding two 
  more properties.
  
### Fixed

* [DRACO-2181](http://tickets.turner.com/browse/DRACO-2181) Fix draco_udi.settings schema definition errors

## [0.5.5] - 2017-01-26
* [DRACO-1278](http://tickets.turner.com/browse/DRACO-1278): Fixed missing
  repositories config.

### Added

### Changed

* Modified `DracoContentRepository->getCurrentContentOnDemandScheduleByTitleId`
  method; renamed `getCurrentContentOnDemandScheduleByTitleId` to
  `getMostRecentContentOnDemandScheduleByTitleId`.
* TBS/TNT team: Please work on DRUMOV-1181 - draco_udi changes to the service
  used to pull assets by titleId In Progress as soon as get the UDI module
  updated. For details how the method works, references to draco-2109 or check
  the PHPDoc for
  `DracoContentRepositoryInterface->getMostRecentContentOnDemandScheduleByTitleId()`
  method.
* Created a new drush command to allow site to manually download one on-demand
  airing from ODT and its corresponding TVE data. Please reference to Upstream
  Data Integration (UDI) Module Developer Guide#DownloadScheduleTVE for details.

* [#222] DRACO-1954 Learn about UDI, review code and report any issues that need to be resolved
  templates and tests code review
* [#223] DRACO-1954 Learn about UDI, review code and report any issues that need to be resolved
  services review
* [#224] DRACO-1954 Learn about UDI, review code and report any issues that need to be resolved
  plugin review
* Revert "[#224] DRACO-1954 Learn about UDI, review code and report any issues that need to be resolved
  plugin review
* [#232] draco-2109 Modify getCurrentContentOnDemandScheduleByTitleId
  rename the method and modified its logic to return most recent schedule
* [#233] DRACO-2129 Create a drush command to directly fetch on-demand schedule/TVE data by airing id
  added drush command to fetch ODT schedule and tve xml file for an airing
* [#234] DRACO-2129 Create a drush command to directly fetch on-demand schedule/TVE data by airing id
  added more info to log entry

### Fixed

* [#229] Merged in fix-default-value
  Fix the default return value on DracoContentRepository::loadScheduleEntities()
