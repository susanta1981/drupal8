<?php

namespace Drupal\draco_udi\PostProcessor;


use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\draco_udi\Context;

/**
 * Interface for PostProcessor Plugins.
 *
 * These are plugins that will run at the end of the UDI workflow.  This will
 * give developers a final opportunity to perform any
 * reporting/notification/clean up tasks necessary.
 */
interface DracoPostProcessorInterface extends PluginInspectionInterface {

  /**
   * Performs the post process functions.
   *
   * @param Context $context
   *    The Context for the current item being processed.
   */
  public function process(Context $context);

}
