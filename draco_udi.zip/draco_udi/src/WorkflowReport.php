<?php

namespace Drupal\draco_udi;

/**
 * Class WorkflowReport.
 *
 * Hold metadata about a content import result for logging and displaying.
 *
 * @package Drupal\draco_udi
 */
class WorkflowReport {
  private $status;
  private $action;
  private $contentSource;
  private $contentType;
  private $entityId;
  private $message;

  const COMPLETE = 'complete';
  const ERROR = 'error';
  const NOP = 'no operation';

  /**
 * Return status code complete or error.
 * @return string
 *    Status.
 */
  public function getStatus() {
    return $this->status;
  }

  /**
   * Set status either complete or error.
   *
   * @param string $status
   *    Status.
   */
  public function setStatus($status) {
    $this->status = $status;
  }

  /**
   * Return message.
   *
   * @return string
   *    Message.
   */
  public function getMessage() {
    return $this->message;
  }

  /**
   * Set message.
   *
   * @param string $message
   *    Message.
   */
  public function setMessage($message) {
    $this->message = $message;
  }

  /**
   * Gets action code.
   *
   * @return string
   *   Action code.
   */
  public function getAction() {
    return $this->action;
  }

  /**
   * Sets action code.
   *
   * @param string $action
   *   The action code.
   */
  public function setAction($action) {
    $this->action = $action;
  }

  /**
   * Get source.
   *
   * @return string
   *   Source of content.
   */
  public function getContentSource() {
    return $this->contentSource;
  }

  /**
   * Set source, ODT, Flow, etc.
   *
   * @param string $source
   *   The source the content is downloaded.
   */
  public function setContentSource($source) {
    $this->contentSource = $source;
  }

  /**
   * Get content type, title, linear schedules, etc.
   *
   * @return string
   *   Content type.
   */
  public function getContentType() {
    return $this->contentType;
  }

  /**
   * Set content type.
   *
   * @param string $type
   *   Content type.
   */
  public function setContentType($type) {
    $this->contentType = $type;
  }

  /**
   * Get id of the Draco entity (not title id).
   *
   * @return int
   *   Entity id.
   */
  public function getEntityId() {
    return $this->entityId;
  }

  /**
   * Set content type.
   *
   * @param int $id
   *   Content type.
   */
  public function setEntityId($id) {
    $this->entityId = $id;
  }

}
