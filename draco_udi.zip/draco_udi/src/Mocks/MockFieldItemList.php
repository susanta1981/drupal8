<?php

namespace Drupal\draco_udi\Mocks;


use Drupal\Core\Field\FieldItemList;

/**
 * Class MockFieldItemList.
 *
 * @package Drupal\draco_udi\Mocks
 *
 * @codeCoverageIgnore
 */
class MockFieldItemList extends FieldItemList {
  protected $list = array();
  protected $name;
  protected $definition;
  protected $value;

  /**
   *
   */
  public function __construct($definition, array $list, $name) {
    $this->list = $list;
    $this->name = $name;
    $this->definition = $definition;
  }

  /**
   * Gets the data value.
   *
   * @return mixed
   */
  public function getValue() {
    return $this->value;
  }

  /**
   *
   */
  public function setValue($value, $notify = TRUE) {
    $this->value = $value;
  }

  /**
   * {@inheritdoc}
   */
  public function get($index) {
    return $this->value;
  }

  /**
   * {@inheritdoc}
   */
  public function first() {
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function __get($index) {
    return $this->value;
  }

  /**
   *
   */
  public function isTranslatable() {
    return TRUE;
  }

}
