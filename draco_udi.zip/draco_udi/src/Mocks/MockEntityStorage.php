<?php
/**
 * @file
 * User: ssjordan.
 */

namespace Drupal\draco_udi\Mocks;
use Drupal\Core\Entity\Entity;
use Drupal\Component\Plugin\Factory\FactoryInterface;
use \Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityStorageInterface;

/**
 * Class MockEntityStorage.
 *
 * @package Drupal\draco_udi\Mocks
 *
 * @codeCoverageIgnore
 */
class MockEntityStorage implements EntityStorageInterface, FactoryInterface {
  private $data;
  private $entity;

  /**
   * Construce MockEntityStorage.
   */
  public function __construct($entity = NULL) {
    $this->entity = $entity;
    $this->data = array();
  }

  /**
   * Set The data.
   *
   * @param array $data
   *    The data.
   */
  public function setData(array $data) {
    $this->data = $data;
  }

  /**
   * Load multiple.
   *
   * @param array $ids
   *   The ids.
   */
  public function loadMultiple(array $ids = NULL) {
    $elements = array();

    if (!empty($this->entity)) {
      $elements[] = $this->entity;
    }
    else {
      foreach ($this->data as $key => $value) {
        if (in_array($key, $ids)) {
          array_push($elements, $value);
        }
      }
    }
    return $elements;
  }

  /**
   * Load entity.
   *
   * @param string $id
   *   Id to load.
   */
  public function load($id) {
    return $this->data[$id];
  }

  /**
   * Create an entity.
   *
   * @param array $values
   *   Values to load.
   */
  public function create(array $values = array()) {
    $rtn = new MockEntity($values, $values["type"], uniqid(), $this);

    if ($this->entity != NULL) {
      $rtn = $this->entity;
    }

    return $rtn;
  }

  /**
   * Save an entity.
   *
   * @param EntityInterface $entity
   *   Entity to return.
   */
  public function save(EntityInterface $entity) {

    $this->data[$entity->id()] = $entity;
  }

  /**
   * Get Query.
   *
   * @param string $conjunction
   *   The  conjuction for query.
   */
  public function getQuery($conjunction = 'AND') {
    return NULL;
  }

  /**
   * Set the Entity.
   *
   * @param string $entity
   *   The entity to return.
   */
  public function setEntity($entity) {
    $this->entity = $entity;
  }

  /**
   * Creates a pre-configured instance of a plugin.
   *
   * @param string $plugin_id
   *   The ID of the plugin being instantiated.
   * @param array $configuration
   *   An array of configuration relevant to the plugin instance.
   *
   * @return object
   *   Itself.
   */
  public function createInstance($plugin_id, array $configuration = array()) {
    return $this;
  }

  /**
   *
   */
  public function resetCache(array $ids = NULL) {

  }

  /**
   *
   */
  public function loadUnchanged($id) {

  }

  /**
   *
   */
  public function loadRevision($revision_id) {

  }

  /**
   *
   */
  public function deleteRevision($revision_id) {

  }

  /**
   *
   */
  public function loadByProperties(array $values = array()) {

  }

  /**
   *
   */
  public function delete(array $entities) {

  }

  /**
   *
   */
  public function getAggregateQuery($conjunction = 'AND') {

  }

  /**
   *
   */
  public function getEntityTypeId() {

  }

  /**
   *
   */
  public function getEntityType() {
  }

}

/**
 * Class MockEntity.
 *
 * @package Drupal\draco_udi\Mocks
 *
 * @codeCoverageIgnore
 */
class MockEntity extends Entity implements EntityInterface {
  protected $mockId;
  protected $storage;

  /**
   * Constructo for MockEntity.
   *
   * @param array $values
   *   The Values.
   * @param string $entity_type
   *   The entity Type.
   * @param string $id
   *   The id.
   * @param string $storage
   *   The storage.
   */
  public function __construct(array $values, $entity_type, $id, $storage) {
    parent::__construct($values, $entity_type);
    $this->setId($id);
    $this->storage = $storage;
  }

  /**
   * Assec ID attribute.
   */
  public function id() {
    return $this->mockId;
  }

  /**
   * Set the ID attribute.
   *
   * $param string $value
   *  Value to set.
   */
  public function setId($value) {
    $this->mockId = $value;
  }

  /**
   * Save.
   */
  public function save() {
    $this->storage->save($this);
  }

  /**
   * Set the Files.
   *
   * @param string $files
   *   The Files.
   */
  public function setFiles($files) {

  }

}
