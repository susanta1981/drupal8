<?php

namespace Drupal\draco_udi;

use Drupal\draco_udi\DataChange\DataChangeDecision;
use Drupal\draco_udi\Entity\DracoContentInterface;

/**
 * Class Context.
 *
 * @package Drupal\draco_udi
 */
class Context {

  const RELATED_MAPPED_CONTENT_KEY = 'mappedEntities';
  const RELATED_LINEAR_SCHEDULE_KEY = 'linearSchedules';
  const RELATED_ONDEMAND_SCHEDULE_KEY = 'odSchedules';
  const RELATED_TO_BE_MAPPED_KEY = 'entitiesToBeMapped';
  const RELATED_TITLES_KEY = 'titles';
  const RELATED_FLIGHTS_KEY = 'flights';

  /**
   * The entity which is currently being processed.
   *
   * @var DracoContentInterface
   */
  protected $currentEntity;

  /**
   * The previous version of $currentEntity.
   *
   * @var DracoContentInterface
   */
  protected $existingEntity;

  /**
   * Clones of deleted entities.
   *
   * @var array
   */
  protected $deletedEntities;

  /**
   * Indicates upsert, delete, etc.
   *
   * @var string
   */
  protected $action;

  /**
   * The type of the entity currently being processed.
   * This type was indicated to the workflow by the
   * data fetcher.
   *
   * @var string
   */
  protected $entityType;

  /**
   * The source of the entity currently being processed.
   * This source was indicated to the workflow by the
   * data fetcher.
   *
   * @var string
   */
  protected $entitySource;

  /**
   * The entity which should be saved.  This
   * may be the $currentEntity or a pending
   * entity.
   *
   * @var DracoContentInterface
   */
  protected $entityToSave;

  /**
   * The result of the approver.
   *
   * @var DataChangeDecision
   */
  protected $dataChangeDecision;

  /**
   * Data necessary for workflow processing.
   * The keys of the map are dependent on
   * the indicated $entityType.
   *
   * @var array
   */
  protected $relatedData;

  /**
   * The original content object downloaded from upstream source.
   *
   * @var \stdClass
   */
  protected $sourceContent;

  /**
   * Context constructor.
   */
  public function __construct() {
    $this->initRelatedData();
  }

  /**
   * @return DracoContentInterface
   */
  public function getCurrentEntity() {

    return $this->currentEntity;
  }

  /**
   * @param DracoContentInterface $current_entity
   */
  public function setCurrentEntity(DracoContentInterface $current_entity) {

    $this->currentEntity = $current_entity;
  }

  /**
   * @return DracoContentInterface
   */
  public function getExistingEntity() {

    return $this->existingEntity;
  }

  /**
   * @param DracoContentInterface $existing_entity
   */
  public function setExistingEntity(DracoContentInterface $existing_entity) {

    $this->existingEntity = $existing_entity;
  }

  /**
   * Return an array of clones of deleted entities.
   *
   * @return array
   */
  public function getDeletedEntities() {
    return $this->deletedEntities;
  }

  /**
   * Add a clone of a deleted entity to array used for referencing purpose.
   *
   * @param DracoContentInterface $deleted_entity
   */
  public function addDeletedEntity(DracoContentInterface $deleted_entity) {
    $this->deletedEntities[] = $deleted_entity;
  }

  /**
   * Set array of clones of deleted entities.
   *
   * @param array $deleted_entities
   */
  public function setDeletedEntities(array $deleted_entities) {
    $this->deletedEntities = $deleted_entities;
  }

  /**
   * @return string
   */
  public function getAction() {

    return $this->action;
  }

  /**
   * @param string $action
   */
  public function setAction($action) {

    $this->action = $action;
  }

  /**
   * @return string
   */
  public function getEntityType() {

    return $this->entityType;
  }

  /**
   * @param string $entity_type
   */
  public function setEntityType($entity_type) {

    $this->entityType = $entity_type;
  }


  /**
   * @return string
   */
  public function getEntitySource() {

    return $this->entitySource;
  }

  /**
   * @param string $entity_source
   */
  public function setEntitySource($entity_source) {

    $this->entitySource = $entity_source;
  }

  /**
   * @return DataChangeDecision
   */
  public function getDataChangeDecision() {

    return $this->dataChangeDecision;
  }

  /**
   * @param DataChangeDecision $data_change_decision
   */
  public function setDataChangeDecision(DataChangeDecision $data_change_decision) {

    $this->dataChangeDecision = $data_change_decision;
  }

  /**
   * @return &array
   *   Returns a reference to the Related Data array.  Note this will make
   *   the array mutable.
   */
  public function &getRelatedData() {

    return $this->relatedData;
  }

  /**
   * @param array $related_data
   */
  public function setRelatedData($related_data) {

    $this->relatedData = $related_data;
  }

  /**
   * @return DracoContentInterface
   */
  public function getEntityToSave() {

    return $this->entityToSave;
  }

  /**
   * @param DracoContentInterface $entity_to_Save
   */
  public function setEntityToSave(DracoContentInterface $entity_to_save) {

    $this->entityToSave = $entity_to_save;
  }

  /**
   * Return source content object.
   *
   * @return \stdClass
   *    Source..
   */
  public function getSourceContent() {
    return $this->sourceContent;
  }

  /**
   * Set downloaded source object.
   *
   * @param \stdClass $source_content
   *    Source.
   */
  public function setSourceContent(\stdClass $source_content) {
    $this->sourceContent = $source_content;
  }

  /**
   *
   */
  private function initRelatedData() {
    $this->relatedData = array();
    $this->relatedData[self::RELATED_MAPPED_CONTENT_KEY] = array();
    $this->relatedData[self::RELATED_LINEAR_SCHEDULE_KEY] = array();
    $this->relatedData[self::RELATED_ONDEMAND_SCHEDULE_KEY] = array();
    $this->relatedData[self::RELATED_TO_BE_MAPPED_KEY] = array();
    $this->relatedData[self::RELATED_TITLES_KEY] = array();
    $this->relatedData[self::RELATED_FLIGHTS_KEY] = array();
  }

}
