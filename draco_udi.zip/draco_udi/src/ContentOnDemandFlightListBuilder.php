<?php


namespace Drupal\draco_udi;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Routing\LinkGeneratorTrait;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Defines a class to build a listing of Content on demand flight entities.
 *
 * @ingroup draco_udi
 */
class ContentOnDemandFlightListBuilder extends EntityListBuilder {
  use LinkGeneratorTrait;

  /**
   * The entity query factory.
   *
   * @var \Drupal\Core\Entity\Query\QueryFactory
   */
  protected $queryFactory;

  /**
   * Logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * ContentOnDemandFlightListBuilder constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeInterface $entity_type
   *    The entity type definition.
   * @param \Drupal\Core\Entity\EntityStorageInterface $storage
   *    The entity storage class.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *    The entity query factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *    The logger factory.
   */
  public function __construct(
      EntityTypeInterface $entity_type,
      EntityStorageInterface $storage,
      QueryFactory $query_factory,
      LoggerChannelFactoryInterface $logger_factory
  ) {
    parent::__construct($entity_type, $storage);
    $this->queryFactory = $query_factory;
    $this->logger = $logger_factory->get('draco_udi');
  }

  /**
   * {@inheritdoc}
   */
  public static function createInstance(ContainerInterface $container, EntityTypeInterface $entity_type) {
    return new static(
      $entity_type,
      $container->get('entity.manager')->getStorage($entity_type->id()),
      $container->get('entity.query'),
      $container->get('logger.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['airing_id'] = $this->t('Airing ID');
    $header['start'] = $this->t('Start');
    $header['end'] = $this->t('End');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\draco_udi\Entity\ContentOnDemandFlight */
    $schedule_id = $this->getOnDemandScheduleId($entity->getAiringId());

    $row['airing_id'] = $this->l(
      $entity->getAiringId(),
      new Url(
        'entity.content_on_demand_schedule.edit_form', array(
          'content_on_demand_schedule' => $schedule_id,
        )
      )
    );
    $row['start'] = $entity->getStart()->format('Y-m-d\TH:i:s');
    $row['end'] = $entity->getEnd()->format('Y-m-d\TH:i:s');

    return $row + parent::buildRow($entity);
  }

  /**
   * Return parent schedule entity's id.
   *
   * @param $airing_id
   *    Associated schedule airing id.
   *
   * @return null|string
   */
  private function getOnDemandScheduleId($airing_id) {
    $entity_query = $this->queryFactory->get('content_on_demand_schedule');
    $entity_query->condition('airing_id', $airing_id);
    $ids = $entity_query->execute();
    $schedule_id = NULL;

    if (count($ids) == 1) {
      $schedule_id = reset($ids);
    }
    elseif (count($ids) > 1) {
      $schedule_id = reset($ids);
      // Or error?
      $this->logger->warning('Found more than one on-demand schedule with airing id @airingId. Schedule @id is returned.',
        ['@airingId' => $airing_id, '$id' => $schedule_id]);
    }
    else {
      $this->logger->error('Not found on-demand schedule with airing id @airingId', ['@airingId' => $airing_id]);
    }

    return $schedule_id;
  }

}
