<?php

namespace Drupal\draco_udi\Plugin\views\field;

use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;

/**
 * Renders a list of title ids. Links to a Content Title id entity if exists.
 *
 * @ingroup views_field_handlers
 *
 * @ViewsField("title_ids_links_field")
 */
class TitleIdsLinksField extends FieldPluginBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    // Do nothing -- to override the parent query.
  }

  /**
   * {@inheritdoc}
   */
  public function render(ResultRow $values) {
    $urls = [];
    $cache_tags = [];
    $entity = $this->getEntity($values);
    foreach($entity->get('title_ids') as $title_id) {
      $title_id = $title_id->getValue()['value'];

      // Check if there is a Content Title entity.
      $query = \Drupal::entityQuery('content_title');
      $query->condition('title_id', $title_id);
      $content_title_ids = $query->execute();

      // If there is an entity, render a link. Otherwise just render the id.
      if (!empty($content_title_ids)) {
        $content_title_id = reset($content_title_ids);
        $content_title = \Drupal::entityTypeManager()->getStorage('content_title')->load($content_title_id);
        $cache_tags += $content_title->getCacheTags();
        $urls[] = new Link(strval($title_id), Url::fromRoute('entity.content_title.canonical', [
          'content_title' => $content_title_id,
        ]));
      }
      else {
        $urls[] = $title_id;
      }
    }

    return [
      '#theme' => 'item_list',
      '#items' => $urls,
      '#cache' => [
        'tags' => $cache_tags,
      ],
    ];
  }

}
