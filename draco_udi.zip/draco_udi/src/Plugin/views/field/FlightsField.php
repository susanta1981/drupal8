<?php

namespace Drupal\draco_udi\Plugin\views\field;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\Random;
use Drupal\views\Plugin\views\field\FieldPluginBase;
use Drupal\views\ResultRow;

/**
 * Renders start and end flights.
 *
 * @ingroup views_field_handlers
 *
 * @ViewsField("flights_field")
 */
class FlightsField extends FieldPluginBase {

  /**
   * {@inheritdoc}
   */
  public function query() {
    // Do nothing -- to override the parent query.
  }
  /**
   * {@inheritdoc}
   */
  public function render(ResultRow $values) {
    $items = [];

    if (!empty($this->getEntity($values))) {
      foreach ($this->getEntity($values)->get('flights')->referencedEntities() as $flight) {
        $flight_datetimes = [];
        if (!empty($flight->get('start'))) {
          $flight_datetimes[] = $this->t('Start: @start_datetime', ['@start_datetime' => $flight->get('start')->getString()]);
        }
        if (!empty($flight->get('end'))) {
          $flight_datetimes[] = $this->t('End: @end_datetime', ['@end_datetime' => $flight->get('end')->getString()]);
        }
        $items[] = implode(' | ', $flight_datetimes);
      }
    }

    return [
      '#theme' => 'item_list',
      '#list_type' => 'ul',
      '#items' => $items,
    ];
  }

}
