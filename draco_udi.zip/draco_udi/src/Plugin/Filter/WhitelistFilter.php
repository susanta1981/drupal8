<?php

namespace Drupal\draco_udi\Plugin\Filter;


use Drupal\Core\Plugin\PluginBase;
use Drupal\draco_udi\Filter\ContentFilterInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Psr\Log\LoggerInterface;

/**
 * Abstract WhiteList Filter.
 */
abstract class WhitelistFilter extends DracoBaseTitleFilter  {

  protected $logger;
  protected $queryFactory;
  protected $entityManager;

  /**
   * Constructs a  FlowTitleFilter object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *   Query Factory.
   * @param LoggerInterface $logger_channel
   *   Logger channel.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      QueryFactory $query_factory,
      EntityManagerInterface $entity_manager,
      LoggerInterface $logger_channel
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->queryFactory = $query_factory;
    $this->logger = $logger_channel;
    $this->entityManager = $entity_manager;
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {

    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity.query'),
      $container->get('entity.manager'),
      $container->get('draco_udi.logger.channel')
    );
  }

  /**
   * Filter Flow Titles.
   *
   * {@inheritDoc}
   */
  public function isApprovedContent($content) {
    $isApproved = FALSE;
    if (is_a($content, 'stdClass')) {
      $isApproved = $this->contentInWhiteList($content);
    }
    else {
      $this->logger->debug("(whitelistFilter) is not a stdClass object: @content", ['@content' => $content]);
    }
    return $isApproved;
  }

  /**
   * Determine if the content is in a whitelist.
   *
   * @param mixed $title
   *   Title Object.
   *
   * @return bool
   *   Boolean indicating if title is in a whitelist.
   */
  protected function contentInWhiteList($title) {
    $titleId = $this->getTitleId($title);
    $type = $this->getContentType($title);
    return $this->inWhiteList($titleId, $type);

  }

  /**
   * Determine if the content is in a whitelist.
   *
   * @param string $titleId
   *   Title Id.
   * @param string $type
   *   Title ContentType.
   *
   * @return bool
   *   Boolean indicating if title is in a whitelist.
   */
  protected function inWhiteList($titleId, $type) {
    $whiteList = $this->getWhiteList($type);
    if ($whiteList == NULL) {
      // If no whitelist then site is not filtering on this type so return that it is valid.
      $inList = TRUE;
    }
    else {
      $inList = $this->isTitleidInArray($titleId, $whiteList->getTitleIds());
    }
    return $inList;
  }

  /**
   * Get the whitelist config object for a content type type.
   *
   * @param string $type
   *   Title ContentType.
   *
   * @return \Drupal\draco_udi\Entity\ContentWhitelist
   *   ContentWhitelist for a content type.
   */
  protected function getWhiteList($type) {
    $whiteList = NULL;
    $ids = $this->queryFactory->get("content_whitelist")
      ->condition('contentType', $type)
      ->execute();

    if (count($ids) > 0) {
      $results = $this->entityManager->getStorage("content_whitelist")->load(array_values($ids)[0]);
      if (!empty($results)) {
        $whiteList = $results;
      }
    }
    return $whiteList;
  }

  /**
   * Determines if the titleid is in the list of $titleIds.
   *
   * @param string $id
   *   Title Id.
   * @param array $titleIds
   *   array of TitleIds from ContentWhitelist config object.
   *
   * @returns bool
   *   Boolean indicating if id is in array.
   */
  private function isTitleidInArray($id, $titleIds) {
    $inArray = FALSE;
    if (!empty($titleIds)) {
      foreach ($titleIds as $titleId) {
        if ($titleId['id'] == $id) {
          $inArray = TRUE;
          break;
        }
      }
    }
    return $inArray;
  }

}
