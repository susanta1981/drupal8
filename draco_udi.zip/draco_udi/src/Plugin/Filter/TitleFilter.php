<?php

namespace Drupal\draco_udi\Plugin\Filter;

/**
 * Class TitleFilter.
 *
 * @package Drupal\draco_udi\Plugin\Filter
 *
 * @ContentFilter(id = "flow_title_filter",
 *                    dataType = "Title",
 *                    label = "Uses whitelists to filter Flow titles",
 *                    dataSource = "flow"  )
 */
class TitleFilter extends WhitelistFilter {

  /**
   * Filter Flow Titles.
   *
   * {@inheritDoc}
   */
  public function isApprovedContent($content) {
    $isApproved = FALSE;
    if (is_a($content, 'stdClass')) {
      $isApproved = $this->checkTitles([$content]);
    }
    else {
      $this->logger->debug("FlowTitleFilter content is not a stdClas object: @content", ['@content' => $content]);
    }
    return $isApproved;
  }

  /**
   * Determines in this title object is part of a series.
   *
   * @param mixed $title
   *   Titlle Object.
   *
   * @returns bool
   *   Boolean indicating whether title belongs to a series
   */
  protected function belongsToSeries($title) {
    $series_or_episode = FALSE;
    if ((!empty($this->getSeriesTitleId($title)) && $this->getSeriesTitleId($title) != 0)) {
      $series_or_episode = TRUE;
    }
    return $series_or_episode;
  }

  /**
   * Determines if this series is in the whitelist.
   *
   * @param mixed $title
   *   Titlle Object.
   *
   * @returns bool
   *   Boolean indiciating if title is in the whitelist.
   */
  protected function seriesOrEpisodeInWhiteList($title) {
    $seriesId = $this->getSeriesId($title);
    return $this->inWhiteList($seriesId, "series");
  }

  /**
   * Get the Series TitleId from the title Object that has a seriesTitleId.
   *
   * @param mixed $title
   *   Title Object.
   *
   * @returns string
   *   The Series Title Id.
   */
  protected function getSeriesTitleId($title) {
    $seriesTitleId = NULL;
    if (property_exists($title, "SeriesTitleId")) {
      $seriesTitleId = $title->SeriesTitleId;
    }
    return $seriesTitleId;
  }

  /**
   * Gets the Series Id from a series releated Object or a Series Object.
   *
   * @param mixed $title
   *   Title Object.
   *
   * @returns string
   *   If title is a mebemer of a series returns SeriesTitleId otherwise returns
   *   the titleID.
   */
  protected function getSeriesId($title) {
    $seriesId = NULL;
    if (!empty($this->getSeriesTitleId($title)) && $this->getSeriesTitleId($title) != 0) {
      $seriesId = $title->SeriesTitleId;
    }
    else {
      if (property_exists($title, "TitleId")) {
        $seriesId = $title->TitleId;
      }
    }
    return $seriesId;
  }

  /**
   * Loops through all titles in array and checkes whitelist for each.
   *
   * @param array $titles
   *   array of Title Objects.
   *
   * @return bool
   *   Boolean indicating if content is approved.
   */
  protected function checkTitles($titles) {
    $isApproved = FALSE;
    foreach ($titles as $title) {
      if (!empty($title)) {
        if ($this->belongsToSeries($title) || $this->isSeries($title)) {
          $isApproved = $this->seriesOrEpisodeInWhiteList($title);
        }
        else {
          $isApproved = $this->contentInWhiteList($title);
        }
        if ($isApproved) {
          break;
        }
      }
    }
    return $isApproved;
  }

}
