<?php

namespace Drupal\draco_udi\Plugin\Filter;

/**
 * Class OnDemandScheduleFilter.
 *
 * @package Drupal\draco_udi\Plugin\Filter
 *
 * @ContentFilter(id = "ondemand_schedule_filter",
 *                dataType = "OnDemandSchedule",
 *                label = "Filters out Schedules which do not have Status set to Video",
 *                dataSource = "ODT"  )
 */
class OnDemandScheduleFilter extends TitleFilter {

  /**
   * Filter On-Demand Schedules by checking options->status->video bool flag.
   *
   * {@inheritDoc}
   */
  public function isApprovedContent($content) {
    $isApproved = FALSE;

    if (is_a($content, '\stdClass')) {
      if (isset($content->options->status)) {
        $status = $content->options->status;

        if (isset($status->video)) {
          $isApproved = $status->video;
        }
      }
    }
    else {
      throw new \InvalidArgumentException('OnDemandScheduleFilter: content is not of stdClass type');
    }
    return $isApproved;
  }

}
