<?php

namespace Drupal\draco_udi\Plugin\Filter;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Psr\Log\LoggerInterface;

/**
 * Class TveContentFilter.
 *
 * @package Drupal\draco_udi\Plugin\Reconciler
 *
 * @ContentFilter(id = "tve_content_filter",
 *                    dataType = "TVE",
 *                    label  = "Filters out TVE xml files which are not a TVE Item",
 *                    dataSource = "TVE"  )
 */
class TveContentFilter extends TitleFilter {


  /**
   * FlowClient.
   *
   * @var \Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface
   */
  protected $flowClient;

  /**
   * Constructs a  TveContentFilter object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *   Query Factory.
   * @param LoggerInterface $logger_channel
   *   Logger channel.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      QueryFactory $query_factory,
      EntityManagerInterface $entity_manager,
      LoggerInterface $logger_channel,
      FlowClientInterface $flowClient
  ) {

    $this->flowClient = $flowClient;
    parent::__construct($configuration, $plugin_id, $plugin_definition, $query_factory, $entity_manager, $logger_channel);
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {

    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity.query'),
      $container->get('entity.manager'),
      $container->get('draco_udi.logger.channel'),
      $container->get('draco_udi.flow.client')
    );
  }

  /**
   * Filter TVE content.
   *
   * {@inheritDoc}
   */
  public function isApprovedContent($content) {

    $isApproved = FALSE;
    if (is_a($content, 'stdClass')) {
      if ($this->isTveItem($content)) {
        // TODO Per request from TBS Not check whitelist.
        // Turn off call $this->checkTitles($this->getTitleForTve($content->TveItem));
        // We may make it configurable as needed in the future.
        $isApproved = TRUE;
      }
    }
    else {
      $this->logger->debug("FlowTitleFilter content is not a stdClass object: @content", ['@content' => $content]);
    }
    return $isApproved;

  }

  /**
   * Indicates if this is a TVEItem.
   *
   * @param mixed $content
   *   Content being filtered.
   *
   * @return bool
   *    TRUE if a TveItem.
   */
  private function isTveItem($content) {
    // For TVE we are only interested in TVEItem posts. So check and see if
    // TveItem is the root property.
    return property_exists($content, "TveItem");
  }

  /**
   * Query Flow for Title data.
   *
   * @param mixed $tveItem
   *   The TVE data being filtered.
   *
   * @return array
   *   List of titles.
   */
  private function getTitleForTve($tveItem) {
    $items = [];
    if (property_exists($tveItem, "Title") && property_exists($tveItem->Title, "Id")) {
      $items = $this->flowClient->getTitlesByTitleIds([$tveItem->Title->Id]);
    }
    return $items;
  }

}
