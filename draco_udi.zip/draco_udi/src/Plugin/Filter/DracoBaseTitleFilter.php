<?php

namespace Drupal\draco_udi\Plugin\Filter;

use Drupal\Core\Plugin\PluginBase;
use Drupal\draco_udi\Filter\ContentFilterInterface;

/**
 * Abstract Draco Title Filter.
 */
abstract class DracoBaseTitleFilter extends PluginBase implements ContentFilterInterface {

  /**
   * Get the Title id from Title Object.
   *
   * @param \stdClass $title
   *   Title Object.
   *
   * @return string
   *   TitleId of the Title.
   */
  protected function getTitleId(\stdClass $title) {
    $titleId = NULL;
    if (property_exists($title, "TitleId")) {
      $titleId = $title->TitleId;
    } elseif (property_exists($title, "titleId")) {
      $titleId = $title->titleId;
    }
    return $titleId;
  }

  /**
   * Get the ContentType of the Title Object.
   *
   * @param mixed $title
   *   Title Object.
   *
   * @return string
   *   Content Type of the Title Object.
   */
  protected function getContentType($title) {
    $contentType = NULL;
    if (property_exists($title, "TitleType")) {
      if (property_exists($title->TitleType, "Name")) {
        $contentType = $title->TitleType->Name;
      }

    }
    return $contentType;
  }

  /**
   * Determines in this title object is  a series.
   *
   * @param \stdClass $title
   *   Title Object.
   *
   * @returns bool
   *   Boolean indicating whether title belongs to a series
   */
  protected function isSeries(\stdClass $title) {
    return property_exists($title, "SeriesItems") && isset($title->SeriesItems) && !empty($title->SeriesItems);
  }

}
