<?php

namespace Drupal\draco_udi\Plugin\Reconciler;

use Drupal\Component\Plugin\PluginBase;
use Drupal\draco_udi\Context;
use Drupal\draco_udi\Entity\ContentTitle;
use Drupal\draco_udi\Reconciler\DracoReconcilerInterface;
use Drupal\draco_udi\Service\ContentFetchManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Abstract Class ContentReconcilerBase.
 *
 * This is the base class for Draco Reconcilers,
 *  it contains common code shared by the reconcilers.
 *
 * @package Drupal\draco_udi\Plugin\Reconciler
 */
abstract class ContentReconcilerBase extends PluginBase implements DracoReconcilerInterface {

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {

    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition
    );
  }

  /**
   * Adds the ContentTitle entity to the list of titles that need to be mapped.
   *
   * If a reconciler alters a title it will need to be remapped.  This method
   * can be used to add the title to the list of titles that need to be mapped.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitle $title
   *   The ContentTitle entiry to add to list of entities needing mapping.
   * @param \Drupal\draco_udi\Context $context
   *   The workflow context object.
   */
  protected function addTitleToBeMapped(ContentTitle $title, Context $context) {
    $relatedData = &$context->getRelatedData();
    if (!in_array($title, $relatedData[Context::RELATED_TO_BE_MAPPED_KEY])) {
      $relatedData[Context::RELATED_TO_BE_MAPPED_KEY][] = $title;
    }
  }

  /**
   * Get the list of Titles that need reconcilition.
   *
   *  The location of the list varies depending on the entity_type.
   *
   * @param Context $context
   *   The workflow context object.
   */
  protected function getTitlesForReconciliation(Context $context) {

    if ($context->getEntityType() == ContentFetchManager::CONTENT_TITLE_TYPE) {
      $titles = array($context->getCurrentEntity());
    }
    else {
      $titles = &$context->getRelatedData()[Context::RELATED_TITLES_KEY];
    }
    return $titles;
  }

  /**
   * Get the list of On Demenad Schedules that need reconcilition.
   *
   *  The location of the list varies depending on the entity_type.
   *
   * @param Context $context
   *   The workflow context object.
   */
  protected function getOndemandSchedulesForReconciliation(Context $context) {

    if ($context->getEntityType() == ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE) {
      $schedules = array($context->getCurrentEntity());
    }
    elseif ($context->getEntityType() == ContentFetchManager::CONTENT_TITLE_TYPE) {
      $schedules = &$context->getRelatedData()[Context::RELATED_ONDEMAND_SCHEDULE_KEY];
    }
    else {
      // If this is something other than title or OnDemand Schedule we will not
      // need to reconcile On Demand with schedules.
      $schedules = array();
    }
    return $schedules;
  }

  /**
   * Get the list of Linear Schedules  that need reconciliation.
   *
   *  The location of the list varies depending on the entity_type.
   *
   * @param Context $context
   *   The workflow context object.
   */
  protected function getLinearSchedulesForReconciliation(Context $context) {

    if ($context->getEntityType() == ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE) {
      $schedules = array($context->getCurrentEntity());
    }
    elseif ($context->getEntityType() == ContentFetchManager::CONTENT_TITLE_TYPE) {
      $schedules = &$context->getRelatedData()[Context::RELATED_LINEAR_SCHEDULE_KEY];
    }
    else {
      // If this is something other than title or Linear Schedule we will not
      // need to reconcile Linear with schedules.
      $schedules = array();
    }
    return $schedules;
  }

  /**
   * Reconcile ContentTitle entities and schedules.
   *
   * {@inheritDoc}
   */
  abstract public function reconcile(Context $context);

}
