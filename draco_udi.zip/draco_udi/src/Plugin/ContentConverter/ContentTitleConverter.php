<?php

namespace Drupal\draco_udi\Plugin\ContentConverter;

use Drupal\draco_udi\Entity\ContentTitleInterface;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;
use Drupal\draco_udi\Service\ContentFetchManager;

/**
 * Class ContentTitleConverter.
 *
 * The id maps to pipeline queue message's type, title,
 * linearSchedule, onDemandSchedule.
 *
 * @package Drupal\draco_udi\Plugin\ContentConverter
 *
 * @ContentConverterStrategy(id = "Title")
 */
class ContentTitleConverter extends ContentConverterBase {

  /**
   * {@inheritdoc}
   */
  public function getMappedEntityType() {
    return 'content_title';
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForCreateEntity(\stdClass $content_data) {
    return array('type' => $content_data->TitleType->Name, 'label' => $content_data->TitleName);
  }

  /**
   * {@inheritdoc}
   */
  protected function mapFields(
      \stdClass $content_data,
      DracoContentInterface $new_draco_entity,
      DracoContentInterface $existing_draco_entity = NULL
  ) {
    $existing_copy = NULL;
    $update = FALSE;

    if ($existing_draco_entity != NULL) {
      $existing_copy = $existing_draco_entity->createDuplicate();
      $update = TRUE;
    }

    $entity = $this->populateEntityFields($content_data, $new_draco_entity, $update);
    $entity_set = new ConvertedEntitySet($content_data, ContentFetchManager::CONTENT_TITLE_TYPE, $entity, $existing_copy);

    return $entity_set;
  }

  /**
   * Map the target entity fields with the source content properties.
   *
   * @param \stdClass $source_data
   *    Newly downloaded upstream content object.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $target_entity
   *    A new or existing corresponding entity to be updated.
   * @param bool $update
   *    TRUE if updating an existing entity, otherwise FALSE.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *    A new or updated ContentTitle entity.
   */
  protected function populateEntityFields(\stdClass $source_data, DracoContentInterface $target_entity, $update) {
    /** @var \Drupal\draco_udi\Entity\ContentTitleInterface $updated_entity */
    $updated_entity = $target_entity;

    $updated_entity->set('title_id', $source_data->TitleId);
    $updated_entity->set('label', $source_data->TitleName);
    $updated_entity->set('title_type', $source_data->TitleType->Name);

    // Set common fields for all types.
    $updated_entity->set('sortable_title_name', $source_data->TitleNameSortable);
    $updated_entity->set('release_year', $source_data->ReleaseYear);
    $updated_entity->setRatings($source_data->Ratings);
    $updated_entity->setTags($source_data->Tags);
    $updated_entity->setKeywords($source_data->Keywords);
    $updated_entity->setGenres($source_data->Genres);
    $updated_entity->setKeyGenres($source_data->KeyGenres);
    $updated_entity->setPerformanceMode($source_data->PerformanceMode);
    $updated_entity->setAnimationMode($source_data->AnimationMode->Name);
    $this->setProcessedDatetime($source_data->ProcessedDatetimeUTC, $updated_entity);

    $updated_entity->setContentJson($source_data);

    // Set optional fields.
    if (isset($source_data->Participants)) {
      $updated_entity->setParticipants($source_data->Participants);
    }
    if (isset($source_data->LengthInSeconds)) {
      $updated_entity->set('length_in_seconds', $source_data->LengthInSeconds);
    }
    if (!empty($source_data->SeriesItems)) {
      $updated_entity->setSeriesItems($source_data->SeriesItems);
    }
    if (!empty($source_data->Seasons)) {
      $updated_entity->setSeasons($source_data->Seasons);
    }
    if (isset($source_data->Storylines)) {
      $this->setStorylineFields($source_data->Storylines, $updated_entity);
    }
    if (!empty($source_data->SeriesTitleId)) {
      $updated_entity->set('series_title_id', $source_data->SeriesTitleId);
    }
    if (!empty($source_data->SeriesTitleName)) {
      $updated_entity->set('series_title_name', $source_data->SeriesTitleName);
    }
    if (!empty($source_data->SeriesTitleNameSortable)) {
      $updated_entity->set('sortable_series_title_name', $source_data->SeriesTitleNameSortable);
    }
    if (!empty($source_data->SeasonNumber)) {
      $updated_entity->set('season_number', $source_data->SeasonNumber);
    }
    if (!empty($source_data->SeriesItemNumber)) {
      $updated_entity->set('series_item_number', $source_data->SeriesItemNumber);
    }
    if (!empty($source_data->ExternalSeriesItemNumber)) {
      $updated_entity->set('external_series_item_number', $source_data->ExternalSeriesItemNumber);
    }
    if (!empty($source_data->SeasonEpisodeNumber)) {
      $updated_entity->set('season_episode_number', $source_data->SeasonEpisodeNumber);
    }

    $this->updateLastChangedTimestamp($updated_entity);

    return $updated_entity;
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForQueryEntity(\stdClass $content_data) {
    $field = new \stdClass();
    $field->name = 'title_id';
    $field->value = $content_data->TitleId;

    return $field;
  }

  /**
   * Set processed time.
   *
   * @param string $datetime_string
   *   Date and time to set.
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title_entity
   *   Title Entity.
   */
  protected function setProcessedDatetime($datetime_string, ContentTitleInterface $title_entity) {
    $datetime = new \DateTime($datetime_string, new \DateTimeZone('UTC'));
    $db_value = $datetime->format('Y-m-d\TH:i:s');
    $title_entity->set('processed_datetime', $db_value);
  }

  /**
   * Set storyline fields.
   *
   * @param array $storylines|NULL
   *    Storyline object.
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title_entity
   *    New or existing ContentTitle object.
   */
  private function setStorylineFields(array $storylines = NULL, ContentTitleInterface $title_entity = NULL) {
    $title_entity->setStorylines($storylines);

    foreach ($storylines as $storyline) {
      if (strchr($storyline->Type, 'External') && isset($storyline->Description)) {
        $title_entity->set('external_storyline', $storyline->Description);
      }
      elseif (strchr($storyline->Type, 'Short') && isset($storyline->Description)) {
        $title_entity->set('short_storyline', $storyline->Description);
      }
    }
  }

}
