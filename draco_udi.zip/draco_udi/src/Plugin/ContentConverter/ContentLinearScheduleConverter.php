<?php

namespace Drupal\draco_udi\Plugin\ContentConverter;

use Drupal\draco_udi\Entity\ContentLinearScheduleInterface;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;
use Drupal\draco_udi\Service\ContentFetchManager;

/**
 * Class ContentLinearScheduleConverter.
 *
 * Convert a title json object to a ContentTitle entity.
 *
 * @package Drupal\draco_udi\Plugin\ContentConverter
 *
 * @ContentConverterStrategy(id = "LinearSchedule")
 */
class ContentLinearScheduleConverter extends ContentConverterBase {

  /**
   * {@inheritdoc}
   */
  public function getMappedEntityType() {
    return 'content_linear_schedule';
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForCreateEntity(\stdClass $content_data) {
    return array('label' => $content_data->Name, 'external_id' => $content_data->ExternalId);
  }

  /**
   * {@inheritdoc}
   */
  protected function mapFields(
      \stdClass $content_data,
      DracoContentInterface $new_draco_entity,
      DracoContentInterface $existing_draco_entity = NULL
  ) {
    $existing_copy = NULL;

    if ($existing_draco_entity != NULL) {
      $existing_copy = $existing_draco_entity->createDuplicate();
    }

    $entity = $this->update($content_data, $new_draco_entity);
    $entity_set = new ConvertedEntitySet($content_data,
      ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE, $entity, $existing_copy);

    return $entity_set;
  }

  /**
   * Update the target entity with the source content data.
   *
   * @param \stdClass $source_data
   *    Newly downloaded upstream content object.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $target_entity
   *    A new or existing corresponding entity to be updated.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *    Entity with new or updated data.
   */
  private function update(\stdClass $source_data, DracoContentInterface $target_entity) {
    if ($source_data == NULL) {
      return $target_entity;
    }

    /** @var \Drupal\draco_udi\Entity\ContentLinearSchedule $updated_entity */
    $updated_entity = $target_entity;
    $updated_entity->setContentJson($source_data);
    $this->setDateFields($updated_entity, $source_data);

    $updated_entity->setNetwork($source_data->Network);
    $updated_entity->setName($source_data->Name);
    $updated_entity->setSource($source_data->Source);
    $updated_entity->setPlatform($source_data->Platform);
    $updated_entity->setFranchiseName($source_data->FranchiseName);
    $updated_entity->setTimeZone($source_data->TimeZone);
    $updated_entity->setFranchiseDuration($source_data->FranchiseDuration);
    $updated_entity->setFranchiseId($source_data->FranchiseId);
    $updated_entity->setIsPremiere($source_data->IsPremiere);
    $updated_entity->setIsLive($source_data->IsLive);
    $updated_entity->setScheduleAiringStartTime($source_data->ScheduleAiringStartTime);
    $updated_entity->setNetworkFeedCode($source_data->NetworkFeedCode);
    $updated_entity->setNewsUpdate($source_data->NewsUpdate);

    if (isset($source_data->PreText)) {
      $updated_entity->setPreText($source_data->PreText);
    }
    if (isset($source_data->CC)) {
      $updated_entity->setClosedCaptions($source_data->CC);
    }

    $this->setTitleIds($source_data, $updated_entity);
    $this->updateLastChangedTimestamp($updated_entity);

    return $updated_entity;
  }

  /**
   * Set title ids.
   *
   * @param $source_data
   * @param \Drupal\draco_udi\Entity\ContentLinearScheduleInterface $updated_entity
   */
  private function setTitleIds($source_data, ContentLinearScheduleInterface $updated_entity) {
    $title_ids = [];

    if (isset($source_data->Titles)) {
      foreach ($source_data->Titles as $title) {
        if (!in_array($title->TitleId, $title_ids)) {
          $title_ids[] = $title->TitleId;
        }
      }
    }

    $updated_entity->setTitleIds($title_ids);
  }

  /**
   * Set date fields.
   *
   * @param \Drupal\draco_udi\Entity\ContentLinearScheduleInterface $updated_entity
   * @param \stdClass $source_data
   */
  private function setDateFields(ContentLinearScheduleInterface $updated_entity, \stdClass $source_data) {
    $start = new \DateTime($source_data->StartDate, new \DateTimeZone('UTC'));
    $updated_entity->setStartDate($start);

    $end = new \DateTime($source_data->EndDate, new \DateTimeZone('UTC'));
    $updated_entity->setEndDate($end);

    $air_date = new \DateTime($source_data->ScheduleAirDate, new \DateTimeZone('UTC'));
    $updated_entity->setScheduleAirDate($air_date);
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForQueryEntity(\stdClass $content_data) {
    $field = new \stdClass();
    $field->name = 'external_id';
    $field->value = $content_data->ExternalId;
    return $field;
  }

}
