<?php

namespace Drupal\draco_udi\Plugin\ContentConverter;

use Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface;
use Drupal\draco_udi\Entity\DracoContentInterface;

/**
 * Class TveContentOnDemandScheduleConverter.
 *
 * This class converts TVE to a ContentOnDemandSchedule entity with possible
 * associated ContentOnDemandFlight entities.
 *
 * @package Drupal\draco_udi\Plugin\ContentConverter
 *
 * @ContentConverterStrategy(id = "TVE")
 */
class TveContentOnDemandScheduleConverter extends ContentOnDemandScheduleConverter {

  /**
   * {@inheritdoc}
   */
  protected function populateEntityFields(\stdClass $source_data, DracoContentInterface $target_entity, $update) {
    /** @var \Drupal\draco_udi\Entity\ContentOnDemandSchedule $updated_entity */
    $updated_entity = $target_entity;

    // Update TVE based fields.
    $updated_entity->setAssets($source_data->TveItem->TurnerPrivate->Assets);
    $updated_entity->setThumbs($source_data->TveItem->Thumbs);
    $updated_entity->setAdBreaks($source_data->TveItem->AdBreaks);
    $updated_entity->setContentSegments($source_data->TveItem->ContentSegments);
    $updated_entity->setTveContent($source_data);

    if ($update == FALSE) {
      // Map some fields with TVE data and use ODT data to map to the rest.
      $updated_entity->setBrand($source_data->TveItem->Title->Network->Net);
      $updated_entity->setDisplayMinutes($source_data->TveItem->Title->Duration->DisplayMinutes);
      $updated_entity->setLengthInSeconds($source_data->TveItem->Title->Duration->ActualSeconds);
      $updated_entity->setName($source_data->TveItem->Title->TitleName);
      $updated_entity->setType($source_data->TveItem->Title->Type);

      // Will be updated with ODT data.
      $this->setTitleIds($source_data, $updated_entity);
    }

    $this->updateLastChangedTimestamp($updated_entity);

    return $updated_entity;
  }

  /**
   * {@inheritdoc}
   */
  protected function updateFlights($content_data, ContentOnDemandScheduleInterface $schedule_entity) {
    $flight_data_list = $content_data->TveItem->Flights->Flight;
    $flight_entities = $this->getFlightDetails($schedule_entity, $flight_data_list);

    return $flight_entities;
  }

  /**
   * Create flight entities.
   *
   * @param ContentOnDemandScheduleInterface $schedule_entity
   *    On-demand schedule entity.
   * @param $flight_data_list
   *    Original flight data.
   *
   * @return array
   *    Flights.
   */
  private function getFlightDetails(ContentOnDemandScheduleInterface $schedule_entity, $flight_data_list) {
    $airing_id = $schedule_entity->getAiringId();
    $flight_entities = [];

    if (!empty($schedule_entity->getFlightIds())) {
      $this->cleanupExistingFlights($schedule_entity);
    }

    $flight_storage = $this->entityManager->getStorage('content_on_demand_flight');

    if (is_array($flight_data_list)) {
      foreach ($flight_data_list as $flight_data) {
        /** @var \Drupal\draco_udi\Entity\ContentOnDemandFlight $flight_entity */
        $flight_entity = $flight_entities[] = $this->setFlightDates($flight_storage, $flight_data, $airing_id);
        $flight_entities[] = $flight_entity;
      }
    }
    else {
      $flight_entities[] = $this->setFlightDates($flight_storage, $flight_data_list, $airing_id);
    }

    return $flight_entities;
  }

  /**
   * Create one flight entity with start and end datetime.
   *
   * @param $flight_storage
   *    Storage instance.
   * @param $flight_data
   *    Data for flight.
   * @param $airing_id
   *    Airing id.
   *
   * @return \Drupal\draco_udi\Entity\ContentOnDemandFlight
   *    Flight entity.
   */
  protected function setFlightDates($flight_storage, $flight_data, $airing_id) {
    $flight_entity = $flight_storage->create(array('airing_id' => $airing_id));
    $start_datetime = new \DateTime($flight_data->Start, new \DateTimeZone('UTC'));
    $flight_entity->setStart($start_datetime);
    $end_datetime = new \DateTime($flight_data->End, new \DateTimeZone('UTC'));
    $flight_entity->setEnd($end_datetime);

    return $flight_entity;
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForCreateEntity(\stdClass $content_data) {
    return array(
      'type' => $content_data->TveItem->Title->Type,
      'label' => $content_data->TveItem->Title->TitleName,
      'airing_id' => $content_data->TveItem->Title->AssetId,
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForQueryEntity(\stdClass $content_data) {
    $field = new \stdClass();
    $field->name = 'airing_id';
    $field->value = $content_data->TveItem->Title->AssetId;
    return $field;
  }

  /**
   * Set title ids.
   *
   * @param $source_data
   *    Source object.
   * @param \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface $updated_entity
   *    New entity.
   */
  protected function setTitleIds($source_data, ContentOnDemandScheduleInterface $updated_entity) {
    $title_ids = [];
    $title_ids[] = $source_data->TveItem->Title->Id;
    $updated_entity->setTitleIds($title_ids);
  }

}
