<?php

namespace Drupal\draco_udi\Plugin\ContentConverter;

use Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;
use Drupal\draco_udi\Service\ContentFetchManager;

/**
 * Class ContentOnDemandScheduleConverter.
 *
 * @package Drupal\draco_udi\Plugin\ContentConverter
 *
 * @ContentConverterStrategy(id = "OnDemandSchedule")
 */
class ContentOnDemandScheduleConverter extends ContentConverterBase {

  /**
   * {@inheritdoc}
   */
  public function getMappedEntityType() {
    return 'content_on_demand_schedule';
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForCreateEntity(\stdClass $content_data) {
    $type = isset($content_data->type) ? $content_data->type : '';
    return array(
      'type' => $type,
      'label' => $content_data->name,
      'airing_id' => $content_data->airingId,
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function mapFields(
    \stdClass $content_data,
    DracoContentInterface $new_draco_entity,
    DracoContentInterface $existing_draco_entity = NULL
  ) {
    $existing_copy = NULL;
    $update = FALSE;

    if ($existing_draco_entity != NULL) {
      $existing_copy = $existing_draco_entity->createDuplicate();
      $update = TRUE;
    }

    $formatted_content = $this->formatSourceContent($content_data);
    $entity = $this->populateEntityFields($formatted_content, $new_draco_entity, $update);
    $flight_entities = $this->updateFlights($formatted_content, $entity);
    $converted_set = new ConvertedEntitySet($formatted_content,
      ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE,
      $entity,
      $existing_copy,
      $flight_entities);

    return $converted_set;
  }

  /**
   * This method allows child class to change format of original json.
   *
   * The default behavior is no change.
   *
   * @param \stdClass $content_data
   *    Original json.
   *
   * @return \stdClass
   *    Formatted json.
   */
  protected function formatSourceContent(\stdClass $content_data) {
    return $content_data;
  }

  /**
   * Map field to field between target entity and source content object.
   *
   * @param \stdClass $source_data
   *    Newly downloaded upstream content object.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $target_entity
   *    A new or existing corresponding entity to be updated.
   * @param bool $update
   *    TRUE is target entity exists. Otherwise FALSE.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *    Entity with new or updated data.
   */
  protected function populateEntityFields(\stdClass $source_data, DracoContentInterface $target_entity, $update) {
    /** @var \Drupal\draco_udi\Entity\ContentOnDemandSchedule $updated_entity */
    $updated_entity = $target_entity;
    $updated_entity->setContentJson($source_data);
    $updated_entity->setBrand($source_data->brand);
    $updated_entity->setLengthInSeconds($source_data->duration->lengthInSeconds);
    $updated_entity->setDisplayMinutes($source_data->duration->displayMinutes);
    $updated_entity->setVersions($source_data->versions);
    $updated_entity->setFiles($source_data->options->files);

    if (isset($source_data->mediaId)) {
      $updated_entity->setMediaId($source_data->mediaId);
    }

    if (isset($source_data->playList)) {
      $updated_entity->setPlaylist($source_data->playList);
    }

    $this->setTitleIds($source_data, $updated_entity);
    $this->setPackages($source_data, $updated_entity);
    $this->updateLastChangedTimestamp($updated_entity);

    return $updated_entity;
  }

  /**
   * Set title ids.
   *
   * @param $source_data
   *    Source object.
   * @param \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface $updated_entity
   *    New entity.
   */
  protected function setTitleIds($source_data, ContentOnDemandScheduleInterface $updated_entity) {
    $updated_entity->setTitleData($source_data->title);

    $title_ids = [];

    if (isset($source_data->options->titles)) {
      foreach ($source_data->options->titles as $title0) {
        if (!in_array($title0->titleId, $title_ids)) {
          $title_ids[] = $title0->titleId;
        }
      }
    }
    else {
      $titles = $source_data->title->titleIds;

      foreach ($titles as $title1) {
        if ($title1->authority == 'Turner') {
          $title = intval($title1->value);
          if (!in_array($title, $title_ids)) {
            $title_ids[] = $title;
          }
        }
      }
    }

    $updated_entity->setTitleIds($title_ids);
  }

  /**
   * Set Package Data.
   *
   * @param $source_data
   *    Source object.
   * @param \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface $updated_entity
   *    New entity.
   */
  protected function setPackages($source_data, ContentOnDemandScheduleInterface $updated_entity) {

    if (isset($source_data->options->packages)) {
      foreach ($source_data->options->packages as $packageData) {
        $updated_entity->setPackage($packageData->type, $packageData->packageData);
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForQueryEntity(\stdClass $content_data) {
    $field = new \stdClass();
    $field->name = 'airing_id';

    if (isset($content_data->airingId)) {
      $field->value = $content_data->airingId;
    }
    elseif (isset($content_data->action) && $content_data->action == 'delete' && isset($content_data->data->AiringId)) {
      $field->value = $content_data->data->AiringId;
    }

    return $field;
  }

  /**
   * Create or update flights.
   *
   * @param \stdClass $content_data
   *    Source object.
   * @param \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface $schedule_entity
   *    New entity.
   *
   * @return array
   *    List of converted flight entities.
   */
  protected function updateFlights($content_data, ContentOnDemandScheduleInterface $schedule_entity) {
    $flight_data_list = $content_data->flights;
    $airing_id = $schedule_entity->getAiringId();
    $flight_entities = [];

    if (!empty($schedule_entity->getFlightIds())) {
      $this->cleanupExistingFlights($schedule_entity);
    }

    $flight_storage = $this->entityManager->getStorage('content_on_demand_flight');

    foreach ($flight_data_list as $flight_data) {
      /** @var \Drupal\draco_udi\Entity\ContentOnDemandFlight $flight_entity */
      $flight_entity = $flight_storage->create(array('airing_id' => $airing_id));
      $start_datetime = new \DateTime($flight_data->start, new \DateTimeZone('UTC'));
      $flight_entity->setStart($start_datetime);
      $end_datetime = new \DateTime($flight_data->end, new \DateTimeZone('UTC'));
      $flight_entity->setEnd($end_datetime);
      $flight_entity->setDestinations($flight_data->destinations);

      $flight_entities[] = $flight_entity;
    }

    return $flight_entities;
  }

  /**
   * Delete existing associated flights for creating them.
   *
   * There is no way to update flights as they don't have a business key.
   *
   * @param \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface $schedule_entity
   *    New entity.
   */
  protected function cleanupExistingFlights(ContentOnDemandScheduleInterface $schedule_entity) {
    /** @var \Drupal\draco_udi\Entity\ContentOnDemandFlight $flight */
    foreach ($schedule_entity->getFlights() as $flight) {
      $flight_id = $flight->id();
      $flight->delete();
      $schedule_entity->removeFlight($flight_id);
    }
  }

}
