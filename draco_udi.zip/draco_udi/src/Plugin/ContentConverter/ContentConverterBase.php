<?php

namespace Drupal\draco_udi\Plugin\ContentConverter;

use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class ContentConverterBase.
 *
 * Base class that source content converter plugin classes extend from.
 *
 * @package Drupal\draco_udi\Plugin\ContentConverter
 */
abstract class ContentConverterBase extends PluginBase implements ContentConverterInterface {

  /**
   * Entity Manager.
   *
   * @var \Drupal\Core\Entity\EntityManagerInterface
   */
  protected $entityManager;

  /**
   * Entity Query.
   *
   * @var \Drupal\Core\Entity\Query\QueryFactory
   */
  protected $entityQuery;

  /**
   * Logger.
   *
   * @var \Drupal\draco_logging\Diagnostic\DiagnosticLoggerChannel
   */
  protected $logger;

  /**
   * ContentConverterBase constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityManagerInterface $entity_manager
   *   The entity manager.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *    Entity query factory for finding entities with same titleId.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   A logger instance.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      EntityManagerInterface $entity_manager,
      QueryFactory $query_factory,
      LoggerChannelFactoryInterface $logger_factory
  ) {

    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityManager = $entity_manager;
    $this->entityQuery = $query_factory;
    $this->logger = $logger_factory->get('draco_udi');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static($configuration, $plugin_id, $plugin_definition,
      $container->get('entity.manager'),
      $container->get('entity.query'),
      $container->get('draco_udi.diagnostic_logger_channel_factory')
    );
  }

  /**
   * Convert a content title json object to a ContentTitle entity.
   *
   * @param \stdClass|NULL $content_data
   *    A json object downloaded from upstream data source.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface|NULL $existing_draco_entity
   *    Existing entity.
   *
   * @return \Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet
   *    An instance of ConvertedEntitySet holding converted entities.
   *
   * @throws \InvalidArgumentException
   *    Thrown when either $content_data is null or not of a stdClass.
   * @throws UdiProcessException
   *    Thrown when failing to create an entity.
   */
  public function convert(\stdClass $content_data = NULL, DracoContentInterface $existing_draco_entity = NULL) {
    if (empty($content_data)) {
      $msg = 'Failed converting source content to Draco entity. The content data is either null or not a stdClass object.';
      $this->logger->error($msg);
      throw new \InvalidArgumentException($msg);
    }

    $new_entity = $this->createEntity($content_data, $existing_draco_entity);
    $this->logger->info("Converted a content json object to a Content entity");

    if ($new_entity == NULL) {
      $msg1 = 'Error creating entity from imported source content.';
      $this->logger->error($msg1);
      throw new UdiProcessException($msg1);
    }

    $entity_set = $this->mapFields($content_data, $new_entity, $existing_draco_entity);

    return $entity_set;
  }

  /**
   * Create Draco entity of corresponding type.
   *
   * The child class should override it to return a new entity of certain type.
   *
   * @param \stdClass $content_data
   *    Source content.
   * @param DracoContentInterface $existing_draco_entity
   *    Existing draco entity for updating.
   *
   * @throws \InvalidArgumentException
   *   Thrown when either $content_data is null or not of a stdClass.
   *
   * @return DracoContentInterface | NULL
   *    Created entity.
   */
  private function createEntity(\stdClass $content_data, DracoContentInterface $existing_draco_entity = NULL) {
    $draco_entity = NULL;

    if ($existing_draco_entity != NULL) {
      $draco_entity = $existing_draco_entity;
    }
    else {
      $entity_storage = $this->entityManager->getStorage($this->getMappedEntityType());

      if (empty($this->getRequiredFieldsForCreateEntity($content_data))) {
        $msg = 'Required fields not defined for creating draco entity.';
        $this->logger->error($msg);
        throw new \InvalidArgumentException($msg);
      }

      $draco_entity = $entity_storage->create($this->getRequiredFieldsForCreateEntity($content_data));
      $this->logger->info("Did not found existing, Created a new draco entity.");
    }

    return $draco_entity;
  }

  /**
   * {@inheritdoc}
   */
  public function findExistingEntity(\stdClass $content_data) {
    $field_data = $this->getRequiredFieldsForQueryEntity($content_data);

    if ($field_data == NULL || !isset($field_data->name) || !isset($field_data->value)) {
      $msg = 'Required fields not defined for searching existing entity.';
      $this->logger->error($msg);
      throw new \InvalidArgumentException($msg);
    }

    $field_name = $field_data->name;
    $field_value = $field_data->value;

    $existing_entity = NULL;
    $query = $this->entityQuery->get($this->getMappedEntityType())->condition($field_name, $field_value);
    $ids = $query->execute();

    if (!empty($ids)) {
      if (count($ids) == 1) {
        $a_id = reset($ids);
        $existing_entity = $this->entityManager->getStorage($this->getMappedEntityType())->load($a_id);
      }
      else {
        $msg1 = sprintf('Found more than one %s entity in db when searching field %s with value %s',
          $this->getMappedEntityType(), $field_name, $field_value);
        $this->logger->error($msg1);
        throw new UdiProcessException($msg1);
      }
      if($existing_entity != NULL) {
        $this->logger->info("Found an existing Draco entity of type:'@type' id:'@aid'.",
          ['@type' => $this->getMappedEntityType(), '@aid' => $a_id]);
      }
    }
    return $existing_entity;
  }

  /**
   * Set last updated timestamp.
   *
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $entity
   */
  protected function updateLastChangedTimestamp(DracoContentInterface $entity) {
    $entity->setChangedTime((new \DateTime())->getTimestamp());
  }

  /**
   * Returns array of required field/value pairs for creating entity.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return array | NULL
   *    Required field/value pairs.
   */
  abstract protected function getRequiredFieldsForCreateEntity(\stdClass $content_data);

  /**
   * Map entity fields to source object properties.
   *
   * @param \stdClass $content_data
   *    Source content.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $new_draco_entity
   *    Newly created entity or existing entity.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $existing_draco_entity
   *    Existing draco entity for updating.
   *
   * @return ConvertedEntitySet | NULL
   *    Set of converted entity and its related entities.
   */
  abstract protected function mapFields(\stdClass $content_data, DracoContentInterface $new_draco_entity, DracoContentInterface $existing_draco_entity = NULL);

  /**
   * Return field name and value for setting entity query condition.
   *
   * Child classes have to implement this method.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return \stdClass | NULL
   *    Content field name and value.
   */
  abstract protected function getRequiredFieldsForQueryEntity(\stdClass $content_data);

}
