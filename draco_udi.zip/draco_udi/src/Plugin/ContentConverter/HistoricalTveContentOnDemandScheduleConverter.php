<?php

namespace Drupal\draco_udi\Plugin\ContentConverter;

/**
 * Class HistoricalTveContentOnDemandScheduleConverter.
 *
 * This class converts a historical TVE to a ContentOnDemandSchedule entity with possible
 * associated ContentOnDemandFlight entities.
 *
 * The plugin id "HistoricalTVE" matches the content type defined by
 * ContentFetchManager::CONTENT_SOURCE_HISTORICAL_TVE.
 *
 * @package Drupal\draco_udi\Plugin\ContentConverter
 *
 * @ContentConverterStrategy(id = "HistoricalTVE")
 */
class HistoricalTveContentOnDemandScheduleConverter extends TveContentOnDemandScheduleConverter {

  /**
   * {@inheritdoc}
   */
  protected function formatSourceContent(\stdClass $content_data) {

    $formatted_content = new \stdClass();
    $formatted_content->TveItem = new \stdClass();
    $formatted_content->TveItem->C3 = $content_data->Attributes->C3;

    $formatted_content->TveItem->Title = new \stdClass();
    $formatted_content->TveItem->Title->Id = $content_data->Title->Attributes->Id;
    $formatted_content->TveItem->Title->Type = $content_data->Title->Attributes->Type;
    $formatted_content->TveItem->Title->Network = new \stdClass();
    $formatted_content->TveItem->Title->Network->Net = $content_data->Title->Network->Attributes->Net;
    $formatted_content->TveItem->Title->AssetId = $content_data->Title->AssetId;
    $formatted_content->TveItem->Title->TitleName = $content_data->Title->TitleName;
    $formatted_content->TveItem->Title->Duration = new \stdClass();
    $formatted_content->TveItem->Title->Duration->ActualSeconds = $content_data->Title->Duration->Attributes->ActualSeconds;
    $formatted_content->TveItem->Title->Duration->DisplayMinutes = $content_data->Title->Duration->Attributes->DisplayMinutes;
    $formatted_content->TveItem->Title->SearchName = $content_data->Title->SearchName;
    $formatted_content->TveItem->Title->Released = new \stdClass();
    $formatted_content->TveItem->Title->Released->Year = $content_data->Title->Released->Attributes->Year;
    $formatted_content->TveItem->Title->MetaKeywords = $content_data->Title->MetaKeywords;
    $formatted_content->TveItem->Title->Genre = $content_data->Title->Genre;
    $formatted_content->TveItem->Title->TVRatingCode = $content_data->Title->TVRatingCode;
    $formatted_content->TveItem->Title->StoryLine = $content_data->Title->StoryLine;
    $formatted_content->TveItem->Title->StoryLineShort = $content_data->Title->StoryLineShort;
    $formatted_content->TveItem->Title->Airings = new \stdClass();
    $formatted_content->TveItem->Title->Airings->Airing = $this->formatAiringsNode($content_data);
    $formatted_content->TveItem->Title->OriginalPremierDate = new \stdClass();
    $formatted_content->TveItem->Title->OriginalPremierDate->Date = $content_data->Title->OriginalPremierDate->Attributes->Date;
    $formatted_content->TveItem->Title->SeriesName = $content_data->Title->SeriesName;
    $formatted_content->TveItem->Title->EpisodeNumber = $content_data->Title->EpisodeNumber;
    $formatted_content->TveItem->Title->SeasonNumber = $content_data->Title->SeasonNumber;
    $formatted_content->TveItem->Title->EpisodeTitle = $content_data->Title->EpisodeTitle;

    $formatted_content->TveItem->Title->Participants = new \stdClass();
    $formatted_content->TveItem->Title->Participants->Participant = $this->formatParticipantsNode($content_data);

    $formatted_content->TveItem->Title->ExternalIds = new \stdClass();
    $formatted_content->TveItem->Title->ExternalIds->ExternalId = $this->formatExternalIdNode($content_data);

    $formatted_content->TveItem->Flights = new \stdClass();
    $formatted_content->TveItem->Flights->Flight = $this->formatFlightsNode($content_data);

    $formatted_content->TveItem->AdBreaks = new \stdClass();
    $formatted_content->TveItem->AdBreaks->AdBreak = $this->formatAdBreaksNode($content_data);

    $formatted_content->TveItem->ContentSegments = new \stdClass();
    $formatted_content->TveItem->ContentSegments->ContentSegment = $this->formatContentSegmentsNode($content_data);;

    $formatted_content->TveItem->Assets = new \stdClass();
    $formatted_content->TveItem->Assets->Asset = $this->formatAssetsNode($content_data);

    $formatted_content->TveItem->Thumbs = new \stdClass();
    $formatted_content->TveItem->Thumbs->AltText = $content_data->Thumbs->AltText;
    $formatted_content->TveItem->Thumbs->Thumb = $this->formatThumbsNode($content_data);

    $formatted_content->TveItem->Playback = $this->formatPlaybackNode($content_data);

    if (isset($content_data->SqueezeCredits)) {
      $formatted_content->TveItem->SqueezeCredits = new \stdClass();
      $formatted_content->TveItem->SqueezeCredits->Start = $content_data->SqueezeCredits->Attributes->Start;
      $formatted_content->TveItem->SqueezeCredits->End = $content_data->SqueezeCredits->Attributes->End;
    }

    if (isset($content_data->Restrictions)) {
      $formatted_content->TveItem->Restrictions = $content_data->Restrictions;
    }
    $formatted_content->TveItem->TurnerPrivate = new \stdClass();
    $formatted_content->TveItem->TurnerPrivate = $this->formatTurnerPrivateNode($content_data);

    return $formatted_content;
  }

  /**
   * Format Playback node.
   *
   * The FF sub-node's attribute may be either 'allowed' or 'Allowed'.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return array
   *  Formatted node data.
   */
  private function formatPlaybackNode(\stdClass $content_data) {
    $playback = new \stdClass();
    $playback->FF = new \stdClass();

    if (isset($content_data->Playback->FF->Attributes->Allowed)) {
      $playback->FF->Allowed = $content_data->Playback->FF->Attributes->Allowed;
    }
    elseif (isset($content_data->Playback->FF->Attributes->allowed)) {
      $playback->FF->Allowed = $content_data->Playback->FF->Attributes->allowed;
    }

    $playback->ProgrammerBrandingReq = new \stdClass();
    $playback->ProgrammerBrandingReq->Required = $content_data->Playback->ProgrammerBrandingReq->Attributes->Required;

    return $playback;
  }

  /**
   * Format Airings node.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return array
   *  Airings.
   */
  private function formatAiringsNode(\stdClass $content_data) {
    $airings = [];

    foreach ($content_data->Title->Airings->Airing as $airing) {
      $item = new \stdClass();
      $item->Date = $airing->Attributes->Date;
      $airings[] = $item;
    }

    return $airings;
  }

  /**
   * Format Participants node. It returns either an array or a single object.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return mixed
   *    Participant names.
   */
  private function formatParticipantsNode(\stdClass $content_data) {
    $participants = NULL;

    if (isset($content_data->Title->Participants->Participant)) {
      if (is_array($content_data->Title->Participants->Participant)) {
        $participants = [];
        foreach ($content_data->Title->Participants->Participant as $participant) {
          $item = new \stdClass();
          $item->Name = $participant->Attributes->Name;
          $participants[] = $item;
        }
      }
      elseif ($content_data->Title->Participants->Participant instanceof \stdClass) {
        $item = new \stdClass();
        $item->Name = $content_data->Title->Participants->Participant->Attributes->Name;
        $participants = $item;
      }
    }

    return $participants;
  }

  /**
   * Format ExternalIds node.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return \stdClass
   *    ExternalId.
   */
  private function formatExternalIdNode(\stdClass $content_data) {
    $externalId = new \stdClass();
    $externalId->Source = $content_data->Title->ExternalIds->ExternalId->Attributes->Source;
    $externalId->Type = $content_data->Title->ExternalIds->ExternalId->Attributes->Type;
    $externalId->Value = $content_data->Title->ExternalIds->ExternalId->Attributes->Value;
    return $externalId;
  }

  /**
   * Format Flights node.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return \stdClass
   *    Flight.
   */
  private function formatFlightsNode(\stdClass $content_data) {
    $flight = new \stdClass();
    $flight->Start = $content_data->Flights->Flight->Attributes->Start;
    $flight->End = $content_data->Flights->Flight->Attributes->End;
    $flight->Auth = $content_data->Flights->Flight->Attributes->Auth;

    return $flight;
  }

  /**
   * Format AdBreaks node.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return array
   *    AdBreaks.
   */
  private function formatAdBreaksNode($content_data) {
    $ad_breaks = [];

    foreach ($content_data->AdBreaks->AdBreak as $break) {
      $item = new \stdClass();
      $item->Start = $break->Attributes->Start;
      $item->End = $break->Attributes->End;
      $ad_breaks[] = $item;
    }

    return $ad_breaks;
  }

  /**
   * Format ContentSegments node.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return array
   *    Content segments.
   */
  private function formatContentSegmentsNode($content_data) {
    $segments = [];

    foreach ($content_data->ContentSegments->ContentSegment as $segment) {
      $item = new \stdClass();
      $item->Start = $segment->Attributes->Start;
      $item->End = $segment->Attributes->End;
      $segments[] = $item;
    }

    return $segments;
  }

  /**
   * Format Thumbs node.
   *
   * @param \stdClass $content_data
   *    Source content.
   *
   * @return array
   *    Thumbs.
   */
  private function formatThumbsNode($content_data) {
    $thumbs = [];

    foreach ($content_data->Thumbs->Thumb as $thumb) {
      $item = new \stdClass();
      $item->Width = $thumb->Attributes->Width;
      $item->Height = $thumb->Attributes->Height;
      $item->ImageUrl = $thumb->Attributes->ImageUrl;
      $thumbs[] = $item;
    }

    return $thumbs;
  }

  /**
   * Format Assets node.
   *
   * @param \stdClass $content_data
   *    Original json data.
   *
   * @return array
   *    Formatted data.
   */
  private function formatAssetsNode($content_data) {
    $assets = [];

    foreach ($content_data->Assets->Asset as $asset) {
      $item = new \stdClass();
      $item->FileName = $asset->Attributes->FileName;
      $item->Bitrate = $asset->Attributes->Bitrate;
      $item->Width = $asset->Attributes->Width;
      $item->Height = $asset->Attributes->Height;
      $item->AudioType = $asset->Attributes->AudioType;
      $assets[] = $item;
    }

    return $assets;
  }

  /**
   * Format the private node.
   *
   * @param \stdClass $content_data
   *    Original json data.
   *
   * @return \stdClass
   *    Formatted data.
   */
  private function formatTurnerPrivateNode($content_data) {
    $turner_private = new \stdClass();

    $turner_private->Flights = new \stdClass();
    $turner_private->Flights->Flight = $this->formatTurnerPrivateFlights($content_data);

    $turner_private->PgmBucket = new \stdClass();
    if (isset($content_data->TurnerPrivate->PgmBucket)) {
      $turner_private->PgmBucket->Value = $content_data->TurnerPrivate->PgmBucket->Attributes->Value;
    }

    // TVE data may not contain PullOutAdv node.
    if (isset($content_data->TurnerPrivate->PullOutAdv)) {
      $turner_private->PullOutAdv = new \stdClass();
      $turner_private->PullOutAdv->Value = $content_data->TurnerPrivate->PullOutAdv->Attributes->Value;
    }

    $turner_private->CaptionsEncoded = $content_data->TurnerPrivate->CaptionsEncoded;
    $turner_private->ResearchCategory = $content_data->TurnerPrivate->ResearchCategory;
    $turner_private->IsActive = $content_data->TurnerPrivate->IsActive;
    $turner_private->FranchiseId = $content_data->TurnerPrivate->FranchiseId;
    $turner_private->SeriesId = $content_data->TurnerPrivate->SeriesId;
    $turner_private->AdCategory = $content_data->TurnerPrivate->AdCategory;
    $turner_private->WebFlags = $content_data->TurnerPrivate->WebFlags;
    $turner_private->SeasonItemNumber = $content_data->TurnerPrivate->SeasonItemNumber;

    $turner_private->Assets = new \stdClass();
    $turner_private->Assets->Asset = $this->formatTurnerPrivateAssetsNode($content_data);

    $turner_private->Thumbs = new \stdClass();
    $turner_private->Thumbs->ThumbSet = $this->formatTurnerPrivateThumbsNode($content_data);

    return $turner_private;
  }

  /**
   * Format TurnerPrivateFlights node.
   *
   * @param \stdClass $content_data
   *    Original json data.
   *
   * @return array
   *    Formatted data.
   */
  private function formatTurnerPrivateFlights($content_data) {
    $flights = [];

    foreach ($content_data->TurnerPrivate->Flights->Flight as $flight) {
      $item = new \stdClass();
      $item->FeedId = $flight->Attributes->FeedId;
      $item->Start = $flight->Attributes->Start;
      $item->End = $flight->Attributes->End;
      $item->Auth = $flight->Attributes->Auth;
      $flights[] = $item;
    }

    return $flights;
  }

  /**
   * Format TurnerPrivateAssetsNode.
   *
   * @param \stdClass $content_data
   *    Original json data.
   *
   * @return array
   *    Formatted data.
   */
  private function formatTurnerPrivateAssetsNode($content_data) {
    $assets = [];

    foreach ($content_data->TurnerPrivate->Assets->Asset as $asset) {
      $item = new \stdClass();
      $item->FileName = $asset->Attributes->FileName;
      $item->mp4DrmArl = $asset->Attributes->mp4DrmArl;

      if (isset($asset->Attributes->Bitrate)) {
        $item->Bitrate = $asset->Attributes->Bitrate;
      }
      if (isset($asset->Attributes->Width)) {
        $item->Width = $asset->Attributes->Width;
      }
      if (isset($asset->Attributes->Height)) {
        $item->Height = $asset->Attributes->Height;
      }
      if (isset($asset->Attributes->AudioType)) {
        $item->AudioType = $asset->Attributes->AudioType;
      }
      if (isset($asset->Attributes->Type)) {
        $item->Type = $asset->Attributes->Type;
      }
      $assets[] = $item;
    }

    return $assets;
  }

  /**
   * Format TurnerPrivateThumbsNode.
   *
   * @param \stdClass $content_data
   *    Original json data.
   *
   * @return array
   *    Formatted data.
   */
  private function formatTurnerPrivateThumbsNode($content_data) {
    $assets = [];

    foreach ($content_data->TurnerPrivate->Thumbs->ThumbSet as $set) {
      $item = new \stdClass();
      $item->Name = $set->Attributes->Name;
      $item->AltText = $set->AltText;

      $item->Thumb = [];

      foreach ($set->Thumb as $thumb) {
        $t = new \stdClass();
        $t->contentName = $thumb->Attributes->contentName;
        $t->Width = $thumb->Attributes->Width;
        $t->Height = $thumb->Attributes->Height;
        $t->SrcUrl = $thumb->Attributes->SrcUrl;

        $item->Thumb[] = $t;
      }

      $assets[] = $item;
    }

    return $assets;
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForCreateEntity(\stdClass $content_data) {
    return array(
      'type' => $content_data->Title->Attributes->Type,
      'label' => $content_data->Title->TitleName,
      'airing_id' => $content_data->Title->AssetId,
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequiredFieldsForQueryEntity(\stdClass $content_data) {
    $field = new \stdClass();
    $field->name = 'airing_id';
    $field->value = $content_data->Title->AssetId;

    return $field;
  }

}
