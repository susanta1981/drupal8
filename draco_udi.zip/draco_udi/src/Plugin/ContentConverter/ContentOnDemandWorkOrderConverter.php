<?php

namespace Drupal\draco_udi\Plugin\ContentConverter;

/**
 * Class ContentOnDemandWorkOrderConverter.
 *
 * This class provides the Discovery Annotations for an OnDemandWorkOrder object.
 * After discovery the work order will be treated just like an OnDemandSchedule
 * so all the code is located in the ContentOnDemandScheduleConverter.
 *
 * @package Drupal\draco_udi\Plugin\ContentConverter
 *
 * @ContentConverterStrategy(id = "OnDemandWorkOrder")
 */
class ContentOnDemandWorkOrderConverter extends ContentOnDemandScheduleConverter {



}
