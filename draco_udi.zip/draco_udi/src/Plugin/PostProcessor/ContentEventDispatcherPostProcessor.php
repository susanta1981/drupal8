<?php

namespace Drupal\draco_udi\Plugin\PostProcessor;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Field\Plugin\Field\FieldType\IntegerItem;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\draco_udi\Context;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Events\UdiContentDeleteEvent;
use Drupal\draco_udi\Events\UdiSeriesEvent;
use Drupal\draco_udi\PostProcessor\DracoPostProcessorInterface;
use Drupal\draco_udi\Service\ContentFetchManager;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Drupal\draco_udi\Events\UdiContentImportEvent;
use Symfony\Component\Serializer\Encoder\JsonEncode;
use Symfony\Component\Serializer\Encoder\JsonEncoder;

/**
 * Class ContentEventDispatcherPostProcessor.
 *
 * Dispatches UdiContentImportEvent at end of UDI workflow.
 *
 * @package Drupal\draco_udi\Plugin\PostProcessor
 *
 * @DracoPostProcessorPlugin(id = "draco_udi_event_dispatcher")
 */
class ContentEventDispatcherPostProcessor extends PluginBase implements DracoPostProcessorInterface, ContainerFactoryPluginInterface {

  /**
   * @var \Symfony\Component\EventDispatcher\EventDispatcherInterface
   */
  private $eventDispatcher;

  /**
   * @var \Drupal\draco_logging\Diagnostic\DiagnosticLoggerChannel
   */
  private $logger;

  /**
   * @var \Drupal\Core\Entity\Query\QueryFactory
   */
  private $entityQuery;

  /**
   * @var \Symfony\Component\Serializer\Encoder\JsonEncoder
   */
  private $jsonEncoder;

  /**
   * Constructs a ContentEventDispatcherPostProcessor object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Symfony\Component\EventDispatcher\EventDispatcherInterface $event_dispatcher
   *    Event dispatcher.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *    Logger factory.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *    Entity query factory.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      EventDispatcherInterface $event_dispatcher,
      LoggerChannelFactoryInterface $logger_factory,
      QueryFactory $query_factory
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->eventDispatcher = $event_dispatcher;
    $this->logger = $logger_factory->get('draco_udi');
    $this->entityQuery = $query_factory;
    $this->jsonEncoder = new JsonEncoder(new JsonEncode());
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
        $configuration,
        $plugin_id,
        $plugin_definition,
        $container->get('event_dispatcher'),
        $container->get('draco_udi.diagnostic_logger_channel_factory'),
        $container->get('entity.query')
      );
  }

  /**
   * Dispatch UDIContentImportEvent indicating that content has been imported.
   *
   * In case the entity is of ContentOnDemandSchedule type, dispatch another
   * event carrying on-demand specific data.
   *
   * @param Context $context
   *    The UDI context object used in workflow.
   */
  public function process(Context $context) {
    $decision = $context->getDataChangeDecision();
    $data = ['context' => $context];
    $event = new UdiContentImportEvent($context->getEntityType(), $data);
    $entity = $context->getCurrentEntity();
    $type = $context->getEntityType();

    if ($decision->getApproved()) {
      if ($context->getAction() == ContentFetchManager::CONTENT_DELETE_ACTION) {
        $this->dispatchContentDeletedSuccessfulEvent($context->getDeletedEntities(), $type);

        $this->logger->info('UDI successfully deleted @type content entity with id %id',
          ['@type' => $type, '%id' => $decision->getEntityId()]);
      }
      else {
        // TODO should we remove this event?
        $this->eventDispatcher->dispatch(UdiContentImportEvent::UDI_CONTENT_IMPORT_SUCCESSFUL, $event);

        $this->logger->info('UDI successfully imported or updated @type content %name',
          ['@type' => $type, '%name' => $entity->getName()]);

        switch ($type) {
          case ContentFetchManager::CONTENT_TITLE_TYPE:
            $this->dispatchTitleImportSuccessfulEvent($entity, $context);
            break;
          case ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE:
            $this->dispatchLinearScheduleImportSuccessfulEvent($entity, $context);
            break;
          case ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE:
            $this->dispatchOnDemandScheduleImportSuccessfulEvent($entity, $context);
            break;
          default:
            break;
        }
      }
    }
    else {
      $this->eventDispatcher->dispatch(UdiContentImportEvent::UDI_CONTENT_IMPORT_NOT_APPROVED, $event);
    }
  }

  /**
   * Dispatch an ODT imported event.
   *
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $entity
   *    The imported on-demand schedule entity.
   * @param Context $context
   *    Context object.
   */
  private function dispatchOnDemandScheduleImportSuccessfulEvent(DracoContentInterface $entity, Context $context) {
    $data = [];
    $data['mediaId'] = ($entity->getMediaId()) ? $entity->getMediaId() : NULL;
    $data['airingId'] = $entity->getAiringId();
    $data['lengthInSeconds'] = $entity->getLengthInSeconds();
    $data['displayMinutes'] = $entity->getDisplayMinutes();
    $data['entity'] = $entity;
    $data['source'] = $context->getEntitySource();
    $data['sourceContent'] = $context->getSourceContent();

    $title_ids = ($entity->getTitleIds()) ? $this->getTitleIdsAsIntegers($entity->getTitleIds(), $data['airingId']) : [];
    $data['titleIds'] = $title_ids;
    $data['missingTitles'] = $this->findMissingTitleContentEntities($title_ids);

    $event = new UdiContentImportEvent($context->getEntityType(), $data);
    $this->eventDispatcher->dispatch(UdiContentImportEvent::UDI_CONTENT_ON_DEMAND_IMPORT_SUCCESSFUL, $event);

    $this->logger->debug('Dispatched UDI_CONTENT_ON_DEMAND_IMPORT_SUCCESSFUL event. airing id: @id; title IDs: @titles',
      ['@id' => $entity->getAiringId(), '@titles' => $this->jsonEncoder->encode($title_ids, 'json')]);
  }

  /**
   * Dispatch a title imported event.
   *
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $entity
   *    The imported title entity.
   * @param Context $context
   *    Context object.
   */
  private function dispatchTitleImportSuccessfulEvent(DracoContentInterface $entity, Context $context) {
    $data = [];
    $data['titleId'] = ($entity->getTitleId()) ? $entity->getTitleId() : NULL;
    $data['entity'] = $entity;
    $data['sourceContent'] = $context->getSourceContent();

    $event = new UdiContentImportEvent($context->getEntityType(), $data);
    $this->eventDispatcher->dispatch(UdiContentImportEvent::UDI_CONTENT_TITLE_IMPORT_SUCCESSFUL, $event);

    $this->logger->debug('Dispatched UDI_CONTENT_TITLE_IMPORT_SUCCESSFUL event. Title id: @id',
      ['@id' => $entity->getTitleId()]);

    // Series should be imported by whitelist that listens to this event.
    if($this->isSeriesTitleContent($context)) {
      $this->dispatchSeriesImportedEvent($context->getEntityType(), $context);
    }
  }

  /**
   * Dispatch linear schedule import successful event.
   *
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $entity
   *    The imported linear schedule entity.
   * @param Context $context
   *    Context object.
   */
  private function dispatchLinearScheduleImportSuccessfulEvent(DracoContentInterface $entity, Context $context) {
    $data = [];
    $data['externalId'] = ($entity->getExternalId()) ? $entity->getExternalId() : NULL;
    $data['entity'] = $entity;
    $data['sourceContent'] = $context->getSourceContent();

    $title_ids = ($entity->getTitleIds()) ? $this->getTitleIdsAsIntegers($entity->getTitleIds(), $data['externalId']) : [];
    $data['titleIds'] = $title_ids;

    $event = new UdiContentImportEvent($context->getEntityType(), $data);
    $this->eventDispatcher->dispatch(UdiContentImportEvent::UDI_CONTENT_LINEAR_SCHEDULE_IMPORT_SUCCESSFUL, $event);

    $this->logger->debug('Dispatched UDI_CONTENT_LINEAR_SCHEDULE_IMPORT_SUCCESSFUL event. external id: @id; title IDs: @titles',
      ['@id' => $entity->getExternalId(), '@titles' => $this->jsonEncoder->encode($title_ids, 'json')]);
  }

  /**
   * Dispatch a content entity deleted event.
   *
   * @param array $deleted_entities
   *    Clones of deleted entities.
   * @param string $entity_type
   *    UDI defined draco entity type.
   */
  private function dispatchContentDeletedSuccessfulEvent(array $deleted_entities, $entity_type) {
    $event_data = [];
    $event_data['deletedEntities'] = $deleted_entities;

    $event = new UdiContentDeleteEvent($entity_type, $event_data);
    $this->eventDispatcher->dispatch(UdiContentDeleteEvent::UDI_CONTENT_DELETE_SUCCESSFUL, $event);

    $this->logger->debug('Dispatched UDI_CONTENT_DELETE_SUCCESSFUL event.');
  }

  /**
   * Return an array of titleIds which corresponding entities not found.
   *
   * @param array $title_ids
   *    Title ids retrieved from on-demand schedule entity.
   *
   * @return array
   *    Title ids of missing title content entities.
   */
  private function findMissingTitleContentEntities(array $title_ids) {
    $missing_titles = [];

    if (empty($title_ids)) {
      return $missing_titles;
    }

    foreach ($title_ids as $title_id) {
      $query = $this->entityQuery->get('content_title')->condition('title_id', $title_id);
      $entity_ids = $query->execute();

      if (empty($entity_ids)) {
        $missing_titles[] = $title_id;
      }
    }

    return $missing_titles;
  }

  /**
   * Check if the Flow title content is a Series type.
   *
   * @param \Drupal\draco_udi\Context $context
   *    Context.
   *
   * @return bool
   *    TRUE if is a Series otherwise FALSE.
   */
  private function isSeriesTitleContent(Context $context) {
    $is_series = FALSE;

    if($context->getEntityType() == ContentFetchManager::CONTENT_TITLE_TYPE
      && $context->getAction() == ContentFetchManager::CONTENT_INSERT_ACTION){
      $source_content = $context->getSourceContent();
      if (isset($source_content->SeriesItems) && !empty($source_content->SeriesItems)){
        $is_series = TRUE;
      }
    }

    return $is_series;
  }

  /**
   * Dispatch UDI_SERIES_CONTENT_IMPORT_SUCCESSFUL event.
   *
   * Dispatch only when importing (insert) series by running series whitelist or
   * from other tools.
   *
   * @param string $type
   *    UDI defined content type.
   * @param Context $context
   *    UDI context object.
   */
  private function dispatchSeriesImportedEvent($type, Context $context) {
    $source_content = $context->getSourceContent();
    $data = [];
    $data['contentType'] = $type;
    $data['sourceContent'] = $source_content;
    $event = new UdiSeriesEvent($data);
    $title_id = $context->getCurrentEntity()->getTitleId();
    $name = $context->getCurrentEntity()->getName();

    $this->eventDispatcher->dispatch(UdiSeriesEvent::UDI_SERIES_CONTENT_IMPORT_SUCCESSFUL, $event);

    $this->logger->debug('Dispatched UDI_SERIES_CONTENT_IMPORT_SUCCESSFUL event for Series @name with title id @id',
      ['@name' => $name, '@id' => $title_id]);
  }

  /**
   * Return array of title ids as integers.
   *
   * @param array $title_ids
   *    Array of title ids of IntegerItem type.
   * @param mixed $content_id
   *    Content id.
   *
   * @throw \InvalidArgumentException
   *
   * @return array
   *    Array of integer title ids.
   */
  private function getTitleIdsAsIntegers($title_ids, $content_id) {
    $ids = [];
    foreach ($title_ids as $title_id) {
      if($title_id instanceof IntegerItem) {
        $ids[] = $title_id->getValue()['value'];
      }
      elseif(is_int($title_id)) {
        $ids[] = $title_id;
      }
      else {
        throw new \InvalidArgumentException(sprintf('Error in on-demand entity with id %s' .
          '. Values in $title_ids array neither IntegerItem nor int.', $content_id));
      }
    }

    return $ids;
  }

}
