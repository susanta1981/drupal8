<?php

namespace Drupal\draco_udi\Plugin\PostProcessor;

use Drupal\Component\Plugin\PluginBase;
use Drupal\draco_udi\Context;
use Drupal\draco_udi\PostProcessor\DracoPostProcessorInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Entity\EntityStorageInterface;

/**
 * Class DracoPostProcessionExample.
 *
 * @package Drupal\draco_udi\Plugin\PostProcessor
 *
 * @DracoPostProcessorPlugin(id = "draco_postprocessor_example")
 */
class ContentReportingSaveInDb extends PluginBase implements DracoPostProcessorInterface, ContainerFactoryPluginInterface {


  /**
   * Entity Storage.
   *
   * @var \Drupal\Core\Entity\EntityStorageInterface
   */
  protected $entityStorage;

  /**
   * Constructs a  ContentReportingSaveInDb object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param EntityStorageInterface $entity_storage
   *   Entity Storage.
   */
  public function __construct(
      array $configuration,
      $plugin_id,
      $plugin_definition,
      EntityStorageInterface $entity_storage
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityStorage = $entity_storage;
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {

    return new static(
          $configuration,
          $plugin_id,
          $plugin_definition,
          $container->get('entity.manager')->getStorage('content_decision_report')
      );
  }

  /**
   * Creates a Content Decision Report entity and saves it in the database.
   *
   * Will be used by Content Report UI to display information about the
   * imported datae.
   *
   * @param DataChangeDecision $decision
   *    The DataChangeDecision object from the Approval Process.
   */
  public function process(Context $context) {
    $decision = $context->getDataChangeDecision();

    $item = $this->entityStorage->create(array('type' => 'content_decision_report'));
    $relatedData = &$context->getRelatedData();

    if (!empty($relatedData)) {
      $mappedArray = &$relatedData[Context::RELATED_MAPPED_CONTENT_KEY];
      if ((!empty($mappedArray)) && array_key_exists($context->getCurrentEntity()->id(), $mappedArray)) {
        $item->setMappedEntities($mappedArray[$context->getCurrentEntity()->id()]);
      }
    }
    $item->setApprovalMessages($decision->getMessages());
    $item->setSourceEntity($context->getCurrentEntity());
    $item->setStatus($decision->getApproved());
    $item->save();
  }

}
