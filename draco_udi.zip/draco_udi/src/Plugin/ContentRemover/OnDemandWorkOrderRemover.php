<?php

namespace Drupal\draco_udi\Plugin\ContentRemover;

/**
 * Class OnDemandWorkOrderRemover
 *
 * @package Drupal\draco_udi\Plugin\ContentRemover
 *
 * @ContentRemoverStrategy(id = "OnDemandWorkOrder")
 */
class OnDemandWorkOrderRemover extends OnDemandScheduleRemover {

}