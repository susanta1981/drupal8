<?php

namespace Drupal\draco_udi\Plugin\ContentRemover;

use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\ContentRemover\ContentRemoverInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class OnDemandScheduleRemover
 *
 * @package Drupal\draco_udi\Plugin\ContentRemover
 *
 * @ContentRemoverStrategy(id = "OnDemandSchedule")
 */
class OnDemandScheduleRemover extends PluginBase implements ContentRemoverInterface {

  /**
   * Logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * LinearScheduleRemover constructor.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   A logger instance.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    LoggerChannelFactoryInterface $logger_factory
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->logger = $logger_factory->get('draco_udi');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static($configuration, $plugin_id, $plugin_definition,
      $container->get('logger.factory')
    );
  }

  /**
   * {@inheritdoc}
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function remove(DracoContentInterface $entity) {
    $deleted_entities = [];
    $id = NULL;

    try {
      // Delete flights first.
      /** @var \Drupal\draco_udi\Entity\ContentOnDemandSchedule $entity */
      $airing_id = $entity->getAiringId();

      /** @var \Drupal\draco_udi\Entity\ContentOnDemandFlight $flight */
      $removed_flights = [];

      foreach ($entity->getFlights() as $flight) {
        $flight_id = $flight->id();
        $removed_flights[] = $flight->createDuplicate();
        $flight->delete();
        $entity->removeFlight($flight_id);
        $entity->save();
        $this->logger->info('OnDemandScheduleRemover: deleted on-demand flight @id for schedule @airingId',
          ['@id' => $flight_id, '@airingId' => $airing_id]);
      }

      $deleted_entities[ContentFetchManager::CONTENT_ONDEMAND_FLIGHT_TYPE] = $removed_flights;

      if (!empty($entity->getTitleIds())) {
        $entity->setTitleIds([]);
        $entity->set('titles', []);
        $entity->save();
      }

      //Delete ContentOnDemandSchedule
      $id = $entity->id();
      $deleted_entities[ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE] = $entity->createDuplicate();
      $entity->delete();

      $this->logger->info('OnDemandScheduleRemover: deleted on-demand schedule @airingId',
        ['@airingId' => $airing_id]);
    }
    catch (EntityStorageException $ex) {
      $this->logger->error('OnDemandScheduleRemover: error deleting entity @id. Error message: ' . $ex->getMessage(), ['@id' => $id]);
      throw $ex;
    }

    return $deleted_entities;
  }

}