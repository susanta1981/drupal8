<?php

namespace Drupal\draco_udi\Plugin\DataChangeDecision;

use Drupal\Component\Plugin\PluginBase;

use Drupal\draco_udi\Context;
use Drupal\draco_udi\DataChange\DataChangeDecisionStrategyInterface;
use Drupal\draco_udi\DataChange\DataChangeDecision;

/**
 * This strategy doesn't nothing for new entities. For entities that exist in db,
 * it updates the entire old entity with the new entity.
 *
 * @DataChangeDecisionStrategy(id = "autoApproveStrategy")
 */
class DataChangeAutoApproveStrategy extends PluginBase implements DataChangeDecisionStrategyInterface {

  /**
   * Make the decision and set related data for logging and reporting.
   *
   * @param Context $context
   *    Context object.
   *
   * @return \Drupal\draco_udi\DataChange\DataChangeDecision
   *    Decision data object.
   */
  public function decide(Context $context) {
    $result = new DataChangeDecision();
    $result->setApproved(TRUE);
    $result->setMessages(array('Approved'));
    $result->setAction($context->getAction());
    $result->setContentSource($context->getEntitySource());
    $result->setContentType($context->getEntityType());

    if($context->getCurrentEntity()) {
      $result->setEntityId($context->getCurrentEntity()->id());
    }

    return $result;
  }

}
