<?php

namespace Drupal\draco_udi\Exception;

/**
 * Class UdiProcessException.
 *
 * Thrown by workflow components.
 *
 * @package Drupal\draco_udi\Exception
 */
class UdiProcessException extends \RuntimeException {

}
