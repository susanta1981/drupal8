<?php

namespace Drupal\draco_udi\Exception;

/**
 * Class LastUpdatedDateNotFoundException.
 *
 * @package Drupal\draco_udi\Exception
 */
class LastUpdatedDateNotFoundException extends UdiProcessException {

}
