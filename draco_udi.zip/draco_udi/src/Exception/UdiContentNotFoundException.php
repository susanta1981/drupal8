<?php

namespace Drupal\draco_udi\Exception;

/**
 * Class UdiContentNotFoundException.
 *
 * @package Drupal\draco_udi\Exception
 */
class UdiContentNotFoundException extends \RuntimeException {

}
