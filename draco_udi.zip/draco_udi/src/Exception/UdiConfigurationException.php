<?php

namespace Drupal\draco_udi\Exception;

use Drupal\Core\Config\ConfigException;

/**
 * Class UdiConfigurationException.
 *
 * @package Drupal\draco_udi\Exception
 */
class UdiConfigurationException extends ConfigException {

}
