<?php

namespace Drupal\draco_udi\Mapper;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\draco_udi\Entity\ContentTitleInterface;

/**
 * Defines mapper interface.
 */
interface DracoMapperInterface extends ContainerFactoryPluginInterface {

  /**
   * Map an imported content title entity to a Node content type.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title_entity
   *    Source data item.
   * @param array $existing_mapped_content_entities
   *    Array of existing mapped entities.
   *
   * @return array
   *    Returns array of Entities
   */
  public function map(ContentTitleInterface $title_entity, array $existing_mapped_content_entities = NULL);

  /**
   * Return a list of source content data types supported by a mapper.
   *
   * @return array
   *    Valid string types.
   */
  public function getSupportedTypes();

}
