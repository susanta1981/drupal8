<?php

namespace Drupal\draco_udi\Mapper;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;

/**
 * Manager for Draco Data Mappers.
 */
class DracoDataMapperManager extends DefaultPluginManager {

  /**
   * Constructor.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin/Mapper', $namespaces, $module_handler, 'Drupal\draco_udi\Mapper\DracoMapperInterface', 'Drupal\draco_udi\Annotation\Mapper');

    $this->alterInfo('draco_data_mapper_info');
    $this->setCacheBackend($cache_backend, 'draco_data_mappers');
  }

  /**
   * Return mappers which id mataches the type of an draco entity, e.g., 'Episode'.
   *
   * @param $content_type
   *    Title type of an draco entity, e.g., 'Feature Film', 'Episode'
   *
   * @return array
   *    Array of mapper instances.
   */
  public function getMappers($content_type) {
    $definitions = $this->getDefinitions();
    $mappers = [];

    if (empty($definitions)) {
      return $mappers;
    }

    foreach ($definitions as $plugin_id => $definition) {
      $mapper = $this->createInstance($plugin_id);

      if ($this->validateMapper($content_type, $mapper) == TRUE) {
        $mappers[] = $mapper;
      }
    }

    return $mappers;
  }

  /**
   * Check if the mapper id matches the draco entity's title type.
   *
   * @param string $content_type
   *    Draco entity's title type.
   * @param \Drupal\draco_udi\Mapper\DracoMapperInterface $mapper
   *    Mapper plugin.
   *
   * @return bool True if valid, otherwise false.
   * True if valid, otherwise false.
   */
  protected function validateMapper($content_type, DracoMapperInterface $mapper) {
    return (in_array($content_type, $mapper->getSupportedTypes())) ? TRUE : FALSE;
  }

}
