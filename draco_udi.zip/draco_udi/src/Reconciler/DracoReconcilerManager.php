<?php

namespace Drupal\draco_udi\Reconciler;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;

/**
 * Manager for Draco Reconcilers.
 */
class DracoReconcilerManager extends DefaultPluginManager {

  /**
   * Constructor.
   *
   * @codeCoverageIgnore
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin/Reconciler', $namespaces, $module_handler, 'Drupal\draco_udi\Reconciler\DracoReconcilerInterface', 'Drupal\draco_udi\Annotation\ContentReconciler');

    $this->alterInfo('draco_reconciler_info');
    $this->setCacheBackend($cache_backend, 'draco_reconcilers');
  }

}
