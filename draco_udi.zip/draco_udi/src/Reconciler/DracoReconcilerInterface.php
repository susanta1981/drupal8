<?php

namespace Drupal\draco_udi\Reconciler;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\draco_udi\Context;

/**
 * Defines reconciler interface.
 */
interface DracoReconcilerInterface extends PluginInspectionInterface {

  /**
   * Reconcile ContentTitle entities and schedules.
   *
   * The reconciler is used to resolve confllicts between schedules and
   *  Titles.  The reconciler is responsible for making any needed changes
   *  to the ContextTitle entity and if it does change the  ContentTitle entity
   *  it should place that entity in the context in the
   *  RelatedData.entitiesToBeMapped array.
   *
   * @param Drupal\draco_udi\Context $context
   *    Draco UDI context object description is
   *      at http://docs.turner.com/display/SASDCMS/UDI+Context+States.
   */
  public function reconcile(Context $context);

}
