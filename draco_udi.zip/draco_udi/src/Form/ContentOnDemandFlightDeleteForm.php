<?php

namespace Drupal\draco_udi\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;
use Drupal\Core\Url;

/**
 * Provides a form for deleting Content on demand flight entities.
 *
 * @ingroup draco_udi
 */
class ContentOnDemandFlightDeleteForm extends ContentEntityDeleteForm {

  /**
   * {@inheritdoc}
   */
  protected function getRedirectUrl() {
    return new Url('entity.content_on_demand_flight.collection');
  }

}
