<?php

namespace Drupal\draco_udi\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Provides a form for deleting Content on demand schedule entities.
 *
 * @ingroup draco_udi
 */
class ContentOnDemandScheduleDeleteForm extends ContentEntityDeleteForm {

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    /** @var \Drupal\Core\Entity\ContentEntityInterface $entity */
    $entity = $this->getEntity();

    // Make sure that deleting a translation does not delete the whole entity.
    if (!$entity->isDefaultTranslation()) {
      $untranslated_entity = $entity->getUntranslated();
      $untranslated_entity->removeTranslation($entity->language()->getId());
      $untranslated_entity->save();
      $form_state->setRedirectUrl($untranslated_entity->urlInfo('canonical'));
    }
    else {
      $this->deleteFlights();
      $entity->delete();
      $form_state->setRedirectUrl($this->getRedirectUrl());
    }

    drupal_set_message($this->getDeletionMessage());
    $this->logDeletionMessage();
  }

  /**
   * Delete child flights of this on-demand schedule entity.
   */
  private function deleteFlights() {
    /** @var \Drupal\draco_udi\entity\ContentOnDemandScheduleInterface $schedule */
    $schedule = $this->getEntity();
    $flights = $schedule->getFlights();

    if (!empty($flights)) {
      /** @var \Drupal\draco_udi\entity\ContentOnDemandFlightInterface $flight */
      foreach ($flights as $flight) {
        $flight->delete();
      }
    }
  }

}
