<?php

namespace Drupal\draco_udi\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;
use Drupal\Core\Url;

/**
 * Provides a form for deleting Content Title entities.
 *
 * @ingroup draco_udi
 */
class ContentTitleDeleteForm extends ContentEntityDeleteForm {

}
