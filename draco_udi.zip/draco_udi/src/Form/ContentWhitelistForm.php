<?php

namespace Drupal\draco_udi\Form;

use Drupal\Core\Ajax\RemoveCommand;
use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Component\Utility\Html;
use Drupal\Core\Render\Element;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\draco_udi\Service\FilterBasedContentFetchManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class ContentWhitelistForm.
 *
 * @package Drupal\draco_udi\Form
 */
class ContentWhitelistForm extends EntityForm {

  /**
   * A flag to determine whether a delete field is clicked.
   *
   * @var bool
   */
  private $isDelete = FALSE;

  /**
   * Boolean indicating whether an add field is clicked.
   *
   * @var bool
   */
  private $isAdd = FALSE;

  /**
   * Content fetch manager.
   *
   * @var FilterBasedContentFetchManagerInterface
   */
  protected $contentFetchManager;

  /**
   * Query factory.
   *
   * @var \Drupal\Core\Entity\Query\QueryFactory
   */
  protected $queryFactory;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('current_route_match'),
      $container->get('draco_udi.filter.based.content.fetch.manager'),
      $container->get('entity.query')
    );
  }

  /**
   * ContentWhitelistForm constructor.
   *
   * @param \Drupal\Core\Routing\RouteMatchInterface $route_match
   *    The current route match.
   * @param \Drupal\draco_udi\Service\FilterBasedContentFetchManagerInterface $content_fetch_manager
   *    Content fetch manager.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   */
  public function __construct(
      RouteMatchInterface $route_match,
      FilterBasedContentFetchManagerInterface $content_fetch_manager,
      QueryFactory $query_factory
  ) {
    $this->routeMatch = $route_match;
    $this->contentFetchManager = $content_fetch_manager;
    $this->queryFactory = $query_factory;
  }

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);
    $wrapper_id = Html::getUniqueId('titleIds-list-wrapper');

    $whitelist = $this->entity;

    $form['label'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Whitelist name'),
      '#description' => $this->t('Unique name of a whitelist.'),
      '#maxlength' => 128,
      '#size' => 64,
      '#default_value' => $whitelist->label(),
      '#required' => TRUE,
    );

    $form['field_container']['id'] = array(
      '#type' => 'machine_name',
      '#description' => $this->t('A unique name, e.g., Series Whitelist, Feature Film Whitelist.'),
      '#default_value' => $whitelist->id(),
      '#machine_name' => array(
        'exists' => '\Drupal\draco_udi\Entity\ContentWhitelist::load',
      ),
      '#disabled' => !$whitelist->isNew(),
    );

    $form['contentType'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Title type'),
      '#description' => $this->t('Type defined by title contents in FLOW. It can be accessed by TitleType->Name in a FLOW title json file.'),
      '#maxlength' => 64,
      '#size' => 32,
      '#default_value' => $whitelist->getContentType(),
      '#required' => TRUE,
    );

    // List header.
    $form['empty_row_1'] = array(
      '#type' => 'item',
      '#title' => $this->t(' '),
    );

    /* Title id entry form */
    $form['titleIds'] = array(
      '#label' => 'Title IDs',
      '#tree' => TRUE,
      '#suffix' => '<div id="' . $wrapper_id . '"></div>',
    );

    $form['empty_row_2'] = array(
      '#type' => 'item',
      '#title' => $this->t(' '),
    );

    $form['add_field'] = array(
      '#type' => 'button',
      '#value' => t('Add content'),
      '#name' => 'add_field',
      '#prefix' => '<div id="add-field">',
      '#suffix' => '</div>',
      '#ajax' => array(
        'callback' => '::addField',
        'wrapper' => $wrapper_id,
        'method' => 'before',
        'effect' => 'fade',
      ),
      '#limit_validation_errors' => array(),
    );

    $form['empty_row_3'] = array(
      '#type' => 'item',
      '#title' => $this->t(' '),
    );

    $title_ids = $whitelist->getTitleIds();

    // Unset field if the delete button has been triggered.
    $triggering_element = $form_state->getTriggeringElement();
    if (strpos($triggering_element['#name'], 'delete_field_') === 0) {
      unset($title_ids[$triggering_element['#parents'][1]]);
      $this->isDelete = TRUE;
    }

    if (is_array($title_ids)) {
      foreach ($title_ids as $index => $title_id) {
        $form['titleIds'][$index] = $this->getTitleIdForm($index, $title_id);
      }
    }

    if (!$this->isDelete) {
      $this->isAdd = preg_match("/add_form/", $this->routeMatch->getRouteName());
    }

    $is_add_field = (!empty($triggering_element) && $triggering_element['#name'] == 'add_field');

    // If we added a position add it to the end of the form.
    if ($is_add_field || $this->isAdd) {
      $form['titleIds'][] = $this->getTitleIdForm(count($title_ids));
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $content_whitelist = $this->entity;
    $content_type = $content_whitelist->getContentType();

    if ($content_whitelist->isNew() && $this->whitelistExists($content_type)) {
      drupal_set_message($this->t('A whitelist for content type %type already exists.',
        ['%type' => $content_type]), 'error');
      return;
    }

    $status = $content_whitelist->save();

    // Fetch title objects from Flow.
    $title_id_objects = $content_whitelist->getTitleIds();
    $ids = [];

    if (!empty($title_id_objects)) {
      foreach ($title_id_objects as $title) {
        $ids[] = $title['id'];
      }

      $this->contentFetchManager->fetchTitlesByIds($ids, [$content_type]);
    }

    switch ($status) {
      case SAVED_NEW:
        drupal_set_message($this->t('Created the %label Content whitelist.', [
          '%label' => $content_whitelist->label(),
        ]));
        break;

      default:
        drupal_set_message($this->t('Saved the %label Content whitelist.', [
          '%label' => $content_whitelist->label(),
        ]));
    }
    $form_state->setRedirectUrl($content_whitelist->urlInfo('collection'));
  }

  /**
   * Try to find if a whitelist of the checked type exists.
   *
   * @param string $content_type
   *
   * @return bool
   *    TRUE if corresponding whitelist found, or otherwise FALSE.
   */
  private function whitelistExists($content_type) {
    $count = $this->queryFactory->get("content_whitelist")
      ->condition('contentType', $content_type)->count()
      ->execute();

    return ($count == 1) ? TRUE : FALSE;
  }

  /**
   * Callback to create a form for entering a content's name and title id.
   *
   * @param int $index
   *   The index of the title id in the whitelist.
   * @param array $title_ids
   *   Array of title ids.
   *
   * @return array
   *   Position form element.
   */
  protected function getTitleIdForm($index, $title_ids = array()) {
    $wrapper_id = "titleIds-titleId-$index";

    $title_id_form = array(
      'name' => [
        '#type' => 'textfield',
        '#title' => $this->t('Content name'),
        '#default_value' => isset($title_ids['name']) ? $title_ids['name'] : '',
        '#required' => TRUE,
        '#size' => 64,
        '#prefix' => '<td>',
        '#suffix' => '</td>',
      ],
      'id' => [
        '#type' => 'textfield',
        '#title' => $this->t('Title id'),
        '#default_value' => isset($title_ids['id']) ? $title_ids['id'] : '',
        '#required' => TRUE,
        '#size' => 16,
        '#prefix' => '<td>',
        '#suffix' => '</td>',
      ],
      'delete' => [
        '#type' => 'button',
        '#name' => 'delete_field_' . $index,
        '#value' => $this->t('Delete'),
        '#ajax' => array(
          'callback' => '::deleteField',
          'effect' => 'fade',
        ),
        '#limit_validation_errors' => array(),
        '#wrapper_id' => $wrapper_id,
        '#prefix' => '<td>',
        '#suffix' => '</td>',
      ],

      '#tree' => TRUE,
      '#prefix' => '<table id="' . $wrapper_id . '"><tr>',
      '#suffix' => '</tr></table>',
      '#wrapper_id' => $wrapper_id,
    );

    return $title_id_form;
  }

  /**
   * Callback to delete a title id from whitelist.
   *
   * @param array $form
   *   The built form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return \Drupal\Core\Ajax\AjaxResponse
   *   The response to the callback.
   */
  public function deleteField(array $form, FormStateInterface $form_state) {
    $triggering_element = $form_state->getTriggeringElement();
    $wrapper_id = $triggering_element['#wrapper_id'];
    $response = new AjaxResponse();
    $response->addCommand(new RemoveCommand("#$wrapper_id", ''));
    return $response;
  }

  /**
   * Callback to return the form elements to insert.
   *
   * @param array $form
   *   The built form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   A render element.
   */
  public function addField(array $form, FormStateInterface $form_state) {
    $last_title_id = end(Element::children($form['titleIds']));
    return $form['titleIds'][$last_title_id];
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $values = $form_state->getValues();

    if (empty($values) || empty($values['titleIds'])) {
      return;
    }

    $title_ids = $values['titleIds'];
    $title_ids_validated = [];

    foreach ($title_ids as $index => $title_id) {
      $field_name = 'titleIds][' . $index . '][id';

      if (in_array($title_id['id'], $title_ids_validated)) {
        $form_state->setErrorByName($field_name, $this->t('The title id %title_id already exists.', ['%title_id' => $title_id['id']]));
      }

      $title_ids_validated[] = $title_id['id'];

      if ($this->validateTitleId($title_id['id']) === FALSE) {
        $form_state->setErrorByName($field_name, $this->t('The title id %title_id must be an integer.', ['%title_id' => $title_id['id']]));
      }
    }
  }

  /**
   * Validate the title id field.
   *
   * The value must be a string integer.
   *
   * @param string $value
   *   Title id.
   *
   * @return bool
   *   Returns TRUE if the format is correct. FALSE otherwise.
   */
  protected function validateTitleId($value) {
    return ctype_digit($value);
  }

}
