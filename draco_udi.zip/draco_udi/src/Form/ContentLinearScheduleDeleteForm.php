<?php

namespace Drupal\draco_udi\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;
use Drupal\Core\Url;

/**
 * Provides a form for deleting Content Linear Schedule entities.
 *
 * @ingroup draco_udi
 */
class ContentLinearScheduleDeleteForm extends ContentEntityDeleteForm {

}
