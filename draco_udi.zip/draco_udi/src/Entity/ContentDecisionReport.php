<?php

namespace Drupal\draco_udi\Entity;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Entity\ContentEntityBase;

/**
 * Defines the DecisionReport entity.
 *
 * Used in the sample Post Processor Plugin provided by Draco.  This is the entity
 * that is stored in the database.  Can
 * later be used to display some type of data change report.
 *
 * @ingroup draco_udi
 *
 * @ContentEntityType(
 *   id = "content_decision_report",
 *   label = @Translation("Content Decision Report"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\Core\Entity\EntityListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *
 *     "form" = {
 *       "default" = "Drupal\Core\Entity\ContentEntityForm",
 *       "add" = "Drupal\Core\Entity\ContentEntityForm",
 *       "edit" = "Drupal\Core\Entity\ContentEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityForm",
 *     },
 *     "access" = "Drupal\Core\Entity\EntityAccessControlHandler",
 *   },
 *   base_table = "content_decision_report",
 *   admin_permission = "administer DecisionReport entity",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   links = {
 *     "canonical" = "/content_decision_report/{contentdecisionreport}",
 *     "edit-form" = "/content_decision_report/{contentdecisionreport}/edit",
 *     "delete-form" = "/content_decision_report/{contentdecisionreport}/delete",
 *   }
 * )
 */
class ContentDecisionReport extends ContentEntityBase {

  use StringTranslationTrait;

  /**
   * Get Mapped Entities.
   *
   * @return array
   *   The list of Mapped entities.
   */
  public function getMappedEntities() {
    return $this->get('mappedEntities')->value;
  }

  /**
   * Set Mapped Entities.
   *
   * @param array $mapped_entities
   *   The mapped Entities.
   *
   * @return ContentDecisionReport
   *   This Decision Report.
   */
  public function setMappedEntities($mapped_entities) {
    $this->set('mappedEntities', $mapped_entities);
    return $this;
  }

  /**
   * Get Approval Message.
   *
   * @return string[]
   *   The Approval Message
   */
  public function getApprovalMessages() {
    return $this->get('approvalMessages')->value;
  }

  /**
   * Set Approval Messages.
   *
   * @param array $approval_message
   *   The Approval Messages.
   *
   * @return ContentDecisionReport
   *   This Decision Report.
   */
  public function setApprovalMessages(array $approval_message) {
    $this->set('approvalMessages', $approval_message);
    return $this;
  }

  /**
   * Get Source Entity.
   *
   * @return ContentEntityInterface
   *   The Source Entity.
   */
  public function getSourceEntity() {
    return $this->get('sourceEntity')->value;
  }

  /**
   * Set Source Entity.
   *
   * @param string $source_entity
   *   The Source Entity.
   *
   * @return ContentDecisionReport
   *   This Decision Report.
   */
  public function setSourceEntity($source_entity) {
    $this->set('sourceEntity', $source_entity);
    return $this;
  }

  /**
   * Get Status.
   *
   * @return status
   *   The Status.
   */
  public function getStatus() {
    return $this->get('status')->value;
  }

  /**
   * Set Status.
   *
   * @param string $status
   *   The Status.
   *
   * @return ContentDecisionReport
   *   This Decision Report.
   */
  public function setStatus($status) {
    $this->set('status', $status);
    return $this;
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function preDelete(EntityStorageInterface $storage, array $entities) {
    parent::preDelete($storage, $entities);

    // Ensure that all entities deleted are removed from the search index.
    if (\Drupal::moduleHandler()->moduleExists('search')) {
      foreach ($entities as $entity) {
        search_index_clear('content_decision_report_search', $entity->id->value);
      }
    }
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields['id'] = BaseFieldDefinition::create('integer')
            ->setLabel(t('ID'))
            ->setReadOnly(TRUE);

    $fields['uuid'] = BaseFieldDefinition::create('uuid')
            ->setLabel(t('Catalog Item ID'))
            ->setReadOnly(TRUE)
            ->setRequired(TRUE)
            ->setDisplayOptions('view', array(
              'label' => 'inline',
              'type' => 'string',
              'weight' => -100,
            ));
    $fields['approvalMessages'] = BaseFieldDefinition::create('string_long')
            ->setLabel(t('Approval Messages'))
            ->setTranslatable(TRUE)
            ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
            ->setDisplayOptions('view', array(
              'label' => 'hidden',
              'type' => 'string',
              'weight' => -18,
            ))
            ->setDisplayOptions('form', array(
              'type' => 'string_textarea',
              'weight' => -18,
              'settings' => array(
                'rows' => 2,
              ),
            ));
    $fields['mappedEntities'] = BaseFieldDefinition::create('entity_reference')
            ->setLabel(t('Mapped Entities'))
            ->setDescription(t('Entities that were created from this change'))
            ->setCardinality(FieldStorageDefinitionInterface::CARDINALITY_UNLIMITED)
            ->setReadOnly(TRUE);

    $fields['sourceEntity'] = BaseFieldDefinition::create('entity_reference')
            ->setLabel(t('Source Entity'))
            ->setDescription(t('The entity downloaded from Source System (ODT,etc) .'))
            ->setReadOnly(TRUE);

    $fields['status'] = BaseFieldDefinition::create('string')
            ->setLabel(t('Status'))
            ->setReadOnly(TRUE)
            ->setDisplayOptions('view', array(
              'label' => 'hidden',
              'type' => 'string',
              'weight' => -12,
            ))
            ->setDisplayOptions('form', array(
              'type' => 'string_textfield',
              'weight' => -12,
            ));

    return $fields;
  }

}
