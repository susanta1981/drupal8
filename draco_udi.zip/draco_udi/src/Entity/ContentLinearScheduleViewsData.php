<?php

namespace Drupal\draco_udi\Entity;

use Drupal\views\EntityViewsData;
use Drupal\views\EntityViewsDataInterface;

/**
 * Provides Views data for Content Linear Schedule entities.
 */
class ContentLinearScheduleViewsData extends EntityViewsData implements EntityViewsDataInterface {

  /**
   * {@inheritdoc}
   */
  public function getViewsData() {
    $data = parent::getViewsData();

    $data['content_linear_schedule']['table']['base'] = array(
      'field' => 'id',
      'title' => $this->t('Content Linear Schedule'),
      'help' => $this->t('The Content Linear Schedule ID.'),
    );

    return $data;
  }

}
