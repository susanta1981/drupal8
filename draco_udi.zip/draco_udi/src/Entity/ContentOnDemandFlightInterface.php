<?php

namespace Drupal\draco_udi\Entity;

/**
 * Provides an interface for defining Content on demand flight entities.
 *
 * @ingroup draco_udi
 */
interface ContentOnDemandFlightInterface extends DracoContentInterface {

  /**
   * Return airing id.
   *
   * @return string
   *    Airing id.
   */
  public function getAiringId();

  /**
   * Set airing id that is unique in ODT.
   *
   * @param string $id
   *    Airing id
   *
   * @return \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface
   *   The called entity.
   */
  public function setAiringId($id);

  /**
   * Get start date.
   *
   * @return \Datetime
   *    The start date
   */
  public function getStart();

  /**
   * Set start datetime.
   *
   * @param \DateTime $datetime
   *    Start datetime.
   *
   * @return \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface
   *   The called entity.
   */
  public function setStart(\DateTime $datetime);

  /**
   * Get end datetime.
   *
   * @return Datetime
   *    The end datetime.
   */
  public function getEnd();

  /**
   * Set end datep.
   *
   * @param \DateTime $datetime
   *    End date.
   *
   * @return \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface
   *   The called entity.
   */
  public function setEnd(\DateTime $datetime);

  /**
   * Get array of destinations data objects.
   *
   * @return array
   *    Array of stdClass objects.
   */
  public function getDestinations();

  /**
   * Set array of destinations data objects.
   *
   * @param array $destinations
   *    An array of stdClass objects.
   *
   * @return \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface
   *   The called entity.
   */
  public function setDestinations($destinations);

}
