<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Interface ContentWhitelistInterface.
 *
 * @package Drupal\draco_udi
 */
interface ContentWhitelistInterface extends ConfigEntityInterface {

  /**
   * Get title ids.
   *
   * @return array
   *   Title ids.
   */
  public function getTitleIds();

  /**
   * Return content type.
   *
   * Set this value as a key that identifies types of the content objects keyed
   * by the title ids entered in this list. For example, set the type to
   * 'Series' means all title ids entered in this list are title ids of series
   * objects.
   *
   * @return string
   */
  public function getContentType();

}
