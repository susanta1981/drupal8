<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;

/**
 * Interface DracoContentInterface.
 *
 * Define getters/setters for common Draco entity properties.
 *
 * @package Drupal\draco_udi
 */
interface DracoContentInterface extends ContentEntityInterface, EntityChangedInterface {

  /**
   * Get name of source data item.
   *
   * @return string
   *    label of the entity that maps to the label field of the base class.
   */
  public function getName();

  /**
   * Set content name, which will be mapped to the title field of ContentEntityBase.
   *
   * @param $name
   *    Content name or title name.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *   The called entity.
   */
  public function setName($name);

  /**
   * Gets creation/import timestamp.
   *
   * @return int
   *   Import timestamp.
   */
  public function getImportedTime();

  /**
   * Sets creation timestamp, which is the time the entity is created at importing time.
   *
   * @param int $timestamp
   *   The UDI entity creation timestamp.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *   The called entity.
   */
  public function setImportedTime($timestamp);

  /**
   * Returns the entity published status indicator.
   *
   * Unpublished entities are only visible to restricted users.
   *
   * @return bool
   *   TRUE if the Content Linear Schedule is published.
   */
  public function isPublished();

  /**
   * Sets the published status.
   *
   * @param bool $published
   *   TRUE to set entity to published, FALSE to set it to unpublished.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *   The called entity.
   */
  public function setPublished($published);

  /**
   * Get titleId of content.
   *
   * @return int titleId
   *    The titleId value.
   */
  public function getTitleId();

  /**
   * Set titleId.
   *
   * @param int $id
   *    The content titleId.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *    The called content entity.
   */
  public function setTitleId($id);

  /**
   * Get entire content as json object.
   *
   * @return \stdClass
   *    Json content object.
   */
  public function getContentJson();

  /**
   * Set the entire content json object.
   *
   * @param \stdClass $content_json
   *    The content json object.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *    The called content entity.
   */
  public function setContentJson($content_json);

}
