<?php

namespace Drupal\draco_udi\Entity;


use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;

/**
 * Defines the Content Title entity.
 *
 * @ingroup draco_udi
 *
 * @ContentEntityType(
 *   id = "content_title",
 *   label = @Translation("Content title"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "views_data" = "Drupal\draco_udi\Entity\ContentTitleViewsData",
 *     "form" = {
 *       "default" = "Drupal\draco_udi\Form\ContentTitleForm",
 *       "edit" = "Drupal\draco_udi\Form\ContentTitleForm",
 *       "delete" = "Drupal\draco_udi\Form\ContentTitleDeleteForm",
 *     },
 *     "access" = "Drupal\draco_udi\ContentTitleAccessControlHandler",
 *   },
 *   base_table = "content_title",
 *   admin_permission = "administer content_title entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *     "langcode" = "langcode",
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/udi/content_title/{content_title}",
 *     "edit-form" = "/admin/structure/udi/content_title/{content_title}/edit",
 *     "delete-form" = "/admin/structure/udi/content_title/{content_title}/delete"
 *   },
 *   field_ui_base_route = "content_title.settings"
 * )
 */
class ContentTitle extends DracoContentBase implements ContentTitleInterface {
  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public function getSortableTitleName() {
    return $this->get('sortable_title_name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSortableTitleName($name) {
    $this->set('sortable_title_name', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getTitleType() {
    return $this->get('title_type')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setTitleType($type) {
    $this->set('title_type', $type);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getLengthInSeconds() {
    return $this->get('length_in_seconds')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setLengthInSeconds($length) {
    $this->set('length_in_seconds', $length);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getReleaseYear() {
    return $this->get('release_year')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setReleaseYear($year) {
    $this->set('release_year', $year);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getProcessedDatetimeUTC() {
    if ($this->get('processed_datetime') != NULL) {
      $date_value = $this->get('processed_datetime')->value;
      $time_zone = new \DateTimeZone('UTC');
      return new \DateTime($date_value, $time_zone);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function setProcessedDatetimeUTC(\DateTime $datetime) {
    $db_value = $datetime->format('Y-m-d\TH:i:s');
    $this->set('processed_datetime', $db_value);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getAnimationMode() {
    return $this->get('animation_mode')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setAnimationMode($mode) {
    $this->set('animation_mode', $mode);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getPerformanceMode() {
    if ($this->get('performance_mode') != NULL) {
      return json_decode($this->get('performance_mode')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setPerformanceMode($mode) {
    $this->set('performance_mode', json_encode($mode));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getExternalStoryline() {
    return $this->get('external_storyline')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setExternalStoryline($story_line) {
    $this->set('external_storyline', $story_line);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getShortStoryline() {
    return $this->get('short_storyline')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setShortStoryline($story_line) {
    $this->set('short_storyline', $story_line);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getStorylines() {
    if ($this->get('storylines') != NULL) {
      return json_decode($this->get('storylines')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setStorylines($story_lines) {
    $this->set('storylines', json_encode($story_lines));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getGenres() {
    if ($this->get('genres') != NULL) {
      return json_decode($this->get('genres')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setGenres($genres) {
    $this->set('genres', json_encode($genres));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getKeyGenres() {
    if ($this->get('key_genres') != NULL) {
      return json_decode($this->get('key_genres')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setKeyGenres($key_genres) {
    $this->set('key_genres', json_encode($key_genres));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getTags() {
    if ($this->get('tags') != NULL) {
      return json_decode($this->get('tags')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setTags($tags) {
    $this->set('tags', json_encode($tags));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getKeywords() {
    if ($this->get('keywords') != NULL) {
      return json_decode($this->get('keywords')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setKeywords($keywords) {
    $this->set('keywords', json_encode($keywords));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getRatings() {
    if ($this->get('ratings') != NULL) {
      return json_decode($this->get('ratings')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setRatings($ratings) {
    $this->set('ratings', json_encode($ratings));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getParticipants() {
    if ($this->get('participants') != NULL) {
      return json_decode($this->get('participants')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setParticipants($value) {
    $this->set('participants', json_encode($value));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeriesTitleId() {
    return $this->get('series_title_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSeriesTitleId($series_title_id) {
    $this->set('series_title_id', $series_title_id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeriesTitleName() {
    return $this->get('series_title_name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSeriesTitleName($name) {
    $this->set('series_title_name', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSortableSeriesTitleName() {
    return $this->get('sortable_series_title_name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSortableSeriesTitleName($name) {
    $this->set('sortable_series_title_name', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeriesItemNumber() {
    return $this->get('series_item_number')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSeriesItemNumber($item_number) {
    $this->set('series_item_number', $item_number);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getExternalSeriesItemNumber() {
    return $this->get('external_series_item_number')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setExternalSeriesItemNumber($item_number) {
    $this->set('external_series_item_number', $item_number);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeasonNumber() {
    return $this->get('season_number')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSeasonNumber($season) {
    $this->set('season_number', $season);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeasonName() {
    return $this->get('season_name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSeasonName($season_name) {
    $this->set('season_name', $season_name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeasonEpisodeNumber() {
    return $this->get('season_episode_number')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSeasonEpisodeNumber($episode_number) {
    $this->set('season_episode_number', $episode_number);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeasons() {
    if ($this->get('seasons') != NULL) {
      return json_decode($this->get('seasons')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setSeasons($seasons) {
    $this->set('seasons', json_encode($seasons));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSeriesItems() {
    if ($this->get('series_items') != NULL) {
      return json_decode($this->get('series_items')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setSeriesItems($series_items) {
    $this->set('series_items', json_encode($series_items));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getMappedContents() {
    $content = array();

    foreach ($this->get('mapped_content') as $mc) {
      if ($mc->entity) {
        $content[] = $mc->entity;
      }
    }

    return $content;
  }

  /**
   * {@inheritdoc}
   */
  public function getMappedContentIds() {
    $content = array();

    foreach ($this->get('mapped_content') as $mc) {
      if ($mc->target_id) {
        $content[] = $mc->target_id;
      }
    }

    return $content;
  }

  /**
   * {@inheritdoc}
   */
  public function addMappedContent($id) {
    $content = $this->getMappedContentIds();
    $content[] = $id;
    $this->set('mapped_content', array_unique($content));
  }

  /**
   * {@inheritdoc}
   */
  public function removeMappedContent($id) {
    $this->set('mapped_content', array_diff($this->getMappedContentIds(), array($id)));
  }

  /**
   * {@inheritdoc}
   */
  public function clearMappedContent() {
    $this->set('mapped_content', array());
  }

  /**
   * {@inheritdoc}
   */
  public function getLanguageName() {
   return (isset($this->getContentJson()->Language->Name))? $this->getContentJson()->Language->Name : NULL;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of Content title entity.'))
      ->setReadOnly(TRUE)
      ->setSetting('unsigned', TRUE);

    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Content title entity.'))
      ->setReadOnly(TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Publishing status'))
      ->setDescription(t('A boolean indicating whether the content entity is published.'))
      ->setDefaultValue(FALSE)
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['imported'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Imported time'))
      ->setDescription(t('The time this title content data was imported from Flow.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -101,
      ));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Last updated'))
      ->setDescription(t('The time this title content data was last updated.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -100,
      ));

    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setLabel(t('Language code'))
      ->setDescription(t('The language code for the Content title entity.'));

    $fields['label'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Name of Content Linear Schedule entity'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -110,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -110,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['title_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Title Id'))
      ->setDescription(t('The title id of associated content title object mapped from upstream source.'))
      ->setReadOnly(TRUE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -108,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -108,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['sortable_title_name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Sortable title name'))
      ->setDescription(t('A title name for sorting purpose.'));

    $fields['title_type'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Title type'))
      ->setDescription(t('Title type, e.g., Episode, Feature Film, Series, etc.'))
      ->setReadOnly(TRUE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -107,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -107,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['length_in_seconds'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Length in seconds'))
      ->setDescription(t('Length of the content in seconds.'))
      ->setReadOnly(FALSE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -96,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -96,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['release_year'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Release year'))
      ->setDescription(t('The year the content is released.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -95,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['processed_datetime'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Processed Datetime'))
      ->setReadOnly(FALSE)
      ->setDescription(t('Content last updated timestamp in UTC format.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'datetime_default',
        'weight' => -94,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['animation_mode'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Animation mode'))
      ->setDescription(t('Animation mode, either Animated or Mon-Animated.'))
      ->setReadOnly(TRUE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -93,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -93,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['performance_mode'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Production mode'))
      ->setDescription(t('Json object containing production mode info.'))
      ->setDisplayConfigurable('view', TRUE);

    $fields['external_storyline'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('External storyline'))
      ->setReadOnly(FALSE)
      ->setDescription(t('Content external storyline.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -90,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -90,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['short_storyline'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Short storyline'))
      ->setReadOnly(FALSE)
      ->setDescription(t('Content short storyline.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -88,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -88,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['storylines'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Storylines'))
      ->setReadOnly(FALSE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -86,
      ))
      ->setDescription(t('Json object containing all storylines.'));

    $fields['genres'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('genres'))
      ->setDescription(t('Array of json objects containing genres info.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -85,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['key_genres'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Key genres'))
      ->setDescription(t('Array of json objects containing key genres info.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -84,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['tags'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Tags'))
      ->setDescription(t('Array of tags'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -83,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['keywords'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Keywords'))
      ->setDescription(t('Array of keywords'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -82,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['ratings'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Ratings'))
      ->setDescription(t('Array of json objects containing rating info per network.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -81,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['participants'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Participants'))
      ->setDescription(t('Array of json objects containing participants info.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -80,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['series_title_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Series title id'))
      ->setDescription(t('Series title id'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -70,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['series_title_name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Series title name'))
      ->setDescription(t('Series title name'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -69,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['sortable_series_title_name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Sortable series title name'))
      ->setDescription(t('Series title name for sorting purpose.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -68,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['series_item_number'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Series item number'))
      ->setDescription(t('Series item number.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -67,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['external_series_item_number'] = BaseFieldDefinition::create('string')
      ->setLabel(t('External series item number'))
      ->setDescription(t('External series item number.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -66,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['season_number'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Season number'))
      ->setDescription(t('Season number.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -65,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['season_name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Season name'))
      ->setDescription(t('Season name.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -64,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['season_episode_number'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Season episode number'))
      ->setDescription(t('Season episode number.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -63,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['seasons'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Seasons'))
      ->setDescription(t('Array of season numbers.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -50,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['series_items'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('series items'))
      ->setDescription(t('Array of json objects containing some episode data.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -40,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['content_json'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Complete content'))
      ->setDescription(t('The entire Flow title content json object.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -30,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['mapped_content'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('mapped content'))
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDescription(t('List of site mapped content'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'entity_reference_label',
        'weight' => -20,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -20,
      ))
      ->setDisplayConfigurable('form', TRUE);

    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function getRatingCodeAndDescriptorsByNetwork($network_code) {
    $rating_json = NULL;

    if (!empty($this->getRatings())) {
      foreach ($this->getRatings() as $rating) {
        if (!empty($rating->RatingDescriptors)) {
          foreach ($rating->RatingDescriptors as $desc) {
            if (isset($desc->NetworkCode) && $desc->NetworkCode == $network_code) {
              $rating_json = new \stdClass();
              $rating_json->rating = $desc->Rating;
              $rating_json->descriptors = $desc->Descriptors;
              break;
            }
          }
        }
      }

      return $rating_json;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function getStringKeywords() {
    $keywords = $this->getKeywords();

    if (empty($keywords)) {
      return NULL;
    }

    return $this->parseItemNames($keywords);
  }

  /**
   * {@inheritdoc}
   */
  public function getStringGenres() {
    $genres = $this->getGenres();

    if (empty($genres)) {
      return NULL;
    }

    return $this->parseItemNames($genres);
  }

  /**
   * {@inheritdoc}
   */
  public function getStringKeyGenres() {
    $key_genres = $this->getKeyGenres();

    if (empty($key_genres)) {
      return NULL;
    }

    return $this->parseItemNames($key_genres);
  }

  /**
   *
   */
  private function parseItemNames(array $items) {
    $names = [];

    foreach ($items as $item) {
      if ($item && isset($item->Name)) {
        $names[] = $item->Name;
      }
    }

    return $names;
  }

}
