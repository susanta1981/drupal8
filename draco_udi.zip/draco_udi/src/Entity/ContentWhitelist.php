<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;

/**
 * Defines the Content whitelist entity.
 *
 * The entity holds a list of title ids that are used as filter for importing
 * contents.
 *
 * @ConfigEntityType(
 *   id = "content_whitelist",
 *   label = @Translation("Content whitelist"),
 *   handlers = {
 *     "list_builder" = "Drupal\draco_udi\ContentWhitelistListBuilder",
 *     "form" = {
 *       "add" = "Drupal\draco_udi\Form\ContentWhitelistForm",
 *       "edit" = "Drupal\draco_udi\Form\ContentWhitelistForm",
 *       "delete" = "Drupal\draco_udi\Form\ContentWhitelistDeleteForm"
 *     }
 *   },
 *   config_prefix = "content_whitelist",
 *   admin_permission = "administer site configuration",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/udi/content_whitelist/{content_whitelist}",
 *     "edit-form" = "/admin/structure/udi/content_whitelist/{content_whitelist}/edit",
 *     "delete-form" = "/admin/structure/udi/content_whitelist/{content_whitelist}/delete",
 *     "collection" = "/admin/structure/udi/visibility_group"
 *   }
 * )
 */
class ContentWhitelist extends ConfigEntityBase implements ContentWhitelistInterface {

  /**
   * The Content whitelist ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The Content whitelist label.
   *
   * @var string
   */
  protected $label;

  /**
   * An array of content title ids.
   *
   * @var array
   */
  protected $titleIds;

  /**
   * Type of content, e.g., 'Series', 'Feature Film'.
   *
   * @var
   */
  protected $contentType;

  /**
   * {@inheritdoc}
   */
  public function getTitleIds() {
    return $this->titleIds;
  }

  /**
   * {@inheritdoc}
   */
  public function getContentType() {
    return $this->contentType;
  }

}
