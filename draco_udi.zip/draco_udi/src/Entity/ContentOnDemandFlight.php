<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;

/**
 * Defines the Content on demand flight entity.
 *
 * @ingroup draco_udi
 *
 * @ContentEntityType(
 *   id = "content_on_demand_flight",
 *   label = @Translation("Content on demand flight"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\draco_udi\ContentOnDemandFlightListBuilder",
 *     "views_data" = "Drupal\draco_udi\Entity\ContentOnDemandFlightViewsData",
 *     "form" = {
 *       "default" = "Drupal\draco_udi\Form\ContentOnDemandFlightForm",
 *       "edit" = "Drupal\draco_udi\Form\ContentOnDemandFlightForm",
 *       "delete" = "Drupal\draco_udi\Form\ContentOnDemandFlightDeleteForm",
 *     },
 *     "access" = "Drupal\draco_udi\ContentOnDemandFlightAccessControlHandler",
 *   },
 *   base_table = "content_on_demand_flight",
 *   admin_permission = "administer content_on_demand_flight entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "langcode" = "langcode",
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/udi/content_on_demand_flight/{content_on_demand_flight}",
 *     "edit-form" = "/admin/structure/udi/content_on_demand_flight/{content_on_demand_flight}/edit",
 *     "delete-form" = "/admin/structure/udi/content_on_demand_flight/{content_on_demand_flight}/delete"
 *   },
 *   field_ui_base_route = "content_on_demand_flight.settings"
 * )
 */
class ContentOnDemandFlight extends DracoContentBase implements ContentOnDemandFlightInterface {
  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public function getAiringId() {
    return $this->get('airing_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setAiringId($id) {
    $this->set('airing_id', $id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getStart() {
    if ($this->get('start') != NULL) {
      $date_value = $this->get('start')->value;
      $time_zone = new \DateTimeZone('UTC');
      return new \DateTime($date_value, $time_zone);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function setStart(\DateTime $datetime) {
    $db_value = $datetime->format('Y-m-d\TH:i:s');
    $this->set('start', $db_value);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getEnd() {
    if ($this->get('end') != NULL) {
      $date_value = $this->get('end')->value;
      $time_zone = new \DateTimeZone('UTC');
      return new \DateTime($date_value, $time_zone);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function setEnd(\DateTime $datetime) {
    $db_value = $datetime->format('Y-m-d\TH:i:s');
    $this->set('end', $db_value);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getDestinations() {
    if ($this->get('destinations') != NULL) {
      return json_decode($this->get('destinations')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setDestinations($destinations) {
    $this->set('destinations', json_encode($destinations));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of the Content on demand flight entity.'))
      ->setReadOnly(TRUE);
    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Content on demand flight entity.'))
      ->setReadOnly(TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Publishing status'))
      ->setDescription(t('A boolean indicating whether the Content on demand flight is published.'))
      ->setDefaultValue(FALSE);

    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setLabel(t('Language code'))
      ->setDescription(t('The language code for the Content on demand flight entity.'));

    $fields['imported'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Imported time'))
      ->setDescription(t('The time that the entity was created (imported from upstream).'));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the entity was last edited.'));

    $fields['airing_id'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Airing Id'))
      ->setDescription(t('The airing id of the associated on-demand schedule entity.'))
      ->setReadOnly(TRUE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -20,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -20,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['start'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Start'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Flight start time.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'datetime_default',
        'weight' => -15,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['end'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('End'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Flight end time.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'datetime_default',
        'weight' => -10,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['destinations'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Destinations'))
      ->setReadOnly(FALSE)
      ->setDescription(t('Array of destination data.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -5,
      ))
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
