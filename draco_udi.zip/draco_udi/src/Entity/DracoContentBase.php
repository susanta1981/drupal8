<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;

/**
 * Denotes that the content is not published.
 */
const CONTENT_NOT_PUBLISHED = 0;

/**
 * Denotes that the content is published.
 */
const CONTENT_PUBLISHED = 1;

/**
 * Class DracoContentBase.
 *
 * @package Drupal\draco_udi\Entity
 */
abstract class DracoContentBase extends ContentEntityBase implements DracoContentInterface {

  use EntityChangedTrait;

  /**
   * This variable is a copy from the Node class for preview preformance reason.
   *
   * See https://www.drupal.org/node/2498919.
   *
   * @var true|null
   *   TRUE if the content entity is being previewed and NULL if it is not.
   */
  public $in_preview = NULL;

  /**
   * {@inheritdoc}
   */
  public function isPublished() {
    return (bool) $this->getEntityKey('status');
  }

  /**
   * {@inheritdoc}
   */
  public function setPublished($published) {
    $this->set('status', $published ? NODE_PUBLISHED : NODE_NOT_PUBLISHED);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->get('label')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setName($name) {
    $this->set('label', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getTitleId() {
    return $this->get('title_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setTitleId($id) {
    $this->set('title_id', $id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getImportedTime() {
    return $this->get('imported')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setImportedTime($timestamp) {
    $this->set('imported', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getChangedTime() {
    return $this->get('changed')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setChangedTime($timestamp) {
    $this->set('changed', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getContentJson() {
    if (!empty($this->get('content_json'))) {
      return json_decode($this->get('content_json')->value);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function setContentJson($content_json) {
    if (!empty($content_json)) {
      $this->set('content_json', json_encode($content_json));
    }
    return $this;
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    return array();
  }

}
