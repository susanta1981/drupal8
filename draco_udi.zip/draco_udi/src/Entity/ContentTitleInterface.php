<?php


namespace Drupal\draco_udi\Entity;


/**
 * Provides an interface for defining Content Title entities.
 *
 * @ingroup draco_udi
 */
interface ContentTitleInterface extends DracoContentInterface {

  /**
   * Get Title's sortable name that is the same as titleName  'name' field.
   *
   * @return string
   *    Sortable title name.
   */
  public function getSortableTitleName();

  /**
   * Set Title's sortable name.
   *
   * @param string $name
   *    Title sortable name.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSortableTitleName($name);

  /**
   * Get type that maps to TitleType->name.
   *
   *     "TitleType": {
   *          "Name": "Episode",
   *          "TitleTypeId": 6,
   *          "TitleTypeCode": "EA"
   *      }
   *
   * @return string
   *    Title type.
   */
  public function getTitleType();

  /**
   * Set type.
   *
   * @param string $type
   *    Title type.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setTitleType($type);

  /**
   * Get length the content plays in seconds.
   *
   * @return int
   *    Length the content plays in seconds.
   */
  public function getLengthInSeconds();

  /**
   * Set length the content plays in seconds.
   *
   * @param int $length
   *    Length in seconds.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setLengthInSeconds($length);

  /**
   * Return release year, e.g., 2016.
   *
   * @return int
   *    Year number.
   */
  public function getReleaseYear();

  /**
   * Set release year.
   *
   * @param int $year
   *    Year number.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setReleaseYear($year);

  /**
   * Return Datetime the title is last updated (mapped to ProcessedDatetimeUTC)
   *
   * @return \DateTime
   *    Datetime the title is last updated.
   */
  public function getProcessedDatetimeUTC();

  /**
   * Set ProcessedDatetimeUTC as string, e.g., '2015-01-13T21:51:00.795Z'.
   *
   * @param \DateTime $datetime
   *    Datetime.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setProcessedDatetimeUTC(\DateTime $datetime);

  /**
   * Get animation mode that maps to AnimationMode->name.
   *
   * @return string
   *   Animation mode e.g. "Animated" or "Non-Animated".
   */
  public function getAnimationMode();

  /**
   * Set animation mode name.
   *
   * @param string $mode
   *    Animation mode.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setAnimationMode($mode);

  /**
   * Get stdClass object containing performance mode info.
   *
   * @return \stdClass
   *    Object containing performance mode info.
   */
  public function getPerformanceMode();

  /**
   * Set stdClass object containing performance mode info.
   *
   * @param mixed $mode
   *    Object containing performance info.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setPerformanceMode($mode);

  /**
   * Get storyline of the "Turner External" type in the storylines json.
   *
   * @return string
   *    External storyline.
   */
  public function getExternalStoryline();

  /**
   * Set external storylines.
   *
   * @param string $storyline
   *    External storyline.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setExternalStoryline($storyline);

  /**
   * Get storyline of the "Turner Short" type in the storylines json..
   *
   * @return string
   *    Short storyline.
   */
  public function getShortStoryline();

  /**
   * Set short storyline string that is mapped to the short type of storylines.
   *
   * @param string $storyline
   *    Short storyline.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setShortStoryline($storyline);

  /**
   * Get storylines as stdClass object that contains all types of storylines.
   *
   * @return \stdClass
   *    A json containing external, short, and other types of storylines.
   */
  public function getStorylines();

  /**
   * Set storylines as stdClass object.
   *
   * @param mixed $storylines
   *    Storylines object.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setStorylines($storylines);

  /**
   * Get array of stdClass objects.
   *
   * @return array
   *    Array of stdClass objects.
   */
  public function getGenres();

  /**
   * Set genres array and each item is a stdClass containing genre name and id.
   *
   * @param array $genres
   *    Array of stdClass objects.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setGenres($genres);

  /**
   * Get array of string genres out from the array of genre objects.
   *
   * This is a helper method that returns only the string genres.
   *
   * @return array
   *    Genres texts.
   */
  public function getStringGenres();

  /**
   * Get array of key genres data.
   *
   * @return array
   *    Array of genre objects.
   */
  public function getKeyGenres();

  /**
   * Set genres array and each item is a json containing genres name and id.
   *
   * @param array $key_genres
   *    Array of json objects.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setKeyGenres($key_genres);

  /**
   * Get array of string key genres out from key_genres array.
   *
   * This is a helper method that returns only the string values of key genres.
   *
   * @return array
   *    String key genres texts.
   */
  public function getStringKeyGenres();

  /**
   * Get tags array.
   *
   * @return array
   *    string tags
   */
  public function getTags();

  /**
   * Set tags array.
   *
   * @param array $tags
   *    Array of string tags.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setTags($tags);

  /**
   * Get array of json objects, each of which contains a keyword name and id.
   *
   * @return array
   *    Keywords
   */
  public function getKeywords();

  /**
   * Set keywords array.
   *
   * @param array $keywords
   *    Array of keywords.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setKeywords($keywords);

  /**
   * Get array of string keywords out from array of keyword objects.
   *
   * @return array
   *    String keywords.
   */
  public function getStringKeywords();

  /**
   * Get array of rating objects.
   *
   * @return array
   *    Array of stdClass objects.
   */
  public function getRatings();

  /**
   * Set array of rating objects containing rating code and descriptors.
   *
   * @param array $ratings
   *    An array of stdClass objects.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setRatings($ratings);

  /**
   * Get partcipants as array of stdClass objects.
   *
   * @return array
   *    Array of stdClass objects.
   */
  public function getParticipants();

  /**
   * Set partcipants as stdClass object.
   *
   * @param array $value
   *    Array of stdClass objects.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setParticipants($value);

  /**
   * Get series titleId.
   *
   * @return int
   *    Series titleId.
   */
  public function getSeriesTitleId();

  /**
   * Set series titleId referencing to a series ContentTitle entity.
   *
   * @param int $series_title_id
   *    Series titleId.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeriesTitleId($series_title_id);

  /**
   * Get series title name.
   *
   * @return string
   *    Series title name
   */
  public function getSeriesTitleName();

  /**
   * Set series title name that maps to seriesTitleName.
   *
   * @param string $name
   *    Series title name.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeriesTitleName($name);

  /**
   * Get sprtable series title name.
   *
   * @return string
   *    Sortable series title name
   */
  public function getSortableSeriesTitleName();

  /**
   * Set sortable series name that maps to seriesTitleName.
   *
   * @param string $name
   *    Sprtable series title name.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSortableSeriesTitleName($name);

  /**
   * Get series item number.
   *
   * @return string
   *    Series item number
   */
  public function getSeriesItemNumber();

  /**
   * Set series item number, i.e., "101".
   *
   * @param string $item_number
   *    Series item number.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeriesItemNumber($item_number);

  /**
   * Get external series item number.
   *
   * @return string
   *    External series item number
   */
  public function getExternalSeriesItemNumber();

  /**
   * Set external series item number, i.e., "S1:E01".
   *
   * @param string $item_number
   *    External series item number.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setExternalSeriesItemNumber($item_number);

  /**
   * Get season number.
   *
   * @return int
   *    Id of season.
   */
  public function getSeasonNumber();

  /**
   * Set season number, i.e., 1, 2, etc.
   *
   * @param int $season
   *    Season number.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeasonNumber($season);

  /**
   * Get season name.
   *
   * @return string
   *    Name of a season.
   */
  public function getSeasonName();

  /**
   * Set season name, e.g., "Season 1".
   *
   * @param string $season_name
   *    Season name.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeasonName($season_name);

  /**
   * Get season episode number.
   *
   * @return string
   *    Season episode number.
   */
  public function getSeasonEpisodeNumber();

  /**
   * Set external series item number, i.e., "5", "S5:E05".
   *
   * @param string $episode_number
   *    Season episode number.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeasonEpisodeNumber($episode_number);

  /**
   * Get seasons array, eash item is a stdClass having a season number.
   *
   * @return array
   *    Season number array
   */
  public function getSeasons();

  /**
   * Set seasons array.
   *
   * @param array $seasons
   *    Season number array.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeasons($seasons);

  /**
   * Return array of objects containing some episode fields e.g., titleIds.
   *
   * @return array
   *    Array of stdClass objects.
   */
  public function getSeriesItems();

  /**
   * Set series items array.
   *
   * @param array $series_items
   *    Array of stdClass objects.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitleInterface
   *   The called entity.
   */
  public function setSeriesItems($series_items);

  /**
   * Return a object contains only rating code and descriptors for a network.
   *
   * This is a helper method for easily retrieving rating from 'ratings' array.
   * Only the rating code and descriptors array are included in the json object
   * for client to use. Here is an example:
   *
   *    {
   *       'rating': 'TV-14',
   *       'descriptors' : ['D','L']
   *    }
   *
   * @param string $network_code
   *   e.g. TBS,TNT, etc.
   *
   * @return \stdClass
   *    An object or NULL if not found.
   */
  public function getRatingCodeAndDescriptorsByNetwork($network_code);

  /**
   * Return all site content mapped to this title.
   *
   * @return array
   *    List of mapped entities.
   */
  public function getMappedContents();

  /**
   * Return content id's of site content mapped to this title.
   *
   * @return array
   *    List of entity ids.
   */
  public function getMappedContentIds();

  /**
   * Add a site created (mapped) entity to title.
   *
   * @param string $id
   *   The ID of the entity to add.
   */
  public function addMappedContent($id);

  /**
   * Remove an entity from the list of site mapped content.
   *
   * @param string $id
   *   ID of entity to remove.
   */
  public function removeMappedContent($id);

  /**
   * Remove all entities from the list of site mapped content.
   */
  public function clearMappedContent();

  /**
   * Return language name mapped from title's Language->Name.
   *
   * Return NULL if the Language node or the node's Name property is missing.
   *
   * @return string | NULL
   *    Language name.
   */
  public function getLanguageName();

}
