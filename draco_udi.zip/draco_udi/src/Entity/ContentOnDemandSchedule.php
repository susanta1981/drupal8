<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityTypeInterface;

/**
 * Defines the Content on demand schedule entity.
 *
 * @ingroup draco_udi
 *
 * @ContentEntityType(
 *   id = "content_on_demand_schedule",
 *   label = @Translation("Content's on-demand schedule"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "views_data" = "Drupal\draco_udi\Entity\ContentOnDemandScheduleViewsData",
 *     "form" = {
 *       "default" = "Drupal\draco_udi\Form\ContentOnDemandScheduleForm",
 *       "edit" = "Drupal\draco_udi\Form\ContentOnDemandScheduleForm",
 *       "delete" = "Drupal\draco_udi\Form\ContentOnDemandScheduleDeleteForm",
 *     },
 *     "access" = "Drupal\draco_udi\ContentOnDemandScheduleAccessControlHandler",
 *   },
 *   base_table = "content_on_demand_schedule",
 *   admin_permission = "administer content_on_demand_schedule entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *     "langcode" = "langcode",
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/udi/content_on_demand_schedule/{content_on_demand_schedule}",
 *     "edit-form" = "/admin/structure/udi/content_on_demand_schedule/{content_on_demand_schedule}/edit",
 *     "delete-form" = "/admin/structure/udi/content_on_demand_schedule/{content_on_demand_schedule}/delete"
 *   },
 *   field_ui_base_route = "content_on_demand_schedule.settings"
 * )
 */
class ContentOnDemandSchedule extends ContentScheduleBase implements ContentOnDemandScheduleInterface, TveContentInterface {




  // BELOW are not final values for these packages.  These are just placeholders
  // for now.  Will update after names are finalized.s.
  const MEZZANINE_PACKAGE_NAME = 'cms-mez';
  const THUMMBNAILS_PACKAGE_NAME = 'thumbnails';
  const VIDEO_PROXY_PACKAGE_NAME = 'proxy';

  /**
   * {@inheritdoc}
   */
  public function getAiringId() {
    return $this->get('airing_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setAiringId($airing_id) {
    $this->set('airing_id', $airing_id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getMediaId() {
    return $this->get('media_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setMediaId($media_id) {
    $this->set('media_id', $media_id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getType() {
    return $this->get('type')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setType($type) {
    $this->set('type', $type);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getBrand() {
    return $this->get('brand')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setBrand($brand) {
    $this->set('brand', $brand);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getLengthInSeconds() {
    return $this->get('length_in_seconds')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setLengthInSeconds($length) {
    $this->set('length_in_seconds', $length);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getDisplayMinutes() {
    return $this->get('display_minutes')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setDisplayMinutes($length) {
    $this->set('display_minutes', $length);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getTitleData() {
    if ($this->get('title_data') != NULL) {
      return json_decode($this->get('title_data')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setTitleData(\stdClass $title) {
    $this->set('title_data', json_encode($title));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getVersions() {
    if ($this->get('versions') != NULL) {
      return json_decode($this->get('versions')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setVersions($versions) {
    $this->set('versions', json_encode($versions));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getPlaylist() {
    if ($this->get('playlist') != NULL) {
      return json_decode($this->get('playlist')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setPlaylist($playlist) {
    $this->set('playlist', json_encode($playlist));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getFiles() {
    if ($this->get('files') != NULL) {
      return json_decode($this->get('files')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setFiles($files) {
    $this->set('files', json_encode($files));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getFlights() {
    $flights = array();

    foreach ($this->get('flights') as $flight) {
      if ($flight->entity) {
        $flights[] = $flight->entity;
      }
    }

    return $flights;
  }

  /**
   * {@inheritdoc}
   */
  public function getFlightIds() {
    $flights = array();

    foreach ($this->get('flights') as $flight) {
      if ($flight->target_id) {
        $flights[] = $flight->target_id;
      }
    }

    return $flights;
  }

  /**
   * {@inheritdoc}
   */
  public function addFlight($flight_id) {
    $flights = $this->getFlightIds();
    $flights[] = $flight_id;
    $this->set('flights', array_unique($flights));
  }

  /**
   * {@inheritdoc}
   */
  public function removeFlight($flight_id) {
    $this->set('flights', array_diff($this->getFlightIds(), array($flight_id)));
  }

  /**
   * {@inheritdoc}
   */
  public function hasFlight($flight_id) {
    return in_array($flight_id, $this->getFlights());
  }

  /**
   * {@inheritdoc}
   */
  public function getTveContent() {
    if ($this->get('tve_content') != NULL) {
      return json_decode($this->get('tve_content')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setTveContent($tve_content) {
    $this->set('tve_content', json_encode($tve_content));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getAssets() {
    if ($this->get('assets') != NULL) {
      return json_decode($this->get('assets')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setAssets($assets) {
    $this->set('assets', json_encode($assets));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getThumbs() {
    if ($this->get('thumbs') != NULL) {
      return json_decode($this->get('thumbs')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setThumbs($thumbs) {
    $this->set('thumbs', json_encode($thumbs));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getAdBreaks() {
    if ($this->get('ad_breaks') != NULL) {
      return json_decode($this->get('ad_breaks')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setAdBreaks($ad_breaks) {
    $this->set('ad_breaks', json_encode($ad_breaks));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getContentSegments() {
    if ($this->get('content_segments') != NULL) {
      return json_decode($this->get('content_segments')->value);
    };
  }

  /**
   * {@inheritdoc}
   */
  public function setContentSegments($content_segments) {
    $this->set('content_segments', json_encode($content_segments));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getVideoStatus() {
    $content = $this->getContentJson();

    if ($content && isset($content->options) && isset($content->options->status)) {
      $status = $content->options->status;

      if (isset($status->video)) {
        return $status->video;
      }
    }

    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function getTurnerPrivate() {
    if ($this->getTveContent() != NULL && isset($this->getTveContent()->TveItem)) {
      return $this->getTveContent()->TveItem->TurnerPrivate;
    }

    return NULL;
  }

  /**
   * {@inheritdoc}
   */
  public function getTveTitleData() {
    if ($this->getTveContent() != NULL && isset($this->getTveContent()->TveItem)) {
      return $this->getTveContent()->TveItem->Title;
    }

    return NULL;
  }

  /**
   * {@inheritdoc}
   */
  public function getPackage($package_name) {
    $data = NULL;
    if ($this->get('packages') != NULL) {
      $packages = json_decode($this->get('packages')->value);
      if (key_exists($package_name, $packages)) {
        $data = $packages->{$package_name};
      }
    };
    return $data;
  }

  /**
   * {@inheritdoc}
   */
  public function setPackage($package_name, \stdClass $contents) {
    if ($this->get('packages') != NULL) {
      $packages = json_decode($this->get('packages')->value);
    }
    else {
      $packages = new \stdClass();
    };
    $packages->{$package_name} = $contents;
    $this->set('packages', json_encode($packages));
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getTitleIdList() {
    $titles = [];
    if (isset($this->getContentJson()->options->titles)) {
      foreach ($this->getContentJson()->options->titles as $title) {
        $titles[] = $title->titleId;
      }
    }
    return $titles;
  }

  /**
   * {@inheritdoc}
   */
  public function getPrimaryTitleId() {
    $titleIds = $this->getTitleIdList();
    $primaryTitleId = NULL;
    if (count($titleIds) <= 1) {
      $primaryTitleId = $titleIds[0];
    }
    else {
      foreach ($this->getContentJson()->title->titleIds as $titleData) {
        if (property_exists($titleData, "primary") && $titleData->primary) {
          $primaryTitleId = $titleData->value;
          break;
        }
      }
    }
    return $primaryTitleId;
  }

  /**
   * {@inheritdoc}
   */
  public function getContentIds() {
    $versions = $this->getVersions();
    $contentIds = [];
    $i = 0;
    foreach ($versions as $version) {
       if (property_exists($version,"contentId")) {
          $contentIds[$i++] = $version->contentId;
       }
    }
    return $contentIds;
  }


  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of content on-demand schedule entity.'))
      ->setReadOnly(TRUE)
      ->setSetting('unsigned', TRUE);

    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Content on-demand Schedule entity.'))
      ->setReadOnly(TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Publishing status'))
      ->setDescription(t('A boolean indicating whether the content on-demand schedule is published.'))
      ->setDefaultValue(FALSE);

    $fields['imported'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Imported time'))
      ->setDescription(t('The time that this on-demand schedule data was imported from ODT.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -98,
      ));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Last updated'))
      ->setDescription(t('The last time this on-demand schedule data was updated.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -97,
      ));

    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setLabel(t('Language code'))
      ->setDescription(t('The language code.'));

    $fields['airing_id'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Airing ID'))
      ->setRequired(TRUE)
      ->setReadOnly(TRUE)
      ->setDescription(t('ID of airing object that is unique in ODT.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -110,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -110,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['media_id'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Media ID'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Airing media id.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -108,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -108,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['label'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Name of content on-demand schedule entity'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -105,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -105,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['type'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Content type'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Type of associated content entity'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -100,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -100,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['length_in_seconds'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Length in seconds'))
      ->setDescription(t('Length of the content in seconds.'))
      ->setReadOnly(FALSE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -96,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -96,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['display_minutes'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Display length in minutes'))
      ->setDescription(t('Length of the content plays in minutes.'))
      ->setReadOnly(FALSE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -95,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -95,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['brand'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Brand name'))
      ->setDescription(t('Brand name, etc. TBS.'))
      ->setReadOnly(FALSE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -94,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -94,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['title_data'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Title data'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Title data.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -93,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['playlist'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Playlist'))
      ->setReadOnly(FALSE)
      ->setDescription(t('Playlist items.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -79,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['versions'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Versions'))
      ->setReadOnly(FALSE)
      ->setDescription(t('Content versions data.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -78,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['files'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Files'))
      ->setReadOnly(FALSE)
      ->setDescription(t('List of related content file urls, e.g., url for video xml file.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -77,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['titles'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Titles'))
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDescription(t('List of associated titles'))
      ->setSetting('target_type', 'content_title')
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'entity_reference_label',
        'weight' => -50,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -50,
      ))
      ->setDisplayConfigurable('form', TRUE);

    $fields['flights'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Flights'))
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDescription(t('List of flights'))
      ->setSetting('target_type', 'content_on_demand_flight')
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -40,
      ))
      ->setDisplayConfigurable('form', TRUE);

    // Drupal creates a table to hold an array of title ids.
    $fields['title_ids'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Title Ids'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Title ids.'))
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -35,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['assets'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Assets'))
      ->setReadOnly(FALSE)
      ->setDescription(t('List of video file data.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -33,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['thumbs'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Thumbs'))
      ->setReadOnly(FALSE)
      ->setDescription(t('List of thumbnail file data.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -32,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['ad_breaks'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Ad breaks'))
      ->setReadOnly(FALSE)
      ->setDescription(t('List of ad breaks.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -31,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['content_segments'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Content segments'))
      ->setReadOnly(FALSE)
      ->setDescription(t('List of content segments.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -30,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['content_json'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Complete ODT content'))
      ->setDescription(t('The entire ODT content json object.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -25,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['tve_content'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Complete TVE content'))
      ->setDescription(t('The entire TVE content json object.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -20,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['packages'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Package Data'))
      ->setDescription(t('Package Data.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -20,
      ))
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
