<?php

namespace Drupal\draco_udi\Entity;

/**
 * Interface TveContentInterface.
 *
 * Defines getters and setters for TVE content specific properties.
 *
 * @package Drupal\draco_udi\Entity
 */
interface TveContentInterface {

  /**
   * Return TVE (TV Everywhere) content data as a stdClass object.
   *
   * This field may be null if TVE data is not imported.
   *
   * @return \stdClass
   *    TVE json object.
   */
  public function getTveContent();

  /**
   * Set TVE json as a encoded string.
   *
   * @param \stdClass $tve_content
   *    TVE json object.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setTveContent($tve_content);

  /**
   * Return array of video file metadata.
   *
   * @return array
   *    List of video files data.
   */
  public function getAssets();

  /**
   * Set video file asserts as array.
   *
   * @param array $assets
   *    Video asset data.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setAssets($assets);

  /**
   * Return array of thumbnail file metadata.
   *
   * @return array
   *    List of thumbnail files data.
   */
  public function getThumbs();

  /**
   * Set thumbnail file asserts as array.
   *
   * @param array $thumbs
   *    Thumbnail asset data.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setThumbs($thumbs);

  /**
   * Return array of ad breaks.
   *
   * @return array
   *    List of ad break data.
   */
  public function getAdBreaks();

  /**
   * Set ad breaks data array.
   *
   * @param array $ad_breaks
   *    Ad break data list.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setAdBreaks($ad_breaks);

  /**
   * Return array of Content segments.
   *
   * @return array
   *    List of content segments.
   */
  public function getContentSegments();

  /**
   * Set content segments data array.
   *
   * @param array $content_segments
   *    Content segment list.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setContentSegments($content_segments);

  /**
   * Return the PrivateProperty Node of the TVE content.
   *
   * @return \stdClass
   */
  public function getTurnerPrivate();

  /**
   * Return the Title node from TVE content.
   *
   * @return \stdClass
   *    Title node.
   */
  public function getTveTitleData();

}
