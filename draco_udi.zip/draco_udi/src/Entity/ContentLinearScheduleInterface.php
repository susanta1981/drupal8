<?php

namespace Drupal\draco_udi\Entity;


/**
 * Interface ContentLinearScheduleInterface.
 *
 * @package Drupal\draco_udi
 */
interface ContentLinearScheduleInterface extends ContentScheduleInterface {

  /**
   * Return external id.
   *
   * @return int
   *    External id.
   */
  public function getExternalId();

  /**
   * Set external id. The id is used for updating.
   *
   * @param int $id
   *    External id.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setExternalId($id);

  /**
   * Get start date.
   *
   * @return \Datetime
   *    The start date
   */
  public function getStartDate();

  /**
   * Set start date.
   *
   * @param \DateTime $datetime
   *    Start date.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setStartDate(\DateTime $datetime);

  /**
   * Get end date.
   *
   * @return \Datetime
   *    The end date.
   */
  public function getEndDate();

  /**
   * Set end datep.
   *
   * @param \DateTime $datetime
   *    End date.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setEndDate(\DateTime $datetime);

  /**
   * Get franchise name.
   *
   * @return string
   *    Franchise name.
   */
  public function getFranchiseName();

  /**
   * Set franchise_name value.
   *
   * @param string $name
   *    Timestamp int value.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setFranchiseName($name);

  /**
   * Get time zone.
   *
   * @return string
   *    Time zone.
   */
  public function getTimeZone();

  /**
   * Set time_zone value, e.g., "Eastern Standard Time".
   *
   * @param string $time_zone
   *    Time zone.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setTimeZone($time_zone);

  /**
   * Get franchise duration (length of a video in minutes).
   *
   * @return int
   *    A content play duration.
   */
  public function getFranchiseDuration();

  /**
   * Set franchise duration in minutes.
   *
   * @param int $duration
   *    A content play duration.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setFranchiseDuration($duration);

  /**
   * Get franchise id.
   *
   * @return int
   *    Franchise id.
   */
  public function getFranchiseId();

  /**
   * Set franchise id.
   *
   * @param int $id
   *    Franchise id.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setFranchiseId($id);

  /**
   * Return is_premiere code.
   *
   * @return string
   *    Is premiere code.
   */
  public function getIsPremiere();

  /**
   * Set content is_premiere code, e.g., "N".
   *
   * @param string $premiere
   *    Is premiere code.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setIsPremiere($premiere);

  /**
   * Return is_live code, e.g., "T".
   *
   * @return string
   *    Is live code.
   */
  public function getIsLive();

  /**
   * Set content is_live code.
   *
   * @param string $live
   *    Is live code.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setIsLive($live);

  /**
   * Return schedule_air_date.
   *
   * @return \DateTime
   *    Schedule air date
   */
  public function getScheduleAirDate();

  /**
   * Set schedule_air_date to a date.
   *
   * @param \DateTime $datetime
   *    Air date.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setScheduleAirDate(\DateTime $datetime);

  /**
   * Return schedule_airing_start_time as an int value.
   *
   * @return int
   *    Schedule airing start time
   */
  public function getScheduleAiringStartTime();

  /**
   * Set schedule_airing_start_time as a int.
   *
   * @param int $time
   *    Schedule airing start time.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setScheduleAiringStartTime($time);

  /**
   * Return pre_text value.
   *
   * @return string
   *    PreText.
   */
  public function getPreText();

  /**
   * Set pre_text value, e.g., '86m'.
   *
   * @param int $text
   *    PreText value.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setPreText($text);

  /**
   * Return network name, e.g., "TBS".
   *
   * @return string
   *    Network name
   */
  public function getNetwork();

  /**
   * Set network name.
   *
   * @param string $network
   *    Network name.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setNetwork($network);

  /**
   * Return platform, e.g., "linear".
   *
   * @return string
   *    Platform type.
   */
  public function getPlatform();

  /**
   * Set platform type.
   *
   * @param string $platform
   *    Platform type.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setPlatform($platform);

  /**
   * Return Source name, e.g., "linear".
   *
   * @return string
   *    Source name.
   */
  public function getSource();

  /**
   * Set source name.
   *
   * @param string $source
   *    Source name.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setSource($source);

  /**
   * Return network feed code, e.g., "E".
   *
   * @return string
   *    Feed code.
   */
  public function getNetworkFeedCode();

  /**
   * Set network feed code.
   *
   * @param string $feed_code
   *    Feed code.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setNetworkFeedCode($feed_code);

  /**
   * Return closed caption flag, e.g., "Y".
   *
   * @return string
   *    CC flag.
   */
  public function getClosedCaptions();

  /**
   * Set closed caption.
   *
   * @param string $cc
   *    CC code.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setClosedCaptions($cc);

  /**
   * Return news_update code.
   *
   * @return int
   *    A code.
   */
  public function getNewsUpdate();

  /**
   * Set news update code.
   *
   * @param int $value
   *    News update code.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentLinearSchedule entity.
   */
  public function setNewsUpdate($value);

}
