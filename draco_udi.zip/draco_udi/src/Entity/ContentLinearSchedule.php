<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;

/**
 * Defines the Content Linear Schedule entity.
 *
 * @ingroup draco_udi
 *
 * @ContentEntityType(
 *   id = "content_linear_schedule",
 *   label = @Translation("Content linear schedule"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "views_data" = "Drupal\draco_udi\Entity\ContentLinearScheduleViewsData",
 *     "form" = {
 *       "default" = "Drupal\draco_udi\Form\ContentLinearScheduleForm",
 *       "add" = "Drupal\draco_udi\Form\ContentLinearScheduleForm",
 *       "edit" = "Drupal\draco_udi\Form\ContentLinearScheduleForm",
 *       "delete" = "Drupal\draco_udi\Form\ContentLinearScheduleDeleteForm",
 *     },
 *     "access" = "Drupal\draco_udi\ContentLinearScheduleAccessControlHandler",
 *   },
 *   base_table = "content_linear_schedule",
 *   admin_permission = "administer content_linear_schedule entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *     "langcode" = "langcode",
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/udi/content_linear_schedule/{content_linear_schedule}",
 *     "edit-form" = "/admin/structure/udi/content_linear_schedule/{content_linear_schedule}/edit",
 *     "delete-form" = "/admin/structure/udi/content_linear_schedule/{content_linear_schedule}/delete"
 *   },
 *   field_ui_base_route = "content_linear_schedule.settings"
 * )
 */
class ContentLinearSchedule extends ContentScheduleBase implements ContentLinearScheduleInterface {
  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public function getExternalId() {
    return $this->get('external_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setExternalId($id) {
    $this->set('external_id', $id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getStartDate() {
    $date = NULL;

    if ($this->get('start_date') != NULL) {
      $date = $this->getUTCDateTime('start_date');
    }
    return $date;
  }

  /**
   * {@inheritdoc}
   */
  public function setStartDate(\DateTime $datetime) {
    if ($datetime != NULL) {
      $this->setDateTimeAsUTCString('start_date', $datetime);
    }
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getEndDate() {
    $date = NULL;

    if ($this->get('end_date') != NULL) {
      $date = $this->getUTCDateTime('end_date');
    }
    return $date;
  }

  /**
   * {@inheritdoc}
   */
  public function setEndDate(\DateTime $datetime) {
    if ($datetime != NULL) {
      $this->setDateTimeAsUTCString('end_date', $datetime);
    }
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getFranchiseName() {
    return $this->get('franchise_name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setFranchiseName($name) {
    $this->set('franchise_name', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getTimeZone() {
    return $this->get('time_zone')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setTimeZone($time_zone) {
    $this->set('time_zone', $time_zone);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getFranchiseDuration() {
    return $this->get('franchise_duration')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setFranchiseDuration($duration) {
    $this->set('franchise_duration', $duration);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getFranchiseId() {
    return $this->get('franchise_id')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setFranchiseId($id) {
    $this->set('franchise_id', $id);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getIsPremiere() {
    return $this->get('is_premiere')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setIsPremiere($premiere) {
    $this->set('is_premiere', $premiere);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getIsLive() {
    return $this->get('is_live')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setIsLive($live) {
    $this->set('is_live', $live);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getScheduleAirDate() {
    $date = NULL;

    if ($this->get('schedule_air_date') != NULL) {
      $date = $this->getUTCDateTime('schedule_air_date');
    }
    return $date;
  }

  /**
   * {@inheritdoc}
   */
  public function setScheduleAirDate(\DateTime $datetime) {
    if ($datetime != NULL) {
      $this->setDateTimeAsUTCString('schedule_air_date', $datetime);
    }
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getScheduleAiringStartTime() {
    return $this->get('schedule_airing_start_time')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setScheduleAiringStartTime($time) {
    $this->set('schedule_airing_start_time', $time);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getPreText() {
    return $this->get('pre_text')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setPreText($text) {
    $this->set('pre_text', $text);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getNetwork() {
    return $this->get('network')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setNetwork($network) {
    $this->set('network', $network);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getPlatform() {
    return $this->get('platform')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setPlatform($platform) {
    $this->set('platform', $platform);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getSource() {
    return $this->get('source')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setSource($source) {
    $this->set('source', $source);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getNetworkFeedCode() {
    return $this->get('network_feed_code')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setNetworkFeedCode($feed_code) {
    $this->set('network_feed_code', $feed_code);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getClosedCaptions() {
    return $this->get('cc')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setClosedCaptions($cc) {
    $this->set('cc', $cc);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getNewsUpdate() {
    return $this->get('news_update')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setNewsUpdate($value) {
    $this->set('news_update', $value);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of Content Linear Schedule entity.'))
      ->setReadOnly(TRUE);

    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Content Linear Schedule entity. It is mapped to _id of content json object.'))
      ->setReadOnly(TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Publishing status'))
      ->setDescription(t('A boolean indicating whether the content linear schedule is published.'))
      ->setDefaultValue(FALSE);

    $fields['imported'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Imported time'))
      ->setDescription(t('The time that this schedule data was imported from Flow.'))
      ->setDisplayConfigurable('view', TRUE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -86,
      ));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Last updated'))
      ->setDescription(t('The time that this schedule data was last updated.'))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -85,
      ));

    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setLabel(t('Language code'))
      ->setDescription(t('The language code for the Content Linear Schedule entity.'));

    $fields['label'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Name of Content Linear Schedule entity'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -100,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -100,
      ))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['external_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('External id'))
      ->setDescription(t('Schedule external id'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -99,
      ))
      ->setDisplayOptions('form', array(
        'weight' => -99,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['start_date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Start date'))
      ->setDescription(t('Date/time when this schedule will start.'))
      ->setSettings(array(
        'default_value' => '',
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'datetime_default',
        'weight' => -98,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -98,
      ))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['end_date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('End date'))
      ->setDescription(t('Date/time when this schedule will expire.'))
      ->setSettings(array(
        'default_value' => '',
        'max_length' => 255,
        'text_processing' => 0,
      ))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'datetime',
        'weight' => -97,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -97,
      ))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['network'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Network'))
      ->setDescription(t('Network name.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -76,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['platform'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Platform'))
      ->setDescription(t('Platform type.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -75,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['source'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Source'))
      ->setDescription(t('Source.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -74,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['pre_text'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Pre-text'))
      ->setDescription(t('Pre text, like 86m.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'datetime_default',
        'weight' => -73,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['time_zone'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Time zone'))
      ->setDescription(t('Time zone, like standard eastern time.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -72,
      ))
      ->setDisplayOptions('form', array(
        'type' => 'string_textfield',
        'weight' => -72,
      ))
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['is_premiere'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Is premiere'))
      ->setSettings(array(
        'max_length' => 10,
      ))
      ->setDescription(t('A flag showing if content is premiere.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -71,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['is_live'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Is live'))
      ->setSettings(array(
        'max_length' => 10,
      ))
      ->setDescription(t('A flag showing if content is live.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -70,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['franchise_name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Franchise name'))
      ->setDescription(t('Franchise name.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -69,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['franchise_id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Franchise Id'))
      ->setDescription(t('Franchise integer id.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -68,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['franchise_duration'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Franchise Duration'))
      ->setDescription(t('The length a content plays in minutes.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -67,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['network_feed_code'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Network feed code'))
      ->setDescription(t('Network feed code.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -66,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['schedule_air_date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Schedule air date'))
      ->setDescription(t('Schedule air date.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -65,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['schedule_airing_start_time'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Schedule airing starting time'))
      ->setDescription(t('Schedule airing starting time.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'integer',
        'weight' => -64,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['cc'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Closed caption'))
      ->setDescription(t('Flag indicating if closed caption is available.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -63,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['news_update'] = BaseFieldDefinition::create('string')
      ->setLabel(t('News update'))
      ->setDescription(t('News update integer code.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -62,
      ))
      ->setDisplayConfigurable('view', TRUE);

    $fields['titles'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Titles'))
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDescription(t('List of associated titles'))
      ->setSetting('target_type', 'content_title')
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'entity_reference_label',
        'weight' => -50,
      ))
      ->setDisplayConfigurable('form', TRUE);

    $fields['content_json'] = BaseFieldDefinition::create('string_long')
      ->setLabel(t('Complete content'))
      ->setDescription(t('The entire linear schedule content json object.'))
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -40,
      ))
      ->setDisplayConfigurable('view', TRUE);

    // Drupal creates a table to hold an array of title ids.
    $fields['title_ids'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('Title Ids'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Title ids.'))
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDisplayOptions('view', array(
        'label' => 'inline',
        'type' => 'string',
        'weight' => -30,
      ))
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

  /**
   * Returns a DateTime instance.
   *
   * @param string $date_field
   *    Field name.
   *
   * @return \DateTime
   *    DateTime object.
   */
  private function getUTCDateTime($date_field) {
    $date_value = $this->get($date_field)->value;
    $time_zone = new \DateTimeZone('UTC');
    return new \DateTime($date_value, $time_zone);
  }

  /**
   * Set DateTime as a string.
   *
   * @param string $field
   *    Field name.
   * @param \DateTime $datetime
   *    DateTime object.
   */
  private function setDateTimeAsUTCString($field, \DateTime $datetime) {
    $db_value = $datetime->format('Y-m-d\TH:i:s');
    $this->set($field, $db_value);
  }

}
