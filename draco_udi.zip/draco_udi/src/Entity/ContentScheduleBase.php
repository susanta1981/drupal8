<?php

namespace Drupal\draco_udi\Entity;

/**
 * Class ContentScheduleBase.
 *
 * A base class that contains common methods shared by content schedule entities
 * including ContentOnDemandSchedule and ContentLinearSchedule.
 *
 * @package Drupal\draco_udi\Entity
 */
abstract class ContentScheduleBase extends DracoContentBase implements ContentScheduleInterface {

  /**
   * {@inheritdoc}
   */
  public function addAssociatedTitle($entity_id) {
    $titles = $this->getAssociatedTitleEntityIds();
    $titles[] = $entity_id;
    $this->set('titles', array_unique($titles));
  }

  /**
   * {@inheritdoc}
   */
  public function removeAssociatedTitle($entity_id) {
    $this->set('titles', array_diff($this->getAssociatedTitleEntityIds(), array($entity_id)));
  }

  /**
   * {@inheritdoc}
   */
  public function getAssociatedTitles() {
    $titles = array();

    foreach ($this->get('titles') as $title) {
      if ($title->entity) {
        $titles[] = $title->entity;
      }
    }

    return $titles;
  }

  /**
   * {@inheritdoc}
   */
  public function getAssociatedTitleEntityIds() {
    $titles = array();

    foreach ($this->get('titles') as $title) {
      if ($title->target_id) {
        $titles[] = $title->target_id;
      }
    }

    return $titles;
  }

  /**
   * {@inheritdoc}
   */
  public function isAssociatedTitle($entity_id) {
    return in_array($entity_id, $this->getAssociatedTitleEntityIds());
  }

  /**
   * {@inheritdoc}
   */
  public function getTitleIdList() {
    $titles = [];

    if (isset($this->getContentJson()->Titles)) {
      foreach ($this->getContentJson()->Titles as $title) {
        $titles[] = $title->TitleId;
      }
    }

    return $titles;
  }

  /**
   * {@inheritdoc}
   */
  public function getTitleIds() {
    return $this->get('title_ids');
  }

  /**
   * {@inheritdoc}
   */
  public function getTitleIdsValue() {
    return $this->getTitleIds()->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setTitleIds(array $title_ids) {
    $this->set('title_ids', $title_ids);
    return $this;
  }

}
