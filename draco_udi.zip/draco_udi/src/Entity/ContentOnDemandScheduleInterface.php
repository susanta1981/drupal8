<?php

namespace Drupal\draco_udi\Entity;

/**
 * Provides an interface for defining Content on demand schedule entities.
 *
 * @ingroup draco_udi
 */
interface ContentOnDemandScheduleInterface extends ContentScheduleInterface {

  /**
   * Return airing id.
   *
   * @return string
   *    Airing id.
   */
  public function getAiringId();

  /**
   * Set airing id. The id is used for updating.
   *
   * @param string $airing_id
   *    Airing id.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentOnDemandSchedule entity.
   */
  public function setAiringId($airing_id);

  /**
   * Return media id of airing object.
   *
   * @return string
   *    Media id.
   */
  public function getMediaId();

  /**
   * Set media id of an airing object.
   *
   * @param string $media_id
   *    Media id.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentOnDemandSchedule entity.
   */
  public function setMediaId($media_id);

  /**
   * Return type, e.g., Feature Film, Episode (Animated), Special (Non-Animated).
   *
   * @return string
   *    Type of content.
   */
  public function getType();

  /**
   * Set type,  e.g., Feature Film, Episode (Animated), Special (Non-Animated).
   *
   * @param string $type
   *    Type of content.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentOnDemandSchedule entity.
   */
  public function setType($type);

  /**
   * Return brand name, e.g., TBS, TCM.
   *
   * @return string
   *    Brand name.
   */
  public function getBrand();

  /**
   * Set brand name,  e.g., TBS, TNT, etc.
   *
   * @param string $brand
   *    Brand name.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentOnDemandSchedule entity.
   */
  public function setBrand($brand);

  /**
   * Get length the content plays in seconds.
   *
   * @return int
   *    Length the content plays in seconds.
   */
  public function getLengthInSeconds();

  /**
   * Set length the content plays in seconds.
   *
   * @param int $length
   *    Length in seconds.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setLengthInSeconds($length);

  /**
   * Get length the content plays in minutes.
   *
   * @return int
   *    Length the content plays in minutes.
   */
  public function getDisplayMinutes();

  /**
   * Set display length in minutes.
   *
   * @param int $length
   *    Length in minutes.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setDisplayMinutes($length);

  /**
   * Return a stdClass object containing title data.
   *
   * @return \stdClass
   *    Title data object.
   */
  public function getTitleData();

  /**
   * Set the title object of the airing object as a json string.
   *
   * @param \stdClass $title
   *    Title data object.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentOnDemandSchedule entity.
   */
  public function setTitleData(\stdClass $title);

  /**
   * Return an array of version data.
   *
   * @return array
   *    List of version data.
   */
  public function getVersions();

  /**
   * Set array version data.
   *
   * @param array $versions
   *    List of version data.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentOnDemandSchedule entity.
   */
  public function setVersions($versions);

  /**
   * Return an array of version data.
   *
   * Sample of playlist items:
   *     {
   *       "position": 1,
   *        "id": "2HDDF/01",
   *        "type": "MaterialID",
   *        "itemType": "Segment",
   *        "idType": "MaterialID"
   *      },
   *      {
   *         "position": 2,
   *         "id": "",
   *         "type": "Trigger",
   *         "itemType": "Trigger",
   *         "idType": ""
   *      }
   *
   * @return array
   *    List of playable items.
   */
  public function getPlaylist();

  /**
   * Set array of playlist items as shown in getPlaylist's doc.
   *
   * @param array $playlist
   *    Playlist array.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called ContentOnDemandSchedule entity.
   */
  public function setPlaylist($playlist);

  /**
   * Get array of file urls.
   *
   * @return array
   *    List of urls.
   */
  public function getFiles();

  /**
   * Set an array of file urls, including a url for accessing video content xml file.
   *
   * Sample array item:
   *
   *  {
   *    "type": "Xml",
   *    "path": "/tbs/flv/protected_auth_!/tveverywhere/2016-03",
   *    "domain": "cdn8view1.turner.com",
   *    "secure": false,
   *    "video": false
   *  }
   *
   * @param array $files
   *    List of file urls.
   *
   * @return \Drupal\draco_udi\Entity\ContentLinearScheduleInterface
   *   The called entity.
   */
  public function setFiles($files);

  /**
   * Add a flight entity.
   *
   * @param string $flight_id
   *   The flight ID to add.
   */
  public function addFlight($flight_id);

  /**
   * Remove a flight.
   *
   * @param string $flight_id
   *   ID of a flight to remove.
   */
  public function removeFlight($flight_id);

  /**
   * Return flight entity list.
   *
   * @return array
   *    List of flights
   */
  public function getFlights();

  /**
   * Return associated flight id list.
   *
   * @return array
   *    List of flight ids
   */
  public function getFlightIds();

  /**
   * Check if a flight exists by using a id.
   *
   * @param string $flight_id
   *   Flight Id.
   *
   * @return bool
   *    True if found, otherwise false.
   */
  public function hasFlight($flight_id);

  /**
   * Return value of odt content's options->status->value, if exists.
   *
   * @return bool
   *    TRUE or FLASE.
   */
  public function getVideoStatus();

  /**
   * Set package contents.
   *
   * @param string $package_name
   *    Package name.
   * @param \stdClass $contents
   *    Package object.
   *
   * @return \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface
   *   The called entity.
   */
  public function setPackage($package_name, \stdClass $contents);

  /**
   * Return package content data as a stdClass object.
   *
   * @param string $package_name
   *    Package name.
   *
   * @return \stdClass
   *    package object.
   */
  public function getPackage($package_name);

  /**
   * Get the primary title id associated with this airing.
   *
   * @return string
   *    primary title id.
   */
  public function getPrimaryTitleId();

  /**
   * Return Content ids.
   *
   * @return array
   *    content ids.
   */
  public function getContentIds();

}
