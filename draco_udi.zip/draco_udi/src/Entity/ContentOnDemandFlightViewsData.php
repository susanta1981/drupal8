<?php

namespace Drupal\draco_udi\Entity;

use Drupal\views\EntityViewsData;
use Drupal\views\EntityViewsDataInterface;

/**
 * Provides Views data for Content on demand flight entities.
 */
class ContentOnDemandFlightViewsData extends EntityViewsData implements EntityViewsDataInterface {

  /**
   * {@inheritdoc}
   */
  public function getViewsData() {
    $data = parent::getViewsData();

    $data['content_on_demand_flight']['table']['base'] = array(
      'field' => 'id',
      'title' => $this->t('Content on demand flight'),
      'help' => $this->t('The Content on demand flight ID.'),
    );

    return $data;
  }

}
