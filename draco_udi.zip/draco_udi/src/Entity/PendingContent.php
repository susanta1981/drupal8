<?php

namespace Drupal\draco_udi\Entity;

use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;

/**
 * Defines the PendingContent Catalog Item entity.
 *
 * This will be an exact copy of a DracoCatalogItem but annotated
 * to be stored in a different table. Lets us store the information
 * so it can be displayed in the manual approval UI.  In that UI this
 * data will be diffed with the DracoCatalogItem.
 *
 * @ingroup draco_udi
 *
 * @ContentEntityType(
 *   id = "pending_content_entity",
 *   label = @Translation("Draco To Be Approved content items."),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "form" = {
 *     },
 *     "access" = "Drupal\draco_udi\DracoCatalogItemAccessControlHandler",
 *   },
 *   base_table = "pending_content_entity",
 *   admin_permission = "administer pending_content_entity entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   links = {
 *   }
 * )
 */
class PendingContent extends DracoContentBase implements DracoContentInterface {

  /**
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $old_item
   *    Entity downloaded from upstream.
   */
  public function copyValuesFromDracoContentEntity(DracoContentInterface $old_item) {

    foreach ($old_item as $key => $val) {
      $this->$key = $old_item->get($key);
    }
    $this->set('type', "pending_content_entity");
    $this->set('fullJsonContent', $old_item->getContentJson());

  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);
    $fields['id'] = BaseFieldDefinition::create('integer')
      ->setLabel(t('ID'))
      ->setDescription(t('The ID of Content entity.'))
      ->setReadOnly(TRUE)
      ->setSetting('unsigned', TRUE);

    $fields['uuid'] = BaseFieldDefinition::create('uuid')
      ->setLabel(t('UUID'))
      ->setDescription(t('The UUID of the Content entity.'))
      ->setReadOnly(TRUE);

    $fields['label'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Content name'))
      ->setReadOnly(TRUE)
      ->setDescription(t('Name of Content entity'));

    $fields['fullJsonContent'] = BaseFieldDefinition::create('string_long')
            ->setLabel(t('Full json content'))
            ->setReadOnly(TRUE)
            ->setDisplayOptions('view', array(
              'label' => 'inline',
              'type' => 'string',
              'weight' => -92,
            ));
    return $fields;
  }

}
