<?php

namespace Drupal\draco_udi;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a listing of Content whitelist entities.
 */
class ContentWhitelistListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['label'] = $this->t('Content whitelist');
    $header['id'] = $this->t('Machine name');
    $header['contentType'] = $this->t('Content type');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['label'] = $entity->label();
    $row['id'] = $entity->id();
    $row['contentType'] = $entity->getContentType();
    return $row + parent::buildRow($entity);
  }

}
