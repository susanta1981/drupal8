<?php

namespace Drupal\draco_udi\DataChange;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\draco_udi\Context;

/**
 * Interface for data change decision strategies.
 *
 * Decision strategies determine things such as if the
 * data should be updated automatically, or will require
 * human intervention.  The strategy can also determine
 * what kind of psot processing actions should be taken.
 */
interface DataChangeDecisionStrategyInterface extends PluginInspectionInterface {

  /**
   * Decide what kind of change will take place to local data.
   *
   * @param Context $context
   *   Context for the current entity
   *   being processed.
   *
   * @return DecisionResult
   *   Result of the decision.
   */
  public function decide(Context $context);

}
