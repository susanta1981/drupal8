<?php

namespace Drupal\draco_udi\DataChange;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;

/**
 * Manages data change decision strategies.
 */
class DataChangeDecisionStrategyManager extends DefaultPluginManager {

  /**
   * The constructor.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin/DataChangeDecision', $namespaces, $module_handler, 'Drupal\draco_udi\DataChange\DataChangeDecisionStrategyInterface', 'Drupal\draco_udi\Annotation\DataChangeDecisionStrategy');

    $this->alterInfo('approval_decision_strategy_info');
    $this->setCacheBackend($cache_backend, 'approval_descision_strategies');
  }

}
