<?php

namespace Drupal\draco_udi\DataChange;

use Drupal\draco_udi\Context;

/**
 * Process DataChangeDecisions.
 */
interface DataChangeDecisionProcessorInterface {

  /**
   * Process the Change Decision.
   *
   * @param Context $context
   *    The processing Context..
   */
  public function process(Context $context);

}
