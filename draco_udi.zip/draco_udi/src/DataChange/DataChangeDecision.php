<?php

namespace Drupal\draco_udi\DataChange;

/**
 * Class DataChangeDecision.
 *
 * The DataChangeDecision object that will be returned by Approver Plugins.
 *
 * @package Drupal\draco_udi\DataChange
 */
class DataChangeDecision {

  private $approved;
  private $messages;
  private $action;
  private $contentSource;
  private $contentType;
  private $entityId;

  /**
   * Gets array of messages.
   *
   * @return array
   *   The messages.
   */
  public function getMessages() {

    return $this->messages;
  }

  /**
   * Sets array of approval messages.
   *
   * @param array $messages
   *   The messages to be set.
   */
  public function setMessages($messages) {

    $this->messages = $messages;
  }

  /**
   * Get the Approved status.
   *
   * @return bool
   *   The approval status.
   */
  public function getApproved() {

    return $this->approved;
  }

  /**
   * Set the Approved Status.
   *
   * @param bool $approved
   *   The approval status to be set.
   */
  public function setApproved($approved) {

    $this->approved = $approved;
  }

  /**
   * Gets action code.
   *
   * @return string
   *   Action code.
   */
  public function getAction() {
    return $this->action;
  }

  /**
   * Sets action code.
   *
   * @param string $action
   *   The action code.
   */
  public function setAction($action) {
    $this->action = $action;
  }

  /**
   * Get source.
   *
   * @return string
   *   Source of content.
   */
  public function getContentSource() {
    return $this->contentSource;
  }

  /**
   * Set source, ODT, Flow, etc.
   *
   * @param string $source
   *   The source the content is downloaded.
   */
  public function setContentSource($source) {
    $this->contentSource = $source;
  }

  /**
 * Get content type, title, linear schedules, etc.
 *
 * @return string
 *   Content type.
 */
  public function getContentType() {
    return $this->contentType;
  }

  /**
   * Set content type.
   *
   * @param string $type
   *   Content type.
   */
  public function setContentType($type) {
    $this->contentType = $type;
  }

  /**
   * Get id of the Draco entity (not title id).
   *
   * @return int
   *   Entity id.
   */
  public function getEntityId() {
    return $this->entityId;
  }

  /**
   * Set content type.
   *
   * @param int $id
   *   Content type.
   */
  public function setEntityId($id) {
    $this->entityId = $id;
  }

}
