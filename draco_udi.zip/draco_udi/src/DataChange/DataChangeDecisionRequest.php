<?php

namespace Drupal\draco_udi\DataChange;

use Drupal\draco_udi\Entity\DracoContentInterface;

/**
 * Represents a request for a data change decision.
 */
class DataChangeDecisionRequest {

  /**
   * @var \Drupal\draco_udi\Entity\DracoContentInterface
   *    Source content item.
   */
  private $dracoEntity;

  /**
   * @var \Drupal\draco_udi\Entity\DracoContentInterface
   *    Source content item.
   */
  private $existingDracoEntity;

  /**
   * @var array Entities created as part of the conversion process.
   */
  private $associatedEntities;
  /**
   * @var array
   *    An array of newly created entities of content type
   */
  private $mappedContentEntities;

  /**
   * @var array
   *    An array of mapped entities found in db
   */
  private $existingMappedContentEntities;

  /**
   * @var object
   *    A object containing info from notification message.
   */
  private $action;

  /**
   * DataChangeDecisionRequest constructor.
   *
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $draco_entity
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $existing_draco_entity
   * @param array $associated_entities
   * @param array $mapped_entities
   * @param array $existing_mapped_entities
   * @param $action
   */
  public function __construct(
      DracoContentInterface $draco_entity,
      DracoContentInterface $existing_draco_entity = NULL,
      array $associated_entities = NULL,
      array $mapped_entities,
      array $existing_mapped_entities = NULL,
      $action
  ) {
    $this->dracoEntity = $draco_entity;
    $this->existingDracoEntity = $existing_draco_entity;
    $this->associatedEntities = $associated_entities;
    $this->mappedContentEntities  = $mapped_entities;
    $this->existingMappedContentEntities = $existing_mapped_entities;
    $this->action = $action;
  }

  /**
   * Get the action.
   *
   * @return mixed
   *   The Action.
   */
  public function getAction() {
    return $this->action;
  }

  /**
   * Return draco entity that just created in memory.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *   The draco entity.
   */
  public function getDracoEntity() {
    return $this->dracoEntity;
  }

  /**
   * Return draco entity that has existed in db.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *   The draco entity.
   */
  public function getExistingDracoEntity() {
    return $this->existingDracoEntity;
  }

  /**
   * Return entities associated with the DracoEntity.
   *
   * @return array
   *    Entities
   */
  public function getAssociatedEntities() {
    return $this->associatedEntities;
  }

  /**
   * Get the entities that newly mapped from the $dracoEntity.
   *
   * @return array
   *   The entities.
   */
  public function getMappedContentEntities() {
    return $this->mappedContentEntities;
  }

  /**
   * Get the entities that have been mapped previously and found in db.
   *
   * @return array
   *   The entities.
   */
  public function getExistingMappedContentEntities() {
    return $this->existingMappedContentEntities;
  }

}
