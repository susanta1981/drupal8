<?php

namespace Drupal\draco_udi\DataChange;

use Drupal\Core\Entity\EntityManager;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\PostProcessor\DracoPostProcessorManager;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\ContentRemover\ContentRemoverManager;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\draco_udi\Service\DracoPersistenceServiceInterface;
use Drupal\draco_udi\Context;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class DataChangeDecisionProcessor.
 *
 * Process DataChangeDecisions.
 *
 * @package Drupal\draco_udi\DataChange
 */
class DataChangeDecisionProcessor implements DataChangeDecisionProcessorInterface, ContainerInjectionInterface {

  private $entityManager;
  private $persistenceService;
  private $postProcessorManager;
  private $eventDispatcher;
  private $logger;
  private $removeManager;

  /**
   * DataChangeDecisionProcessor constructor.
   *
   * @param \Drupal\Core\Entity\EntityManager $entity_manager
   *    Entity manager.
   * @param \Drupal\draco_udi\Service\DracoPersistenceServiceInterface $persistence_service
   *    Persistence service.
   * @param \Drupal\draco_udi\PostProcessor\DracoPostProcessorManager $postProcessor_manager
   *    Post Processor manager.
   * @param \Symfony\Component\EventDispatcher\EventDispatcherInterface $event_dispatcher
   *    Event dispatcher.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *    Logger factory.
   * @param ContentRemoverManager $remover_manager
   *    Content remover manager.
   */
  public function __construct(
      EntityManager $entity_manager,
      DracoPersistenceServiceInterface $persistence_service,
      DracoPostProcessorManager $postProcessor_manager,
      EventDispatcherInterface $event_dispatcher,
      LoggerChannelFactoryInterface $logger_factory,
      ContentRemoverManager $remover_manager
  ) {
    $this->entityManager = $entity_manager;
    $this->persistenceService  = $persistence_service;
    $this->postProcessorManager = $postProcessor_manager;
    $this->eventDispatcher = $event_dispatcher;
    $this->logger = $logger_factory->get('draco_udi');
    $this->removeManager = $remover_manager;
  }

  /**
   * {@inheritdoc}
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container) {
    return new static(
        $container->get('entity.manager'),
        $container->get('udiPersistence.service'),
        $container->get('plugin.manager.udi_post_processor'),
        $container->get('event_dispatcher'),
        $container->get('logger.factory'),
        $container->get('draco_udi.content.remover.manager')
      );
  }

  /**
   * Process the Change Decision and execute the action defined in context.
   *
   * Invoke post processor plugin to do things like dispatching events.
   *
   * @param Context $context
   *    The Context.
   */
  public function process(Context $context) {
    switch ($context->getAction()) {
      case ContentFetchManager::CONTENT_INSERT_ACTION:
      case ContentFetchManager::CONTENT_UPSERT_ACTION:
        $this->saveEntities($context);
        $this->logger->info("Entity has been saved for context : '@context'.", ['@context' => $context->getAction()]);
        break;

      case ContentFetchManager::CONTENT_DELETE_ACTION:
        $this->removeEntities($context);
        $this->logger->info("Entity has been deleted for context : '@context'.", ['@context' => $context->getAction()]);
        break;

      default:
        break;
    }

    $this->callPostProcessorPlugins($context);
  }

  /**
   * Save either the current entity or a pending entity.
   * The persistor will also save any related entities.
   *
   * @param \Drupal\draco_udi\Context $context
   *    The Context.
   *
   * @throws UdiProcessException
   */
  private function saveEntities(Context $context) {

    $decision = $context->getDataChangeDecision();

    if ($decision->getApproved()) {
      $context->setEntityToSave($context->getCurrentEntity());
    }
    else {
      $pending_content = $this->createPendingContentEntity($context);
      $context->setEntityToSave($pending_content);
    }

    try {
      $this->persistenceService->save($context);
    }
    catch (\Exception $e) {
      throw new UdiProcessException('Error saving processed entities.', 0, $e);
    }
  }

  /**
   * Create a PendingContent object.
   *
   * @param \Drupal\draco_udi\Context $context
   *    The Context.
   *
   * @return \Drupal\draco_udi\Entity\PendingContent|NULL
   *    Pending content.
   */
  private function createPendingContentEntity(Context $context) {
    /** @var \Drupal\draco_udi\Entity\PendingContent $pending_content */
    $pending_content = NULL;
    if ($this->entityManager != NULL) {
      $storage = $this->entityManager->getStorage("pending_content_entity");
      if ($storage != NULL) {
        $pending_content = $storage->create(array(
          'type' => 'pending_content_entity',
        ));
        $pending_content->copyValuesFromDracoContentEntity($context->getCurrentEntity());
      }
    }
    return $pending_content;
  }

  private function removeEntities(Context $context) {
    $remover_plugin = $this->removeManager->getRemover($context->getEntityType());

    try {
      if ($remover_plugin) {
        $removed_entities = $remover_plugin->remove($context->getCurrentEntity());
        $context->setDeletedEntities($removed_entities);
      }
      else {
        throw new UdiProcessException('Failed to find a ContentRemoverStrategy plugin to remove %s entity %s', $context->getEntityType(), $context->getCurrentEntity()->id());
      }
    }
    catch (\Exception $ex) {
      throw new UdiProcessException(sprintf('Error removing %s entity with id %s', $context->getEntityType(), $context->getCurrentEntity()->id()), 0, $ex);
    }
  }

  /**
   * Call all the Post Processor Plugins.
   *
   * @param Context $context
   *    The Context.
   */
  private function callPostProcessorPlugins(Context $context) {
    $plugins = $this->postProcessorManager->getDefinitions();
    foreach ($plugins as $postProcessor_plugin) {
      $instance = $this->postProcessorManager->createInstance($postProcessor_plugin['id']);
      $instance->process($context);
    }
  }

}
