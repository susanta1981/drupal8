<?php

namespace Drupal\draco_udi\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\DataSource\Tve\TveClientInterface;
use Psr\Log\LoggerInterface;
use Drupal\draco_udi\Service\ContentFetchManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

/**
 * Class UdiTveController.
 *
 * Controller to handle TVE posts and requests.
 *
 * @package Drupal\draco_udi\Controller
 */
class UdiTveController extends ControllerBase {

  protected $tveClient;

  /**
   * Content fetch manager.
   *
   * @var \Drupal\draco_udi\Service\ContentFetchManagerInterface
   */
  protected $fetchManager;

  /**
   * Logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * UdiTveController constructor.
   *
   * @param \Drupal\Core\Logger\LoggerInterface $logger_channel
   *   Logger.
   */
  public function __construct(ContentFetchManagerInterface $fetch_manager, LoggerInterface $logger_channel, TveClientInterface $tveClient) {
    $this->fetchManager = $fetch_manager;
    $this->logger = $logger_channel;
    $this->tveClient = $tveClient;
  }

  /**
   * Create method.
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('draco_udi.content.fetch.manager'),
      $container->get('draco_udi.logger.channel'),
      $container->get('draco_udi.tve.historical')
    );
  }

  /**
   * Post TV anywhere json for use in UDI workflow.
   *
   * @param string $title_id
   *   The title id.
   * @param Request $request
   *   The HTTP request object.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   Http Response
   */
  public function postTveJson($title_id, Request $request) {
    $status = Response::HTTP_CREATED;
    $msg = "Tve Content Created";
    $this->logger->debug("UDITveController::postTveJson received tve json for : @title_id: @json",
       ['@title_id' => $title_id, '@json' => $request->getContent()]);
    try {
      $this->fetchManager->postTveJson($request->getContent(), ContentFetchManager::CONTENT_SOURCE_TVE);
    }
    catch (\Exception $ex) {
      $status = Response::HTTP_INTERNAL_SERVER_ERROR;
      $msg = $ex->getMessage();
      $this->logger->debug("UDITveController error in postTveJson: @msg",
        ['@msg' => $msg]);
    }
    return new Response($msg, $status);
  }

}
