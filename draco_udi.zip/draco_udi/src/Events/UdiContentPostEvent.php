<?php

namespace Drupal\draco_udi\Events;

/**
 * Class UdiContentPostEvent.
 *
 * This event is dispatched for posting contents to upstream service, like ODT.
 *
 * @package Drupal\draco_udi\Events
 */
class UdiContentPostEvent extends UdiEvent {

  const UDI_CONTENT_POST_SUCCESSFUL = 'UDI content post successful';
  const UDI_CONTENT_POST_FAILED = 'UDI content post failed';

  
}
