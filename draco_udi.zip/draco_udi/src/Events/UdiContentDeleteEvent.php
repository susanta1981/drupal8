<?php

namespace Drupal\draco_udi\Events;

/**
 * Class UdiContentDeleteEvent.
 *
 * @package Drupal\draco_udi\Events
 */
class UdiContentDeleteEvent extends UdiContentImportEvent  {

  const UDI_CONTENT_DELETE_FAILED = 'UDI content delete failed';
  const UDI_CONTENT_DELETE_SUCCESSFUL = 'UDI content delete successful';

}