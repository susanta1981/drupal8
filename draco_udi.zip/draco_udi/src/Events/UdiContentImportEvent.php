<?php

namespace Drupal\draco_udi\Events;

/**
 * Class UdiContentImportEvent.
 *
 * @package Drupal\draco_udi\Events
 */
class UdiContentImportEvent extends UdiEvent {

  const UDI_CONTENT_IMPORT_SUCCESSFUL = 'UDI content import successful';
  const UDI_CONTENT_TITLE_IMPORT_SUCCESSFUL = 'UDI title content import successful';
  const UDI_CONTENT_LINEAR_SCHEDULE_IMPORT_SUCCESSFUL = 'UDI linear schedule content import successful';
  const UDI_CONTENT_ON_DEMAND_IMPORT_SUCCESSFUL = 'UDI on-demand content import successful';
  const UDI_CONTENT_IMPORT_NOT_APPROVED = 'UDI content import not approved';
  const UDI_CONTENT_IMPORT_FAILED = 'UDI content import failed';
  const UDI_CONTENT_TITLE_IMPORT_FAILED = 'UDI title import failed';
  const UDI_CONTENT_LINEAR_SCHEDULE_IMPORT_FAILED = 'UDI linear schedule import failed';
  const UDI_CONTENT_ON_DEMAND_IMPORT_FAILED = 'UDI on demand schedule import failed';

  /**
   * Type of Content imported.
   *
   * @var string
   */
  protected $type;

  /**
   * UdiContentImportEvent constructor.
   *
   * @type string $type
   *    Type of content imported ex onDemandSchedule,Title,etc
   * @param array $data
   *    Data used by listeners.
   */
  public function __construct($type, array $data) {
    parent::__construct($data);
    $this->type = $type;
  }

  /**
   * Get content type imported.
   *
   * @return string
   */
  public function getType() {
    return $this->type;
  }

  /**
   * Set content type imported.
   *
   * @param string $type
   */
  public function setType($type) {
    $this->type = $type;
  }

}
