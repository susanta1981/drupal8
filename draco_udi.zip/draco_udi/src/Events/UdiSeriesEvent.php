<?php

namespace Drupal\draco_udi\Events;
/**
 *
 */
class UdiSeriesEvent extends UdiEvent {

  const UDI_SERIES_CONTENT_IMPORT_SUCCESSFUL = 'UDI series import successful';

}
