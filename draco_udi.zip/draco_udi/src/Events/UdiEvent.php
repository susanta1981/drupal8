<?php

namespace Drupal\draco_udi\Events;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class UdiEvent.
 *
 * @package Drupal\draco_udi\Events
 */
class UdiEvent extends Event {


  /**
   * A variable holding data of interest for event listener.
   *
   * @var array
   */
  protected $data;

  /**
   * UdiEvent constructor.
   *
   * @param array $data
   *    Data used by listeners.
   */
  public function __construct(array $data) {
    $this->data = $data;
  }

  /**
   * Get array of data for listener.
   *
   * @return array
   *    Data.
   */
  public function getData() {
    return $this->data;
  }

  /**
   * Set an array of data that the listeners are interested in.
   *
   * @param array $data
   *    Data.
   */
  public function setData(array $data) {
    $this->data = $data;
  }

}
