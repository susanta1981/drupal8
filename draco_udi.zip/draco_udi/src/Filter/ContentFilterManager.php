<?php

namespace Drupal\draco_udi\Filter;

use Drupal\Core\Config\Config;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;

/**
 * Manager for Content Filters.
 */
class ContentFilterManager extends DefaultPluginManager {

  protected $config;

  /**
   * Constructor.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler, Config $config) {
    parent::__construct('Plugin/Filter', $namespaces, $module_handler, 'Drupal\draco_udi\Filter\ContentFilterInterface', 'Drupal\draco_udi\Annotation\ContentFilter');

    $this->alterInfo('content_filter_info');
    $this->setCacheBackend($cache_backend, 'content_filters');
    $this->config = $config;
  }

  /**
   * Return Filters for a content type and data source.
   *
   * @param string $content_type
   *    The data type for the content.
   * @param string $content_source
   *    The data source for the content.
   *
   * @return array
   *    Array of ContentFilter instances.
   */
  public function getFilters($content_type, $content_source) {
    $definitions = $this->getDefinitions();
    $filters = [];
    foreach ($definitions as $plugin_id => $definition) {
      if ($this->validateFilter($content_type, $content_source, $definition)) {
        $filters[] = $this->createInstance($plugin_id);
      }
    }
    return $filters;
  }

  /**
   * Check if the filter is for content_source and enabled.
   *
   * @param string $contentSource
   *    Upstread data source.
   * @param mixed $definition
   *    Filter Definition.
   *
   * @return bool
   *   True if valid, otherwise false.
   */
  protected function validateFilter($contentType, $contentSource, $definition) {
    $validFilter = FALSE;
    if ((!empty($definition)) && array_key_exists("dataType", $definition) && array_key_exists("dataSource", $definition)) {
      if ($definition['dataType'] == $contentType
        && $definition['dataSource'] == $contentSource
        && $this->isFilterEnabled($definition['id'])) {
        $validFilter = TRUE;
      }
    }
    return $validFilter;
  }

  /**
   * Determine if a filter is enabled in the UDI configuration.
   *
   * @param string $filter_id
   *   The identifier of the filter to check if it is enabled.
   *
   * @return boolean
   *   True if the filter is enabled.
   */
  private function isFilterEnabled($filter_id) {
    $active_filters = $this->config->get('filter_settings.active_filters');
    return in_array($filter_id, $active_filters);
  }

}
