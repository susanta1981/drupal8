<?php
namespace Drupal\draco_udi\Filter\UnusedFilters;
use Drupal\draco_udi\Plugin\Filter\TitleFilter;

// Filters are placed in UnusedFilters so Discovery process will not find them
//  To use this filter copy it to the Plugin/Filter direcoty and replace the
//  namespace line with this:
// namespace Drupal\draco_udi\Plugin\Filter;.
/**
 * Class OnDemandScheduleFilter.
 *
 * @package Drupal\draco_udi\Plugin\Reconciler
 *
 * @ContentFilter(id = "ondemand_schedule_filter",
 *                    dataType = "OnDemandSchedule",
 *                    dataSource = "ODT"  )
 */
class OnDemandScheduleFilter extends TitleFilter {

  /**
   * Filter Flow Linear Schedules.
   *
   * {@inheritDoc}
   */
  public function isApprovedContent($content) {
    $isApproved = FALSE;
    if (is_a($content, 'stdClass')) {
      if (!empty($content->options->titles)) {
        $isApproved = $this->checkTitles($content->options->titles);
      }
    }
    else {
      $this->logger->debug("OnDemandScheduleFilter content is not a stdClass Object: @content", ['@content' => $content]);
    }
    return $isApproved;
  }

  /**
   * Get the Series TitleId from the title Object that has a seriesTitleId.
   *
   * {@inheritDoc}.
   */
  protected function getSeriesTitleId($title) {
    $seriesTitleId = NULL;
    if (property_exists($title, "seriesTitleId")) {
      $seriesTitleId = $title->seriesTitleId;
    }
    return $seriesTitleId;

  }

  /**
   * Gets the Series Id from a series releated Object or a Series Object.
   *
   * {@inheritDoc}.
   */
  protected function getSeriesId($title) {
    $seriesId = NULL;
    if (!empty($this->getSeriesTitleId($title)) && $this->getSeriesTitleId($title) != 0) {
      $seriesId = $title->seriesTitleId;
    }
    else {
      $seriesId = $title->titleId;
    }
    return $seriesId;
  }

  /**
   * Get the ContentType of the Title Object.
   *
   * {@inheritDoc}.
   */
  protected function getContentType($title) {
    // ODT data sometimes returns the titleType as a string so we need to
    // decode it before getting value.
    $contentType = NULL;
    $titleType = NULL;
    if (property_exists($title, "titleType")) {
      $titleType = $title->titleType;
    }
    if (is_string($titleType)) {
      $titleData = json_decode($title->titleType);
      if ($titleData) {
        $contentType = $titleData->Name;
      }
    }
    else {
      $contentType = $title->titleType->Name;
    }
    return $contentType;
  }

}
