<?php
namespace Drupal\draco_udi\Filter\UnusedFilters;

use Drupal\draco_udi\Plugin\Filter\TitleFilter;

// Filters are placed in UnusedFilters so Discovery process will not find them
//  To use this filter copy it to the Plugin/Filter direcoty and replace the
//  namespace line with this:
// namespace Drupal\draco_udi\Plugin\Filter;.
/**
 * Class FlowLinearScheduleFilter.
 *
 * @package Drupal\draco_udi\Plugin\Filter       s
 *
 * @ContentFilter(id = "flow_linear_filter",
 *                    dataType = "LinearSchedule",
 *                    dataSource = "flow"  )
 */
class FlowLinearScheduleFilter extends TitleFilter {

  /**
   * Filter Flow Linear Schedules.
   *
   * {@inheritDoc}
   */
  public function isApprovedContent($content) {
    $isApproved = FALSE;
    if (is_a($content, 'stdClass')) {
      if (!empty($content->Titles)) {
        $isApproved = $this->checkTitles($content->Titles);
      }
    }
    else {
      $this->logger->debug("FlowLinearSchedule Filter content is not a stdClass Object: @content", ['@content' => $content]);
    }
    return $isApproved;
  }

}
