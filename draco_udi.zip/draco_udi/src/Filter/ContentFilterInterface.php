<?php

namespace Drupal\draco_udi\Filter;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;

/**
 * Defines content filter interface.
 */
interface ContentFilterInterface extends ContainerFactoryPluginInterface {

  /**
   * Determines if the content should be filtered out.
   *
   * @param mixed $content
   *    The data to filter.
   *
   * @return bool
   *   Boolean value indicating if content is allowed to proceed.  True will
   *   mean content is allowed to continue.  False will mean data should be
   *   filtered out.
   */
  public function isApprovedContent($content);

}
