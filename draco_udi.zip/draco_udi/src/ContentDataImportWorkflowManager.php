<?php

namespace Drupal\draco_udi;

use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\draco_udi\DataChange\DataChangeDecision;
use Drupal\draco_udi\DataChange\DataChangeDecisionProcessor;
use Drupal\draco_udi\Entity\ContentLinearSchedule;
use Drupal\draco_udi\Entity\ContentOnDemandSchedule;
use Drupal\draco_udi\Entity\ContentTitle;
use Drupal\draco_udi\Entity\ContentTitleInterface;
use Drupal\draco_udi\Events\UdiContentImportEvent;
use Drupal\draco_udi\Exception\UdiContentNotFoundException;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\Service\ContentConverter\ContentConverterManager;
use Drupal\draco_udi\Mapper\DracoDataMapperManager;
use Drupal\draco_udi\DataChange\DataChangeDecisionStrategyManager;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\Preparation\DataChangePreparerInterface;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\Serializer\Encoder\JsonEncode;
use Symfony\Component\Serializer\Encoder\JsonEncoder;

/**
 * Imports items from content source, e.g., Flow.
 *
 * @class ContentDataImportWorkflowManager
 */
class ContentDataImportWorkflowManager implements ContainerInjectionInterface {

  /**
   * ContentConvertedManager.
   *
   * @var \Drupal\draco_udi\Service\ContentConverter\ContentConverterManager
   */
  protected $contentConverterManager;

  /**
   * EntityMapperPluginManager.
   *
   * @var \Drupal\draco_udi\Mapper\DracoDataMapperManager
   */
  protected $entityMapperPluginManager;

  /**
   * DataChangeApprover.
   *
   * @var \Drupal\draco_udi\DataChange\DataChangeDecisionStrategyManager
   */
  protected $dataChangeApprover;

  /**
   * ChangeDecisionProcessor.
   *
   * @var \Drupal\draco_udi\DataChange\DataChangeDecisionProcessor
   */
  protected $changeDecisionProcessor;

  /**
   * DataChangePreparer.
   *
   * @var \Drupal\draco_udi\Service\Preparation\DataChangePreparerInterface
   */
  protected $dataPreparer;

  /**
   * @var \Drupal\draco_logging\Diagnostic\DiagnosticLoggerChannel
   */
  protected $logger;

  /**
   * @var \Symfony\Component\Serializer\Encoder\JsonEncoder
   */
  protected $jsonEncoder;

  /**
   * @var \Symfony\Component\EventDispatcher\EventDispatcherInterface
   */
  protected $eventDispatcher;

  /**
   * ContentDataImportWorkflowManager constructor.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *    Have to inject factory as this class is loaded as a service.
   * @param \Drupal\draco_udi\Service\ContentConverter\ContentConverterManager $content_converter_manager
   *    Source content data converter.
   * @param \Drupal\draco_udi\Mapper\DracoDataMapperManager $entity_mapper_plugin_manager
   *     Mapper manager.
   * @param \Drupal\draco_udi\DataChange\DataChangeDecisionStrategyManager $data_change_approver
   *    Evaluate and approve an import.
   * @param \Drupal\draco_udi\DataChange\DataChangeDecisionProcessor $change_decision_processor
   *    Save source content and converted content type entity and send report.
   * @param \Drupal\draco_udi\Service\Preparation\DataChangePreparerInterface $data_preparer
   *    Data preparer object.
   * @param \Symfony\Component\EventDispatcher\EventDispatcherInterface $event_dispatcher
   *    Event dispatcher.
   */
  public function __construct(
      LoggerChannelFactoryInterface $logger_factory,
      ContentConverterManager $content_converter_manager,
      DracoDataMapperManager $entity_mapper_plugin_manager,
      DataChangeDecisionStrategyManager $data_change_approver,
      DataChangeDecisionProcessor $change_decision_processor,
      DataChangePreparerInterface $data_preparer,
      EventDispatcherInterface $event_dispatcher
  ) {
    $this->logger = $logger_factory->get('draco_udi');
    $this->contentConverterManager = $content_converter_manager;
    $this->entityMapperPluginManager = $entity_mapper_plugin_manager;
    $this->dataChangeApprover = $data_change_approver;
    $this->changeDecisionProcessor = $change_decision_processor;
    $this->dataPreparer  = $data_preparer;
    $this->eventDispatcher = $event_dispatcher;

    $this->jsonEncoder = new JsonEncoder(new JsonEncode());
  }

  /**
   * Create an instance.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The service container this instance should use.
   *
   * @return ContentDataImportWorkflowManager
   *    This.
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container) {
    return new static($container->get('logger.factory'),
      $container->get('draco_udi.content.converter.manager'),
      $container->get('plugin.manager.udi_data_mapper'),
      $container->get('plugin.manager.udi_data_change_approver'),
      $container->get('draco_udi.decision.processor'),
      $container->get('draco_udi.data.preparer'),
      $container->get('event_dispatcher'));
  }

  /**
   * Import one item into Drupal. This is starting point of the workflow.
   *
   * It first maps the item to a draco content entity. If it is a title entity,
   * the workflow maps it to site specific content entities like episode and
   * feature film.
   * If it is a schedule entity, it will bypass the mapping phrase and directly
   * go to the approval phrase.
   *
   * @param \stdClass $item
   *    A json object downloaded from a content source.
   * @param string $type
   *    Type of pipeline message used to determine if mapping is needed.
   * @param string $action
   *    A string extracted from notification,
   *    such as action type, like "update", "delete", etc.
   * @param string $source
   *   Source of pipeline message.
   *
   * @return array
   *   List of WorkflowReport objects for logging and debugging.
   *
   * @throws \Exception
   */
  public function import(\stdClass $item, $type, $action, $source = NULL) {
    $return_data = [];
    $entity_set = NULL;

    $this->draco_logging($type, $item, $action);

    $this->logger->info('------Udi import process Starts.-----');
    try {
      $draco_entity_sets = $this->convertContentDataToDracoEntity($item, $type);

      /** @var \Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet $draco_entity_set */
      foreach ($draco_entity_sets as $draco_entity_set) {
        $entity_set = $draco_entity_set;
        $target_type = $draco_entity_set->getTargetType();
        $return_data[] = $this->processImport($draco_entity_set, $target_type, $action, $source);
      }
    }
    catch (UdiProcessException $e) {
      $msg = sprintf('Error processing a %s content for %s. Error message: %s', $type, $action, $e->getMessage());
      $return_data[] = new WorkflowReport(WorkflowReport::ERROR, NULL, $msg);
      $this->dispatchErrorEvent($item, $msg, $type, $action, $source, $entity_set);
    }
    catch(\InvalidArgumentException $e) {
      $msg = sprintf('Error processing a %s content for %s due to invalid content data. Error message: %s', $type, $action, $e->getMessage());
      $return_data[] = new WorkflowReport(WorkflowReport::ERROR, NULL, $msg);
      $this->dispatchErrorEvent($item, $msg, $type, $action, $source, $entity_set);
    }
    catch (\Exception $e) {
      $msg = sprintf('Error importing a %s content for %s. Error message: %s', $type, $action, $e->getMessage());
      $this->dispatchErrorEvent($item, $msg, $type, $action, $source, $entity_set);
      throw $e;
    }

    $this->logger->info('------Udi Import process Ends.------');
    return $return_data;
  }

  /**
   *
   * This uses draco_logging module method setDiagnosticData.
   *
   * @param string $type
   *    Type of pipeline message used to determine if mapping is needed.
   * @param \stdClass $item
   *    A json object downloaded from a content source.
   * @param string $action
   *    A string extracted from notification,
   *    such as action type, like "update", "delete", etc.
   */
  private function draco_logging($type, $item, $action) {
    try {
      $lid = '';

      switch ($type) {
        case ContentFetchManager::CONTENT_TITLE_TYPE;
          $lid = $item->TitleId;
          break;

        case ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE;
          $lid = $item->ExternalId;
          break;

        case ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE;
          $lid = $item->airingId;
          break;
      }
      $this->logger->setDiagnosticData([
        'ImportType' => $type,
        'ID' => $lid,
        'Action' => $action
      ]);
    }
    catch (\Exception $er) {
      $this->logger->error("Problem setting diagnostic logging data. Cause:'@reason, @trace'",
        ['@reason' => $er->getMessage(), '@trace' => $er->getTraceAsString()]);
    }
  }

  /**
   * Dispatch an error event and log error message.
   *
   * Values for Arguments $type, $action, and $source are defined
   * in ContentFetchManager.
   *
   * @see \Drupal\draco_udi\Service\ContentFetchManager
   *
   * @param \stdClass $item
   *   Downloaded source content.
   * @param string $message
   *   Error message.
   * @param string $type
   *   UDI content type
   * @param string $action
   *   UDI action code
   * @param string $source
   *   UDI data source
   * @param \Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet $converted_entity_set|null
   *   ConvertedEntitySet object.
   */
  private function dispatchErrorEvent(\stdClass $item, $message, $type, $action, $source, ConvertedEntitySet $converted_entity_set = NULL) {
    $this->logger->error($message);

    $data = [];
    $data['action'] = $action;
    $data['source'] = $source;
    $data['contentType'] = $type;
    $data['sourceContent'] = $item;
    $data['errorMessage'] = $message;

    $event = new UdiContentImportEvent(UdiContentImportEvent::UDI_CONTENT_IMPORT_FAILED, $data);

    // Get additional data on specific content types.
    if (!empty($converted_entity_set)) {
      $converted_entity = $converted_entity_set->getConvertedEntity();

      if ($converted_entity instanceof ContentLinearSchedule) {
        $data['externalId'] = $converted_entity->getExternalId();
        $data['titleIds'] = $converted_entity->getTitleIdList();
        $event->setType(UdiContentImportEvent::UDI_CONTENT_LINEAR_SCHEDULE_IMPORT_FAILED);
      }
      elseif ($converted_entity instanceof ContentOnDemandSchedule) {
        $data['airingId'] = $converted_entity->getAiringId();
        $data['mediaId'] = $converted_entity->getMediaId();
        $data['titleIds'] = $converted_entity->getTitleIdList();
        $event->setType(UdiContentImportEvent::UDI_CONTENT_ON_DEMAND_IMPORT_FAILED);
      }
      elseif ($converted_entity instanceof ContentTitle) {
        $data['titleId'] = $converted_entity->getTitleId();
        $event->setType(UdiContentImportEvent::UDI_CONTENT_TITLE_IMPORT_FAILED);
      }

      $event->setData($data);
    }

    $this->eventDispatcher->dispatch($event->getType(), $event);
  }

  /**
   * Remove an entity from database or make an entity as removed.
   *
   * What remove means depends on entity types, and implemented by type
   * specific entity removal plugins.
   *
   * @param \stdClass $item
   *    A json object downloaded from a content source.
   * @param string $type
   *    Type of pipeline message used to determine if mapping is needed.
   * @param string $source
   *   Source of pipeline message.
   *
   * @return array
   *    Array of reporting data objects.
   *
   * @throws \Exception
   * @throws UdiContentNotFoundException
   */
  public function remove(\stdClass $item, $type, $source = NULL) {
    $messages = [];

    $action = ContentFetchManager::CONTENT_DELETE_ACTION;
    $this->draco_logging($type, $item, $action);
    $this->logger->info("------Udi import 'remove' process Starts.-----");

    try {
      $entity = $this->loadExistingEntity($item, $type);
    }
    catch (\Exception $e){
      $msg = sprintf('Error finding %s entity to remove based on message %s', $type, $this->jsonEncoder->encode($item, 'json'));
      $this->logger->error($msg);
      throw new UdiContentNotFoundException($msg, 0, $e);
    }

    if(!$entity) {
      $msg = sprintf('Not found %s entity to remove based on message %s', $type, $this->jsonEncoder->encode($item, 'json'));
      $this->logger->error($msg);
      throw new UdiContentNotFoundException($msg, 0, NULL);
    }

    try {
      $this->logger->debug('Load @type entity based on data @data',
        ['@type' => $type, '@data' => $this->jsonEncoder->encode($item, 'json')]);

      $context = $this->dataPreparer->prepareContextForRemoveEntity($entity, $type, $source);
      $context->setAction(ContentFetchManager::CONTENT_DELETE_ACTION);

      $this->evaluateContentEntities($context);
      $this->changeDecisionProcessor->process($context);
      $messages[] = $this->getWorkflowReport(WorkflowReport::COMPLETE, $context);
    }
    catch (\Exception $ex) {
      $this->logger->error('Error removing @type entity based on delete message @data. Exception messages: ' . $ex->getMessage(),
        ['@type'=> $type, '@data'=> $this->jsonEncoder->encode($item, 'json')]);
      throw $ex;
    }

    $this->logger->info("------Udi import 'remove' process Ends.-----");

    return $messages;
  }

  /**
   * Load a Draco entity using the data in the passed item.
   *
   * @param \stdClass $item
   *    Data fetched from queue.
   * @param string $type
   *    Content type, e.g., LinearSchedule, Title, OnDemandSchedule.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface|NULL
   *
   * @throws \Exception
   */
  private function loadExistingEntity(\stdClass $item, $type) {
    $converters = $this->contentConverterManager->getConverters($type);
    $existing_entity = NULL;

    if (!empty($converters)) {
      try {
        /** @var  \Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface $converter */
        foreach ($converters as $converter) {
          $existing_entity = $converter->findExistingEntity($item);

          if($existing_entity) {
            break;
          }
        }
      }
      catch (\Exception $ex) {
        throw new UdiProcessException('Error finding existing content of type ' . $type, 0, $ex);
      }
    }
    else {
      throw new UdiProcessException('Converter plugin not found for ' . $type);
    }

    return $existing_entity;
  }


  /**
   * Process an imported content as a converted Draco entity, e.g.,ContentTitle.
   *
   * @param ConvertedEntitySet $draco_entity_set
   *    The set contains the converted entity along with related entities.
   * @param string $type
   *    Type of pipeline message used to determine if mapping is needed.
   * @param string $action
   *    A string extracted from notification
   * @param string $source
   *   Source of pipeline message.
   *
   * @return DataChangeDecision
   *   Decision object for logging or displaying.
   */
  private function processImport(ConvertedEntitySet $draco_entity_set, $type, $action,$source) {
    $context = $this->dataPreparer->prepareContext($draco_entity_set, $type, $source);
    $context->setAction($action);
    $relatedData = $context->getRelatedData();

    // Update context with mapped entities and related entities.
    foreach ($relatedData[Context::RELATED_TO_BE_MAPPED_KEY] as $entityToBeMapped) {
      $relatedData[Context::RELATED_MAPPED_CONTENT_KEY][$entityToBeMapped->id()] = [];
      $mapped_entity = $this->mapToContentEntity($entityToBeMapped);
      $relatedData[Context::RELATED_MAPPED_CONTENT_KEY][$entityToBeMapped->id()] = $mapped_entity;
    }

    $context->setRelatedData($relatedData);

    // Evaluate and decide what to do with the draco entity and mapped
    // site entities.
    $this->evaluateContentEntities($context);

    // Do final processing, including entity persistence and post processing.
    $this->changeDecisionProcessor->process($context);

    return $this->getWorkflowReport(WorkflowReport::COMPLETE, $context);
  }

  /**
   * Create and return an WorkflowReport object for a completed import.
   *
   * @param string $status
   *    Status code.
   * @param \Drupal\draco_udi\Context $context | NULL
   *    Context object.
   * @param string $message | NULL
   *    Message.
   *
   * @return WorkflowReport
   *    Report object.
   */
  private function getWorkflowReport($status, Context $context = NULL, $message = NULL) {
    $report = new WorkflowReport();
    $report->setStatus($status);

    if ($context) {
      $report->setAction($context->getAction());
      $report->setContentSource($context->getEntitySource());
      $report->setContentType($context->getEntityType());

      if ($context->getCurrentEntity()) {
        $report->setEntityId($context->getCurrentEntity()->id());
      }
    }
    else {
      $report->setMessage($message);
    }

    return $report;
  }

  /**
   * Convert Content Data to Draco Entity and returns ConvertedEntitySets.
   *
   * We support converting a source object to more than one Draco entities, e.g.
   * a TVE XML data set is converted to a ContentTitle and a
   * ContentOnDemandSchedule.
   *
   * @param \stdClass $item
   *    Data downloaded from upstream.
   * @param string $converter_id
   *    Message type used as converter id, e.g., 'Title',
   *    'LinearSchedule', "OnDemandSchedule".
   *
   * @return array
   *    Array of objects of ConvertedEntitySet type.
   *
   * @throws \Exception
   * @throws UdiProcessException
   */
  private function convertContentDataToDracoEntity(\stdClass $item, $converter_id) {
    $converters = $this->contentConverterManager->getConverters($converter_id);
    $converted_sets = [];

    if (!empty($converters)) {
      try {
        /** @var  \Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface $converter */
        foreach ($converters as $converter) {
          if ($converter) {
            $existing_entity = $converter->findExistingEntity($item);
            $converted_sets[] = $converter->convert($item, $existing_entity);
          }
          else {
            $this->logger->error('Draco entity converter for @type is null.', ['@type' => $converter_id]);
            throw new UdiProcessException('Draco entity converter for ' . $converter_id . ' is null.');
          }
        }
      }
      catch (\Exception $ex) {
        throw new UdiProcessException('Error converting imported content of type ' . $converter_id, 0, $ex);
      }
    }
    else {
      throw new UdiProcessException('Converter plugin not found for ' . $converter_id);
    }

    return $converted_sets;
  }

  /**
   * Look up mappers and map a content source to a corresponding content type.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title_entity
   *    Newly converted content title entity.
   *
   * @return array
   *    An array of mapped content entities and their previous versions
   *    found in db if exists.
   */
  private function mapToContentEntity(ContentTitleInterface $title_entity) {
    $mappers = $this->entityMapperPluginManager->getMappers($title_entity->getTitleType());

    if (empty($mappers)) {
      $this->logger->warning("No mappers found for mapping '@type' content entity",
        ['@type' => $title_entity->getTitleType()]
      );

      return [];
    }
    else {
      $this->logger->warning("Found a mapper for '@type' content entity.", ['@type' => $title_entity->getTitleType()]);
    }

    $mapped_entities = [];

    /** @var \Drupal\draco_udi\Mapper\DracoMapperInterface $mapper */
    foreach ($mappers as $mapper) {
      $mapped_entities = $mapper->map($title_entity, $title_entity->getMappedContents());
    }

    if (empty($mapped_entities)) {
      // Can be NULL that is not acceptable by persistence service.
      $mapped_entities = [];
      $this->logger->warning("No mapped entities returned when mapping a '@type' content entity",
        ['@type' => $title_entity->getTitleType()]
      );
    }
    else {
      $this->logger->info("Mapped a Draco '@type' entity to a brand entity",
        ['@type' => $title_entity->getTitleType()]);
    }

    return $mapped_entities;
  }

  /**
   * Evaluate the Content Entities.
   *
   * @param Context $context
   *   The workflow context object.
   */
  private function evaluateContentEntities(Context $context) {
    $decision_data = NULL;
    $definitions = $this->dataChangeApprover->getDefinitions();

    $draco_entity = $context->getCurrentEntity();
    $action = $context->getAction();

    if (empty($definitions)) {
      $msg = 'No data change approve strategy found for @action on @itemName';
      $this->logger->warning($msg, ['@action' => $action, '@itemName' => $draco_entity->getName()]);
    }
    else {
      foreach ($definitions as $plugin_id => $definition) {
        $decision_maker = $this->dataChangeApprover->createInstance($plugin_id);

        /*** @var \Drupal\draco_udi\DataChange\DataChangeDecision $decision_data */
        $decision_data = $decision_maker->decide($context);
        $this->logger->info("Evaluating the Content Entities");
      }
    }

    $context->setDataChangeDecision($decision_data);
  }

}
