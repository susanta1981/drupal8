<?php

namespace Drupal\draco_udi\Service;

use Aws\CloudFront\Exception\Exception;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\draco_udi\Events\UdiContentImportEvent;
use Drupal\draco_udi\Exception\LastUpdatedDateNotFoundException;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\Filter\ContentFilterManager;
use Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface;
use Drupal\draco_udi\Service\DataSource\OdtClientInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\draco_udi\Service\Queue\UdiQueueClientInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\State\State;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Validator\Exception\NoSuchMetadataException;

/**
 * Class ContentFetchManager.
 *
 * Fetches Contents/messages from upstream systems and posts to queue.
 *
 * @package Drupal\draco_udi\Service
 */
class ContentFetchManager implements ContainerInjectionInterface, ContentFetchManagerInterface, EventSubscriberInterface {

  // This const is part of some very temporary testing code.  It will only
  // be here for a few days.   See comments in the processOdtQueueMsg
  // method for more details.
  const AVS_TESTING = FALSE;


  const TITLES_LAST_UPDATED_KEY = 'draco_udi.titles_last_updated';
  const LINEAR_SCHEDULE_LAST_UPDATED_KEY = 'draco_udi.linear_schedule_last_updated';
  const LINEAR_SCHEDULE_LAST_DELETED_KEY = 'draco_udi.linear_schedule_last_deleted';
  const CONTENT_TITLE_TYPE = "Title";
  const CONTENT_LINEAR_SCHEDULE_TYPE = "LinearSchedule";
  const CONTENT_ONDEMAND_SCHEDULE_TYPE = "OnDemandSchedule";
  const CONTENT_ONDEMAND_WORKORDER_TYPE = "OnDemandWorkOrder";
  const CONTENT_ONDEMAND_FLIGHT_TYPE = "OnDemandFlight";
  const CONTENT_HISTORICAL_TVE_TYPE = "HistoricalTVE";
  const CONTENT_SOURCE_FLOW = "flow";
  const CONTENT_SOURCE_TVE = "TVE";
  const CONTENT_SOURCE_HISTORICAL_TVE = "HistoricalTVE";
  const CONTENT_SOURCE_ODT = "ODT";
  const CONTENT_SOURCE_WORKORDER = "OdtWorkOrder";
  const CONTENT_UPSERT_ACTION = "upsert";
  const CONTENT_INSERT_ACTION = "insert";
  const CONTENT_DELETE_ACTION = "delete";
  const ONE_SECOND = "PT1S";

  /**
   * Logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * FlowClient.
   *
   * @var \Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface
   */
  protected $flowClient;

  /**
   * Odt Queue Client.
   *
   * @var \Drupal\draco_udi\Service\Queue\UdiQueueClientInterface
   */
  protected $odtQueueClient;


  /**
   * Odt http Client.
   *
   * @var \Drupal\draco_udi\Service\DataSource\OdtClientInterface
   */
  protected $odtHttpClient;

  /**
   * State.
   *
   * @var \Drupal\Core\State\State
   */
  protected $state;

  /**
   * Client to comunicate with Queue.
   *
   * @var \Drupal\draco_udi\Service\Queue\UdiQueueClientInterface
   */
  protected $queueClient;

  /**
   * Filter Manager.
   *
   * @var \Drupal\draco_udi\Filter\ContentFilterManager
   */
  protected $filterManager;

  /**
   * ContentDataImportWorkflowManager constructor.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $channelFactory
   *    Have to inject factory as this class is loaded as a service.
   * @param \Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface $flowClient
   *    Flow Client.
   * @param \Drupal\draco_udi\Service\Queue\UdiQueueClientInterface $odtQueueClient
   *    ODT Queue Client.
   * @param \Drupal\draco_udi\Service\DataSource\OdtClientInterface $odtHttpClient
   *    ODT Http Client.
   * @param \Drupal\draco_udi\Service\Queue\UdiQueueClientInterface $queueClient
   *    Queue Client.
   * @param ContentFilterManager $filterManager
   *    Filter manager.
   * @param \Drupal\Core\State\State $state
   *    State.
   */
  public function __construct(
    LoggerChannelFactoryInterface $channelFactory,
    FlowClientInterface $flowClient,
    UdiQueueClientInterface $odtQueueClient,
    OdtClientInterface $odtHttpClient,
    UdiQueueClientInterface $queueClient,
    ContentFilterManager $filterManager,
    State $state
  ) {
    $this->logger = $channelFactory->get('draco_udi');
    $this->flowClient = $flowClient;
    $this->odtQueueClient = $odtQueueClient;
    $this->odtHttpClient = $odtHttpClient;
    $this->state = $state;
    $this->queueClient = $queueClient;
    $this->filterManager = $filterManager;
  }

  /**
   * Create an instance.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The service container this instance should use.
   *
   * @return array
   *    array of services.
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('logger.factory'),
      $container->get('draco_udi.flow.client'),
      $container->get('draco_udi.odt.queue.client'),
      $container->get('draco_udi.odt.http.client'),
      $container->get('draco_udi.queue.client'),
      $container->get('draco_content_filter_manager'),
      $container->get('state')
    );
  }

  /**
   * Fetch Titles from flow.
   *
   * {@inheritdoc}
   */
  public function fetchTitles($lastFetched = NULL) {
    try {
      $this->logger->info("------Download fetch titles updated-since starts.------");
      $this->fetchUpdateSinceDataFromFlow(self::CONTENT_TITLE_TYPE, self::TITLES_LAST_UPDATED_KEY, $lastFetched);
    }
    catch (\Exception $ex) {
      $msg = "(fetchTitles) Error fetch titles. Error message: " . $ex->getMessage();
      $this->logger->error($msg);
      throw new UdiProcessException($msg);
    }
    $this->logger->info("------Download fetch titles updated-since Ends.------");
  }

  /**
   * Fetch Linear Schedules.
   *
   * {@inheritdoc}
   */
  public function fetchLinearSchedules() {
    try {
      $this->logger->info('------Download Linear Schedule Starts.------');
      $this->fetchUpdateSinceDataFromFlow(self::CONTENT_LINEAR_SCHEDULE_TYPE, self::LINEAR_SCHEDULE_LAST_UPDATED_KEY);
    }
    catch (\Exception $e) {
      $msg = "(fetchLinearSchedules) Error fetch linear schedules. Error message: " . $e->getMessage();
      $this->logger->error($msg);

      // Throw out this special exception and let drush command handle it.
      if ($e instanceof LastUpdatedDateNotFoundException) {
        throw $e;
      }
      else {
        throw new UdiProcessException($msg);
      }
    }
    $this->logger->info('------Download Linear Schedule Ends.------');
  }

  /**
   * {@inheritdoc}
   */
  public function syncLinearSchedules(\DateTime $start_date) {
    if (!$start_date) {
      throw new UdiProcessException('(syncLinearSchedules) Start date is not provided.');
    }

    $this->logger->info("------Download sync LinearSchedule with StartDate:'@date' Starts.------",
      ['@date' => $start_date->format('Y-m-d H:i:s')]);

    // Get the BSON ID representing a date that is used by the updated-since API to get all
    // schedules for the specified start date.
    $bson_id = $this->flowClient->getBSONIdFromFlow($start_date);

    if ($bson_id) {
      // Set the date based on the BSON ID as the actual starting date.
      $fetch_start = new \DateTime();
      $time_stamp = $this->flowClient->getTimeStampFromFlowObjectid($bson_id);
      $fetch_start->setTimestamp($time_stamp);

      try {
        $this->fetchUpdateSinceDataFromFlow(self::CONTENT_LINEAR_SCHEDULE_TYPE, self::LINEAR_SCHEDULE_LAST_UPDATED_KEY, $fetch_start, $start_date);
      }
      catch (\Exception $ex) {
        $msg = sprintf('Error sync linear schedules with start date %s. Error message: %s', $start_date->format('c'), $ex->getMessage());
        $this->logger->error($msg);
        throw new UdiProcessException($msg);
      }
    }
    else {
      $msg1 = sprintf('Failed to get BSON ID from FLOW for start date %s', $start_date->format('c'));
      $this->logger->error($msg1);
      throw new UdiProcessException($msg1);
    }
    $this->logger->info("------Download Sync LinearSchedule Ends.------");
  }

  /**
   * Sample of a deleted since message object.
   *
   *   {
   *      _id": "581a550518bcda084ca3e4e1",
   *       ExternalId": "10060477",
   *       ProcessedDatetimeUTC": "2016-11-02T21:05:09.563Z"
   *   }
   *
   * {@inheritdoc}
   */
  public function fetchLinearScheduleDeletedSinceMessages($lastFetched = NULL) {
    if ($lastFetched == NULL) {
      $lastFetched = $this->getLastUpdatedDate(self::LINEAR_SCHEDULE_LAST_DELETED_KEY);
      if (empty($lastFetched)) {
        $this->logger->error("(fetchLinearScheduleDeletedSinceMessages) must have a lastFetched Date");
        throw new \InvalidArgumentException("Must supply lastFetchedDate");
      }
    }
    $this->logger->info("------Download LinearScedule deleted-since message Starts.------");
    $deleted_messages = $this->flowClient->getDeletedSince($lastFetched, self::CONTENT_LINEAR_SCHEDULE_TYPE);

    if (empty($deleted_messages)) {
      $this->logger->info("(fetchLinearScheduleDeletedSinceMessages) Flow returns no deleted messages for @type since @date",
        ['@type' => self::CONTENT_LINEAR_SCHEDULE_TYPE, '@date' => $lastFetched->format('Y-m-d H:i:s')]);
    }
    else {
      $this->logger->info("(fetchLinearScheduleDeletedSinceMessages) Flow returns @count deleted messages for @type since @date",
        [
          '@count' => count($deleted_messages),
          '@type' => self::CONTENT_LINEAR_SCHEDULE_TYPE,
          '@date' => $lastFetched->format('Y-m-d H:i:s'),
        ]);

      foreach ($deleted_messages as $message) {
        $this->postToQueue($message,
          new \DateTime(),
          self::CONTENT_LINEAR_SCHEDULE_TYPE,
          self::CONTENT_SOURCE_FLOW,
          self::CONTENT_DELETE_ACTION,
          FALSE);
      }

      $lastFetched = $lastFetched->add(new \DateInterval(self::ONE_SECOND));
      $this->setLastUpdatedDate($lastFetched, self::LINEAR_SCHEDULE_LAST_DELETED_KEY);
    }
    $this->logger->info("------Download LinearScedule deleted-since message Ends.------");
  }

  /**
   * Fetch Linear Schedules.
   *
   * {@inheritdoc}
   */
  public function fetchLinearSchedulesForDateRange(\DateTime $startDate, \DateTime $endDate) {
    try {
      $this->logger->info('------Download Linear Schedule by Date Range Starts.------');
      $schedules = $this->flowClient->getLinearSchedulesbyDateRange($startDate, $endDate);
      if ($schedules != NULL && count($schedules) > 0) {
        foreach ($schedules as $flowSchedule) {
          $this->processFlowData($flowSchedule, self::CONTENT_LINEAR_SCHEDULE_TYPE, new \DateTime());
        }
      }
    }
    catch (\Exception $ex) {
      $this->logger->error('(fetchLinearSchedulesForDateRange) exception occurred: @msg Detailed messages: @trace',
        array(
          '@msg' => $ex->getMessage(),
          '@trace' => $ex->getTraceAsString(),
        ));
    }
    $this->logger->info('------Download Linear Schedule By Date Range Ends.------');

  }

  /**
   * {@inheritdoc}
   */
  public function fetchOnDemandSchedules($time_limit, $max_items) {
    try {
      $this->logger->info("------Download OnDemandSchedules with TimeLimit: '@limit' and MaxItems: '@max' starts------",
        ['@limit' => $time_limit, '@max' => $max_items]);
      $this->odtQueueClient->listen($this->processOdtQueueMsg(self::CONTENT_ONDEMAND_SCHEDULE_TYPE, self::CONTENT_SOURCE_ODT), $time_limit, $max_items);
    }
    catch (\Exception $ex) {
      $this->logger->error('(fetchOnDemandSchedules) exception occurred: @msg Detailed messages: @trace',
        array(
          '@msg' => $ex->getMessage(),
          '@trace' => $ex->getTraceAsString(),
        ));
    }
    $this->logger->info('------Download OnDemandSchedule Ends-----');
  }

  /**
   * Fetch On Demand WorkOrders.
   *
   * {@inheritdoc}
   */
  public function fetchOnDemandWorkOrders($time_limit, $max_items) {
    try {
    $this->logger->info('--------Download ODWorkOrder Starts----------');
      $this->logger->info("(fetchOnDemandWorkOrders) start fetching on-demand work orders with a time limit @limit and max items of @max", ['@limit' => $time_limit, '@max' => $max_items]);
      $this->odtQueueClient->listen($this->processOdtQueueMsg(self::CONTENT_ONDEMAND_WORKORDER_TYPE, self::CONTENT_SOURCE_WORKORDER), $time_limit, $max_items);;
    }
    catch (\Exception $ex) {
      $this->logger->error('(fetchOnDemandWorkOrders) exception occurred: @msg Detailed messages: @trace',
        array(
          '@msg' => $ex->getMessage(),
          '@trace' => $ex->getTraceAsString(),
        ));
    }
    $this->logger->info('--------Download ODWorkorder Ends----------');
  }

  /**
   * Post TVE Json.
   *
   * {@inheritdoc}
   */
  public function postTveJson($data, $tve_type) {
    try {
      $tveJson = json_decode($data);
      if ($tveJson) {
        $this->postToQueue($tveJson, new \DateTime(), $tve_type, $tve_type, self::CONTENT_UPSERT_ACTION);
      }
      else {
        $this->logger->error('(postTveJson) data could not be decoded : @data', array('@data' => $data));
      }
    }
    catch (\Exception $ex) {
      $this->logger->error('(postTveJson) exception occurred: @msg Detailed messages: @trace',
        array(
          '@msg' => $ex->getMessage(),
          '@trace' => $ex->getTraceAsString(),
        ));
    }

  }

  /**
   * Calls updateSince and processes Flow data returned from call.
   *
   * For sync linear schedules the argument $expire_date is the start date
   * that is used as a criterion to determine if a downloaded linear schedule
   * should be imported.
   *
   * @param string $type
   *   Type of Data to Fetch.
   * @param string $lastUpdateKey
   *   Key to use to store and retrieve lastUpdate key from state.
   * @param \DateTime $lastFetched
   *   Date from which to start search. If null will try and get last date
   *   run from state.
   * @param \DateTime $expire_date
   *   The date used for validation purpose.
   *
   * @throws LastUpdatedDateNotFoundException
   */
  private function fetchUpdateSinceDataFromFlow($type, $lastUpdateKey, \DateTime $lastFetched = NULL, \DateTime $expire_date = NULL) {
    if ($lastFetched == NULL) {
      $lastFetched = $this->getLastUpdatedDate($lastUpdateKey);

      if (empty($lastFetched)) {
        $msg = "(fetchUpdateSinceDataFromFlow) UDI can't find last updated date by " . $lastUpdateKey;
        $this->logger->error($msg);
        throw new LastUpdatedDateNotFoundException($msg);
      }
    }

    do {
      $this->logger->debug("(fetchUpdateSinceDataFromFlow) Start with date @date", ['@date' => $lastFetched->format('Y-m-d H:i:s')]);

      $flowData = $this->flowClient->getUpdatedSince($lastFetched, $type);

      $this->logger->debug("(fetchUpdateSinceDataFromFlow) Fetched @count messages", ['@count' => count($flowData)]);

      if ($flowData != NULL && count($flowData) > 0) {
        $this->logger->info("(fetchUpdateSinceDataFromFlow) Fetched @count updated-since messages for type @type",
          ['@count' => count($flowData), '@type' => $type]);

        $this->logger->info("~~~ Will Start fetching  messages 1 by 1. ~~~");
        foreach ($flowData as $flowUpdateSince) {
          $lastFetched = $this->getProcessedDate($flowUpdateSince, $type);
          $this->processFlowData($flowUpdateSince, $type, $lastFetched, $expire_date);
        }
        $this->logger->info("~~~ Done fetching all messages.  ~~~");
        $lastFetched = $lastFetched->add(new \DateInterval(self::ONE_SECOND));
        $this->setLastUpdatedDate($lastFetched, $lastUpdateKey);
      }
      else {
        $this->logger->info("(fetchUpdateSinceDataFromFlow) Flow returns no updated-since data for type '@type'", ['@type' => $type]);
      }
    } while ($flowData != NULL && count($flowData) > 0);

    $this->logger->info("(fetchUpdateSinceDataFromFlow) End with date @date", ['@date' => $lastFetched->format('Y-m-d H:i:s')]);
  }

  /**
   * Process Change Notifications From Flow.
   *
   * @param mixed $flowUpdateSince
   *   Data returned from Flow updateSinceCall.
   * @param string $type
   *   Type of Data.
   * @param mixed $fetchTime
   *   Date fetched from Flow.
   * @param \DateTime $expire_date
   *   Date used for determining if content is expired or invalid.
   */
  private function processFlowData($flowUpdateSince, $type, $fetchTime, \DateTime $expire_date = NULL) {
    $flowId = $this->getIdFromFlowUpdate($flowUpdateSince, $type);
    $this->logger->debug('(processFlowData) is fetching @type id: @id',
      array(
        '@id' => $flowId,
        '@type' => $type,
      ));
    $data = $this->getDataFromFlow($flowId, $type);

    if ($data != NULL && $this->validateContentByDate($data, $type, $expire_date)) {
      $this->postToQueue($data, $fetchTime, $type, self::CONTENT_SOURCE_FLOW, self::CONTENT_UPSERT_ACTION);
    }
  }

  /**
   * Validate a content if it is expired using the $expire_date as criterion.
   *
   * Note that different type of contents or different actions may either not
   * need to check, or have different rules with the criterion.
   *
   * For running syncLinearSchedules, the rule is that if a linear schedule has
   * an end date earlier than the expire date, which is the start date provided
   * as the argument, the schedule content is invalid.
   *
   * @param \stdClass $content
   *   Content json object.
   * @param string $type
   *   Content type.
   * @param \DateTime $expire_date
   *   A date used as criterion.
   *
   * @return bool
   *   TRUE if valid, otherwise FALSE.
   */
  private function validateContentByDate(\stdClass $content, $type, \DateTime $expire_date = NULL) {
    $valid = TRUE;

    if ($expire_date && $type == self::CONTENT_LINEAR_SCHEDULE_TYPE) {
      $end_date = new \DateTime($content->EndDate);

      if ($end_date < $expire_date) {
        $valid = FALSE;
      }
    }

    return $valid;
  }

  /**
   * Get Date that the Flow Data was processed/posted.
   *
   * @param mixed $flowUpdateSince
   *   Data returned from Flow updateSinceCall.
   * @param string $type
   *   Type of Data.
   *
   * @return \DateTime
   *   Processed date.
   */
  private function getProcessedDate($flowUpdateSince, $type) {
    $processedDate = NULL;

    if (isset($flowUpdateSince->ProcessedDatetimeUTC)) {
      $processedDate = new \DateTime($flowUpdateSince->ProcessedDatetimeUTC);
    }
    else {
      $this->logger->error('Error missing ProcessedDatetimeUTC in updated-since messages of @type type', ['@type' => $type]);

      // Workaround to keep moving. But need to report to Flow.
      $processedDate = \DateTime::createFromFormat('U', $this->flowClient->getTimeStampFromFlowObjectId($flowUpdateSince->_id));
    }

    return $processedDate;
  }

  /**
   * Fetch the content from Flow based on id.
   *
   * @param string $flowId
   *   Flow Id.
   * @param string $type
   *   Type of Data.
   *
   * @return mixed
   *   Flow content.
   */
  protected function getDataFromFlow($flowId, $type) {
    $data = NULL;
    switch ($type) {
      case self::CONTENT_TITLE_TYPE:
        $dataArray = $this->flowClient->getTitlesByTitleIds([$flowId]);
        break;

      case self::CONTENT_LINEAR_SCHEDULE_TYPE:
        $dataArray = $this->flowClient->getLinearSchedulesByExternalIds([$flowId]);
        break;

      default:
        break;
    }
    if (!empty($dataArray)) {
      $data = $dataArray[0];
    }
    else {
      $this->logger->debug('(getDataFromFlow)  could not retrieve @type -- id: @id from upstream system',
        array('@type' => $type, '@id' => $flowId));
      $data = NULL;
    }
    return $data;
  }

  /**
   * Get the Id for a particular type of data.
   *
   * @param mixed $flowUpdateSince
   *   Data returned from Flow updateSinceCall.
   * @param string $type
   *   Type of Data.
   *
   * @return int|null
   *   Linear schedule ExternalId.
   */
  private function getIdFromFlowUpdate($flowUpdateSince, $type) {
    $id = NULL;
    switch ($type) {
      case self::CONTENT_TITLE_TYPE:
        $id = $flowUpdateSince->TitleId;
        break;

      case self::CONTENT_LINEAR_SCHEDULE_TYPE:
        $id = $flowUpdateSince->ExternalId;
        break;

      default:
        break;
    }
    return $id;
  }

  /**
   * Function that processes the queue message from ODT.
   *
   * @param string $msgType
   *   Queue message type.
   * @param string $msgSource
   *   Queue message source.
   *
   * @return \Closure
   *   ODT message handler.
   */
  public function processOdtQueueMsg($msgType, $msgSource = ContentFetchManager::CONTENT_SOURCE_ODT) {
    return function ($msg) use ($msgType, $msgSource) {
      try {
        $first_decode = json_decode($msg->body);
        // Have to decode twice because of way data returned from ODT.
        $airingmsg = json_decode($first_decode);

        if ((!empty($airingmsg)) && property_exists($airingmsg, "AiringId")) {
          $airingId = $airingmsg->AiringId;

          // Parse message to determine if it is delete or modify.
          if (strtolower($airingmsg->Action) == self::CONTENT_DELETE_ACTION) {
            $data = new \stdClass();
            $data->airingId = $airingId;
            $data->action = self::CONTENT_DELETE_ACTION;
            $msgAction = self::CONTENT_DELETE_ACTION;
            $apply_filter = FALSE;
          }
          else {
            $data = $this->getOnDemandSchedule($airingId);
            $msgAction = self::CONTENT_UPSERT_ACTION;
            $apply_filter = TRUE;
          }
        }

        if (!empty($data)) {
          $this->postToQueue($data, new \DateTime(), $msgType, $msgSource, $msgAction, $apply_filter);
        }
      }
      catch (\Exception $ex) {
        $this->logger->error("(ContentFetchManager) Error posting airing from odt airingid : @airingid  --  msg is @msg",
          array('@airingid' => $airingmsg->AiringId, "@msg" => $ex->getMessage()));
      }

      if (!empty($msg->delivery_info)) {
        $msg->delivery_info['channel']->basic_ack($msg->delivery_info['delivery_tag']);
      }
      else {
        // This is mainly for local testing, but it may occur in prod.
        $this->logger->error('(ContentFetchManager) ODT message does not contain a callback for acknowledgement. ODT message content: @msg', ['@msg' => $airingmsg]);
      }

    };
  }

  /**
   * Get the OnDemand Schedule from ODT.
   *
   * @param string $airingId
   *   Airing Id.
   *
   * @return string
   *    Airing content in string.
   */
  private function getOnDemandSchedule($airingId) {
    $airing = NULL;
    if (!empty($airingId)) {
      $airing = $this->odtHttpClient->getFullAiringContentById($airingId);
    }
    return $airing;
  }

  /**
  * Get The Last Updated Date.
  *
  * @param string $key
  *   Key for the state object.
  *
  * @return \Datetime
  *   Datetime value.
   */
  private function getLastUpdatedDate($key) {
    return $this->state->get($key);
  }

  /**
   * Set the Last Updated Date.
   *
   * @param \DateTime $lastFetchedDate
   *   The DateTime to store.
   * @param string $key
   *   State key.
   */
  private function setLastUpdatedDate(\DateTime $lastFetchedDate, $key) {
    $this->state->set($key, $lastFetchedDate);
  }

  /**
   * Post data to the queue.
   *
   * @param \stdClass $data
   *   Data to post.
   * @param \DateTime $fetchTime
   *   Time message fetched.
   * @param string $type
   *    Type of data.
   * @param string $source
   *    Source of data.
   * @param string $action
   *    Action to perform.
   * @param bool $filterContent
   *    Boolean indication if data should go through filtering process.
   */
  protected function postToQueue(\stdClass $data, \DateTime $fetchTime, $type, $source, $action, $filterContent = TRUE) {
    if ($data != NULL) {
      if ((!$filterContent) || $this->shouldProceed($type, $source, $data)) {
        try {
          $this->logger->info("(ContentFetchManager) Filters passed and will be posted content: @data",
            ['@data' => json_encode($data)]);
          $this->queueClient->postJsonMessage($this->buildMsg($data, $fetchTime, $type, $source, $action));
        }
        catch (\Exception $ex) {
          $this->logger->error("Error posting msg: @msg", ['@msg' => $ex->getMessage()]);
        }
      }
      else {
        $this->logger->info("(ContentFetchManager) Filters rejected content: @data",
          ['@data' => json_encode($data)]);
      }
    }
  }

  /**
   * Apply filters to data to determine if data should be posted to queue.
   *
   * @param string $type
   *   Type of data.
   * @param string $source
   *   Source of data.
   * @param string $data
   *   Data to filter.
   *
   * @return bool
   *   True if data should be Posted. False if filtered out.
   */
  private function shouldProceed($type, $source, $data) {

    // If no filter is defined for this type and source then data will
    // be approved and method will return TRUE.
    $shouldProceed = TRUE;

    try {
      // All filters defined for this type and filter must approve data.  If any
      // one filter sets isApproved to False then the data will be filtered out.
      foreach ($this->filterManager->getFilters($type, $source) as $filter) {
        if (!$filter->isApprovedContent($data)) {
          $shouldProceed = FALSE;
          $this->logger->info("This '@filter' Filter rejected content",
            ['@filter' => $filter->getPluginId()]);
        }
      }
    }
    catch (\InvalidArgumentException $ex) {
      // Handle exception here to prevent from interrupting a running drush
      // process that downloads upstream contents.
      $this->logger->error('Error in filter for a @type content. Error message: @msg',
        ['@type' => $type, '@msg' => $ex->getMessage()]);
      $shouldProceed = FALSE;
    }

    return $shouldProceed;
  }

  /**
   * Build msg to post.
   *
   * @param \stdClass $data
   *   Message Data.
   * @param \DateTime $fetchTime
   *   Time on upstream system.
   * @param string $type
   *    Type of data.
   * @param string $source
   *    Source of data.
   * @param string $action
   *    Action to perform.
   *
   * @return string
   *   Message.
   */
  private function buildMsg(\stdClass $data, \DateTime $fetchTime, $type, $source, $action) {
    $msg = new \stdClass();
    $now = new \DateTime();
    $msg->messageTimestamp = $now->getTimestamp();
    $msg->type = $type;
    $msg->source = $source;
    $attributes = new \stdClass();
    $fetched = $fetchTime;
    $attributes->fetchTimestamp = $fetched->getTimestamp();
    $msg->attributes = $attributes;
    $msg->action = $action;
    $msg->data = $data;
    return json_encode($msg);
  }

  /**
   * Callback for handling event UdiContentImportEvent.
   *
   * The handler fetches missing title content entities associated with
   * on-demand schedule entities.
   *
   * @param \Drupal\draco_udi\Events\UdiContentImportEvent $event
   *    Event to be listened.
   */
  public function onDemandScheduleImportCompleteEventHandler(UdiContentImportEvent $event) {
    $data = $event->getData();

    if ($data == NULL || !isset($data['missingTitles'])) {
      return;
    }

    $airing_id = $data['airingId'];
    $missing_titles = $data['missingTitles'];

    if ($event->getType() == self::CONTENT_ONDEMAND_SCHEDULE_TYPE && !empty($missing_titles)) {
      foreach ($missing_titles as $missing_title) {
        $title_data = $this->getDataFromFlow($missing_title, self::CONTENT_TITLE_TYPE);

        // Import is subject to filtering.
        // In case title filter is activated in config, title contents may not
        // be imported this way.
        if (!empty($title_data)) {
          $this->postToQueue($title_data, new \DateTime(), self::CONTENT_TITLE_TYPE,
            self::CONTENT_SOURCE_FLOW, self::CONTENT_UPSERT_ACTION);
        }
        else {
          $this->logger->error('Failed to fetch content by title id ', ['$title_id' => $missing_title]);
        }
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    $events[UdiContentImportEvent::UDI_CONTENT_ON_DEMAND_IMPORT_SUCCESSFUL][] = ['onDemandScheduleImportCompleteEventHandler'];
    return $events;
  }

}
