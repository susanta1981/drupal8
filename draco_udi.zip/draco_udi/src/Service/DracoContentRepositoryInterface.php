<?php

namespace Drupal\draco_udi\Service;

/**
 * Interface DracoContentRepositoryInterface.
 *
 * @package Drupal\draco_udi\Service
 */
interface DracoContentRepositoryInterface {

  /**
   * Return a ContentTitle entity or NULL if not found.
   *
   * @param int $title_id
   *   Title id.
   *
   * @return \Drupal\draco_udi\Entity\ContentTitle|null
   *   Title entity.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function getContentTitleByTitleId($title_id);

  /**
   * Return an array of ContentOnDemandSchedule entities or an empty array.
   *
   * There may be more than one airings are associated with the request titleId.
   *
   * The list includes all current and future schedules. Future schedules are
   * ones which start time is later than the current time, whereas current
   * schedules are ones which start time is on or earlier than the current time,
   * but their end time is later than the current time.
   *
   * @param int $title_id
   *     Title id.
   *
   * @return array
   *    List of ContentOnDemandSchedule entities.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function getContentOnDemandSchedulesByTitleId($title_id);

  /**
   * Return an array of ContentOnDemandSchedule entities for a media id.
   *
   * There may be more than one airing for a media id.
   *
   * The list includes all current and future schedules.
   *
   * @param string $media_id
   *    Media id.
   *
   * @return array
   *    List of ContentOnDemandSchedule entities.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function getOnDemandSchedulesByMediaId($media_id);

  /**
   * Return a ContentOnDemandSchedule entity with the most recent flight.
   *
   * A schedule usually contains multiple flights. There may be more than one
   * schedule exists by the same title id. A most recent schedule is one
   * having a flight that could be either the most active, the closest in the
   * future, or the most recently expired.
   *
   * A active schedule is one with a flight start time earlier than or equal to
   * the current time, and the end datetime later than the current time.
   * A schedule containing at least one active flight is treated as an active
   * schedule. In case there are more than one active schedule, the method
   * returns the schedule with a flight which start time is closest to the
   * current time.
   *
   * If no active schedule is found, the method looks for future schedules,
   * and if found, the method returns the schedule with a future flight which
   * start time is the closest to the current time.
   *
   * If no future schedule is found, the method looks for expired schedules,
   * and if found, the method returns the schedule with an expired flight which
   * end time is the closest to the current time.
   *
   * If no any schedule is found, the method returns null.
   *
   * @param int $title_id
   *     Title id.
   *
   * @return ContentOnDemandSchedule|null
   *    A ContentOnDemandSchedule entity.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function getMostRecentContentOnDemandScheduleByTitleId($title_id);

  /**
   * Sort provided array of flights in terms of a field name, e.g., StartDate.
   *
   * @param array &$flights
   *    List of DracoOnDemandFlight entities.
   *
   * @param string $field
   *    Name of a ContentOnDemandSchedule entity field.
   *
   * @param bool $asc
   *    Sort order flag.
   *
   * @return array
   *    Sorted array.
   */
  public function sortOnDemandFlights(array &$flights, $field, $asc = TRUE);

  /**
   * Return an array of ContentLinearSchedule entities or an empty array.
   *
   * There may be more than one linear schedules associated with the requested
   * titleId.
   *
   * @param int $title_id
   *    Title id.
   *
   * @return array
   *    List of ContentLinearSchedule entities.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function getContentLinearSchedulesByTitleId($title_id);

}
