<?php

namespace Drupal\draco_udi\Service\DataSource;

use GuzzleHttp\Client;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class UdiDataSourceClient.
 *
 * @package Drupal\draco_udi\Service\DataSource
 */
class UdiDataSourceClient implements UdiDataSourceClientInterface {

  /**
   * HTTP client.
   *
   * @var \GuzzleHttp\Client
   */
  protected $client;

  /**
   * UdiDataSourceClient constructor.
   *
   * @param \GuzzleHttp\Client|null $client
   *    HTTP Client.
   */
  public function __construct(Client $client = NULL) {
    if ($client != NULL) {
      $this->client = $client;
    }
    else {
      $this->client = new Client();
    }
  }

  /**
   * Create method for UdiDataSourceClient.
   *
   * Ignore because create functions are not tested.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *    Service container.
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get("http_client")
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getContents($url, array $headers) {
    $response = $this->client->get($url, $headers);
    $output   = json_decode($response->getBody());

    return $output;
  }

}
