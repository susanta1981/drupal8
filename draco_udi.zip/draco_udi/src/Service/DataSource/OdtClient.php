<?php

namespace Drupal\draco_udi\Service\DataSource;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\draco_udi\Events\UdiContentPostEvent;
use Drupal\draco_udi\Exception\UdiConfigurationException;
use GuzzleHttp\Client;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class OdtClient.
 *
 * @package Drupal\draco_udi\Service\DataSource
 */
class OdtClient extends UdiDataSourceClient implements OdtClientInterface {

  protected $rootPath = NULL;
  protected $authKey = NULL;
  protected $postUrl = NULL;
  protected $airingIdPrefix = NULL;
  protected $registerUrl = NULL;
  protected $eventDispatcher;

  protected static $airingPath = '/airing/';
  protected static $airingsPath = '/airings/';
  protected static $filesPath = '/files/';

  const POST_ACTION = 'posting_airing';
  const REGISTER_ACTION = 'register_airing';

  /**
   * OdtClient constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *    Config factory.
   * @param \Psr\Log\LoggerInterface $logger
   *    Logger.
   * @param \GuzzleHttp\Client|null $client
   *    HTTP client.
   * @param \Symfony\Component\EventDispatcher\EventDispatcherInterface $event_dispatcher
   *    Event dispatcher.
   */
  public function __construct(
      ConfigFactoryInterface $config_factory,
      LoggerInterface $logger,
      Client $client = NULL,
      EventDispatcherInterface $event_dispatcher = NULL) {

    Parent::__construct($client);

    $config = $config_factory->get('draco_udi.settings');
    $this->logger = $logger;

    if (!empty($config)) {
      $this->rootPath = $config->get('odt_settings.odt_root');
      $this->authKey = $config->get('odt_settings.odt_auth_key');
      $this->airingIdPrefix = $config->get('odt_settings.odt_airing_id_prefix');
    }

    // Validate.
    if (empty($this->rootPath)) {
      throw new UdiConfigurationException('ODT root path is not defined.');
    }
    if (empty($this->authKey)) {
      throw new UdiConfigurationException('ODT auth key is not defined.');
    }
    if (!empty($this->airingIdPrefix)) {
      $this->postUrl = $this->rootPath . self::$airingPath . $this->airingIdPrefix;
    }
    else {
      throw new UdiConfigurationException('ODT airing id prefix not defined.');
    }

    $this->registerUrl = $this->rootPath . self::$filesPath;
    $this->eventDispatcher = $event_dispatcher;
  }

  /**
   * Create method for OdtClient.
   *
   * Ignore because create functions are not tested.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *    Service container.
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('draco_udi.logger.channel'),
      $container->get("http_client"),
      $container->get('event_dispatcher')
    );
  }

  /**
   * Retrieve an airing json object by an airingId with all options.
   *
   * @param string $id
   *    AiringId that uniquely identifies an airing object in ODT.
   *
   * @return \stdClass
   *    A Json object of stdClass type.
   */
  public function getFullAiringContentById($id) {
    return $this->getAiringContentById($id, TRUE, TRUE, TRUE, TRUE, TRUE);
  }

  /**
   * {@inheritdoc}
   */
  public function getAiringContentById(
      $id,
      $file = FALSE,
      $title = FALSE,
      $destination = FALSE,
      $status = FALSE,
      $package = FALSE
  ) {
    $url = $this->rootPath . self::$airingPath . $id;

    if ($file || $title || $destination || $status) {
      $url = $url . '?options=';
    }
    if ($file) {
      $url = $url . 'file';
    }
    if ($title) {
      $url = $url . (($file) ? '|title' : 'title');
    }
    if ($destination) {
      $url = $url . (($file || $title) ? '|destination' : 'destination');
    }
    if ($status) {
      $url = $url . (($file || $title || $destination) ? '|status' : 'status');
    }
    if ($package) {
      $url = $url . (($file || $title || $destination || $status) ? '|package' : 'package');
    }

    $airing = $this->getContents($url, $this->getRequestHeaders());

    return $airing;
  }

  /**
   * Get request headers.
   */
  public function getRequestHeaders() {
    $headers = [];
    $headers['Content-Type'] = 'application/json';
    $headers['Accept'] = 'application/json';
    $headers['Authorization'] = $this->authKey;

    return array('headers' => $headers);
  }

  /**
   * {@inheritdoc}
   */
  public function postAiring($airing_data) {
    $options = $this->getRequestHeaders();
    $options['body'] = (is_a($airing_data, '\stdClass')) ? json_encode($airing_data) : $airing_data;

    $result = new \stdClass();

    try {
      $response = $this->client->post($this->postUrl, $options);
      $result->statusCode = $response->getStatusCode();
      $result->responseBody = $response->getBody();

      if ($result->statusCode != 200) {
        $result->status = 'ERROR';
        $result->message = 'ODT returns error';
        $this->dispatchFailedEvent($result, self::POST_ACTION);
      }
      else {
        $response_body = json_decode($response->getBody());
        $result->airingId = $response_body->airingId;
        $result->mediaId = $response_body->mediaId;
        $result->status = 'SUCCESSFUL';
        $result->message = 'Posting content airing data to ODT successful.';
      }
    }
    catch (\Exception $ex) {
      $this->logger->error('Error posting airing: ' . $ex->getMessage());
      $result->status = 'ERROR';
      $result->statusCode = $ex->getCode();
      $result->responseBody = NULL;
      $result->message = 'Error posting airing: ' . $ex->getMessage();
      $this->dispatchFailedEvent($result, self::POST_ACTION);
    }

    return $result;
  }

  /**
   * {@inheritdoc}
   */
  public function postFiles($data_to_register, $airing_data = NULL) {
    $options = $this->getRequestHeaders();
    $options['body'] = (is_array($data_to_register)) ? json_encode($data_to_register) : $data_to_register;

    $result = new \stdClass();

    try {
      $response = $this->client->post($this->registerUrl, $options);
      $result->statusCode = $response->getStatusCode();
      $result->responseBody = $response->getBody();

      if ($result->statusCode == 200) {
        $result->status = 'SUCCESSFUL';

        // Dispatch event.
        $data = [];
        $data['airing'] = (is_a($airing_data, '\stdClass')) ? json_encode($airing_data) : $airing_data;
        $data['registered'] = $options['body'];

        $this->dispatchContentPostEvent(UdiContentPostEvent::UDI_CONTENT_POST_SUCCESSFUL, $data);
      }
      else {
        $result->status = 'ERROR';
        $result->message = 'ODT response for registering contains error. Return code: ' . $response->getStatusCode();
        $this->logger->error('Error registering content: ' . $result->message);
        $this->dispatchFailedEvent($result, self::REGISTER_ACTION);
      }
    }
    catch (\Exception $ex) {
      $this->logger->error('Error registering content: ' . $ex->getTraceAsString());
      $result->statusCode = $ex->getCode();
      $result->responseBody = NULL;
      $result->status = 'ERROR';
      $result->message = 'Error registering content: ' . $ex->getMessage();
      $this->dispatchFailedEvent($result, self::REGISTER_ACTION);
    }

    return $result;
  }

  /**
   * Dispatch an event.
   *
   * @param string $type
   *    Type of UdiContentPostEvent.
   * @param array $data
   *    Data carried by the event.
   */
  private function dispatchContentPostEvent($type, array $data) {
    $event = new UdiContentPostEvent($data);
    $this->eventDispatcher->dispatch($type, $event);
  }

  /**
   * Dispatch failed event.
   *
   * @param \stdClass $response
   *    Object containing status and message.
   * @param string $action
   *    Posting or registering.
   */
  private function dispatchFailedEvent(\stdClass $response, $action) {
    $err_data = [];
    $err_data['action'] = $action;
    $err_data['statusCode'] = $response->statusCode;
    $err_data['message'] = $response->message;
    $this->dispatchContentPostEvent(UdiContentPostEvent::UDI_CONTENT_POST_FAILED, $err_data);
  }

}
