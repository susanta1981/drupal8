<?php

namespace Drupal\draco_udi\Service\DataSource\Tve;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\draco_udi\Exception\UdiConfigurationException;
use Drupal\draco_udi\Service\ContentFetchManager;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use GuzzleHttp\Client;

/**
 * TveClient.
 */
class TveClient implements TveClientInterface, ContainerInjectionInterface {

  protected $logger;
  protected $client;
  protected $config;
  protected $fetchManager;
  protected $baseUrl;

  /**
   * TveClient constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *    Config factory.
   * @param \Psr\Log\LoggerInterface $logger
   *    Logger.
   * @param \GuzzleHttp\Client $client
   *    Http client.
   * @param ContentFetchManager $fetch_manager
   *    Fetch manager.
   */
  public function __construct(
      ConfigFactoryInterface $config_factory,
      LoggerInterface $logger,
      Client $client,
      ContentFetchManager $fetch_manager
  ) {
    $this->logger = $logger;
    $this->client = $client;
    $this->config = $config_factory->get('draco_udi.settings');
    $this->fetchManager = $fetch_manager;
    $this->baseUrl = trim($this->config->get('tve_settings.historical_file_location'));
  }

  /**
   * Create method for TveClient.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *    Service container.
   *
   * @return static
   *
   * @codeCoverageIgnore
   *    ignore because create functions are not tested
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('draco_udi.logger.channel'),
      $container->get("http_client"),
      $container->get('draco_udi.content.fetch.manager')
    );
  }

  /**
   * Post historical files and process through the UDI workflow.
   *
   * {@inheritdoc}
   */
  public function postFiles(\DateTime $startTime = NULL, \DateTime $endTime = NULL) {
    $this->verifyBaseUrl();
    if ($startTime == NULL) {
      $startTime = new \DateTime('2016-01-01');
    }
    if ($endTime == NULL) {
      $endTime = new \DateTime();
    }
    $this->postTveFilesBetweenDates($startTime, $endTime);
  }

  /**
   * Download TVE file from DMI site.
   *
   * {@inheritdoc}
   */
  public function getTveFileForAiring($file_url) {
    $json = NULL;
    $xml_tve = simplexml_load_file($file_url);
    if ($xml_tve) {
      $json_tve = json_encode($xml_tve);
      $json = str_replace(array('@attributes'), 'Attributes', $json_tve);
    }
    return $json;
  }

  /**
   * Find Files on TVE server between startTime and EndTime and post them.
   *
   * @param \DateTime $startTime
   *   The beginning date/time to retrieve xml files.
   * @param \DateTime $endTime
   *   The end date/time to retrieve xml files.
   */
  private function postTveFilesBetweenDates(\DateTime $startTime, \DateTime $endTime) {

    foreach ($this->getDirectoriesBetweenDates($startTime, $endTime) as $directory) {
      $this->requestFilesFromDmi($directory, $startTime, $endTime);
    }
  }

  /**
   * Verify the historical file location has been configured properly.
   *
   * @throws UdiConfigurationException
   */
  private function verifyBaseUrl() {

    if (empty($this->baseUrl)) {
      $this->logger->error("tve_settings.historical_file_location is not properly configured");
      throw new UdiConfigurationException("tve_settings.historical_file_location is not properly configured");
    }
  }

  /**
   * Get date-bound list of directories on remote server.
   *
   * Get a list of directories on remote server that are between start and end
   * dates.
   *
   * @param \DateTime $startTime
   *   The beginning date/time to retrieve xml files.
   * @param \DateTime $endTime
   *   The end date/time to retrieve xml files.
   */
  private function getDirectoriesBetweenDates(\DateTime $startTime, \DateTime $endTime) {

    $directories = array();
    $directoriesInRange = array();

    preg_match_all("/(a href\=\")([^\?\"]*)(\")/i", $this->getFileListing($this->baseUrl), $directories);

    foreach ($directories[2] as $directory) {
      $dateMatches = array();
      if (preg_match("/(\d+)-(\d+)\//", $directory, $dateMatches)) {
        $year = (int) $dateMatches[1];
        $month = (int) $dateMatches[2];
        if ($this->isDirectoryInDateRange($year, $month, $startTime, $endTime)) {
          $directoriesInRange[] = $this->baseUrl . '/' . $dateMatches[0];
        }
      }
    }
    return $directoriesInRange;
  }

  /**
   * Get xml files that need to be posted.
   *
   * @param string $url
   *   The url of the tve content server dirctory to look in.
   * @param \DateTime $startTime
   *   The beginning date/time to retrieve xml files.
   * @param \DateTime $endTime
   *   The end date/time to retrieve xml files.
   */
  private function requestFilesFromDmi($url, \DateTime $startTime, \DateTime $endTime) {
    $files = array();
    preg_match_all("/(a href\=\")([^\?\"]*)\"\S*\s+(\S*)/i", $this->getFileListing($url), $files);
    $i = -1;
    foreach ($files[2] as $file) {
      if (preg_match("/.+\.xml/i", $file)) {
        $fileTime = new \DateTime($files[3][$i]);
        if ($fileTime >= $startTime && $fileTime <= $endTime) {
          $file_url = $url . $file;

          // We used to request DMI to post this file to UDI endpoint.
          // Now we directly download the file.
          $this->downloadAndPostTveFile($file_url);
        }
      }
      $i++;
    }
  }

  /**
   * Determines if the year and month fall inbetween start and end date.
   */
  private function isDirectoryInDateRange($year, $month, \DateTime $startDate, \DateTime $endDate) {
    $inRange = FALSE;
    $startMonth = (int) $startDate->format('m');
    $startYear = (int) $startDate->format('Y');
    $endMonth = (int) $endDate->format('m');
    $endYear = (int) $endDate->format('Y');

    if (
      ($year > $startYear || ($year == $startYear) && ($month >= $startMonth)) &&
      ($year < $endYear || ($year == $endYear) && ($month <= $endMonth))) {
      $inRange = TRUE;
    }

    return $inRange;
  }

  /**
   * Download a TVE XML file and drop it in Draco internal queue for importing.
   *
   * @param string $file_url
   *   URl of file on DMI server.
   */
  private function downloadAndPostTveFile($file_url) {
    $json = $this->getTveFileForAiring($file_url);
    if ($json) {
      $this->fetchManager->postTveJson($json, ContentFetchManager::CONTENT_HISTORICAL_TVE_TYPE);
    }
  }

  /**
   * Get File listing from http server.
   */
  private function getFileListing($url) {

    $content = '';
    $fp_load = fopen("$url", "rb");
    if ($fp_load) {
      while (!feof($fp_load)) {
        $content .= fgets($fp_load, 8192);
      }
      fclose($fp_load);
      return $content;
    }
  }

}
