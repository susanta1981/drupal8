<?php

namespace Drupal\draco_udi\Service\DataSource\Tve;

/**
 * Interface TveClientInterface.
 *
 * @package Drupal\draco_udi\Service\DataSource\Tve
 */
interface TveClientInterface {

  /**
   * Post historical files and process through the UDI workflow.
   *
   * Retrieves historical tve xml files between startTime and endTime. If
   * startTime is null will retrieve files beginning 01/01/2016 which is the
   * earliest tve xml files we have.  If endTime is null will retrieve files up
   * to current time and date.
   *
   * @param \DateTime $startTime
   *   The beginning date/time to retrieve xml files.
   * @param \DateTime $endTime
   *   The end date/time to retrieve xml files.
   */
  public function postFiles(\DateTime $startTime = NULL, \DateTime $endTime = NULL);

  /**
   * Get Historial file for an airing from TVE server.
   *
   * @param string $file_url
   *   The url of the file to retrieve.
   *
   * @return string|NULL
   *   Return json formatted TVE data from historical server or Null if file
   *   can not be found.
   */
  public function getTveFileForAiring($file_url);

}
