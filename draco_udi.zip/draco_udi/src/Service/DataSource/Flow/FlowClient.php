<?php

namespace Drupal\draco_udi\Service\DataSource\Flow;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\draco_udi\Exception\UdiConfigurationException;
use GuzzleHttp\Client;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\DataSource\UdiDataSourceClient;
use Psr\Log\LoggerInterface;

/**
 * Class FlowClient.
 *
 * @package Drupal\draco_udi\Service\DataSource\Flow
 */
class FlowClient extends UdiDataSourceClient implements FlowClientInterface {

  protected $rootPath = NULL;
  protected $authKey = NULL;
  protected $networkId = NULL;
  protected $flowObjectIdGenerator = NULL;
  protected $logger;

  /**
   * FlowClient constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *    Config Factory.
   * @param \Psr\Log\LoggerInterface $logger_channel
   *    Logger.
   * @param \GuzzleHttp\Client|null $client
   *    Http client.
   */
  public function __construct(ConfigFactoryInterface $config_factory, LoggerInterface $logger_channel, Client $client = NULL) {
    parent::__construct($client);

    $config = $config_factory->get('draco_udi.settings');

    // TODO: Inject these as individual constructor parameters instead of the
    // whole config factory.
    if (!empty($config)) {
      $this->rootPath = $config->get('flow_settings.flow_root');
      $this->authKey = $config->get('flow_settings.flow_auth_key');
      $this->networkId = $config->get('flow_settings.flow_network_id');
    }

    // Validate.
    if (empty($this->rootPath)) {
      throw new UdiConfigurationException('Flow root path is not defined.');
    }
    if (empty($this->authKey)) {
      throw new UdiConfigurationException('Flow auth key is not defined.');
    }
    $this->logger = $logger_channel;
    $this->flowObjectIdGenerator = new FlowObjectIdGenerator();
  }

  /**
   * Create method for FlowClient.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *    Container.
   *
   * @return static
   *    Container objects.
   *
   * @codeCoverageIgnore
   *    ignore because create functions are not tested
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('draco_udi.logger.channel'),
      $container->get("http_client")
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getNetworkFeedSchedulesForDateTitle(array $networks, array $feeds, \DateTime $start_date, \DateTime $end_date, $title) {

    $networkCSV = implode(',', $networks);
    $feedCSV = implode(',', $feeds);
    $startDateStr = $start_date->format('Y-m-d');
    $endDateStr = $end_date->format('Y-m-d');

    $url = "{$this->rootPath}/v2/schedules/{$networkCSV}/{$feedCSV}/{$startDateStr}/{$endDateStr}/{$title}?api_key={$this->authKey}";

    return $this->doGet($url);
  }

  /**
   * Get linear schedule data objects by ids.
   *
   * @param array|null $external_ids
   *   ExternalIds.
   *
   * @return mixed
   *   List of Flow schedules
   *
   * @throws \InvalidArgumentException
   */
  public function getLinearSchedulesByExternalIds(array $external_ids) {
    if (empty($external_ids)) {
      $msg = 'No external ids are passed in. At least one is required.';
      $this->logger->error($msg, []);
      throw new \InvalidArgumentException($msg);
    }
    elseif (count($external_ids) > 25) {
      $this->logger->error('@size external ids are passed in. Flow only accept up to 25 in each call.',
                          ['@size' => count($external_ids)]);
      throw new \InvalidArgumentException('More than 25 external ids passed in. Only 25 is allowed.');
    }

    $id_strings = implode(',', $external_ids);
    $url = "{$this->rootPath}/v2/schedules/{$id_strings}?api_key={$this->authKey}";

    return $this->doGet($url);
  }

  /**
   * Get Flow Data Updated since for a type.
   *
   * {@inheritdoc}
   */
  public function getUpdatedSince(\DateTime $date_time, $type) {
    $data = NULL;
    switch ($type) {
      case ContentFetchManager::CONTENT_TITLE_TYPE:
        $data = $this->getTitlesUpdatedSince($date_time);
        break;

      case ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE:
        $data = $this->getLinearSchedulesUpdatedSince($date_time);
        break;

      default:
        $data = NULL;
    }
    return $data;
  }

  /**
   * Get Flow Data deleted since for a type.
   *
   * {@inheritdoc}
   */
  public function getDeletedSince(\DateTime $date_time, $type) {
    $data = NULL;
    switch ($type) {
      case ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE:
        $data = $this->getLinearSchedulesDeletedSince($date_time);
        break;

      default:
        $data = NULL;
    }
    return $data;
  }

  /**
   * Get Titles Update since.
   *
   * {@inheritdoc}
   */
  public function getTitlesUpdatedSince(\DateTime $date_time) {

    $this->logger->debug('fetching titles since : @date_time',
      array(
        '@date_time' => date_format($date_time, 'Y-m-d H:i:s'),
      ));
    $objectId = $this->flowObjectIdGenerator->generate($date_time);

    $url = "{$this->rootPath}/v2/title/since/{$objectId}";
    if (!empty($this->networkId)) {
      $url .= "/{$this->networkId}";
    }
    $url .= "?api_key={$this->authKey}";
    return $this->doGet($url);
  }

  /**
   * Get Linear Schedules by date range.
   *
   * {@inheritdoc}
   */
  public function getLinearSchedulesByDateRange(\DateTime $start, \DateTime $end) {

    $this->logger->debug('fetching linear schedules between  : @start - @end',
      array(
        '@start' => date_format($start, 'Y-m-d H:i:s'),
        '@end' => date_format($end, 'Y-m-d H:i:s'),
      ));

    $url = "{$this->rootPath}/v2/schedules";
    if (!empty($this->networkId)) {
      $url .= "/{$this->networkId}";
    }
    $url .= "/{$start->format('c')}";
    $url .= "/{$end->format('c')}";
    $url .= "?api_key={$this->authKey}";
    return $this->doGet($url);
  }

  /**
   * {@inheritdoc}
   */
  public function getLinearSchedulesUpdatedSince(\DateTime $date_time) {
    $this->logger->info('Fetching linear schedules updated since : @date_time',
      array(
        '@date_time' => date_format($date_time, 'Y-m-d H:i:s'),
      ));

    $objectId = $this->flowObjectIdGenerator->generate($date_time);
    $url = "{$this->rootPath}/v2/schedules/since/{$objectId}";

    if (!empty($this->networkId)) {
      $url .= "/{$this->networkId}";
    }
    $url .= "?api_key={$this->authKey}";

    return $this->doGet($url);
  }

  /**
   * Get linear schedules deleted since a datetime.
   *
   * @code
   * http://flowqa.turner.com/v2/schedules/deleted/since/57cf2fb8bfd8460c9c9f44a9/TBS?api_key={your_QA_api_key}
   * @endcode
   *
   * {@inheritdoc}
   */
  private function getLinearSchedulesDeletedSince(\DateTime $date_time) {

    $this->logger->info('Fetching messages containing linear schedules deleted since : @date_time',
      array(
        '@date_time' => date_format($date_time, 'Y-m-d H:i:s'),
      ));
    $objectId = $this->flowObjectIdGenerator->generate($date_time);

    $url = "{$this->rootPath}/v2/schedules/deleted/since/{$objectId}";
    if (!empty($this->networkId)) {
      $url .= "/{$this->networkId}";
    }
    $url .= "?api_key={$this->authKey}";

    return $this->doGet($url);
  }

  /**
   * Get Titles By Title IDs.
   *
   * {@inheritdoc}
   */
  public function getTitlesByTitleIds(array $ids) {

    $idCSV = implode(',', $ids);

    $url = "{$this->rootPath}/v2/title/{$idCSV}?api_key={$this->authKey}";

    return $this->doGet($url);
  }

  /**
   * Get a TimeStamp from Flow Object Id.
   *
   * @param string $id
   *   Flow Id.
   *
   * @return int
   *   Timestamp.
   */
  public function getTimeStampFromFlowObjectId($id) {
    return $this->flowObjectIdGenerator->getTimeStampFromFlowObjectId($id);
  }

  /**
   * Get request headers.
   */
  protected function getRequestHeaders() {
    $headers = [];
    $headers['Accept'] = 'application/json';

    return array('headers' => $headers);
  }

  /**
   * Do Get.
   *
   * @param string $url
   *   Url.
   *
   * @return \stdClass
   *   Data returned.
   */
  protected function doGet($url) {

    $data = $this->getContents($url, $this->getRequestHeaders());

    return $data;
  }

  /**
   * {@inheritdoc}
   */
  public function getBSONIdFromFlow(\DateTime $date_time) {
    $datetime_string = $date_time->format('c');

    $url = "{$this->rootPath}/v2/schedules/syncsince/{$datetime_string}";

    if (!empty($this->networkId)) {
      $url .= "/{$this->networkId}";
    }
    $url .= "?api_key={$this->authKey}";

    $bson_id_info = $this->doGet($url);
    $bson_id = NULL;

    if (!empty($bson_id_info)) {
      $bson_id = reset($bson_id_info)->_id;
    }

    return $bson_id;
  }

}
