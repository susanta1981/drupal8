<?php

namespace Drupal\draco_udi\Service\DataSource\Flow;

/**
 * Flow Object Id Generator.
 */
class FlowObjectIdGenerator {
  private $counter;

  /**
   * Constructor.
   *
   * @param int $counter
   *   Counter to use for trailing part of Id.
   */
  public function __construct($counter = NULL) {
    $this->counter = ($counter ? $counter : rand());
  }

  /**
   * Generate a string representing the object id.
   *
   * This code was lifted from here:
   * http://stackoverflow.com/questions/14370143/create-mongodb-objectid-from-date-in-the-past-using-php-driver.
   *
   * @param \DateTime $date_time
   *   Date to use when generating id.
   * @param string $host_name
   *   Host name to use when generating id.
   * @param string $pid
   *   Pid to use when generating id.
   *
   * @return string
   *   Flow Id.
   */
  public function generate(\DateTime $date_time = NULL, $host_name = NULL, $pid = NULL) {
    $dateTime = ($date_time ? $date_time : new \DateTime());
    $hostName = ($host_name ? $host_name : gethostname());
    $pid = ($pid ? $pid : posix_getpid());

    $ts = pack('N', $dateTime->getTimestamp());
    $m = substr(md5($hostName), 0, 3);
    $pid = pack('n', $pid);
    $trail = substr(pack('N', $this->counter++), 1, 3);

    $bin = sprintf("%s%s%s%s", $ts, $m, $pid, $trail);

    $id = '';

    for ($i = 0; $i < 12; $i++) {
      $id .= sprintf("%02X", ord($bin[$i]));
    }

    return $id;
  }

  /**
   * Extract timestamp from a Flow Object Id.
   *
   * @param string $id
   *   Flow Object Id.
   *
   * @return int
   *   Timestamp extracted from Object Id.
   */
  public function getTimeStampFromFlowObjectId($id) {
    $ts = NULL;
    if (!empty($id)) {
      $ts = intval(substr($id, 0, 8), 16);
    }
    return $ts;

  }

}
