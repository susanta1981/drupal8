<?php

namespace Drupal\draco_udi\Service\DataSource\Flow;

use Drupal\draco_udi\Service\DataSource\UdiDataSourceClientInterface;

/**
 * Interface FlowClientInterface.
 *
 * @see http://iodocs.turner.com/flowv2
 *
 * @package Drupal\draco_udi\Service\DataSource\Flow
 */
interface FlowClientInterface extends UdiDataSourceClientInterface {

  /**
   * Get linear scheduling information.
   *
   * @param string[] $networks
   *   An array of network IDs, such as 'TBS'.
   * @param array $feeds
   *   An array of feed IDs, such as 'EU' for the CNNI Eastern European Time
   *   Feed.
   * @param \DateTime $start_date
   *   The start date to search from.
   * @param \DateTime $end_date
   *   The end date to search to.
   * @param string $title
   *   Title Data.
   *
   * @return mixed
   *   Feed Data From Flow.
   */
  public function getNetworkFeedSchedulesForDateTitle(array $networks, array $feeds, \DateTime $start_date, \DateTime $end_date, $title);

  /**
   * Get updated Since data from Flow for a type.
   *
   * Currently there are two types defined in ContentFetchManager:
   *    CONTENT_TITLE_TYPE
   *    CONTENT_LINEAR_SCHEDULE_TYPE
   *
   * @param \DateTime $date_time
   *    Date from which to start data retrieval.
   * @param string $type
   *    Type of data to retrieve titles or linear schedules.
   *
   * @return array
   *    Array of objects containing titleIds or externalIds updated since.
   */
  public function getUpdatedSince(\DateTime $date_time, $type);

  /**
   * Get deleted Since data from Flow for a type.
   *
   * Currently there are two types defined in ContentFetchManager:
   *    CONTENT_TITLE_TYPE
   *    CONTENT_LINEAR_SCHEDULE_TYPE
   *
   * @param \DateTime $date_time
   *    Date from which to start data retrieval.
   * @param string $type
   *    Data type for retrieving titles or linear schedules.
   *
   * @return array
   *    Array of objects containing titleIds or externalIds of deleted contents.
   */
  public function getDeletedSince(\DateTime $date_time, $type);

  /**
   * Get updated titles.
   *
   * @param \DateTime $date_time
   *   Date from which to start search.
   *
   * @return array
   *    Array of objects containing titleIds updated since $data_time.
   */
  public function getTitlesUpdatedSince(\DateTime $date_time);

  /**
   * Get updated Linear Schedules.
   *
   * @param \DateTime $date_time
   *   Date and Time from which to start search.
   *
   * @return array
   *    Array of objects containing Schedule External Ids updated since.
   */
  public function getLinearSchedulesUpdatedSince(\DateTime $date_time);

  /**
   * Get Linear Schedules by date range.
   *
   * @param \DateTime $start
   *   Start of Date/Time range.
   * @param \DateTime $end
   *   End of Date/Time range.
   */
  public function getLinearSchedulesByDateRange(\DateTime $start, \DateTime $end);

  /**
   * Get the timestamp from a Flow Object Id.
   *
   * @param string $id
   *   Flow Object Id.
   *
   * @return mixed
   *   Timestamp extracted from id.
   */
  public function getTimeStampFromFlowObjectid($id);

  /**
   * Get title by id.
   *
   * @param array $ids
   *   Array of Title Ids.
   *
   * @return array
   *    Array of objects containing Flow Titles.
   */
  public function getTitlesByTitleIds(array $ids);

  /**
   * Get linear schedule data objects by ExternalIds.
   *
   * Flow sets the array limit to 25.
   *
   * @param array|null $external_ids
   *   ExternalIds.
   *
   * @return array
   *   Array of objects containing Flow Linear Schedules.
   */
  public function getLinearSchedulesByExternalIds(array $external_ids);

  /**
   * Returns BSON id based on provided date.
   *
   * It makes a call to FLOW API that determines date based on the provided date
   * so that no schedule data will be missed due to early updates of schedules
   * beyond the Grid Viewable Date. FLOW returns a BSON id based on the
   * determined date.
   *
   * @param \DateTime $date_time
   *   A date.
   *
   * @return string
   *   BSON id value, e.g., 58aab3dcea020707a4fa786e.
   */
  public function getBSONIdFromFlow(\DateTime $date_time);

}
