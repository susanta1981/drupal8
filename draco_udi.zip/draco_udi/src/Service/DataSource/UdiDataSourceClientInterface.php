<?php

namespace Drupal\draco_udi\Service\DataSource;

/**
 *
 */
interface UdiDataSourceClientInterface {

  /**
   * Make a http request call and return the body of response.
   *
   * @param string $url
   *    URL string of HTTP request.
   * @param array $headers
   *    Headers of HTTP request.
   *
   * @return \stdClass
   *    Response body as an object.
   */
  public function getContents($url, array $headers);

}
