<?php

namespace Drupal\draco_udi\Service\DataSource;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\draco_udi\Exception\UdiContentNotFoundException;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\WorkflowReport;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\Queue\UdiQueueClientInterface;
use Drupal\draco_udi\ContentDataImportWorkflowManager;

/**
 * Class UdiChangeProcessor.
 *
 * Process changes to upstream data from flow.
 *
 * @package Drupal\draco_udi\Service\DataSource
 */
class UdiChangeProcessor {

  /**
   * Logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * Constructor for UdiChangeProcessor.
   *
   * @param \Drupal\draco_udi\Service\Queue\UdiQueueClientInterface $queue_client
   *   Udi Queue Client that provides communication to draco queue.
   * @param \Drupal\draco_udi\ContentDataImportWorkflowManager $workflow_manager
   *   Draco import workflow manager.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $channel_factory
   *   Logger Factory.
   */
  public function __construct(UdiQueueClientInterface $queue_client,
                              ContentDataImportWorkflowManager $workflow_manager,
                              LoggerChannelFactoryInterface $channel_factory) {

    $this->queueClient = $queue_client;
    $this->logger = $channel_factory->get('udi_change_processor');
    $this->workflowManager = $workflow_manager;
  }

  /**
   * Defines the function that will process the queue messages.
   */
  public function getProcessFunction() {
    return function ($msg) {
      try {
        $change_msg = json_decode($msg);
        $item = $change_msg->data;
        $type = $change_msg->type;
        $action = $change_msg->action;
        $source = $change_msg->source;

        switch ($type) {
          case ContentFetchManager::CONTENT_TITLE_TYPE:
          case ContentFetchManager::CONTENT_SOURCE_TVE:
          case ContentFetchManager::CONTENT_ONDEMAND_WORKORDER_TYPE:
          case ContentFetchManager::CONTENT_SOURCE_HISTORICAL_TVE:
            $import_report = $this->workflowManager->import($item, $type, $action, $source);
            $this->logReport($import_report);
            break;

          case ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE:
          case ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE:
            if ($action == ContentFetchManager::CONTENT_DELETE_ACTION) {
              $remove_report = $this->workflowManager->remove($item, $type, $source);
              $this->logReport($remove_report);
            }
            else {
              // Insert or update.
              $import_report = $this->workflowManager->import($item, $type, $action, $source);
              $this->logReport($import_report);
            }
            break;

          default:
            $this->logger->error('Content type not yet implemented from source @source, ignoring.', ['@source' => $change_msg->source]);
            break;
        }
      }
      catch (UdiContentNotFoundException $e) {
        throw $e;
      }
      catch (\Exception $e) {
        $this->logger->error('Error processing SQS queue message: @msg, @errMsg', ['@msg' => $msg, '@errMsg' => $e->getMessage()]);
        // Let calling UdiSQSClient to handle the exception.
        throw new UdiProcessException('UdiChangeProcessor: Error in processing ' . $type . ' @type content item', 0, $e);
      }
    };
  }

  /**
   * Listen to messages on Queue until the provided time limit is reached.
   *
   * The $time_limit is optional. The client may get a limit set in UDI config.
   * If no limit is set in either case, this process will run indefintely until
   * been manually terminated.
   *
   * @param int $time_limit
   *   Time limit.
   */
  public function listen($time_limit = 0) {
    $processFunction = $this->getProcessFunction();
    $this->queueClient->listen($processFunction, $time_limit);
  }

  /**
   * Log meta about the process and processed item.
   *
   * @param array $reports
   *   Data from workflow for reporting.
   */
  private function logReport(array $reports) {
    /** @var WorkflowReport $report */
    foreach ($reports as $report) {
      if ($report->getStatus() == WorkflowReport::COMPLETE) {
        $action = $report->getAction();
        $type = $report->getContentType();
        $src = $report->getContentSource();
        $id = $report->getEntityId();
        $this->logger->info("UDI workflow processor: Processed message: type: @type; action: @action; upstream source: @src, draco entity id: @id",
          ['@type' => $type, '@action' => $action, '@src' => $src, '@id' => $id]);
      }
      elseif ($report->getStatus() == WorkflowReport::ERROR) {
        $this->logger->error("UDI workflow processor: " . $report->getMessage());
      }
      elseif ($report->getStatus() == WorkflowReport::NOP) {
        $this->logger->info("UDI workflow processor: " . $report->getMessage());
      }
    }
  }

}
