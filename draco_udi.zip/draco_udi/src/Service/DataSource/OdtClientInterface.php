<?php

namespace Drupal\draco_udi\Service\DataSource;


/**
 * Interface OdtClientInterface.
 *
 * @package Drupal\draco_udi\Service\DataSource
 */
interface OdtClientInterface extends UdiDataSourceClientInterface {

  /**
   * Retrieve an airing json object by an airingId with all options.
   *
   * @param $id
   *    AiringId that uniquely identifies an airing object in ODT.
   *
   * @return object
   *    A Json object of stdClass type.
   */
  public function getFullAiringContentById($id);

  /**
   * Retrieve an airing json object with selected options by an airingId.
   *
   * The default case is there is no options included in the returned airing.
   * If a flag, e.g., $file is set to true, the returned json will include the
   * corresponding data, "files" array in this case, in the "options" property.
   * If the data doesn't exist, an empty array will be returned.
   *
   * @param string $id
   *    AiringId that uniquely identifies an airing object in ODT.
   * @param bool $file
   *    Flag indicating if include file data in the returned json object.
   * @param bool $title
   *    Flag indicating if include title data in the returned json object.
   * @param bool $destination
   *    Flag indicating if include destination data in the returned json object.
   * @param bool $status
   *    Flag indicating if corresponding video is ready for various devices.
   *
   * @return object
   *    A Json object of stdClass type.
   */
  public function getAiringContentById(
      $id,
      $file = FALSE,
      $title = FALSE,
      $destination = FALSE,
      $status = FALSE
  );

  /**
   * Post video airing data to ODT and returns mediaId to calling client.
   *
   * The parameter can be either string or stdClass.
   *
   * The method returns a stdClass with following structure for successful post:
   * {
   *   'status': 'SUCCESSFUL',
   *   'airingId': 'TBSW1007201600000206',
   *   'mediaId': '3ad091fcee8aec2c65d83f2eb7adf59fbde808ad',
   *   'message': NULL
   * }
   *
   * If errors occur, it returns stdClass with following structure:
   * {
   *    'status': 'ERROR',
   *    'message': 'Post failed due to missing required data'
   * }
   *
   * @param mixed $airing_data
   *    A stdClass object or string json data for creating an airing.
   *
   * @return \stdClass
   *    Response object including mediaId or error.
   */
  public function postAiring($airing_data);

  /**
   * Register (post) media file data in ODT.
   *
   * The client may pass airing data as an option.
   *
   * Successful case:
   * {
   *   'status': 'SUCCESSFUL',
   *   'message': NULL
   * }
   *
   * Error/failure case:
   * {
   *   'status': 'ERROR',
   *   'message': 'Register failed due to invalid data.'
   * }
   *
   * @param mixed $register_data
   *    Array or encoded array string of airing data or files.
   * @param mixed $airing_data
   *    Airing data.
   */
  public function postFiles($register_data, $airing_data = NULL);

}
