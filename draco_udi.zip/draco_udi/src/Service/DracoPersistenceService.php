<?php

namespace Drupal\draco_udi\Service;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\draco_udi\Context;
use Drupal\draco_udi\Entity\ContentOnDemandSchedule;
use Drupal\draco_udi\Entity\ContentTitle;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Psr\Log\LoggerInterface;

/**
 * Class DracoPersistenceService.
 */
class DracoPersistenceService implements DracoPersistenceServiceInterface, ContainerInjectionInterface {

  protected $logger;

  /**
   * Constructor for Class.
   */
  public function __construct(LoggerInterface $logger_channel) {
    $this->logger = $logger_channel;
  }

  /**
   * Create an instance.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The service container this instance should use.
   *
   * @codeCoverageIgnore
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('draco_udi.logger.channel')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function save(Context $context) {

    if ($this->isEntityToBeSavedPending($context)) {
      $context->getEntityToSave()->save();
    }
    else {
      // For now we only have 1 Context. At some point we may add other contexts
      // such as a DRE context from sports clips.  When that happens we will
      // need to refactor to select a different persistence strategy for each
      // context, possibly utilizing plugins.
      $this->saveTitleContext($context);
    }
  }

  /**
   * Saves all entities in a  Title context object.
   *
   * @param \Drupal\draco_udi\Context $context
   *    Draco Context Object.
   */
  private function saveTitleContext(Context $context) {

    // Depending on the source and type of the incoming upstream element the
    // context will be different.  Therefore we need to check the type and
    // extract the data to be saved from the context.
    switch ($context->getEntityType()) {
      case ContentFetchManager::CONTENT_TITLE_TYPE:
        $this->saveDracoTitle($context);
        break;

      case ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE:
        $this->saveDracoLinearSchedule($context);
        break;

      case ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE:
        $this->saveDracoOndemandSchedule($context);
        break;

      default:
        $this->logger->error("Unknown Entity Type @type:  Could not be persisted",
          ['@type' => $context->getEntityType()]);
    }

  }

  /**
   * Save a Draco ContentTitle.
   *
   * @param \Drupal\draco_udi\Context $context
   *   context ojbect from Draco workflow.
   */
  private function saveDracoTitle(Context $context) {
    $title = $context->getEntityToSave();
    $relatedData = &$context->getRelatedData();
    $mappedContentArray = $this->getValueFromArray($relatedData, Context::RELATED_MAPPED_CONTENT_KEY, []);
    $mappedContent = $this->getValueFromArray($mappedContentArray, $title->id(), []);
    $this->saveTitleEntity($title, $mappedContent);
    $this->saveSchedulesForTitle($title, $this->getValueFromArray($relatedData, Context::RELATED_ONDEMAND_SCHEDULE_KEY, []));
    $this->saveSchedulesForTitle($title, $this->getValueFromArray($relatedData, Context::RELATED_LINEAR_SCHEDULE_KEY, []));

  }

  /**
   * Save a Draco ContentLinearSchedule.
   *
   * @param \Drupal\draco_udi\Context $context
   *   context object from Draco workflow.
   */
  private function saveDracoLinearSchedule(Context $context) {
    $schedule = $context->getEntityToSave();
    $relatedData = &$context->getRelatedData();
    $relatedTitles = $this->getValueFromArray($relatedData, Context::RELATED_TO_BE_MAPPED_KEY, []);
    $this->saveRelatedTitles($relatedTitles, $relatedData);
    $this->addTitlesToSchedule($schedule, $relatedTitles);
    $this->saveContent([$schedule]);

  }

  /**
   * Save a Draco ContentOndemandSchedule.
   *
   * @param \Drupal\draco_udi\Context $context
   *   context ojbect from Draco workflow.
   */
  private function saveDracoOndemandSchedule(Context $context) {
    $schedule = $context->getEntityToSave();
    $relatedData = &$context->getRelatedData();
    $relatedTitles = $this->getValueFromArray($relatedData, Context::RELATED_TO_BE_MAPPED_KEY, []);
    $this->saveRelatedTitles($relatedTitles, $relatedData);
    $this->addTitlesToSchedule($schedule, $relatedTitles);
    $flights = $this->getValueFromArray($relatedData, Context::RELATED_FLIGHTS_KEY, []);
    $this->saveContent($flights);
    $this->addFlightsToOndemandSchedule($schedule, $flights);
    $this->saveContent([$schedule]);

  }

  /**
   * Save Titles and their mappedContent.
   *
   * @param array $titles
   *   Array of ContentTitleEntities.
   * @param array $relatedData
   *   The relatedData from context.
   */
  private function saveRelatedTitles($titles, $relatedData) {
    foreach ($titles as $title) {
      $mappedContentArray = $this->getValueFromArray($relatedData, Context::RELATED_MAPPED_CONTENT_KEY, []);
      $mappedContent = $this->getValueFromArray($mappedContentArray, $title->id(), []);
      $this->saveTitleEntity($title, $mappedContent);
    }
  }

  /**
   * Save TitleEntity.
   *
   * @param ContentTitle $title
   *   ContentTitleEntitiy.
   * @param array $mappedContent
   *   Array of objects created during mapping process.
   */
  private function saveTitleEntity(ContentTitle $title, array $mappedContent) {
    $this->saveContent($mappedContent);
    $this->addMappedContentToTitle($title, $mappedContent);
    $this->saveContent([$title]);
  }

  /**
   * Call save on array of content.
   *
   * @param array $content
   *   Array of content to save.
   */
  private function saveContent(array $content) {
    foreach ($content as $entity) {
      if (method_exists($entity, 'save')) {
        $entity->save();
      }
      else {
        $this->logger->error('content to be saved contains an element which does not have a save method: @entity', ['@entity' => $entity]);
      }
    }
  }

  /**
   * Add mappedContent entity references to a title.
   *
   * @param ContentTitle $title
   *   ContentTitleEntitiy.
   * @param array $mappedContent
   *   Array of objects created during mapping process.
   */
  private function addMappedContentToTitle(ContentTitle $title, array $mappedContent) {
    $title->clearMappedContent();
    foreach ($mappedContent as $entity) {
      if (!$entity instanceof EntityInterface) {
        $this->logger->error('mapped content is not of type EntityInterface');
      }
      else {
        if (!in_array($entity->id(), $title->getMappedContentIds())) {
          $title->addMappedContent($entity->id());
        }
      }
    }
  }

  /**
   * Add Title entity references to a Schedule.
   *
   * @param mixed $schedule
   *   Schedule.
   * @param array $titles
   *   Array of TitleContent Entities.
   */
  private function addTitlesToSchedule($schedule, array $titles) {
    foreach ($titles as $title) {
      if (!$schedule->isAssociatedTitle($title->id())) {
        $schedule->addAssociatedTitle($title->id());
      }
    }
  }

  /**
   * Add Flight entity references to a Schedule.
   *
   * @param ContentOnDemandSchedule $schedule
   *   Schedule.
   * @param array $flights
   *   Array of ContentOndemandFlight Entities.
   */
  private function addFlightsToOndemandSchedule(ContentOnDemandSchedule $schedule, array $flights) {
    $this->removeExistingFlights($schedule);
    foreach ($flights as $flight) {
      if (!$schedule->hasFlight($flight->id())) {
        $schedule->addFlight($flight->id());
      }
    }
  }

  /**
   * Remove all the Flights from a schedule.
   *
   * @param ContentOnDemandSchedule $schedule
   *   Schedule.
   */
  private function removeExistingFlights(ContentOnDemandSchedule $schedule) {
    $flights = $schedule->getFlights();
    if (!empty($flights)) {
      foreach ($flights as $flight) {
        $schedule->removeFlight($flight->id());
        $flight->delete();
      }
    }
  }

  /**
   * Add Titles to all the schedules and save the schedule.
   *
   * @param ContentTitle $title
   *   ContentTitleEntitiy.
   * @param array $schedules
   *   Array of schedules.
   */
  private function saveSchedulesForTitle(ContentTitle $title, $schedules) {
    if (!empty($schedules)) {
      foreach ($schedules as $schedule) {
        $this->addTitlesToSchedule($schedule, [$title]);
        $this->saveContent([$schedule]);
      }
    }

  }

  /**
   * Determine in Entity is a Pending entity.
   *
   * @param Context $context
   *   Context object.
   */
  private function isEntityToBeSavedPending(Context $context) {
    $isPending = FALSE;
    if (!empty($context->getEntityToSave() && $context->getEntityToSave()->getEntityTypeId() == 'pending_content_entity')) {
      $isPending = TRUE;
    }
    return $isPending;
  }

  /**
   * Gets a value from an array object.
   *
   * @param array $data
   *   The array object.
   * @param string $key
   *   The key.
   * @param mixed $default
   *   Default value if key not found in array.
   *
   * @returns mixed
   *   Value from array.
   */
  private function getValueFromArray(array $data, $key, $default = NULL) {
    $val = $default;
    if (!empty($data)) {
      if (array_key_exists($key, $data)) {
        $val = $data[$key];
      }
    }
    return $val;
  }

}
