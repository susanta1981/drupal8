<?php

namespace Drupal\draco_udi\Service;

/**
 * Fetches Content from upstream systems and posts to queue.
 */
interface ContentFetchManagerInterface {

  /**
   * Fetch Titles from flow.
   *
   * @param mixed $lastFetched
   *   Date from which to start search.
   */
  public function fetchTitles($lastFetched = NULL);

  /**
   * Fetch Linear Schedules.
   *
   * It fetches linear schedules that are created or updated since the last
   * time this method is called. UDI saves the last updated date at the end
   * of each call. If no last updated date is found, it will throw an error
   * message.
   *
   * Usually user will run drush command udi-linear-schedule-fetcher that calls
   * this method. If no last updated date is found, the drush command will stop
   * and ask the user to run the udi-sync-linear-schedules to get all possible
   * missing schedules and reset the last updated date.
   */
  public function fetchLinearSchedules();

  /**
   * Fetch all linear schedules for the provided starting date.
   *
   * @param \DateTime $start_date
   *   Start date.
   */
  public function syncLinearSchedules(\DateTime $start_date);

  /**
   * Fetch deleted-since messages for linear schedules.
   *
   * It calls Flow's deletes-since API to download delete messages and drop
   * them to queue for UDI's workflow to process.
   *
   * @param mixed $lastFetched
   *   Date from which to start search.
   */
  public function fetchLinearScheduleDeletedSinceMessages($lastFetched = NULL);

  /**
   * Fetch Linear Schedules for a Date Range.
   *
   * @param \DateTime $start_date
   *   Start of Date/Time range.
   * @param \DateTime $end_date
   *   End of Date/Time range.
   */
  public function fetchLinearSchedulesForDateRange(\DateTime $start_date, \DateTime $end_date);

  /**
   * Fetch On Demand Schedules.
   *
   * @param int $time_limit
   *   Maximum amount of time to run.
   * @param int $max_items
   *   Maximum number of items to fetch from queue.
   */
  public function fetchOnDemandSchedules($time_limit, $max_items);

  /**
   * Fetch On Demand WorkOrders.
   *
   * @param int $time_limit
   *   Maximum amount of time to run.
   * @param int $max_items
   *   Maximun number of items to fetch from queue.
   */
  public function fetchOnDemandWorkOrders($time_limit, $max_items);

  /**
   * Post the TVE data to the Draco queue.
   *
   * @param string $data
   *   Tve data in serialized JSON format.
   * @param string $tve_type
   *   TVE Type, Current or historical.
   */
  public function postTveJson($data, $tve_type);

}
