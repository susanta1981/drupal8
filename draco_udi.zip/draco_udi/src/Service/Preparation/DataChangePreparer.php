<?php

namespace Drupal\draco_udi\Service\Preparation;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\draco_udi\Entity\ContentTitleInterface;
use Drupal\draco_udi\Entity\ContentLinearScheduleInterface;
use Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface;
use Drupal\draco_udi\Context;
use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\Reconciler\DracoReconcilerManager;
use Drupal\draco_udi\Service\ContentFetchManager;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;
use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class DataChangePreparer.
 *
 * Creates a context object to be used by the UDI workflow manager.
 *
 * @package Drupal\draco_udi\Service\Preparation
 */
class DataChangePreparer implements DataChangePreparerInterface, ContainerInjectionInterface {

  protected $logger;

  protected $entityManager;

  protected $queryFactory;

  protected $reconcilerManager;

  /**
   * DataChangePreparer constructor.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $channelFactory
   *    Logger factory.
   * @param \Drupal\Core\Entity\EntityManagerInterface $entity_manager
   *    Entity manager.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *    Query factory.
   * @param \Drupal\draco_udi\Reconciler\DracoReconcilerManager $reconciler_plugin_manager
   *    Reconciler service manager.
   */
  public function __construct(
      LoggerChannelFactoryInterface $channelFactory,
      EntityManagerInterface $entity_manager,
      QueryFactory $query_factory,
      DracoReconcilerManager $reconciler_plugin_manager
  ) {

    $this->logger = $channelFactory->get('draco_udi');
    $this->entityManager = $entity_manager;
    $this->queryFactory = $query_factory;
    $this->reconcilerManager = $reconciler_plugin_manager;

  }

  /**
   * Create an instance of DataChangePreparer.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *    Symfony container.
   *
   * @return static
   *    Injected services.
   */
  public static function create(ContainerInterface $container) {
    return new static(
          $container->get('logger.factory'),
          $container->get('entity.manager'),
          $container->get('entity.query'),
          $container->get('draco_udi.reconciler.manager')
      );
  }

  /**
   * Set context data for entire workflow.
   *
   * @param \Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet $converted_entity_set
   *    Set of converted Draco entities.
   * @param string $type
   *    Content data message type.
   * @param string $source
   *    Content data message source.
   *
   * @return \Drupal\draco_udi\Context
   *    Context.
   *
   * @throws UdiProcessException
   */
  public function prepareContext(ConvertedEntitySet $converted_entity_set, $type, $source) {

    $draco_entity = $converted_entity_set->getConvertedEntity();
    $context = NULL;

    if ($type == ContentFetchManager::CONTENT_TITLE_TYPE) {
      $context = $this->handleTitle($draco_entity);
    }
    elseif ($type == ContentFetchManager::CONTENT_LINEAR_SCHEDULE_TYPE) {
      $context = $this->handleLinearSchedule($draco_entity);
    }
    elseif ($type == ContentFetchManager::CONTENT_ONDEMAND_SCHEDULE_TYPE) {
      $context = $this->handleOnDemandSchedule($draco_entity, $converted_entity_set->getAssociatedEntities());
    }
    else {
      throw new UdiProcessException('Unknown type ' . $type . ' when trying to prepare context');
    }

    $context->setEntityType($type);
    $context->setEntitySource($source);
    $context->setSourceContent($converted_entity_set->getSourceJson());

    $this->reconcile($context);

    return $context;
  }

  /**
   * {@inheritdoc}
   */
  public function prepareContextForRemoveEntity(DracoContentInterface $entity, $type, $source) {
    $context = new Context();
    $context->setAction(ContentFetchManager::CONTENT_DELETE_ACTION);
    $context->setEntityType($type);
    $context->setEntitySource($source);
    $context->setCurrentEntity($entity);
    $context->setExistingEntity($entity);

    return $context;
  }

  /**
   * Add title entity and related data to a context object.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title
   *    Title entity.
   *
   * @return \Drupal\draco_udi\Context
   *    Context instance.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function handleTitle(ContentTitleInterface $title) {

    $context = new Context();
    $context->setCurrentEntity($title);

    $titles = $this->loadTitles([$title->getTitleId()]);
    $existingTitle = reset($titles);

    if ($existingTitle) {
      $context->setExistingEntity($existingTitle);
    }

    $odSchedules = $this->loadODSchedulesForTitle($title);
    $linearSchedules = $this->loadLinearSchedulesForTitle($title);
    $relatedData = &$context->getRelatedData();
    $relatedData['entitiesToBeMapped'] = [$title];
    $relatedData['odSchedules'] = $odSchedules;
    $relatedData['linearSchedules'] = $linearSchedules;

    return $context;

  }

  /**
   * Add linear schedule entity and related data to a context object.
   *
   * @param \Drupal\draco_udi\Entity\ContentLinearScheduleInterface $schedule
   *    Linear schedule entity.
   *
   * @return \Drupal\draco_udi\Context
   *    Context object.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function handleLinearSchedule(ContentLinearScheduleInterface $schedule) {

    $context = new Context();
    $context->setCurrentEntity($schedule);

    $existingSchedule = $this->loadLinearSchedule($schedule->getExternalId());

    if ($existingSchedule) {
      $context->setExistingEntity($existingSchedule);
    }
    $relatedData = &$context->getRelatedData();
    $relatedData[Context::RELATED_TITLES_KEY] = $this->loadTitles($schedule->getTitleIdList());
    return $context;
  }

  /**
   * Add on-demand schedule entity and related data to a context object.
   *
   * @param \Drupal\draco_udi\Entity\ContentOnDemandScheduleInterface $schedule
   *    On-demand schedule entity.
   * @param array $flights
   *    Array of on-demand schedule flight entities.
   *
   * @return \Drupal\draco_udi\Context
   *    Context object.
   */
  private function handleOnDemandSchedule(ContentOnDemandScheduleInterface $schedule, array $flights) {

    $context = new Context();
    $context->setCurrentEntity($schedule);

    $existingSchedule = $this->loadOnDemandSchedule($schedule->getAiringId());

    if ($existingSchedule) {
      $context->setExistingEntity($existingSchedule);
    }

    $relatedData = &$context->getRelatedData();
    $relatedData[Context::RELATED_FLIGHTS_KEY] = $flights;
    $relatedData[Context::RELATED_TITLES_KEY] = $this->loadTitles($schedule->getTitleIdList());

    return $context;

  }

  /**
   * Returns on-demand schedule entities related to the passed title.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title
   *    A title entity.
   *
   * @return array
   *    Associated on-demand schedule entities.
   */
  private function loadODSchedulesForTitle(ContentTitleInterface $title) {
    return $this->loadSchedulesForTitle($title, 'content_on_demand_schedule');
  }

  /**
   * Returns linear schedule entities related to the passed title.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title
   *    A title entity.
   *
   * @return array
   *    Associated linear schedule entities.
   */
  private function loadLinearSchedulesForTitle(ContentTitleInterface $title) {
    return $this->loadSchedulesForTitle($title, 'content_linear_schedule');
  }

  /**
   * Returns schedule entities associated with the passed title.
   *
   * @param \Drupal\draco_udi\Entity\ContentTitleInterface $title
   *    A title entity.
   * @param string $entity_type_id
   *    Type of schedule type, linear or on-demand.
   *
   * @return array
   *    Schedule entities.
   */
  private function loadSchedulesForTitle(ContentTitleInterface $title, $entity_type_id) {

    $query = $this->queryFactory->get($entity_type_id)->condition('title_ids', $title->getTitleId(), 'CONTAINS');
    $ids = $query->execute();

    $entities = array();

    if (count($ids) > 0) {
      // TODO Investigate this:
      // Returns an array of entity objects indexed by their IDs.
      $results = $this->entityManager->getStorage($entity_type_id)->loadMultiple($ids);

      if ($results) {
        $entities = array_values($results);
      }
    }

    return $entities;
  }

  /**
   * Returns content_title entities.
   *
   * @param array $title_ids
   *   Title_ids.
   *
   * @return array
   *   Title entities.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function loadTitles(array $title_ids) {
    $entities = array();

    if (empty($title_ids)) {
      return $entities;
    }

    $entityTypeId = 'content_title';

    $query = $this->queryFactory->get($entityTypeId)->condition('title_id', $title_ids, 'IN');
    $ids = $query->execute();

    if (count($ids) > 0) {
      if (count($ids) > count($title_ids)) {
        // TODO log here.
        throw new EntityStorageException('Too many titles found for ids ' . implode(',', $title_ids));
      }

      // TODO Investigate this:
      // Returns an array of entity objects indexed by their IDs.
      $results = $this->entityManager->getStorage($entityTypeId)->loadMultiple($ids);

      if ($results) {
        $entities = array_values($results);
      }
    }

    return $entities;

  }

  /**
   * Load a linear schedule entity by external_id defined by Flow.
   *
   * @param string $external_id
   *    External_id.
   *
   * @return \Drupal\Core\Entity\EntityInterface|null
   *    Linear schedule entity.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function loadLinearSchedule($external_id) {
    return $this->loadSchedule($external_id, 'external_id', 'content_linear_schedule');
  }

  /**
   * Load an on-demand schedule entity by airing_id defined by ODT.
   *
   * @param string $airing_id
   *    Airing id.
   *
   * @return \Drupal\Core\Entity\EntityInterface|null
   *    On-demand schedule entity.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function loadOnDemandSchedule($airing_id) {
    return $this->loadSchedule($airing_id, 'airing_id', 'content_on_demand_schedule');
  }

  /**
   * Load a schedule entity.
   *
   * @param string $id
   *    Entity id.
   * @param string $field_name
   *    A field name.
   * @param string $entity_type_id
   *    Entity type.
   *
   * @return \Drupal\Core\Entity\EntityInterface|null
   *    Schedule entity.
   *
   * @throws UdiProcessException
   */
  private function loadSchedule($id, $field_name, $entity_type_id) {

    $query = $this->queryFactory->get($entity_type_id)->condition($field_name, $id);
    $ids = $query->execute();

    $entity = NULL;

    if (count($ids) > 0) {
      if (count($ids) > 1) {
        $msg = sprintf('Error found more than one %s entity in db when searching field %s with value %s. Only one is expected.',
          $entity_type_id, $field_name, $id);
        $this->logger->error($msg);
        throw new UdiProcessException($msg);
      }

      // The the value in ids is keyed by the value itself. ids[0] doesn't work.
      foreach ($ids as $id) {
        $entity = $this->entityManager->getStorage($entity_type_id)->load($id);
      }
    }

    return $entity;
  }

  /**
   * Reconcile data.
   *
   * TODO currently do nothing. We need to revisit our design if we should
   * remove it.
   *
   * @param Context $context
   *    Context object.
   */
  private function reconcile(Context $context) {

    $reconcilers = $this->reconcilerManager->getDefinitions();
    foreach ($reconcilers as $reconciler) {
      $instance = $this->reconcilerManager->createInstance($reconciler['id']);
      $instance->reconcile($context);
    }
  }

}
