<?php

namespace Drupal\draco_udi\Service\Preparation;

use Drupal\draco_udi\Entity\DracoContentInterface;
use Drupal\draco_udi\Service\ContentConverter\ConvertedEntitySet;

/**
 * Interface DataChangePreparerInterface.
 *
 * Prepares the context for further workflow processing.
 * Preparing includes fetching related data and performing
 * reconciliation.
 */
interface DataChangePreparerInterface {

  /**
   * Create a Context object for importing contents.
   *
   * @param ConvertedEntitySet $converted_entity_set
   *   Converted entity set.
   * @param string $type
   *   Type of the incoming entity.
   * @param string $source
   *    Content data message source.
   *
   * @return \Drupal\draco_udi\Context
   *   The prepared Context.
   */
  public function prepareContext(ConvertedEntitySet $converted_entity_set, $type, $source);

  /**
   * Create a Context object for removing the target entity.
   *
   * @param DracoContentInterface $entity
   *   Converted entity set.
   * @param string $type
   *   Type of the content entity.
   * @param string $source
   *    Content data message source.
   *
   * @return \Drupal\draco_udi\Context
   *   The prepared Context.
   */
  public function prepareContextForRemoveEntity(DracoContentInterface $entity, $type, $source);

}
