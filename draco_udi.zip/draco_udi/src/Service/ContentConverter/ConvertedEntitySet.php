<?php

namespace Drupal\draco_udi\Service\ContentConverter;

use Drupal\draco_udi\Entity\DracoContentInterface;

/**
 * Class ConvertedEntitySet.
 *
 * @package Drupal\draco_udi\Service\ContentConverter
 */
class ConvertedEntitySet {
  private $sourceJson;
  private $convertedEntity;
  private $convertedEntityExistingCopy;
  private $associatedEntities;
  private $targetType;

  /**
   * ConvertedEntitySet constructor.
   *
   * @param \stdClass $source_json
   *   Source Json.
   * @param string $target_type
   *   Type of target entity defined in ContentFetchManager, e.g., "Title.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $converted_entity
   *   The converted Draco entity.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $existing_copy
   *   Existing Copy.
   * @param array $associated_entities
   *   Associated entities.
   */
  public function __construct(
      \stdClass $source_json,
      $target_type,
      DracoContentInterface $converted_entity = NULL,
      DracoContentInterface $existing_copy = NULL,
      array $associated_entities = NULL
  ) {
    $this->setSourceJson($source_json);
    $this->setConvertedEntity($converted_entity);
    $this->setConvertedEntityExistingCopy($existing_copy);
    if (empty($associated_entities)) {
      $associated_entities = [];
    }
    $this->setAssociatedEntities($associated_entities);
    $this->setTargetType($target_type);
  }

  /**
   * Get downloaded source json object.
   *
   * @return \stdClass
   *   Source json object.
   */
  public function getSourceJson() {
    return $this->sourceJson;
  }

  /**
   * Set downloaded source json object.
   *
   * @param \stdClass $source_json
   *   | NULL
   *   Source json object.
   */
  public function setSourceJson(\stdClass $source_json = NULL) {
    $this->sourceJson = $source_json;
  }

  /**
   * Get converted converted entity.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *   The converted primary entity.
   */
  public function getConvertedEntity() {
    return $this->convertedEntity;
  }

  /**
   * Set converted entity, e.g., ContentTitle, ContentOnDemandSchedule.
   *
   * @param mixed $converted_entity
   *   Converted entity.
   */
  public function setConvertedEntity($converted_entity) {
    $this->convertedEntity = $converted_entity;
  }

  /**
   * Get clone of the existing converted entity.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface
   *   Entity.
   */
  public function getConvertedEntityExistingCopy() {
    return $this->convertedEntityExistingCopy;
  }

  /**
   * Set clone of the existing converted entity.
   *
   * @param mixed $existing_copy
   *    Clone of entity.
   */
  public function setConvertedEntityExistingCopy($existing_copy) {
    $this->convertedEntityExistingCopy = $existing_copy;
  }

  /**
   * Get converted associated entities.
   *
   * @return array
   *   Associated entities.
   */
  public function getAssociatedEntities() {
    return $this->associatedEntities;
  }

  /**
   * Set converted associated entities, e.g., ContentOnDemandFlight.
   *
   * ContentOnDemandFlight is created from ODT airing object, along with its
   * parent entity ContentOnDemandSchedule.
   *
   * @param array $assoc_entities
   *   Associated entities.
   */
  public function setAssociatedEntities(array $assoc_entities = NULL) {
    $this->associatedEntities = $assoc_entities;
  }

  /**
   * Return target entity type, i.e., 'Title', 'OnDemandSchedule', etc.
   *
   * @return string
   *    Target entity type.
   */
  public function getTargetType() {
    return $this->targetType;
  }

  /**
   * Set target type.
   *
   * @param string $target_type
   *    Type of target entity.
   */
  public function setTargetType($target_type) {
    $this->targetType = $target_type;
  }

}
