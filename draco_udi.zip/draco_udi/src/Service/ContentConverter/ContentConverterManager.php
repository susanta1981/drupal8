<?php

namespace Drupal\draco_udi\Service\ContentConverter;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;

/**
 * Class ContentConverterManager.
 *
 * @package Drupal\draco_udi\Service\ContentConverter
 */
class ContentConverterManager extends DefaultPluginManager {

  /**
   * ContentConverterManager constructor.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   *
   * @codeCoverageIgnore
   */
  public function __construct(
      \Traversable $namespaces,
      CacheBackendInterface $cache_backend,
      ModuleHandlerInterface $module_handler
  ) {
    parent::__construct('Plugin/ContentConverter', $namespaces, $module_handler,
                        'Drupal\draco_udi\Service\ContentConverter\ContentConverterInterface',
                        'Drupal\draco_udi\Annotation\ContentConverterStrategy');

    $this->alterInfo('draco_content_converter_info');
    $this->setCacheBackend($cache_backend, 'draco_content_converters');
  }

  /**
   * Return converter plugin instances by the converter type.
   *
   * @param string $converter_type
   *    Id of converter, e.g., 'Title', 'onDemandSchedule'.
   *
   * @return array
   *    Array of Converter plugin instances.
   */
  public function getConverters($converter_type) {
    $converters = [];
    $definitions = $this->getDefinitions();

    if (empty($definitions) || count($definitions) == 0) {
      return $converters;
    }
    else {
      foreach ($definitions as $plugin_id => $definition) {
        if ($plugin_id == $converter_type) {
          $converters[] = $this->createInstance($plugin_id);
        }
      }
    }

    return $converters;
  }

}
