<?php

namespace Drupal\draco_udi\Service\ContentConverter;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\draco_udi\Entity\DracoContentInterface;

/**
 * Interface ContentConverterInterface.
 *
 * Implemented by content data converter plugins.
 *
 * @package Drupal\draco_udi\Service\ContentConverter
 */
interface ContentConverterInterface extends ContainerFactoryPluginInterface {

  /**
   * Convert downloaded upstream content data to an entity.
   *
   * @param \stdClass $content_data
   *    Downloaded upstream content data.
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $existing_draco_entity
   *    Existing draco entity for updating.
   *
   * @return ConvertedEntitySet
   *    An instance of ConvertedEntitySet holding converted entites.
   */
  public function convert(\stdClass $content_data = NULL, DracoContentInterface $existing_draco_entity = NULL);

  /**
   * Search db and return the entity if found. There should be only one found.
   *
   * @param \stdClass $content_data
   *    Upstream content object.
   *
   * @return \Drupal\draco_udi\Entity\DracoContentInterface|null
   *    Entity loaded from db or NULL if not found.
   */
  public function findExistingEntity(\stdClass $content_data);

  /**
   * Get the Mapped Entity Type.
   *
   * @return string
   *    Machine name of the mapped entity, i.e., content_title,
   *    content_linear_schedule.
   */
  public function getMappedEntityType();

}
