<?php

namespace Drupal\draco_udi\Service;

/**
 *
 */
interface FilterBasedContentFetchManagerInterface {

  /**
   * Fetch title objects by ids from Flow.
   *
   * @param array $title_ids
   *    Title id list.
   * @param array $content_types
   *    Array of types of content on the list.
   */
  public function fetchTitlesByIds(array $title_ids, array $content_types);

}
