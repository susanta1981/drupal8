<?php

namespace Drupal\draco_udi\Service;

use Drupal\Core\Entity\EntityManagerInterface;
use Drupal\Core\Entity\EntityStorageException;
use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\draco_udi\Entity\ContentOnDemandSchedule;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class DracoContentRepository.
 *
 * @package Drupal\draco_udi\Service
 */
class DracoContentRepository implements DracoContentRepositoryInterface {

  /**
   * Logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * Query factory.
   *
   * @var \Drupal\Core\Entity\Query\QueryFactory
   */
  protected $entityQuery;

  /**
   * Entity manager.
   *
   * @var \Drupal\Core\Entity\EntityManagerInterface
   */
  protected $entityManager;

  const ON_DEMAND_SCHEDULE_ACTIVE = 'active on-demand schedule';
  const ON_DEMAND_SCHEDULE_FUTURE = 'future on-demand schedule';
  const ON_DEMAND_SCHEDULE_EXPIRED = 'expired on-demand schedule';

  /**
   * DracoContentRepository constructor.
   *
   * @param \Psr\Log\LoggerInterface $logger
   *    Logger.
   * @param EntityManagerInterface $entity_manager
   *    Entity manager.
   * @param QueryFactory $query_factory
   *    Entity query factory.
   */
  public function __construct(
      LoggerInterface $logger,
      EntityManagerInterface $entity_manager,
      QueryFactory $query_factory
  ) {
    $this->logger = $logger;
    $this->entityManager = $entity_manager;
    $this->entityQuery = $query_factory;
  }

  /**
   * Create method for DracoContentRepository.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *    Service container.
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('draco_udi.logger.channel'),
      $container->get('entity.manager'),
      $container->get('entity.query')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getContentTitleByTitleId($title_id) {
    $query = $this->entityQuery->get('content_title')->condition('title_id', $title_id);
    $ids = $query->execute();
    $title = NULL;

    if (count($ids) == 1) {
      $id = reset($ids);
      $title = $this->entityManager->getStorage('content_title')->load($id);
    }
    elseif (count($ids) > 1) {
      throw new EntityStorageException('Found more than one ContentTitle entity found for title id ' . $title_id);
    }

    return $title;
  }

  /**
   * {@inheritdoc}
   */
  public function getOnDemandSchedulesByMediaId($media_id) {
    $schedules = [];
    $query = $this->entityQuery->get('content_on_demand_schedule')->condition('media_id', $media_id);
    $ids = $query->execute();
    if (!empty($ids)) {
      $schedules = $this->entityManager->getStorage('content_on_demand_schedule')
        ->loadMultiple($ids);
    }
    return $schedules;
  }

  /**
   * {@inheritdoc}
   */
  public function getContentOnDemandSchedulesByTitleId($title_id) {
    return $this->loadScheduleEntities($title_id, 'content_on_demand_schedule');
  }

  /**
   * {@inheritdoc}
   */
  public function getMostRecentContentOnDemandScheduleByTitleId($title_id) {
    $schedules = $this->getContentOnDemandSchedulesByTitleId($title_id);

    $active_schedules = [];
    $future_schedules = [];
    $expired_schedules = [];

    if (count($schedules) == 0) {
      return NULL;
    }

    // Time used to determine if a flight is active, future, or expired.
    $current_time = (new \DateTime())->getTimestamp();

    // Sort schedules into three categories by one of their flights.
    // In case a schedule has more than one flight, it may be added
    // to more than one times in different categories, depending on
    // if the flight is active, future, or expired.

    /** @var \Drupal\draco_udi\Entity\ContentOnDemandSchedule $schedule */
    foreach ($schedules as $schedule) {
      $flights = $schedule->getFlights();

      /** @var \Drupal\draco_udi\Entity\ContentOnDemandFlight $flight */
      foreach ($flights as $flight) {
        $flight_start = $flight->getStart()->getTimestamp();
        $flight_end = $flight->getEnd()->getTimestamp();

        if ($current_time >= $flight_start && $current_time <= $flight_end) {
          $active_schedules[$flight_start] = $schedule;
        }
        elseif ($current_time > $flight_end) {
          $expired_schedules[$flight_end] = $schedule;
        }
        elseif ($current_time < $flight_start) {
          $future_schedules[$flight_start] = $schedule;
        }
      }
    }

    // Find the most recent schedule in sequence: active, future, expired.
    $airing = NULL;

    if (count($active_schedules) > 0) {
      $airing = $this->getMostRecentOnDemandSchedule($active_schedules, self::ON_DEMAND_SCHEDULE_ACTIVE);
    }
    elseif (count($future_schedules) > 0) {
      $airing = $this->getMostRecentOnDemandSchedule($future_schedules, self::ON_DEMAND_SCHEDULE_FUTURE);
    }
    elseif (count($expired_schedules) > 0) {
      $airing = $this->getMostRecentOnDemandSchedule($expired_schedules, self::ON_DEMAND_SCHEDULE_EXPIRED);
    }

    return $airing;
  }

  /**
   * Get the most recent schedule with flight closest to the current time.
   *
   * The most recent active schedule is one with biggest start time.
   * The most recent expired schedule is one with biggest end time.
   * The most recent future schedule is one with smallest start time.
   *
   * @param array $schedules
   *    List of schedules keyed by start time.
   *
   * @param string $flight_state
   *    Flight state, i.e., active, future, or expired.
   *
   * @return ContentOnDemandSchedule
   *    An on-demand schedule entity.
   */
  private function getMostRecentOnDemandSchedule(array $schedules, $flight_state) {
    $recent_schedule = NULL;

    switch ($flight_state) {
      case self::ON_DEMAND_SCHEDULE_ACTIVE:
      case self::ON_DEMAND_SCHEDULE_EXPIRED:
        krsort($schedules);
        $recent_schedule = reset($schedules);
        break;
      case self::ON_DEMAND_SCHEDULE_FUTURE:
        ksort($schedules);
        $recent_schedule = reset($schedules);
        break;
      default:
        break;
    }

    return $recent_schedule;
  }

  /**
   * {@inheritdoc}
   */
  public function sortOnDemandFlights(array &$flights, $field, $asc = TRUE) {
    usort($flights, function ($a, $b) use (&$field, &$asc) {
      if ($asc) {
        return strcmp(strtolower($a->$field), strtolower($b->$field));
      }
      else {
        return strcmp(strtolower($b->$field), strtolower($a->$field));
      }
    });
  }

  /**
   * {@inheritdoc}
   */
  public function getContentLinearSchedulesByTitleId($title_id) {
    return $this->loadScheduleEntities($title_id, 'content_linear_schedule');
  }

  /**
   * Query and load associated linear/on-demand schedule entities by title id.
   *
   * TitleId is business key that associate schedule entities with its title
   * entity, and one schedule may be associated with more than one title.
   *
   * @param int $title_id
   *   Title id.
   * @param string $entity_name
   *   Values like "content_on_demand_schedule", "content_linear_schedule", etc.
   *
   * @return array|null
   *    Schedule entities.
   *
   * @throws EntityStorageException
   */
  private function loadScheduleEntities($title_id, $entity_name) {
    $query = $this->entityQuery->get($entity_name)->condition('title_ids.value', $title_id);
    $ids = $query->execute();
    $schedules = [];

    if (!empty($ids)) {
      $schedules = $this->entityManager->getStorage($entity_name)->loadMultiple($ids);
    }

    return $schedules;
  }

}
