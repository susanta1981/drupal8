<?php

namespace Drupal\draco_udi\Service;

use Drupal\draco_udi\Context;

/**
 * Class DracoPersistenceServiceInterface.
 */
interface DracoPersistenceServiceInterface {

  /**
   * Saves all entities in a context object.
   *
   * @param \Drupal\draco_udi\Context $context
   *    Draco Context Object.
   *    All elements in context must be of type Drupal\Core\Entity\Entity.
   */
  public function save(Context $context);

}
