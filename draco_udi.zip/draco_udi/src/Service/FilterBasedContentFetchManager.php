<?php

namespace Drupal\draco_udi\Service;

use Drupal\Core\Entity\Query\QueryFactory;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\State\State;
use Drupal\draco_udi\Events\UdiSeriesEvent;
use Drupal\draco_udi\Filter\ContentFilterManager;
use Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface;
use Drupal\draco_udi\Service\DataSource\OdtClientInterface;
use Drupal\draco_udi\Service\Queue\UdiQueueClientInterface;

/**
 * Class FilterBasedContentFetchManager.
 *
 * @package Drupal\draco_udi\Service
 */
class FilterBasedContentFetchManager extends ContentFetchManager implements FilterBasedContentFetchManagerInterface {

  protected $queryFactory;

  /**
   * FilterBasedContentFetchManager constructor.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $channel_factory
   *   Have to inject factory as this class is loaded as a service.
   * @param \Drupal\draco_udi\Service\DataSource\Flow\FlowClientInterface $flow_client
   *   Flow Client.
   * @param \Drupal\draco_udi\Service\Queue\UdiQueueClientInterface $odt_queue_client
   *   ODT Queue Client.
   * @param \Drupal\draco_udi\Service\DataSource\OdtClientInterface $odt_http_client
   *   ODT Http Client.
   * @param \Drupal\draco_udi\Service\Queue\UdiQueueClientInterface $queue_client
   *   Queue Client.
   * @param \Drupal\draco_udi\Filter\ContentFilterManager $filter_manager
   *   Filter manager.
   * @param \Drupal\Core\State\State $state
   *   State.
   * @param \Drupal\Core\Entity\Query\QueryFactory $query_factory
   *   Entity query factory.
   */
  public function __construct(
      LoggerChannelFactoryInterface $channel_factory,
      FlowClientInterface $flow_client,
      UdiQueueClientInterface $odt_queue_client,
      OdtClientInterface $odt_http_client,
      UdiQueueClientInterface $queue_client,
      ContentFilterManager $filter_manager,
      State $state,
      QueryFactory $query_factory
  ) {
    parent::__construct($channel_factory, $flow_client, $odt_queue_client,
      $odt_http_client, $queue_client, $filter_manager, $state);
    $this->queryFactory = $query_factory;
  }

  /**
   * {@inheritdoc}
   */
  public function fetchTitlesByIds(array $title_ids, array $content_types) {
    foreach ($title_ids as $title_id) {
      // Ignore if the entity already exists.
      if (!$this->titleExists($title_id)) {
        $title_json = $this->getDataFromFlow($title_id, self::CONTENT_TITLE_TYPE);

        if ($title_json != NULL && $this->validateContentType($title_json, $content_types)) {
          // Action is insert not upsert.
          $this->postToQueue($title_json, new \DateTime(), self::CONTENT_TITLE_TYPE,
            self::CONTENT_SOURCE_FLOW, self::CONTENT_INSERT_ACTION);

          $this->logger->info('Whitelist: downloaded and enqueued title content object @id.',
            ['@id' => $title_id]);
        }
        else {
          $this->logger->error('Whitelist failed to download title content with title id @id. ' .
            'Check if the title id is invalid, content is a wrong type in this whitelist, or the title content does not exist in connected Flow service.',
            ['@id' => $title_id]);
        }
      }
      else {
        $this->logger->info('Whitelist for content object @id already exists.',
          ['@id' => $title_id]);
      }
    }
  }

  /**
   * Determines if $title is a series.
   *
   * Determines if $title is a series based on the presence of the SeriesItem
   *   property.
   *
   * @param \stdClass $title
   *   Title Json.
   *
   * @return bool
   *   Boolean indicating if $title is a series.
   */
  private function isSeries(\stdClass $title) {
    $series = FALSE;
    if (isset($title->SeriesItems)) {
      $series = TRUE;
    }
    return $series;
  }

  /**
   * Check the TitleType->Name of downloaded flow title with $content_type.
   *
   * In case user adds a wrong type of titleid, we can't import it.
   *
   * @param \stdClass $title_json
   *   Title object.
   * @param array $content_types
   *   Array of content types.
   *
   * @return bool
   *    True if valid or false.
   */
  private function validateContentType(\stdClass $title_json, array $content_types) {
    if (isset($title_json->TitleType)) {
      $type = $title_json->TitleType->Name;

      if ($this->isSeries($title_json) || in_array($type, $content_types)) {
        return TRUE;
      }
    }

    return FALSE;
  }

  /**
   * Check if a ContentTitle entity with a certain titleid exists in db.
   *
   * @param int $title_id
   *   Title id to check.
   *
   * @return bool
   *   True if exists otherwise false.
   */
  private function titleExists($title_id) {
    $count = $this->queryFactory->get('content_title')
      ->condition('title_id', $title_id)
      ->count()
      ->execute();

    return ($count == 1) ? TRUE : FALSE;
  }

  /**
   * Parse the series content object to get the title ids of its child items.
   *
   * @param \stdClass $title_json
   *   Content data object.
   *
   * @return array
   *   Title ids of child items.
   */
  private function getChildItemTitleIds(\stdClass $title_json) {
    $title_ids = [];

    if (isset($title_json->SeriesItems)) {
      $items = $title_json->SeriesItems;

      foreach ($items as $item) {
        if (isset($item->TitleId)) {
          $title_ids[] = $item->TitleId;
        }
      }
    }

    return $title_ids;
  }

  /**
   * Get title types of child items.
   *
   * @param \stdClass $title_json
   *   Content data object.
   *
   * @return array
   *   Array of child items Title Types.
   */
  private function getChildItemTypes(\stdClass $title_json) {
    $title_types = [];

    if (isset($title_json->SeriesItems)) {
      $items = $title_json->SeriesItems;

      foreach ($items as $item) {
        if (isset($item->TitleType)) {
          if (!in_array($item->TitleType, $title_types)) {
            $title_types[] = $item->TitleType;
          }
        }
      }
    }

    return $title_types;
  }

  /**
   * UdiSeriesEvent::UDI_SERIES_CONTENT_IMPORT_SUCCESSFUL event callback.
   *
   * @param \Drupal\draco_udi\Events\UdiSeriesEvent $event
   *   Event received.
   *
   * @throws \Exception
   */
  public function onSeriesContentImportComplete(UdiSeriesEvent $event) {
    $data = $event->getData();

    if ($data == NULL || !isset($data['contentType'])) {
      return;
    }

    if ($data['contentType'] == self::CONTENT_TITLE_TYPE && isset($data['sourceContent'])) {
      $source_content = $data['sourceContent'];
      $child_title_ids = $this->getChildItemTitleIds($source_content);
      $content_types = $this->getChildItemTypes($source_content);
      $name = $source_content->TitleName;

      // Import series episodes.
      if (!empty($child_title_ids)) {
        $this->logger->info("Whitelist: import child items of series '" . $name .
          "'. Number of items: " . count($child_title_ids));

        $this->fetchTitlesByIds($child_title_ids, $content_types);
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    $events[UdiSeriesEvent::UDI_SERIES_CONTENT_IMPORT_SUCCESSFUL][] = ['onSeriesContentImportComplete'];
    return $events;
  }

}
