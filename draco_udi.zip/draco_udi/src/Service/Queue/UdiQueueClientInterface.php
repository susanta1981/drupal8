<?php

namespace Drupal\draco_udi\Service\Queue;

/**
 * Queue client for draco_udi module.
 *
 * Interface UdiQueueClientInterface.
 *
 * @package Drupal\draco_udi\Service\Queue
 */
interface UdiQueueClientInterface {

  /**
   * Post a message to SQS queue.
   *
   * @param mixed $messageBody
   *   Body of the message.
   * @param string $type
   *   Content type of message.
   */
  public function postMessage($messageBody, $type = NULL);

  /**
   * Post a JSON message to SQS queue.
   *
   * @param mixed $messageBody
   *   Body of the message.
   */
  public function postJsonMessage($messageBody);

  /**
   * Listen to queue for messages.
   *
   * @param mixed $process_function
   *   Callback function to call when message received.
   */

  /**
   * Listen to queue for messages.
   *
   * @param $process_function
   *    Callback function.
   * @param int $time_limit
   *    Run time length. If > 0 then process will end after that many minutes.
   *    0 means run indefinitely.
   * @param int $max_items
   *    Maximum number of items to fetch from queue.
   *    If > 0 then after $max_items are fetched from queue
   *    the listen process will end.
   */
  public function listen($process_function, $time_limit = 0, $max_items = 0);

}
