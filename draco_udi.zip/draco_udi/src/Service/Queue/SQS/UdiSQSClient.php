<?php

namespace Drupal\draco_udi\Service\Queue\SQS;

use Drupal\Component\Utility\Timer;
use Drupal\draco_udi\Exception\UdiConfigurationException;
use Drupal\draco_udi\Exception\UdiContentNotFoundException;
use Drupal\draco_udi\Exception\UdiProcessException;
use Drupal\draco_udi\Service\Queue\UdiQueueClientInterface;
use Aws\Sqs\SqsClient;
use Drupal\Core\Config\ConfigFactoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Psr\Log\LoggerInterface;

/**
 * Class UdiSQSClient.
 *
 * Draco client to communicate with SQS for draco_udi module.
 *
 * @package Drupal\draco_udi\Service\Queue\SQS
 */
class UdiSQSClient implements UdiQueueClientInterface {

  private $queueUrl;
  private $client;
  private $waitTimeSeconds;
  private $runtime_limit;
  private $logger;

  static private $PROCESS_NAME = 'udi-workflow-processor';

  /**
   * UdiSQSClient constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *    Config factory.
   * @param \Psr\Log\LoggerInterface $logger_channel
   *    Logger.
   */
  public function __construct(ConfigFactoryInterface $config_factory, LoggerInterface $logger_channel) {

    $config = $config_factory->get('draco_udi.settings');

    if (!empty($config)) {
      $key = $config->get('queue_settings.sqs_key');
      $secret = $config->get('queue_settings.sqs_secret');
      $region = $config->get('queue_settings.sqs_region');
      $changeQueueName = $config->get('queue_settings.sqs_change_q_name');
      $this->waitTimeSeconds = $config->get('queue_settings.sqs_wait_time_secs');
      $this->runtime_limit = $config->get('workflow_settings.processing_runtime_limit');

      if (empty($this->runtime_limit) || $this->runtime_limit < 0) {
        $this->runtime_limit = 0;
      }
    }

    // Validate.
    if (empty($key)) {
      throw new UdiConfigurationException('key is not defined.');
    }
    if (empty($secret)) {
      throw new UdiConfigurationException('secret is not defined.');
    }
    if (empty($region)) {
      throw new UdiConfigurationException('region is not defined.');
    }
    if (empty($changeQueueName)) {
      throw new UdiConfigurationException('change queue name is not defined.');
    }
    if (empty($this->waitTimeSeconds)) {
      throw new UdiConfigurationException('wait time seconds is not defined.');
    }

    $this->logger = $logger_channel;

    $this->client = SqsClient::factory(
          array(
            'credentials' => array('key' => $key, 'secret' => $secret),
            'region' => $region,
            'version' => '2012-11-05',
          )
      );

    $this->queueUrl = $this->client->getQueueUrl(
          array(
            'QueueName' => $changeQueueName,
          )
      )->get('QueueUrl');

  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container) {

    return new static(
      $container->get('config.factory'),
      $container->get('draco_udi.logger.channel')
    );
  }

  /**
   * Post Message to queue.
   *
   * {@inheritDoc}
   */
  public function postMessage($messageBody, $type = NULL) {

    return $this->client->sendMessage(array('QueueUrl' => $this->queueUrl, 'MessageBody' => $this->compressMessage($messageBody)));
  }

  /**
   * Post JSON message to queue.
   *
   * {@inheritDoc}.
   */
  public function postJsonMessage($messageBody) {

    $this->postMessage($messageBody);
  }

  /**
   * {@inheritDoc}
   */
  public function listen($process_function, $time_limit = 0, $max_items = 0) {
    // TODO implement max_items for SQS queue.
    $this->runtime_limit = ($time_limit > 0) ? $time_limit : $this->runtime_limit;
    $length_microtime = $this->runtime_limit * 60 * 1000000;
    $start = 0;

    if ($this->runtime_limit == 0) {
      $this->logger->warning("UdiSQSClient: Start UDI workflow processor without runtime limit set in config or provided at command line.");
    }
    else {
      $this->logger->info("UdiSQSClient: Start UDI workflow processor that will terminate after @limit minutes.",
        ['@limit' => $this->runtime_limit]);

      $start = microtime();
      Timer::start(self::$PROCESS_NAME);
    }

    while ($this->isTimeLimitReached($start, $length_microtime) == FALSE) {
      $result = $this->client->receiveMessage(array('QueueUrl' => $this->queueUrl, 'WaitTimeSeconds' => $this->waitTimeSeconds));

      $payload = $this->decompressPayload($result->get('Messages')[0]['Body']);
      $handle = $result->get('Messages')[0]['ReceiptHandle'];

      if ($payload) {
        try {
          $process_function($payload);
          $this->deleteMessageFromQueue($handle);
        }
        catch (UdiProcessException $ex) {
          $this->logger->error('UdiSQSClient: Error processing downloaded SQS item. Detailed messages: @msg. Content data: @content',
            ['@msg' => $ex->getMessage(), '@content' => $payload]);
        }
        catch (UdiContentNotFoundException $ex) {
          $this->logger->error('UdiSQSClient: @msg. Content data: @content',
            ['@msg' => $ex->getMessage(), '@content' => $payload]);

          // Remove message from queue.
          $this->deleteMessageFromQueue($handle);
        }
      }
    }

    if ($this->runtime_limit > 0) {
      Timer::stop(self::$PROCESS_NAME);
    }
  }

  /**
   * Delete message from SQS queue.
   *
   * @param mixed $handle
   *   Handle object.
   */
  private function deleteMessageFromQueue($handle) {
    $this->client->deleteMessage(
      array(
        'QueueUrl' => $this->queueUrl,
        'ReceiptHandle' => $handle,
      )
    );
  }

  /**
   * Monitor time and return status if the limit is reached.
   *
   * @param $start_time
   *    Start time in micro seconds.
   * @param $time_limit
   *    Runtime length.
   *
   * @return bool
   */
  private function isTimeLimitReached($start_time, $time_limit) {
    $time_reached = FALSE;

    if ($this->runtime_limit > 0) {
      if((Timer::read(self::$PROCESS_NAME) * 1000 - $start_time) >= $time_limit) {
        $this->logger->info('UdiSQSClient: Time limit is reached.');
        $time_reached = TRUE;
      }
    }

    return $time_reached;
  }

  /**
   * Compress the message using zip and base_64.
   *
   * @param string $messageBody
   *   The message body to compress.
   *
   * @return string
   *   The compressed message.
   */
  private function compressMessage($messageBody) {

    $compressedMessage = $messageBody;
    if (!empty($messageBody)) {
      $zippedMessage = gzencode($messageBody, 9);
      $compressedMessage = base64_encode($zippedMessage);
    }
    return $compressedMessage;
  }

  /**
   * Decompress the incoming message.
   *
   * @param string $payload
   *   The message payload.
   *
   * @return string
   *   The decompressed payload.
   */
  private function decompressPayload($payload) {

    $decompressedPayload = $payload;
    if (!empty($payload)) {

      $zippedPayload = base64_decode($payload, TRUE);
      if ($zippedPayload) {
        $decompressedPayload = gzdecode($zippedPayload);
      }
    }

    return $decompressedPayload;
  }

}
