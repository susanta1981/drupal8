<?php

namespace Drupal\draco_udi\Service\Queue\RabbitMQ\ODT;

use Drupal\Core\Config\Config;
use Drupal\draco_udi\Service\Queue\RabbitMQ\UdiRabbitMQClient;
use Psr\Log\LoggerInterface;

/**
 * Rabbit Client for OnDemand Tools.
 */
class ODTRabbitMQClient extends UdiRabbitMQClient {

  /**
   * UdiRabbitMQClient Constructor.
   *
   * {@inheritdoc}
   */
  public function __construct(Config $config, LoggerInterface $logger_channel) {

    if (!empty($config)) {
      $this->rabbitHost = $config->get('odt_settings.odt_queue_host');
      $this->rabbitPort = $config->get('odt_settings.odt_queue_host_port');
      $this->rabbitQueue = $config->get('odt_settings.odt_queue_name');
      $this->rabbitUser = $config->get('odt_settings.odt_queue_userid');
      $this->rabbitPw = $config->get('odt_settings.odt_queue_pwd');
      $this->rabbitVhost = $config->get('odt_settings.odt_queue_vhost');
    }
    parent::__construct($config, $logger_channel);
  }

}
