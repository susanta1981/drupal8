<?php

namespace Drupal\draco_udi\Service\Queue\RabbitMQ;

use Drupal\Core\Config\Config;
use Drupal\draco_udi\Exception\UdiConfigurationException;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\draco_udi\Service\Queue\UdiQueueClientInterface;
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Channel\AMQPChannel;
use PhpAmqpLib\Message\AMQPMessage;
use Psr\Log\LoggerInterface;
use PhpAmqpLib\Exception\AMQPTimeoutException;

/**
 * Rabbit queue client for draco_udi module.
 */
abstract class UdiRabbitMQClient implements UdiQueueClientInterface {

  /**
   * @var string
   */
  protected $rabbitQueue;

  /**
   * @var string
   */
  protected $rabbitHost;

  /**
   * @var string
   */
  protected $rabbitPort;

  /**
   * @var string
   */
  protected $rabbitUser;

  /**
   * @var string
   */
  protected $rabbitPw;

  /**
   * @var string
   */
  protected $rabbitVhost;

  /**
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * @var \PhpAmqpLib\Channel\AMQPChannel
   */
  protected $channel;

  /**
   * @var  \PhpAmqpLib\Connection\AMQPStreamConnection
   */
  protected $connection;

  /**
   * Constructor.
   *
   * @param \Drupal\Core\Config\Config $config
   *   Configuration.
   * @param LoggerInterface $logger_channel
   *   Udi logger channel.
   *
   * @throws UdiConfigurationException
   */
  public function __construct(Config $config, LoggerInterface $logger_channel) {

    if (empty($this->rabbitHost)) {
      throw new UdiConfigurationException('rabbit_host is not defined.');
    }
    if (empty($this->rabbitPort)) {
      throw new UdiConfigurationException('rabbit_port is not defined.');
    }
    if (empty($this->rabbitUser)) {
      throw new UdiConfigurationException('rabbit_user is not defined.');
    }
    if (empty($this->rabbitPw)) {
      throw new UdiConfigurationException('rabbit_pw is not defined.');
    }
    if (empty($this->rabbitQueue)) {
      throw new UdiConfigurationException('rabbit_queue is not defined.');
    }

    $this->logger = $logger_channel;

    $this->createConnection($this->rabbitHost, $this->rabbitPort, $this->rabbitUser, $this->rabbitPw, $this->rabbitVhost);
  }

  /**
   * Create method for UdiRabbitMQClent.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   Drupal container.
   *
   * @return static
   *
   * @codeCoverageIgnore
   * ignore because create functions are not tested
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('draco_udi.logger.channel')
    );
  }

  /**
   * Create the connection to the Rabbit Queue.
   *
   * @param string $rabbitHost
   *   Rabbit Host.
   * @param string $rabbitPort
   *   Rabbit Port.
   * @param string $rabbitUser
   *   Rabbit UserId.
   * @param string $rabbitPw
   *   Rabbit user password.
   * @param string $rabbitVhost
   *   Rabbit server vhost name.
   */
  protected function createConnection($rabbitHost, $rabbitPort, $rabbitUser, $rabbitPw, $rabbitVhost) {

    $this->connection = new AMQPStreamConnection($rabbitHost, $rabbitPort, $rabbitUser, $rabbitPw, $rabbitVhost);
    $this->channel = $this->connection->channel();
  }

  /**
   * Post JSON message to queue.
   *
   * {@inheritdoc}
   */
  public function postJsonMessage($messageBody) {
    $this->postMessage($messageBody, 'application/json');
  }

  /**
   * Post Message to queue.
   *
   * {@inheritDoc}.
   */
  public function postMessage($messageBody, $type = NULL) {

    if ($type == NULL) {
      $type = 'text/plain';
    };
    $message = new AMQPMessage($messageBody, array('content_type' => $type, 'delivery_mode' => AMQPMessage::DELIVERY_MODE_PERSISTENT));
    $this->channel->basic_publish($message, '', $this->rabbitQueue);
  }

  /**
   * {@inheritDoc}
   */
  public function listen($process_function, $time_limit = 0, $max_items = 0) {
    $this->channel->basic_consume($this->rabbitQueue, 'callback', FALSE, FALSE, FALSE, FALSE, $process_function);

    $startTime = new \DateTime();
    $secondsLeft = $time_limit * 60;
    $num_dequeued = 0;
    if ($secondsLeft > 0) {
      $this->logger->info('UdiRabbitMQClient: Start listening. Will stop after running for @limit minutes.', ['@limit' => $time_limit]);
    }
    if ($max_items > 0) {
      $this->logger->info('UdiRabbitMQClient: Start listening. Will stop after fetching for @limit items.', ['@limit' => $max_items]);
    }
    $dateInterval = new \DateInterval('PT' . $secondsLeft . 'S');
    $timeToQuit = $startTime->add($dateInterval);
    try {
      while (count($this->channel->callbacks)) {
        if ($time_limit > 0) {
          $this->channel->wait(NULL, FALSE, $secondsLeft);
        }
        else {
          $this->channel->wait();
        }
        $curTime = new \DateTime();
        if ($this->limitReached($curTime, $timeToQuit, $time_limit, $max_items, ++$num_dequeued)) {
          break;
        }
        else {
          $secondsLeft = $timeToQuit->getTimestamp() - $curTime->getTimestamp();
        }
      }
    }
    catch (AMQPTimeoutException $runTimeException) {
      $this->logger->debug('UdiRabbitMQClient: Cancel listening. Time limit is reached.');
    }
    catch (\Exception $ex) {
      $this->logger->debug('RabbitMQ exception: ' . $ex->getMessage());
    }
    finally {
      if ($this->connection && $this->connection->isConnected()) {
        $this->channel->basic_cancel('callback', FALSE);
      }
    }
  }

  /**
   * Check all limits.
   *
   * @param \DateTime $curTime
   *   The current time.
   * @param \DateTime $timeToQuit
   *   The Time at which the process should end.
   * @param int $time_limit
   *   Number of minutes to run listener.  0 indicates run forever.
   * @param int $max_items
   *   Maximum number of items to fetch from queue.  0 means no limit.
   * @param int $num_dequeued
   *   Number of items fetched so far.
   *
   * @return bool
   *   Boolean indicating if limits have been reached
   */
  private function limitReached(\DateTime $curTime, \DateTime $timeToQuit, $time_limit, $max_items, $num_dequeued) {
    $limit_reached = FALSE;
    if ($time_limit > 0 && $curTime >= $timeToQuit) {
      $this->logger->debug('UdiRabbitMQClient: Cancel listening. Time limit is reached.');
      $limit_reached = TRUE;
    }
    if ($max_items > 0 && $num_dequeued >= $max_items) {
      $this->logger->debug('UdiRabbitMQClient: Cancel listening. Max items limit of @limit is reached.', ['@limit' => $max_items]);
      $limit_reached = TRUE;
    }
    return $limit_reached;
  }

}
