<?php

namespace Drupal\draco_udi\Service\Tools;

/**
 * Interface DracoIdToolsInterface.
 *
 * @package Drupal\draco_udi\Service\Tools
 */
interface DracoIdToolsInterface {

  /**
   * Get Ids From Drush arguments.
   *
   * Take the $argv array from a drush command and retrieve the list of ids
   * passes into the command.  The number of ids in the list is variable.
   *
   * @param array $args
   *   the $argv array from a Drush command dispatcher.
   */
  public function getIdsFromDrushArgs(array $args);

  /**
   * Get Ids from File.
   *
   * Read a list of Ids from a file.  The file structure should be 1
   * Id per line:  example file contents:
   *
   * 123446
   * 521521521
   * 4614645235
   * 151351512
   *
   * @param string $file_name
   *   Name of the file containing the Ids.
   */
  public function getIdsFromFile($file_name);

}
