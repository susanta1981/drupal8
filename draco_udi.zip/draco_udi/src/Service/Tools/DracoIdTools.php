<?php

namespace Drupal\draco_udi\Service\Tools;

use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class DracoIdTools.
 *
 * Holds tools used by Draco to manage Ids.
 *
 * @package Drupal\draco_udi\Service\Tools
 */
class DracoIdTools implements ContainerInjectionInterface, DracoIdToolsInterface {

  protected $logger;

  /**
   * DracoIdTools constructor.
   *
   * @param \Psr\Log\LoggerInterface $logger
   *    Logger.
   */
  public function __construct(LoggerInterface $logger) {
    $this->logger = $logger;
  }

  /**
   * Create method for DracoIdTools.
   *
   * Ignore because create functions are not tested.
   *
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *    Service container.
   *
   * @return static
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('draco_udi.logger.channel')
    );
  }

  /**
   * Gete ids From Drush arguments.
   *
   * {@inheritdoc}
   */
  public function getIdsFromDrushArgs(array $args) {
    $ids = [];
    for ($i = 1; $i < count($args); $i++) {
      $ids[] = trim($args[$i]);
    }
    return $ids;
  }

  /**
   * Get ids from File.
   *
   * {@inheritdoc}
   */
  public function getIdsFromFile($file_name) {
    $ids = [];
    if (file_exists($file_name)) {
      try {
        $file = fopen($file_name, "r");
        if ($file) {
          while (!feof($file)) {
            $id = fgets($file);
            $id = trim($id);
            if (strlen($id) > 0) {
              $ids[] = trim($id);
            }
          }
        }
        else {
          $this->logger->error('Could not open id file ' . $file_name);
        }
      } finally {
        if ($file) {
          fclose($file);
        }
      }
    }
    else {
      $this->logger->error('Could not find id file ' . $file_name);
    }
    return $ids;
  }

}
