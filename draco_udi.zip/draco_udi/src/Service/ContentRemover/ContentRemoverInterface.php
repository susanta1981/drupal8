<?php

namespace Drupal\draco_udi\Service\ContentRemover;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\draco_udi\Entity\DracoContentInterface;

/**
 * Interface ContentRemoverInterface.
 *
 * @package Drupal\draco_udi\Service\ContentRemover
 */
interface ContentRemoverInterface extends ContainerFactoryPluginInterface {

  /**
   * Remove the passed entity.
   *
   * @param \Drupal\draco_udi\Entity\DracoContentInterface $entity
   *    Entity to be removed.
   *
   * @return array
   *    Clones of removed entities.
   */
  public function remove(DracoContentInterface $entity);

}
