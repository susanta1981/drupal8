<?php

namespace Drupal\draco_udi\Service\ContentRemover;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;

/**
 * Class ContentRemoverManager.
 *
 * @package Drupal\draco_udi\Service\ContentRemover
 */
class ContentRemoverManager extends DefaultPluginManager {

  /**
   * ContentRemoveManager constructor.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   *
   * @codeCoverageIgnore
   */
  public function __construct(
    \Traversable $namespaces,
    CacheBackendInterface $cache_backend,
    ModuleHandlerInterface $module_handler
  ) {
    parent::__construct('Plugin/ContentRemover', $namespaces, $module_handler,
      'Drupal\draco_udi\Service\ContentRemover\ContentRemoverInterface',
      'Drupal\draco_udi\Annotation\ContentRemoverStrategy');

    $this->alterInfo('draco_content_remover_info');
    $this->setCacheBackend($cache_backend, 'draco_content_removers');
  }

  /**
   * Return ContentRemoverPlugin instances by the remover type.
   *
   * @param string $remover_type
   *    Id of remover, e.g., 'Title', 'LinearSchedule', 'OnDemandSchedule'.
   *
   * @return ContentRemoverInterface|null
   *    A remover plugin instance.
   */
  public function getRemover($remover_type) {
    $remover = NULL;
    $definitions = $this->getDefinitions();

    if (empty($definitions)) {
      return $remover;
    }
    else {
      foreach ($definitions as $plugin_id => $definition) {
        if ($plugin_id == $remover_type) {
          $remover = $this->createInstance($plugin_id);
          break;
        }
      }
    }

    return $remover;
  }


}