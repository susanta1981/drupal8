<?php

namespace Drupal\draco_udi\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Class ContentFilter.
 *
 * @package Drupal\draco_udi\Annotation
 *
 * @Annotation
 */
class ContentFilter extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The data type this filter will accept.
   *
   * @var string
   */
  public $dataType;

  /**
   * The data source this filter will accept.
   *
   * @var string
   */
  public $dataSource;

}
