<?php

namespace Drupal\draco_udi\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Class Mapper.
 *
 * @package Drupal\draco_udi\Annotation
 *
 * @Annotation
 */
class Mapper extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

}
