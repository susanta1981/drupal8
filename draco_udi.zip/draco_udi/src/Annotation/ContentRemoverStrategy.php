<?php

namespace Drupal\draco_udi\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Class ContentRemoverStrategy.
 *
 * Defines plugins for removing entities.
 *
 * @package Drupal\draco_udi\Annotation
 *
 * @Annotation
 */
class ContentRemoverStrategy extends Plugin {

  /**
   * The plugin id that maps to content type.
   *
   * @var string
   */
  public $id;

}
