<?php

namespace Drupal\draco_udi\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Class ContentReconciler.
 *
 * @package Drupal\draco_udi\Annotation
 *
 * @Annotation
 */
class ContentReconciler extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

}
