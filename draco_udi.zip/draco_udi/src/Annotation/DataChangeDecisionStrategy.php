<?php

namespace Drupal\draco_udi\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Class DataChangeDecisionStrategy.
 *
 * @package Drupal\draco_udi\Annotation
 *
 * @Annotation
 */
class DataChangeDecisionStrategy extends Plugin {
  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

}
