<?php

namespace Drupal\draco_udi\Annotation;


use Drupal\Component\Annotation\Plugin;

/**
 * Class ContentConverterStrategy.
 *
 * Defines plugins for converting imported upstream contents into entities.
 *
 * @package Drupal\draco_udi\Annotation
 *
 * @Annotation
 */
class ContentConverterStrategy extends Plugin {

  /**
   * The plugin id that maps to pipeline queue message key.
   *
   * @var string
   */
  public $id;

}
