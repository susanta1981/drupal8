-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 14, 2017 at 02:18 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `training`
--

-- --------------------------------------------------------

--
-- Table structure for table `authuser`
--

CREATE TABLE `authuser` (
  `id` int(10) UNSIGNED NOT NULL COMMENT 'Unique record ID.',
  `fname` varchar(60) DEFAULT NULL COMMENT 'First name',
  `lname` varchar(60) DEFAULT NULL COMMENT 'Last name',
  `email` varchar(60) DEFAULT NULL COMMENT 'Email',
  `login` varchar(35) NOT NULL COMMENT 'Login. Should be the users UPS ADID',
  `password` varchar(250) NOT NULL COMMENT 'Password',
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0' COMMENT '0=new/pending, 1=enabled/approved, 2=disabled/rejected',
  `access` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'User access - a bitmask integer that sums all the access rights given.',
  `created` datetime DEFAULT NULL COMMENT 'Date and Time account created.',
  `lastmod` datetime DEFAULT NULL COMMENT 'Date and time account last modified.',
  `lastip` char(15) DEFAULT NULL COMMENT 'The users last IP used when accessing their account.'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `authuser`
--

INSERT INTO `authuser` (`id`, `fname`, `lname`, `email`, `login`, `password`, `status`, `access`, `created`, `lastmod`, `lastip`) VALUES
(1, 'Abhilash', 'Mun', 'abhi@gmail.com', 'admin', '$2y$10$wJxa1Wm0rtS2BzqKnoCPd.7QQzgu7D/aLlMR5Aw3O.m9jx3oRJ5R2', 1, 2, '2017-11-14 00:00:00', '2017-11-14 00:00:00', '127.0.0.1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authuser`
--
ALTER TABLE `authuser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authuser`
--
ALTER TABLE `authuser`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Unique record ID.', AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
