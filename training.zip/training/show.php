<?php
require('start.php');

$config = Application_Factory::config();
$pathInfo = Application_Factory::pathInfo();
$response = new Aksman_Response_PageResponse($config->directories->templates . 'showvideo.phtml');
if ($config->application->stage == 'development') {
    $response->_reportErrors = true;
}

try {
    $ticket = $pathInfo[0];
    if (!$ticket) {
        throw new Exception('Missing ticket');
    }

    $linkManager = new Application_Video_LinkManager2($config->directories->vidlinks);
    $linkData = $linkManager->lookup($ticket);
    if (!$linkData) {
        $message = 'This video link is invalid.';
    } else {
        $nowDT = new DateTime;
        $expiresDT = ($linkData['expires']);
        if ($nowDT < $expiresDT) {
            $data = $config->videos->{$linkData['video']};
            $video = array(
                'id' => $linkData['video'],
                'title' => $data->title,
                'source' => $data->video,
                'type' => $data->type,
                'poster' => $data->screenshot,
                'width' => $data->width,
                'height' => $data->height,
            );
            $response->video = $video;

            $pdo = Application_Factory::pdo();
            $commentsManager = new Application_Video_Comments($pdo, $linkData['video']);
            $comments = $commentsManager->getComments(true, true, true);
            $response->comments = $comments;

            $linkManager->incrementVisits($ticket);
            $message = 'Enjoy the show';
        } else {
            $message = 'Video link has expired. Please contact ATC support if you feel that you need extended access to this video.';
            $response->video = false;
            $response->comments = array();
        }
    }

    exit($response->success($message));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, $ex->getMessage()));
}
