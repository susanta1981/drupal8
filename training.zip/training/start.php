<?php
if (count(get_included_files()) == 1) {
    header('Location: index.php');
}
$thisFile = trim(preg_replace("/\(.*$/", "", __FILE__));


/*
if ($thisFile == "C:\\webserver\\www\\start.php") {
    require('/webserver/src/bootstrap.php');
} else if ($thisFile == "D:\\www\\start.php") {
    require('D:\\www_config\\bootstrap.php');
}
*/

// Changed to use relative paths because ...
// relative paths are more flexible than absolute paths. No guess work or wizardry required.
// 6/14/17 -ena-
require('config/bootstrap.php');
