<?php
require('../start.php');

$config = Application_Factory::config();
$post = new Aksman_Request_RawPostJson;
$response = new Aksman_Response_JsonResponse;
if ($config->application->stage == 'development') {
    $response->_reportErrors = true;
    $response->_prettyPrint = true;
}

try {
    $video = $post->video;
    $comment = $post->comment;
    $author = $post->author;
    $email = $post->email;
    $authorIp = $_SERVER['REMOTE_ADDR'];

    $pdo = Application_Factory::pdo();
    $comments = new Application_Video_Comments($pdo, $video);
    $insertedRow = $comments->addComment(array(
        'comment' => $comment,
        'author' => $author,
        'email' => $email,
        'author_ip' => $authorIp,
    ));
    $videoTitle = $config->videos->{$insertedRow['video']}->title;

    $phpmailer = Application_Factory::mailer();
    $mailer = new Application_Mailer($phpmailer);
    $mailer->sendNewCommentNotification($insertedRow, $videoTitle);

    $response->newrow = $insertedRow;
    exit($response->success('Comment added'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex));
}