<?php
require('../start.php');

$post = new Aksman_Request_RawPostJson;
$response = new Aksman_Response_JsonResponse;
if ($config->application->stage == 'development') {
    $response->_prettyPrint = true;
}

$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    $ex = new Exception('Your log in has expired. Please log back in to respond to comments.');
    exit($response->error($ex));
}

try {
    $video = $post->video;
    $comment = $post->comment;
    $author = $post->author;
    $email = $post->email;
    $authorIp = $_SERVER['REMOTE_ADDR'];
    $respondingTo = $post->respondingTo;

    $pdo = Application_Factory::pdo();
    $commentsManager = new Application_Video_Comments($pdo, $video);
    $insertedRow = $commentsManager->addComment(array(
        'comment' => $comment,
        'author' => $author,
        'email' => $email,
        'author_ip' => $authorIp,
    ), $respondingTo);
    $videoTitle = $config->videos->{$insertedRow['video']}->title;

    $response->newrow = $insertedRow;
    $response->videoTitle = $videoTitle;
    exit($response->success('Response submitted'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex));
}
