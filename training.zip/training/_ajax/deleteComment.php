<?php
require('../start.php');

$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    $ex = new Exception('Your log in has expired. Please log back in to approve comments.');
    exit($response->error($ex));
}

$post = new Aksman_Request_RawPostJson;
$response = new Aksman_Response_JsonResponse;
$response->_prettyPrint = true;

try {
    $commentid = $post->commentid;
    $pdo = Application_Factory::pdo();
    $commentsManager = new Application_Video_Comments($pdo);

    $commentsManager->deleteComment($commentid);
    exit($response->success('Comment has been deleted'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex));
}
