<?php
require('../start.php');
$response = new Aksman_Response_JsonResponse;
if ($config->application->stage == 'development') {
    $response->_prettyPrint = true;
}

$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    $ex = new Exception('Your log in has expired. Please log back in to approve comments.');
    exit($response->error($ex));
}

$post = new Aksman_Request_RawPostJson;

try {
    $commentid = $post->commentid;
    $approval = $post->approval;
    $pdo = Application_Factory::pdo();
    $commentManager = new Application_Video_Comments($pdo);
    $commentManager->approveComment($commentid, $approval);

    if ($approval) {
        $message = 'Comment approved';
    } else {
        $message = 'Comment no longer approved';
    }

    exit($response->success($message));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex));
}