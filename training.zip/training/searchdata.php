<?php
require('start.php');


$config = Application_Factory::config();


$vidList = array();

 $searchdata = $_GET['search'];
//print_r( $config->videos);
if(empty($searchdata)){
	$vidList = $config->videos;
}else{


foreach($config->videos as $label => $attrs) {
    if (!empty($attrs->public)) {
	if (stripos($attrs->title, $searchdata) !== false) {
        $vidList[$label] = array(
            'title' => $attrs->title,
            'screenshot' => $attrs->screenshot,
            'length' => $attrs->length,
            'label' =>$label,

        );
	}
    }
}

}
 echo json_encode($vidList);
 


?>

