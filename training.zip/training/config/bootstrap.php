<?php
// Autoloading
/*
$thisFile = trim(preg_replace("/\(.*$/", "", __FILE__));
if ($thisFile == "C:\\webserver\\src\\bootstrap.php") {
    require('/webserver/src/tools.5.2/autoload.php');
    require('/webserver/src/domain/models/autoload.php');
    define('APP_CONFIG_FILE', '/webserver/src/domain/config.json');
} else {
    require("D:\\www_config\\tools.5.2\\autoload.php");
    require("D:\\www_config\\domain\\models\\autoload.php");
    define('APP_CONFIG_FILE', "D:\\www_config\\domain\\config.json");
}
*/

// Changed to use relative paths because ...
// relative paths are more flexible than absolute paths. No guess work or wizardry required.
// 6/14/17 -ena-
require("tools.5.2/autoload.php");
require("config/domain/models/autoload.php");
define('APP_CONFIG_FILE', "config/domain/config.json");

$config = Application_Factory::config();
date_default_timezone_set($config->application->timezone);

$logger = Application_Factory::logger();
set_error_handler(array($logger, 'logError'));

