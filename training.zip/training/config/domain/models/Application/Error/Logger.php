<?php

/**
 * Description of Logger
 *
 * @author David Gable
 * @created Jul 28, 2015
 */
class Application_Error_Logger
{
    protected $filemap = array();

    public function __construct($filemap)
    {
        $this->setFilemap($filemap);
    }

    public function setFilemap(array $filemap)
    {
        foreach($filemap as $key => $file) {
            if (!$this->fileIsAvailable($file)) {
                throw new Application_Error_Logger_Exception("Invalid log file \"$file\"");
            }
        }
        $this->filemap = $filemap;
    }

    protected function fileIsAvailable($file)
    {
        if (is_writable($file)) {
            return true;
        } else if (is_writable(dirname($file))) {
            return true;
        }
        return false;
    }

    public function logException($ex)
    {

        $fields = array(
            'type' => get_class($ex),
            'script' => $_SERVER['SCRIPT_NAME'],
            'file' => $ex->getFile(),
            'line' => $ex->getLine(),
            'message' => $ex->getMessage(),
        );
        $this->log('exception', $fields);
        /*try {
            $fh = fopen($this->exceptionLog, 'a');
            fputcsv($fh, $fields);
            fclose($fh);
            return $this;
        } catch (Exception $ex) {
            throw new Application_Error_Logger_Exception($ex->getMessage());
        }*/
    }

    public function logError($errorNumber, $errorMessage, $errorFile, $errorLine)
    {
        switch($errorNumber) {
            case E_ERROR:
                $errorType = 'E_ERROR';
                break;
            case E_WARNING:
                $errorType = 'E_WARNING';
                break;
            case E_PARSE:
                $errorType = 'E_PARSE';
                break;
            case E_NOTICE:
                $errorType = 'E_NOTICE';
                break;
            case E_CORE_ERROR:
                $errorType = 'E_CORE_ERROR';
                break;
            case E_CORE_WARNING:
                $errorType = 'E_CORE_WARNING';
                break;
            case E_COMPILE_ERROR:
                $errorType = 'E_COMPILE_ERROR';
                break;
            case E_COMPILE_WARNING:
                $errorType = 'E_COMPILE_WARNING';
                break;
            case E_USER_ERROR:
                $errorType = 'E_USER_ERROR';
                break;
            case E_USER_WARNING:
                $errorType = 'E_USER_WARNING';
                break;
            case E_USER_NOTICE:
                $errorType = 'E_USER_NOTICE';
                break;
            case E_STRICT:
                $errorType = 'E_STRICT';
                break;
            case E_RECOVERABLE_ERROR:
                $errorType = 'E_RECOVERABLE_ERROR';
                break;
            case E_DEPRECATED:
                $errorType = 'E_DEPRECATED';
                break;
            case E_USER_DEPRECATED:
                $errorType = 'E_USER_DEPRECATED';
                break;
            default:
                $errorType = 'UNKNOWN';
        }
        $fields = array(
            'type' => $errorType,
            'file' => $errorFile,
            'line' => $errorLine,
            'message' => $errorMessage,
        );
        $this->log('error', $fields);
        return false;
        /*try {
            $fh = fopen($logFile, 'a');
            fputcsv($fh, $fields);
            fclose($fh);
            return false;
        } catch (Exception $ex) {
            throw new Application_Error_Logger_Exception($ex->getMessage());
        }*/
    }

    public function log($key, array $specs)
    {
        $file = $this->getFile($key);
        $dt = new DateTime;
        $fields = array(
            'datetime' => $dt->format('Y-m-d H:i:s'),
            'type' => $specs['type'],
            'script' => $_SERVER['SCRIPT_NAME'],
            'file' => $specs['file'],
            'line' => $specs['line'],
            'message' => $specs['message'],
        );
        try {
            $fh = fopen($file, 'a');
            fputcsv($fh, $fields);
            fclose($fh);
            return false;
        } catch (Exception $ex) {
            throw new Application_Error_Logger_Exception($ex->getMessage());
        }
    }

    protected function getFile($key)
    {
        if (isset($this->filemap[$key])) {
            return $this->filemap[$key];
        } else {
            throw new Application_Error_Logger_Exception("Invalid log key \"$key\"");
        }
    }
}

class Application_Error_Logger_Exception extends Exception {}