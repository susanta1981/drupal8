<?php

/**
 * Description of Factory
 *
 * @author David Gable
 * @created Jun 1, 2015
 */
class Application_Factory
{
    public static function config()
    {
        static $instance = false;
        if (!$instance) {
            $reader = new Aksman_Config_ReadConfigFile;
            $instance = $reader->useFile(APP_CONFIG_FILE)
                ->importJson()
                ->export();
        }
        return $instance;
    }

    public static function random()
    {
        static $instance = false;
        if (!$instance) {
            $instance = new Aksman_Random_Random;
        }
        return $instance;
    }

    public static function hash()
    {
        static $instance = false;
        if (!$instance) {
            $config = self::config();
            $random = self::random();
            $hashType = $config->hash->type;
            switch($hashType) {
                case 'bcrypt':
                    $hash = new Aksman_Hash_BcryptHash($random, array(
                        'cost' => $config->hash->cost,
                    ));
                    break;
                case 'sha512':
                    $hash = new Aksman_Hash_Sha512Hash($random, array(
                        'rounds' => $config->hash->rounds,
                    ));
                    break;
                case 'sha256':
                    $hash = new Aksman_Hash_Sha256Hash($random, array(
                        'rounds' => $config->hash->rounds,
                    ));
                    break;
                case 'md5':
                    $hash = new Aksman_Hash_MD5Hash($random);
                    break;
                case 'extdes':
                    $hash = new Aksman_Hash_ExtDES($random);
                    break;
                case 'stddes':
                    $hash = new Aksman_Hash_StdDESHash($random);
                    break;
                case 'sha1':
                    $hash = new Aksman_Hash_Sha1Hash($random, array(
                        'rounds' => $config->hash->rounds,
                    ));
                    break;
                default:
                    throw new Application_Factory_Exception("Invalid hash type \"{$hashType}\"");
            }
        }
        return $hash;
    }

    public static function auth()
    {
        static $instance = false;
        if (!$instance) {
            $config = self::config();
            $instance = new Aksman_Auth_File(self::hash(), $config->auth->directory, $config->auth->timeout);
        }
        return $instance;
    }

    public static function key()
    {
        static $instance = false;
        if (!$instance) {
            $config = self::config();
            $instance = file_get_contents($config->encryption->keyfile);
        }
        return $instance;
    }

    public static function encrypter()
    {
        static $instance = false;
        if (!$instance) {
            $key = self::key();
            $instance = new PHPSecLib_Crypt_Blowfish;
            $instance->setKey($key);
        }
        return $instance;

    }

    public static function logger()
    {
        static $instance = false;
        if (!$instance) {
            $config = self::config();
            $filemap = array(
                'error' => $config->log->error,
                'exception' => $config->log->exception,
            );
            $instance = new Application_Error_Logger($filemap);
        }
        return $instance;
    }

    public static function pathInfo()
    {
        static $instance = false;
        if (!$instance) {
            $rawPathInfo = $_SERVER['PATH_INFO'];
            if (substr($rawPathInfo, 0, 1) == '/') {
                $rawPathInfo = substr($rawPathInfo, 1);
            }
            $instance = explode('/', $rawPathInfo);
        }
        return $instance;
    }

    public static function pdo()
    {
        static $instance = false;
        if (!$instance) {
            $config = self::config();
            $host = $config->db->host;
            $port = $config->db->port;
            $dbname = $config->db->dbname;
            $user = $config->db->user;
            $pass = $config->db->password;

            $dsn = "mysql:host={$host};port={$port};dbname={$dbname}";
            try {
                $instance = new PDO($dsn, $user, $pass);
            } catch (PDOException $ex) {
                throw new Application_Factory_Exception('Failure to create PDO object: ' . $ex->getMessage());
            } catch (Exception $ex) {
                throw new Application_Factory_Exception('Unexpected error: ' . $ex->getMessage());
            }
        }
        return $instance;
    }

    public static function mailer()
    {
        static $instance = false;
        if (!$instance) {
            $config = self::config();
            $instance = new PHPMailer_PHPMailer;
            $instance->SetLanguage('en', $config->mail->languagePath);
            $instance->Host = $config->mail->smtpHost;
            $instance->WordWrap = $config->mail->wordWrap;
            $instance->IsSMTP();
            $instance->IsHTML(true);

            $instance->From = $config->mail->from;
            $instance->FromName = $config->mail->fromName;
            $recipients = explode('|', $config->mail->recipients);
            foreach($recipients as $recipient) {
                $instance->AddAddress($recipient);
            }
        }
        return $instance;
    }
}

class Application_Factory_Exception extends Exception {}
