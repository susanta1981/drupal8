<?php

/**
 * Description of UserManager
 *
 * @author David Gable
 * @created Jun 8, 2015
 */
class Application_UserManager
{
    protected $currentUser;
    protected $workingUser;
    protected $usersList;
    protected $rolesList;

    public function __construct(Aksman_Auth_Interface $loggedInUser, $roleRequired) {
        $this->currentUser = $loggedInUser;
        $this->roleRequired = $roleRequired;
    }

    public function resetWorkingUser() {
        $this->workingUser = array(
            'name' => null,
            'password' => null,
            'roles' => array(),
        );
    }

    public function hasPermission() {
        if ($this->currentUser->check() && $this->currentUser->hasRole($this->roleRequired)) {
            return true;
        }
        return false;
    }


}