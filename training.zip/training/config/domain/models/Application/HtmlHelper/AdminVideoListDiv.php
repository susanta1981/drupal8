<?php

/**
 * Description of AdminVideoListDiv
 *
 * @author David Gable
 * @created Jun 10, 2015
 */
class Application_HtmlHelper_AdminVideoListDiv
{
    protected $label;
    protected $video;

    public function __construct($label, $video) {
        $this->label = $label;
        $this->video = $video;
    }

    public function __toString() {
        $video = $this->video;
        $infoLink = "videoinfo.php?video={$this->label}";
        $config = Application_Factory::config();
        $bob = new Aksman_Html_Factory;
        $div = $bob->build('div', null, array(
            'class' => 'admin-videolist-div',
            'vid-label' => $this->label,
        ));
        $link1 = $bob->build('a', null, array(
            'class' => 'admin-videolist-img-link',
            'href' => $infoLink,
        ));
        $img = $bob->build('img', null, array(
            'src' => $config->webLocations->screenshots . '/' . $video->screenshot,
            'class' => 'admin-videolist-img',
        ));
        $link1->appendElement($img);
        $div->appendElement($link1);
        $infoDiv = $bob->build('div', null, array('class' => 'admin-videolist-infodiv'));

        $titleDiv = $bob->build('div')
            ->appendElement($bob->build('a', $video->title, array('href' => $infoLink)));
        $infoDiv->appendElement($titleDiv);

        $div->appendElement($infoDiv);

        $container = $bob->build('div', null, array(
            'class' => 'admin-videolist-div-container',
        ))->appendElement($div);

        return (string) $container;
    }
}