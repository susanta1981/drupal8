<?php

/**
 * Description of Mailer
 *
 * @author David Gable
 * @created Nov 4, 2015
 */
class Application_Mailer
{
    private $mailer;

    public function __construct(PHPMailer_PHPMailer $mailer)
    {
        $this->mailer = $mailer;
    }

    public function sendNewCommentNotification($comment, $videoTitle)
    {
        $dt = new DateTime($comment['created']);
        $this->mailer->Subject = "[Supplemental Videos] {$comment['author']} has posted a comment";
        $mailBody = "{$comment['author']} has just posted the following comment to the video \"{$videoTitle}\":"
            . "<br />\n<br />\n"
            . "Email: {$comment['email']}<br />\n"
            . "IP: {$comment['author_ip']}<br />\n"
            . "Submitted: {$dt->format('m/j/Y \a\t g:i a')}<br />\n"
            . "<br />\n"
            . "<pre>{$comment['comment']}</pre>";
        $this->mailer->Body = $mailBody;
        try {
            $this->mailer->Send();
        } catch (Exception $ex) {
            throw new Application_Mailer_Exception($ex->getMessage());
        }
    }
}

class Application_Mailer_Exception extends Exception {}