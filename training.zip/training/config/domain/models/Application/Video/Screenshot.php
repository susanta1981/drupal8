<?php

/**
 * Description of Screenshot
 *
 * @author David Gable
 * @created Jun 1, 2015
 */
class Application_Video_Screenshot
{
    protected $ffmpegCommand = 'ffmpeg';
    protected $ffmpegDir;
    protected $videoFile;
    protected $imgFile;
    protected $time = '00:00:00';
    protected $validImgExt = array(
        'jpg' => true,
        'jpeg' => true,
        'png' => true,
    );
    protected $stdout = array();
    protected $strerr = array();

    protected $durationLineMatch = "Duration: ([0-9]{2}:[0-9]{2}:[0-9]{2}(\\.[0-9]+)?)";
    protected $dimensionsLineMatch = "Stream #[0-9]+:.*: Video:.* ([0-9]{2,})x([0-9]{2,}).*";

    public function setFfmpegCommand($command)
    {
        $this->ffmpegCommand = $command;
        return $this;
    }

    public function getFfmpegCommand()
    {
        return $this->ffmpegCommand;
    }

    public function setFfmpegDir($dir)
    {
        $this->ffmpegDir = $dir;
        return $this;
    }

    public function getFfmpegDir()
    {
        return $this->ffmpegDir;
    }

    public function setVideoFile($file)
    {
        $this->videoFile = $file;
        return $this;
    }

    public function getVideoFile()
    {
        return $this->videoFile;
    }

    public function setImgFile($file)
    {
        $this->imgFile = $file;
        return $this;
    }

    public function getImgFile()
    {
        return $this->imgFile;
    }

    public function setTime($time)
    {
        $this->time = $time;
        return $this;
    }

    public function getTime()
    {
        return $this->time;
    }

    public function createScreenshot($overwrite=false)
    {
        if (!file_exists($this->videoFile)) {
            throw new Application_Video_Screenshot_Exception("Video file \"{$this->videoFile}\" does not exist");
        }
        $imgFileParts = explode('.', basename($this->imgFile));
        $imgFileExt = end($imgFileParts);
        if (!isset($this->validImgExt[$imgFileExt])) {
            throw new Application_Video_Screenshot_Exception("Image file extension \"$imgFileExt\" is invalid");
        }
        if (!$overwrite && file_exists($this->imgFile)) {
            throw new Application_Video_Screenshot_Exception("Image file \"{$this->imgFile}\" already exists");
        }

        $this->command = $this->ffmpegCommand . " -ss " . escapeshellarg($this->time)
            . " -i " . escapeshellarg($this->videoFile)
            . " " . escapeshellarg($this->imgFile);

        $descriptors = array(
            0 => array('pipe', 'r'),
            1 => array('pipe', 'w'),
            2 => array('pipe', 'w'),
        );

        $process = proc_open($this->command, $descriptors, $pipes, $this->ffmpegDir, null);

        $stdout = stream_get_contents($pipes[1]);
        echo $stdout;
        /*fclose($pipes[1]);
        $this->stdout = explode("\r\n", $stdout);

        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);
        $this->stderr = explode("\r\n", $stderr);*/

        return $this;
    }

    public function getStdout()
    {
        return $this->stdout;
    }

    public function getStdErr()
    {
        return $this->stderr;
    }

    public function getCommand()
    {
        return $this->command;
    }

    public function process()
    {
        $fullCommand = $this->ffmpegDir . $this->ffmpegCommand;
    }
}

class Application_Video_Screenshot_Exception extends Exception {}
