<?php

/**
 * Description of Processor
 *
 * @author David Gable
 * @created Jun 16, 2015
 */
class Application_Video_Processor
{
    protected $ffmpegCommand = 'ffmpeg';
    protected $ffmpegDir;
    protected $videoFile;
    protected $imageFile;
    protected $time = '00:00:00.000';
    protected $validImageExt = array(
        'jpg' => true,
        'jpeg' => true,
        'png' => true,
    );
    protected $stdout = array();
    protected $stderr = array();

    protected $durationLineMatch = "/Duration: ([0-9]{2}):([0-9]{2}):([0-9]{2})\\.?([0-9]+)?/";
    protected $dimensionLineMatch = "/Stream #[0-9]+:.*: Video:.* ([0-9]{2,})x([0-9]{2,}).*/";

    protected $resizeDimension = 'height';
    protected $resizeValue = 540;

    public function __construct($ffmpegCommand=null, $ffmpegDir=null, $videoFile=null, $imageFile=null, $time=null)
    {
        if ($ffmpegCommand) {
            $this->setFFmpegCommand($ffmpegCommand);
        }
        if ($ffmpegDir) {
            $this->setFFmpegDir($ffmpegDir);
        }
        if ($videoFile) {
            $this->setVideoFile($videoFile);
        }
        if ($imageFile) {
            $this->setImageFile($imageFile);
        }
        if ($time) {
            $this->setTime($time);
        }
    }

    public function setFFmpegCommand($command)
    {
        if (!preg_match("/^[0-9a-zA-Z]+$/", $command)) {
            throw new Application_Video_Processor_Exception("Invalid command name \"$command\"");
        } else {
            if ($this->checkIfExecutable($command) === false) {
                throw new Application_Video_Processor_Exception("Non-executable command \"$command\"");
            } else {
                $this->ffmpegCommand = $command;
            }
        }
        return $this;
    }

    protected function checkIfExecutable($command=null)
    {
        if ($command === null) {
            $command = $this->ffmpegCommand;
        }
        if ($this->ffmpegDir && $command) {
            $dirEndChar = substr($this->ffmpegDir, -1);
            if ($dirEndChar != '/' && $dirEndChar != '\\') {
                $this->ffmpegDir .= DIRECTORY_SEPARATOR;
            }
            if (substr($command, -4) != '.exe') {
                $command .= '.exe';
            }
            if (is_executable($this->ffmpegDir . $command)) {
                return true;
            } else {
                return false;
            }
        } else {
            return null;
        }
    }

    public function setFFmpegDir($dir)
    {
        if (is_dir($dir)) {
            if (substr($dir, -1) != DIRECTORY_SEPARATOR) {
                $dir .= DIRECTORY_SEPARATOR;
            }
            $this->ffmpegDir = $dir;
        } else {
            throw new Application_Video_Processor_Exception("Invalid directory \"$dir\"");
        }
        return $this;
    }

    public function setVideoFile($file)
    {
        if (file_exists($file)) {
            $this->videoFile = $file;
        } else {
            throw new Application_Video_Processor_Exception("Invalid video file \"$file\"");
        }
        return $this;
    }

    public function setImageFile($file)
    {
        if (is_dir(dirname($file))) {
            if (file_exists($file)) {
                throw new Application_Video_Processor_Exception("Image file \"$file\" already exists");
            } else {
                $this->imageFile = $file;
            }
        } else {
            throw new Application_Video_Processor_Exception("Invalid directory for image file \"$file\"");
        }
        return $this;
    }

    public function setTime($time) {
        $this->time = $time;
        return $this;
    }

    public function setResize($dimension, $value)
    {
        $validResizeDimensions = array(
            'width' => true,
            'height' => true,
        );
        if (!isset($validResizeDimensions[$dimension])) {
            throw new Application_Video_Processor_Exception("Invalid resize dimension \"$dimension\"");
        }
        if (is_int($value)) {
            throw new Application_Video_Processor_Exception("Invalid resize value \"$value\"");
        }
        if ($value < 25) {
            throw new Application_Video_Processor_Exception("Resize value \"$value\" is too small");
        }
        $this->resizeDimension = $dimension;
        $this->resizeValue = $value;
        return $this;
    }

    public function createFullCommand() {
        $fullCommand = $this->ffmpegCommand . " -ss " .
            escapeshellarg($this->time) . " -i " . escapeshellarg($this->videoFile) .
            " " . escapeshellarg($this->imageFile);
        return $fullCommand;
    }

    public function process() {
        $fullCommand = $this->createFullCommand();
        $descriptors = array(
            0 => array('pipe', 'r'),
            1 => array('pipe', 'w'),
            2 => array('pipe', 'w'),
        );
        $process = proc_open($fullCommand, $descriptors, $pipes, $this->ffmpegDir, null);

        /*$stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $this->stdout = explode("\r\n", $stdout);*/

        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);
        $this->stderr = explode("\r\n", $stderr);

        // Scan stderr for duration and dimension information
        foreach($this->stderr as $line) {
            if (preg_match($this->durationLineMatch, $line, $matches)) {
                $rawDuration = $matches[1].':'.$matches[2].':'.$matches[3].'.'.$matches[4];
                $hr = (int) $matches[1];
                $min = (int) $matches[2];
                $sec = (int) $matches[3];
                $micro = $matches[4];
                $duration = '';
                if ($hr) {
                    $duration .= $hr . ':';
                }
                if ($min) {
                    if ($duration) {
                        $min = str_pad($min, 2, '0', STR_PAD_LEFT);
                    }
                    $duration .= $min . ':';
                } elseif ($duration) {
                   $duration .= '00:';
                } else {
                    $duration .= '0:';
                }
                if ($sec) {
                    if (substr($micro, 0, 1) >= 5) {
                        $sec += 1;
                    }
                    if ($duration) {
                        $sec = str_pad($sec, 2, '0', STR_PAD_LEFT);
                    }
                    $duration .= $sec;
                } else {
                    $duration .= '00';
                } 
            } elseif (preg_match($this->dimensionLineMatch, $line, $matches)) {
                $width = $matches[1];
                $height = $matches[2];
            }
        }

        $newDimensions = $this->resize($width, $height, $this->resizeDimension, $this->resizeValue);

        return array(
            'video' => basename($this->videoFile),
            'poster' => basename($this->imageFile),
            'length' => $duration,
            'original-width' => $width,
            'original-height' => $height,
            'onscreen-width' => $newDimensions['width'],
            'onscreen-height' => $newDimensions['height'],
            'raw-duration' => $rawDuration,
        );
    }

    public function getStdOut()
    {
        return $this->stdout;
    }

    public function getStdErr()
    {
        return $this->stderr;
    }

    protected function resize($originalWidth, $originalHeight, $newDimension, $newValue)
    {
        if ($newDimension == 'width') {
            $newWidth = $newValue;
            $newHeight = round($originalHeight * $newValue / $originalWidth);
        } else {
            $newWidth = round($originalWidth * $newValue / $originalHeight);
            $newHeight = $newValue;
        }
        return array(
            'width' => $newWidth,
            'height' => $newHeight,
        );
    }
}

class Application_Video_Processor_Exception extends Exception {}