<?php

/**
 * Description of LinkManager
 *
 * @author David Gable
 * @created Jul 30, 2015
 */
class Application_Video_LinkManager
{
    protected $directory;

    public function __construct($directory)
    {
        if (!is_string($directory)) {
            $class = gettype($directory);
            throw new Application_Error_Logger_Exception("Directory should be a string, was \"$class\" instead.");
        } else if (!file_exists($directory)) {
            throw new Application_Error_Logger_Exception("Directory \"$directory\" does not exist.");
        } else if (!is_dir($directory)) {
            throw new Application_Error_Logger_Exception("Directory \"$directory\" is not a valid directory.");
        } else {
            if (substr($directory, -1) != DIRECTORY_SEPARATOR) {
                $directory .= DIRECTORY_SEPARATOR;
            }
            $this->directory = $directory;
        }
    }

    protected function findFile($index)
    {
        $file = $this->directory . $index;
        if (file_exists($file) && is_file($file) && is_writeable($file)) {
            return $file;
        } else {
            return false;
        }
    }

    public function lookup($index)
    {
        if ($file = $this->findFile($index)) {
            $raw = file_get_contents($file);
            $lines = explode("\n", $raw);
            return array(
                'video' => $lines[0],
                'expires' => new DateTime($lines[1]),
            );
        } else {
            return false;
        }
    }

    public function create($random, $video, $expires)
    {
        $expiresDT = new DateTime($expires);
        $lines = array(
            $video,
            $expiresDT->format('Y-m-d H:i:s'),
        );
        $file = null;
        while($file == null || file_exists($file)) {
            $ticket = $random->getRandomString(8, 'abcdefghjklmnpqrstuvwxyz23456789');
            $file = $this->directory . $ticket;
        }
        file_put_contents($file, implode("\n", $lines));
        return $ticket;
    }

    public function update($index, array $data)
    {
        if ($file = $this->findFile($index)) {
            file_put_contents($file, implode("\n", $data));
            return true;
        } else {
            return false;
        }
    }

    public function updateExpires($index, $newExpires)
    {
        if ($data = $this->lookup($index)) {
            $newDT = new DateTime($newExpires);
            $newData = array(
                'video' => $data['video'],
                'expires' => $newDT->format('Y-m-d H:i:s'),
            );
            $this->update($index, $newData);
            return true;
        } else {
            return false;
        }
    }
}

class Application_Video_LinkManager_Exception {}