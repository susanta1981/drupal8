<?php

/**
 * Description of Lister
 *
 * @author David Gable
 * @created Aug 4, 2015
 */
class Application_Video_Lister
{
    protected $dir;

    public function __construct($dir)
    {
        $this->setDirectory($dir);
    }

    public function setDirectory($dir)
    {
        if (is_dir($dir)) {
            $this->dir = $dir;
        } else {
            throw new Application_Video_Lister_Exception("Invalid directory \"$dir\"");
        }
        return $this;
    }

    public function listFiles($excludes=array())
    {
        $fileList = scandir($this->dir);
        foreach($fileList as $key => $file) {
            if ($file == '.' || $file == '..'
                || $file == 'Thumbs.db'
                || $file == 'debug' || $file == 'info'
                || is_dir($this->dir . $file)
                || in_array($file, $excludes)) {
                unset($fileList[$key]);
            }

        }
        return array_values($fileList);
    }

    public function listExcludes($configVideoList)
    {
        $list = array();
        foreach($configVideoList as $videoEntry) {
            $list[] = $videoEntry->video;
        }
        return $list;
    }
}

class Application_Video_Lister_Exception extends Exception {}