<?php

/**
 * Description of GetDuration
 *
 * @author David Gable
 * @created Jun 2, 2015
 */
class Application_Video_GetDuration
{
    protected $videoFile;
    protected $ffmpegCommand = 'ffmpeg';
    protected $ffmpegDir;

    protected $duration;

    protected $command;
    protected $stdout;
    protected $stderr;

    public function setVideoFile($file)
    {
        if (!file_exists($file)) {
            throw new Application_Video_GetDuration_Exception("Video file \"$file\" does not exist");
        }
        $this->videoFile = $file;
        return $this;
    }

    public function getVideoFile()
    {
        return $this->videoFile;
    }

    public function setFfmpegCommand($command)
    {
        $this->ffmpegCommand = $command;
        return $this;
    }

    public function setFfmpegDir($dir)
    {
        $this->ffmpegDir = $dir;
        return $this;
    }

    public function findDuration()
    {
        $this->command = $this->ffmpegCommand . " -i " . $this->videoFile;
        $descriptors = array(
            0 => array('pipe', 'r'),
            1 => array('pipe', 'w'),
            2 => array('pipe', 'w'),
        );
        $process = proc_open($this->command, $descriptors, $pipes, $this->ffmpegDir, null);

        $stdout = stream_get_contents($pipes[1]);
        fclose($pipes[1]);
        $this->stdout = explode("\r\n", $stdout);

        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[2]);
        $this->stderr = explode("\r\n", $stderr);

        $duration = false;
        foreach($this->stderr as $line) {
            if (strpos($line, 'Duration:') !== false) {
                $sections = explode(',', $line);
                $durationParts = explode('Duration:', $sections[0]);
                $duration = trim(end($durationParts));
                break;
            }
        }
        if (!$duration) {
            throw new Application_Video_GetDuration_Exception('Duration not found');
        } else {
            $this->duration = $duration;
        }
        return $this;
    }

    public function getDuration()
    {
        return $this->duration;
    }

    public function getCommand()
    {
        return $this->command;
    }

    public function getStdout()
    {
        return $this->stdout;
    }

    public function getStderr()
    {
        return $this->stderr;
    }
}

class Application_Video_GetDuration_Exception extends Exception {}