<?php

/**
 * Description of LinkManager2
 *
 * @author David Gable
 * @created Aug 18, 2015
 */
class Application_Video_LinkManager2
{
    protected $directory;

    public function __construct($directory)
    {
        $this->setDirectory($directory);
    }

    public function setDirectory($directory)
    {
        if (!is_string($directory)) {
            $class = gettype($directory);
            throw new Application_Video_LinkManager2_Exception("Directory should be a string, was \"$class\" instead");
        } else if (!file_exists($directory)) {
            throw new Application_Video_LinkManager2_Exception("Directory \"$directory\" does not exist");
        } else if (!is_dir($directory)) {
            throw new Application_Video_LinkManager2_Exception("\"$directory\" is not a valid directory");
        } else {
            if (substr($directory, -1) != DIRECTORY_SEPARATOR) {
                $directory .= DIRECTORY_SEPARATOR;
            }
            $this->directory = $directory;
        }
        return $this;
    }

    protected function findFile($index)
    {
        $file = $this->directory . $index;
        if (file_exists($file) && is_file($file) && is_writable($file)) {
            return $file;
        } else {
            return false;
        }
    }

    public function lookup($index)
    {
        if ($file = $this->findFile($index)) {
            $json = json_decode(file_get_contents($file), true);
            return array(
                'video' => $json['video'],
                'expires' => new DateTime($json['expires']),
                'location' => $json['location'],
                'visits' => $json['visits'],
            );
        } else {
            return false;
        }
    }

    public function create($random, $video, $expires, $location, $prettyPrint=true)
    {
        if ($expires instanceof DateTime) {
            $expiresDT = $expires;
        } else {
            $expiresDT = new DateTime($expires);
        }
        $settings = array(
            'video' => $video,
            'expires' => $expiresDT->format('Y-m-d H:i:s'),
            'location' => $location,
            'visits' => 0,
        );
        $file = null;
        while($file == null || file_exists($file)) {
            $ticket = $random->getRandomString(8, 'abcdefghjkmnpqrstuvwxyz23456789');
            $file = $this->directory . $ticket;
        }
        if ($prettyPrint) {
            if (version_compare(PHP_VERSION, '5.4.0', '>=')) {
                $json = json_encode($settings, JSON_PRETTY_PRINT);
            } else {
                $json = $this->prettyprintJson(json_encode($settings));
            }
        } else {
            $json = json_encode($json);
        }
        file_put_contents($file, $json);
        return $ticket;
    }

    public function update($index, array $data, $prettyPrint=true)
    {
        if ($file = $this->findFile($index)) {
            if ($data['expires'] instanceof DateTime) {
                $data['expires'] = $data['expires']->format('Y-m-d H:i:s');
            }
            if ($prettyPrint) {
                if (version_compare(PHP_VERSION, '5.4.0', '>=')) {
                    $json = json_encode($data, JSON_PRETTY_PRINT);
                } else {
                    $json = $this->prettyprintJson(json_encode($data));
                }
            } else {
                $json = json_encode($data);
            }
            file_put_contents($file, $json);
            return true;
        } else {
            return false;
        }
    }

    public function incrementVisits($index, $increment=1)
    {
        if ($settings = $this->lookup($index)) {
            $settings['visits'] += $increment;
            if ($this->update($index, $settings)) {
                return $settings['visits'];
            } else {
                throw new Application_Video_LinkManager2_Exception("Failed to update link \"$index\"");
            }
        } else {
            throw new Application_Video_LinkManager2_Exception("Invalid index \"$index\"");
        }
    }

    /**
     * Replacement pretty print function for when JSON_PRETTY_PRINT option is
     * not available.
     * @param string $json
     * @return string
     */
    protected static function prettyPrintJson($json)
    {
        $result = '';
        $level = 0;
        $in_quotes = false;
        $in_escape = false;
        $ends_line_level = NULL;
        $json_length = strlen( $json );

        for( $i = 0; $i < $json_length; $i++ ) {
            $char = $json[$i];
            $new_line_level = NULL;
            $post = "";
            if( $ends_line_level !== NULL ) {
                $new_line_level = $ends_line_level;
                $ends_line_level = NULL;
            }
            if ( $in_escape ) {
                $in_escape = false;
            } else if( $char === '"' ) {
                $in_quotes = !$in_quotes;
            } else if( ! $in_quotes ) {
                switch( $char ) {
                    case '}': case ']':
                        $level--;
                        $ends_line_level = NULL;
                        $new_line_level = $level;
                        break;

                    case '{': case '[':
                        $level++;
                    case ',':
                        $ends_line_level = $level;
                        break;

                    case ':':
                        $post = " ";
                        break;

                    case " ": case "\t": case "\n": case "\r":
                        $char = "";
                        $ends_line_level = $new_line_level;
                        $new_line_level = NULL;
                        break;
                }
            } else if ( $char === '\\' ) {
                $in_escape = true;
            }
            if( $new_line_level !== NULL ) {
                $result .= "\n".str_repeat( "    ", $new_line_level );
            }
            $result .= $char.$post;
        }

        return $result;
    }
}

class Application_Video_LinkManager2_Exception extends Exception {}