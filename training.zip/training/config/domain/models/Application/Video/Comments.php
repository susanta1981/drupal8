<?php

/**
 * Description of Comments
 *
 * @author David Gable
 * @created Oct 27, 2015
 */
class Application_Video_Comments
{
    private $pdo;
    private $video;
    private $comments;

    public function __construct($pdo, $video=null)
    {
        $this->setPDO($pdo);
        if ($video) {
            $this->setVideo($video);
        }
    }

    public function setPDO($pdo)
    {
        if (!($pdo instanceof PDO)) {
            throw new Application_Video_Comments_Exception('Initialized with invalid non-PDO connector object');
        } else {
            $this->pdo = $pdo;
            return $this;
        }
    }

    public function setVideo($video)
    {
        if (!is_string($video)) {
            throw new Application_Video_Comments_Exception('Invalid non-string value for video ID');
        } else {
            $this->video = $video;
            return $this;
        }
    }

    public function addComment($specs, $respondingTo=0)
    {
        if (!is_array($specs)) {
            throw new Application_Video_Comments_Exception('Invalid non-array value for adding a comment');
        } else if (!isset($specs['comment'])) {
            throw new Application_Video_Comments_Exception('Missing comment value for adding a comment');
        } else if (!isset($specs['author'])) {
            throw new Application_Video_Comments_Exception('Missing author value for adding a comment');
        } else if (!isset($specs['author_ip'])) {
            throw new Application_Video_Comments_Exception('Missing author IP address value for adding a comment');
        } else if (!(is_int($respondingTo) || (ctype_digit($respondingTo))) || $respondingTo < 0) {
            throw new Application_Video_Comments_Exception("Invalid \"responding to\" comment ID \"{$respondingTo}\"");
        } else {
            try {
                $qry = "INSERT INTO comments (video, comment, author, email, author_ip, created, in_response_to) "
                    . "VALUES "
                    . "(:video, :comment, :author, :email, :author_ip, NOW(), :in_response_to)";
                $data = array(
                    'video' => $this->video,
                    'comment' => $specs['comment'],
                    'author' => $specs['author'],
                    'email' => ($specs['email']) ? $specs['email'] : '',
                    'author_ip' => $specs['author_ip'],
                    'in_response_to' => $respondingTo,
                );
                $stmt = $this->pdo->prepare($qry)->execute($data);

                $lastId = $this->pdo->lastInsertId();
                $qry2 = "SELECT * FROM comments WHERE id = :id";
                $stmt2 = $this->pdo->prepare($qry2);
                $stmt2->execute(array('id' => $lastId));
                return $stmt2->fetch(PDO::FETCH_ASSOC);
            } catch (PDOException $ex) {
                throw new Application_Video_Comments_Exception('PDO Execution Error on addComment(): ' . $ex->getMessage());
            } catch (Exception $ex) {
                throw new Application_Video_Comments_Exception('Unexpected Error on addComment(): ' . $ex->getMessage());
            }
        }
    }

    public function getComments($approvedOnly=true, $desc=false, $includeResponses = false)
    {
        try {
            $qry = "SELECT * FROM comments WHERE video = :video AND in_response_to = 0 ";
            if ($approvedOnly) {
                $qry .= "AND approved = 1 ";
            }
            $qry .= "ORDER BY created";
            if ($desc) {
                $qry .= " DESC";
            }
            $stmt = $this->pdo->prepare($qry);
            $stmt->execute(array(
                'video' => $this->video,
            ));
            $comments = array();
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if ($includeResponses) {
                    $row['responses'] = $this->getCommentResponses($row['id'], $approvedOnly);
                }
                $comments[] = $row;
            }
            return $comments;
        } catch (PDOException $ex) {
            throw new Application_Video_Comments_Exception('PDO Execution Error on getComments(): ' . $ex->getMessage());
        } catch (Exception $ex) {
            throw new Application_Video_Comments_Exception('Unexpected Error on getComments(): ' . $ex->getMessage());
        }
    }

    public function getCommentResponses($commentid, $approvedOnly=true, $desc=false) {
        try {
            $qry = "SELECT * FROM comments WHERE video = :video AND in_response_to = :in_response_to ";
            if ($approvedOnly) {
                $qry .= "AND approved = 1 ";
            }
            $qry .= "ORDER BY created";
            if ($desc) {
                $qry .= " DESC";
            }
            $stmt = $this->pdo->prepare($qry);
            $stmt->execute(array(
                'video' => $this->video,
                'in_response_to' => $commentid,
            ));
            $responses = array();
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $responses[] = $row;
            }
            return $responses;
        } catch (PDOException $ex) {
            throw new Application_Video_Comments_Exception('PDO Execution Error on getCommentResponses(): ' . $ex->getMessage());
        } catch (Exception $ex) {
            throw new Application_Video_Comments_Exception('Unexpected Error on getCommentResponses(): ' . $ex->getMessage());
        }
    }

    public function approveComment($commentid, $approval=true)
    {
        if ($approval) {
            $approved = 1;
        } else {
            $approved = 0;
        }
        $stmt = $this->pdo->prepare("UPDATE comments SET approved = :approved WHERE id = :id");
        $result = $stmt->execute(array(
            'id' => $commentid,
            'approved' => $approved,
        ));
        if (!$result) {
            throw new Application_Video_Comments_Exception('Comment approval failed');
        } else {
            return true;
        }
    }

    public function deleteComment($commentid)
    {
        $stmt = $this->pdo->prepare("DELETE FROM comments WHERE id = :commentid");
        $result = $stmt->execute(array('commentid' => $commentid));
        if (!$result) {
            throw new Application_Video_Comments_Exception('Comment deletion failed');
        } else {
            return true;
        }
    }
}

class Application_Video_Comments_Exception extends Exception {}