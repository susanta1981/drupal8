<?php

/**
 * Description of MultiPartFormDataParser
 *
 * @author David Gable
 * @created Jun 15, 2015
 */
class Application_MultiPartFormDataParser
{
    protected $patterns = array(
        'begin' => "/^-----------------------------([0-9]+)$/",
        'end' => "/^-----------------------------([0-9]+)--$/",
        'simple-value' => "/^Content-Disposition: form-data; name=\"([a-zA-Z0-9_\.]+)\"\$/",
        'file-value' => "/^Content-Disposition: form-data; name=\"([a-zA-Z0-9\-_\.]+)\"; filename=\"([a-zA-Z0-9\-_\. ]+)\"\$/",
        'content-type' => "/^Content-Type: ([a-zA-Z0-9\-\_\.\/]+)$/",
    );
    protected $input;
    protected $fileOutput;
    protected $debug;
    protected $dir;
    protected $ended = false;

    protected $random = null;
    protected $randomFileNames = false;
    protected $extWhiteList = array();
    protected $extBlackList = array();

    protected $post = array();
    protected $files = array();

    public function __construct($random, $dir, $debug=false)
    {
        $this->random = $random;
        $this->dir = $dir;
        if ($debug) {
            $this->debug = fopen($this->dir . 'debug', 'w');
            $this->info = fopen($this->dir . 'info', 'w');
        }
        $this->input = fopen("php://input", 'rb');
    }

    public function __destruct()
    {
        if (is_resource($this->input)) {
            fclose($this->input);
        }
        if (is_resource($this->debug)) {
            fclose($this->debug);
        }
        if (is_resource($this->info)) {
            fwrite($this->info, json_encode($this->post));
            fwrite($this->info, "\r\n\r\n");
            fwrite($this->info, json_encode($this->files));
            fclose($this->info);
        }
        if (is_resource($this->fileOutput)) {
            fclose($this->fileOutput);
        }
    }

    public function getPost()
    {
        return $this->post;
    }

    public function getFiles()
    {
        return $this->files;
    }
    
    protected function getFileExt($filename) 
    {
        $pos = strrpos($filename, '.');
        if ($pos === false) {
            return '';
        } else {
            return substr($filename, $pos + 1);
        }
    }

    public function setExtWhiteList(array $list)
    {
        $this->extWhiteList = array();
        foreach($list as $ext) {
            $this->extWhiteList[$ext] = true;
        }
        return $this;
    }

    public function setExtBlackList(array $list)
    {
        $this->extBlackList = array();
        foreach($list as $ext) {
            $this->extBlackList[$ext] = true;
        }
        return $this;
    }

    protected function passesWhiteList($filename)
    {
        // If no white list is set up, it passes.
        if (count($this->extWhiteList)) {
            return true;
        }
        $ext = $this->getFileExt($filename);
        if (isset($this->extWhiteList[$ext])) {
            return true;
        } else {
            return false;
        }
    }

    protected function passesBlackList($filename)
    {
        // If no black list is set up, it passes.
        if (count($this->extBlackList)) {
            return true;
        }
        $ext = $this->getFileExt($filename);
        if (isset($this->extBlackList[$ext])) {
            return false;
        } else {
            return true;
        }
    }

    public function setRandomFileNames($bool)
    {
        $this->randomFileNames = (bool) $bool;
        return $this;
    }

    public function randomizeFileName($filename)
    {
        if (strpos($filename, '.') !== false) {
            $pieces = explode('.', $filename);
            $ext = end($pieces);
        } else {
            $ext = false;
        }
        do {
            $randomFileName = $this->random->getRandomString(20, 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.');
            if ($ext) {
                $randomFileName .= '.' . $ext;
            }
        } while (file_exists($this->dir . $randomFileName));
        return $randomFileName;
    }

    protected function postDebugLine($msg) {
        if ($this->debug) {
            fwrite($this->debug, $msg . "\r\n");
        }
        return $this;
    }

    public function parse()
    {
        $nextLine = fgets($this->input);
        $this->postDebugLine($nextLine);
        while (!$this->ended) {
            $nextLine = fgets($this->input);
            $this->postDebugLine($nextLine);
            if ($valName = $this->lineDefinesPostValue($nextLine)) {
                $this->post[$valName] = $this->parseValue();
            } elseif ($values = $this->lineDefinesFileValue($nextLine)) {
                $this->files[$values['name']] = $this->parseFile($this->dir . $values['file']);
            }
        }
        return $this;
    }

    protected function parseValue()
    {
        $value = '';
        $blankLine = fgets($this->input);
        $this->postDebugLine($blankLine);
        $nextLine = fgets($this->input);
        $this->postDebugLine($nextLine);
        while(!$this->lineIsEndOfValue($nextLine)) {
            $value .= $nextLine;
            $nextLine = fgets($this->input);
            $this->postDebugLine($nextLine);
        }
        return trim($value);
    }

    protected function parseFile($file)
    {
        if ($this->passesWhiteList($file) && $this->passesBlackList($file)) {
            $acceptFile = true;
            //$this->postDebugMessage('File accepted.');
        } else {
            $acceptFile = false;
            //$this->postDebugMessage('File not accepted.');
        }
        $originalName = basename($file);
        if ($this->randomFileNames) {
            $file = $this->randomizeFileName($file);
            $file = $this->dir . $file;
        }
        if ($acceptFile) {
            //$this->postDebugMessage('File Path: '.$file."\r\n");
            $this->fileOutput = fopen($file, 'wb');
        }
        $typeLine = fgets($this->input);
        $this->postDebugLine($typeLine);
        $type = $this->lineDefinesFileContentType($typeLine);
        $blankLine = fgets($this->input);
        $this->postDebugLine($blankLine);
        $nextLine = fgets($this->input);
        $this->postDebugLine($nextLine);
        while(!$this->lineIsEndOfValue($nextLine)) {
            if ($acceptFile) {
                fwrite($this->fileOutput, $nextLine);
            }
            $nextLine = fgets($this->input);
            $this->postDebugLine($nextLine);
        }
        if ($acceptFile) {
            fclose($this->fileOutput);
        }
        return array(
            'original_name' => $originalName,
            'real_name' => basename($file),
            'type' => $type,
            'accepted' => $acceptFile,
        );
    }
    
    protected function lineDefinesPostValue($line)
    {
        if (preg_match($this->patterns['simple-value'], trim($line), $matches)) {
            return $matches[1];
        } else {
            return false;
        }
    }
    
    protected function lineDefinesFileValue($line)
    {
        if (preg_match($this->patterns['file-value'], trim($line), $matches)) {
            return array(
                'name' => $matches[1],
                'file' => $matches[2],
            );
        } else {
            return false;
        }
    }
    
    protected function lineDefinesFileContentType($line)
    {
        if (preg_match($this->patterns['content-type'], trim($line), $matches)) {
            return $matches[1];
        } else {
            return false;
        }
    }

    protected function lineBeginsNextValue($line)
    {
        return preg_match($this->patterns['begin'], trim($line));
    }

    protected function lineEndsUpload($line)
    {
        $retval = preg_match($this->patterns['end'], trim($line));
        if ($retval) {
            fclose($this->input);
            $this->ended = true;
        }
        return $retval;
    }

    protected function lineIsEndOfValue($line) {
        return ($this->lineBeginsNextValue($line) || $this->lineEndsUpload($line));
    }
}