<?php

function ApplicationAutoloader($className)
{
	$filepath = dirname(__FILE__) . DIRECTORY_SEPARATOR . str_replace(array('_', '\\'), DIRECTORY_SEPARATOR, $className) . '.php';
	if (file_exists($filepath)) {
		require($filepath);
	}
}

spl_autoload_register('ApplicationAutoloader');