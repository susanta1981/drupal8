<?php
require('../start.php');


echo $data=$_GET['search'];

?>