$(function(){
    $('#get-link-button').click(function() {
        $.ajax({
            data: JSON.stringify({
                video: videoID,
                expire: $('#expireDT').val(),
                location: $('#location').val()
            }),
            dataType: "JSON",
            success: function(response) {
                if (response.success) {
                    $('#my-link').empty().html(response.data.link);
                } else {
                    alert("ERROR: " + response.message);
                }
                if ($('#my-link').html()) {
                    $('#email-link-button').css('display', 'inline');
                } else {
                    $('#email-link-button').css('display', 'none');
                }
            },
            processData: false,
            type: "post",
            url: "createlink.php"
        });
    });
    $('#chk-public').click(function() {
        $.ajax({
            "data": JSON.stringify({
                "video": videoID,
                "checked": $('#chk-public').is(':checked')
            }),
            "dataType": "json",
            "error": function(jqXHR, status, error) {
                window.alert(jqXHR.responseText);
            },
            "method": "post",
            "processData": false,
            "success": function(response) {
                if (response.public) {
                    $('#chk-public').prop('checked', true);
                } else {
                    $('#chk-public').prop('checked', false);
                }
            },
            "url": "ajaxTogglePublic.php"
        });
    });
    
    $('#email-link-button').click(function() {
        var subject = 'Supplemental Video--'+videoTitle;
        var body = "Visit%20this%20link%20to%20view%20the%20supplemental%20video%20\""+videoTitle+"\":%0A%0D%0A%0D" + $('#my-link').html();
        var link = "mailto:?subject="+subject+"&body="+body;
        window.location.href = link;
    });
    
    $('#delete-button').click(function() {
        $('#delete-confirm-modal').modal('show');
    });

    $('#delete-confirm-button').click(function() {
        $.ajax({
            "data": JSON.stringify({
                id: videoID
            }),
            "dataType": "json",
            "error": function(jqXHR, status, error) {
                $('#delete-config-modal').modal('hide');
            },
            "success": function(response) {
                if (response.success) {
                    location = "index.php";
                } else {
                    if (!response.data.auth) {
                        location = "../logout.php";
                    }
                }
            },
            "processData": false,
            "method": "post",
            "url": "ajaxDelete.php"
        });
    });
    
    $('#expireDT').datetimepicker();
});