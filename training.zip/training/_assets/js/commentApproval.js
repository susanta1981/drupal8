var commentsManager = {
    commentToDelete: null,
    approve: function(id, commentDiv) {
        var data = {
            commentid: id,
            approval: true
        };
        $.ajax({
            data: JSON.stringify(data),
            dataType: 'json',
            error: function(jqXHR, status, error) {
                commentApprovalDialog('ERROR: ' + error);
            },
            method: 'post',
            processData: false,
            success: function(response) {
                commentDiv.addClass('comment-is-approved');
                commentApprovalDialog(response.message);
            },
            url: '_ajax/approveComment.php'
        });
    },
    disapprove: function(id, commentDiv) {
        var data = {
            commentid: id,
            approval: false
        };
        $.ajax({
            data: JSON.stringify(data),
            dataType: 'json',
            error: function(jqXHR, status, error) {
                commentApprovalDialog('ERROR: ' + error);
            },
            method: 'post',
            processData: false,
            success: function(response) {
                commentDiv.removeClass('comment-is-approved');
                commentApprovalDialog(response.message);
            },
            url: '_ajax/approveComment.php'
        });
    },
    delete: function(id, commentDiv) {
        var data = {
            commentid: id
        };
        $.ajax({
            data: JSON.stringify(data),
            dataType: 'json',
            error: function(jqXHR, status, error) {
                $('#comment-delete-error-modal .modal-body').empty().html('Deletion failed due to the following error: ' + error);
                $('#comment-delete-error-modal').show();                
            },
            method: 'post',
            processData: false,
            success: function(response) {
                if (response.success) {
                    commentDiv.remove();
                    $('#comment-delete-confirm-modal').modal('hide');
                } else {
                    $('#comment-delete-confirm-modal').modal('hide');
                    $('#comment-delete-error-modal .modal-body').empty().html('Deletion failed due to the following error: ' + response.message);
                    $('#comment-delete-error-modal').show();
                }
            },
            url: '_ajax/deleteComment.php'
        });
    }
};

$(function() {
    $('.approved-checkbox').change(function(e) {
        var commentid = $(this).attr('commentid');
        var commentDiv = $(this).closest('div.panel');
        if ($(this).is(':checked')) {
            commentsManager.approve(commentid, commentDiv);
        } else {
            commentsManager.disapprove(commentid, commentDiv);
        }
    });
    
    $('#delete-confirm-modal-ok-button').click(function() {
        var commentid = commentsManager.commentToDelete;
        var commentDiv = commentsManager.divToDelete;
        commentsManager.delete(commentid, commentDiv);        
    });
    
    $('.btn-comment-delete').click(function() {
        commentsManager.commentToDelete = $(this).attr('commentid');
        commentsManager.divToDelete = $(this).closest('div.panel');
        $('#comment-delete-confirm-modal').modal('show');
    });
    
    $('.btn-comment-respond').click(function() {
        var commentid = $(this).attr('commentid');
        openResponseForm(commentid);
    });
    
    $('[data-toggle="tooltip"]').tooltip();
});

function commentApprovalDialog(message) {
    $('#comment-confirm-modal .modal-body').empty().html(message);
    $('#comment-confirm-modal').modal('show');
}

function openResponseForm(commentid) {
    var form = $('<div />').addClass('panel').addClass('panel-primary')
            .attr('id', 'addResponsePanel');
    
    var formHeading = $('<div />').addClass('panel-heading');
    var formHeadingInner = $('<div />').addClass('panel-heading-inner');
    var authorSpan = $('<span />').addClass('author').html('Add a response...');
    formHeadingInner.append(authorSpan);
    formHeading.append(formHeadingInner);
    form.append(formHeading);
    
    var formBody = $('<div />').addClass('panel-body');
    var commentidHidden = $('<input type="hidden" id="hidden-commentid" name="commentid" />').val(commentid);
    var table = $('<table />');
    
    var tr1 = $('<tr />');
    var td1_1 = $('<td />');
    var nameLabel = $('<label for="add-response-author" />').html('Name: ');
    td1_1.append(nameLabel);
    var td1_2 = $('<td />');
    var nameInput = $('<input type="text" id="add-response-author" name="author" value="" />');
    td1_2.append(nameInput);
    tr1.append(td1_1).append(td1_2);
    
    var tr2 = $('<tr />');
    var td2_1 = $('<td />');
    var emailLabel = $('<label for="add-response-author-email" />').html('Email: ');
    td2_1.append(emailLabel);
    var td2_2 = $('<td />');
    var emailInput = $('<input type="text" id="add-response-author-email" name="email" value="" />');
    td2_2.append(emailInput);
    tr2.append(td2_1).append(td2_2);
    
    var tr3 = $('<tr />');
    var td3_1 = $('<td />');
    var commentLabel = $('<label for="add-response-text" />').html('Comment: ');
    td3_1.append(commentLabel);
    var td3_2 = $('<td />');
    var commentTA = $('<textarea id="add-response-text" name="comment" rows="5" cols="100" />');
    td3_2.append(commentTA);
    tr3.append(td3_1).append(td3_2);
        
    table.append(tr1).append(tr2).append(tr3); //.append(tr4);
    formBody.append(commentidHidden).append(table);
    form.append(formBody);
    
    var formFooter = $('<div class="panel-footer" />');
    var cancelButton = $('<button type="button" class="btn btn-default" id="add-response-form-cancel-button" />').html('Cancel');
    var okButton = $('<button type="button" class="btn btn-primary" id="add-response-form-ok-button" />').html('OK');
    formFooter.append(cancelButton).append(okButton);
    form.append(formFooter);
    
    $('#main-comment-container-' + commentid).append(form);
    
    $('#add-response-form-cancel-button').click(cancelResponseForm);
    $('#add-response-form-ok-button').click(submitResponseForm);
}

function cancelResponseForm() {
    $('#addResponsePanel').remove();
}

function submitResponseForm() {
    var author = $('#add-response-author').val().trim();
    if (!author) {
        $('#add-response-author').addClass('forgot-me');
        alertDialog('You must provide a name in order to respond to a comment.');
        return false;
    } else {
        $('#add-response-author').removeClass('forgot-me');
    }
    var responseText = $('#add-response-text').val().trim();
    if (!responseText) {
        $('#add-response-text').addClass('forgot-me');
        alertDialog('In order to make a response, you must...actually say something.');
        return false;
    } else {
        $('#add-response-text').removeClass('forgot-me');
    }
    var email = $('#add-response-author-email').val().trim();
    var respondingTo = $('#hidden-commentid').val();
    
    var ajaxData = {
        video: videoID,
        author: author,
        email: email,
        comment: responseText,
        respondingTo: respondingTo
    };
    $.ajax({
        data: JSON.stringify(ajaxData),
        dataType: 'json',
        error: function(jqXHR, status, error) {
            alertDialog('ERROR: ' + error);
        },
        method: 'post',
        processData: false,
        success: function(response) {
            if (response.success) {
                $('#addResponsePanel').remove();
                addResponsePanel(response.data.newrow);
            } else {
                alertDialog('ERROR: ' + response.message);
            }
        },
        url: "_ajax/addResponse.php"
    });
}

function alertDialog(message) {
    $('#alert-modal .modal-body').empty().html(message);
    $('#alert-modal').modal('show');
}

function addResponsePanel(data) {
    var panel = $('<div class="panel panel-default response-to-comment comment-is-approved" />');
    
    var panelHeading = $('<div class="panel-heading" />');
    var panelHeadingInner = $('<div class="panel-heading-inner" />');
    var arrowSpan = $('<span class="arrow glyphicon glyphicon-chevron-right" />');
    var authorSpan = $('<span class="author" />').html(data.author);
    var emailLink = $('<a />').attr('mailto', data.email).html(data.email);
    var emailSpan = $('<span class="email" />').append('[').append(emailLink).append(']');
    var chk = $('<input type="checkbox" class="approved-checkbox" data-toggle="tooltip" data-placement="top" title="Unapprove this response" />').attr('id', 'approved-' + data.id).attr('commentid', data.id);
    var approvedSpan = $('<span class="approved" />').append(chk);
    var trashCan = $('<span class="glyphicon glyphicon-trash" />');
    var deleteButton = $('<button type="button" class="btn btn-danger btn-xs btn-comment-delete" data-toggle="tooltip" data-placement="top" title="Delete this comment" />').attr('commentid', data.id).append(trashCan);
    var deleteSpan = $('<span class="delete" />').append(deleteButton);
    var ipSpan = $('<span class="ip" />');
    if (data.author_ip) {
        ipSpan.append('[' + data.author_ip + ']');
    }
    var datetimeSpan = $('<span class="datetime" />').append(moment(data.created).format('MMM D, YYYY [at] h:mm a'));
    panelHeadingInner.append(arrowSpan).append(authorSpan).append(emailSpan).append(approvedSpan).append(deleteSpan).append(ipSpan).append(datetimeSpan);
    panelHeading.append(panelHeadingInner);
    panel.append(panelHeading);
    
    var panelBody = $('<div class="panel-body" />');
    var commentPre = $('<pre class="comment" />').html(data.comment);
    panelBody.append(commentPre);
    panel.append(panelBody);
    
    $('#main-comment-container-' + data.in_response_to).append(panel);
    return true;
}
