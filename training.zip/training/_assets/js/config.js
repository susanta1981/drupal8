$(function() {
    $('.btn-save').click(function() {
        var configPath = $(this).attr('config-path');
        var value = $('#' + $(this).attr('value-input')).val();
        editConfig(configPath, value);
    });
});

function editConfig(configPath, value) {
    var data = {
        configPath: configPath,
        value: value
    };
    $.ajax({
        data: JSON.stringify(data),
        dataType: 'json',
        error: function(jqXHR, status, error) {
            alertDialog('ERROR: ' + error, 'JS ERROR!');
        },
        method: 'post',
        processData: false,
        success: function(response) {
            if (response.success) {
                alertDialog(response.message, 'Success!');
            } else {
                alertDialog('ERROR: ' + response.message, 'PHP ERROR!');
            }
        },
        url: 'editConfig.php'
    });
}

function alertDialog(message, title) {
    if (title) {
        $('#alert-dialog-modal .modal-title').empty().html(title);
    }
    $('#alert-dialog-modal .modal-body').empty().html(message);
    $('#alert-dialog-modal').modal('show');
    return true;
}