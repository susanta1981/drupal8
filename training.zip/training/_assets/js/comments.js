var commentsManager = {
    add: function(video, author, email, comment) {
        var data = {
            video: video,
            author: author,
            email: email,
            comment: comment
        };
        $.ajax({
            data: JSON.stringify(data),
            dataType: 'json',
            error: function(jqXHR, status, error) {
                alert('ERROR: ' + error);
            },
            method: 'post',
            processData: false,
            success: function(response) {
                clearAddCommentForm();
                prependNewComment(response.data.newrow);
                toggleAddNewCommentPanel();
            },
            url: '_ajax/addComment.php'
        });
    }
};

$(function() {
    $('#submit-comment-button').click(function() {
        var video = $('#hidden-video-id').val();
        var author = $('#add-comment-author').val();
        if (!author) {
            alert('A name is required');
            return false;
        }
        var email = $('#add-comment-author-email').val();
        var comment = $('#add-comment-text').val();
        if (!comment) {
            alert('You must write your comment first.');
            return false;
        }
        commentsManager.add(video, author, email, comment);
        return true;
    });
    
    $('#addCommentButton').click(toggleAddNewCommentPanel);
});

function clearAddCommentForm() {
   $('#add-comment-author').val('');
   $('#add-comment-author-email').val('');
   $('#add-comment-text').val('');
}

function prependNewComment(comment) {
    var commentDOM = $('<div />').addClass('panel').addClass('panel-default').addClass('comment-is-approved');
    
    var panelHeading = $('<div />').addClass('panel-heading');
    var panelHeadingInner = $('<div />').addClass('panel-heading-inner');
    var authorSpan = $('<span />').addClass('author').html(comment.author);
    var datetimeSpan = $('<span />').addClass('datetime').html(moment(comment.created).format('MMM D, YYYY [at] h:mm a'));
    panelHeadingInner.append(authorSpan).append(datetimeSpan);
    panelHeading.append(panelHeadingInner);
    
    /*var paragraphs = comment.comment.split("\n");
    var panelBody = $('<div />').addClass('panel-body');
    for(var i = 0; i < paragraphs.length; i++) {
        var p = $('<p />').html(paragraphs[i]);
        panelBody.append(p);
    }*/
    var panelBody = $('<div />').addClass('panel-body');
    var commentPre = $('<pre />').addClass('comment').html(comment.comment);
    panelBody.append(commentPre);
    
    commentDOM.append(panelHeading).append(panelBody);
    $('#commentsContainer-inner').prepend(commentDOM);
}

function toggleAddNewCommentPanel() {
    var addCommentPanel = $('#addCommentPanel');
    if (addCommentPanel.css('display') == 'none') {
        addCommentPanel.css('display', 'block');
        $('#addCommentButton').html('Hide Add Comment Panel');
    } else {
        addCommentPanel.css('display', 'none');
        $('#addCommentButton').html('Add Comment');
    }
}