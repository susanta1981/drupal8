<?php
require('../../start.php');

$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('config')) {
    header('Location: ../index.php');
}

$config = Application_Factory::config();
$response = new Aksman_Response_PageResponse($config->directories->templates . 'config.phtml');

$response->config = $config;

$response->app = array(
    'name' => $config->application->name,
    'version' => $config->application->version,
);
$response->webdir = array(
    'lib' => $config->webLocations->lib,
    'css' => $config->webLocations->css,
    'js' => $config->webLocations->js,
    'img' => $config->webLocations->images,
    'video' => $config->webLocations->videos,
    'screenshots' => $config->webLocations->screenshots,
);
$response->copyright = array(
    'holder' => $config->application->copyright->holder,
    'years' => $config->application->copyright->years,
);
$response->user = $auth->getUsername();
$response->logoutScript = $config->auth->logoutScript;

$response->success('Page generated.');
echo $response;