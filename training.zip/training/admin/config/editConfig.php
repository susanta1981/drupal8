<?php
require('../../start.php');

$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('config')) {
    header('Location: ../index.php');
}

$post = new Aksman_Request_RawPostJson;
$response = new Aksman_Response_JsonResponse;

try {
    $configPath = $post->configPath;
    $value = $post->value;
    $configTraversal = explode('-', $configPath);

    $config->traverseByArraySetValue($configTraversal, $value);
    $writer = $config->createWriter();
    $writer->useFile(APP_CONFIG_FILE)->exportJson(true);

    $response->config = $config->export();
    exit($response->success('Configuration changed.'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex));
}
