<?php
require('../../start.php');

$auth = Application_Factory::auth();
if (!$auth->check()) {
    header("Location: ../index.php");
}

$config = Application_Factory::config();
$response = new Aksman_Response_JsonResponse;
if ($config->application->stage == 'development') {
    $response->_reportErrors = true;
}

try {
    $post = new Aksman_Request_RawPostJson;
    $server = new Aksman_Request_Server;
    $encrypter = Application_Factory::encrypter();

    //Check incoming values
    $video = $post->video;
    if (!isset($config->videos->{$video})) {
        $msg = "Invalid video designation \"{$video}\"";
        $ex = new Exception($msg);
        exit($response->error($ex, $msg));
    }
    $expire = $post->expire;
    try {
        $expireDT = new DateTime($expire);
        $formattedExpire = $expireDT->format('Y-m-d H:i:s');
    } catch (Exception $ex) {
        exit($response->error($ex, "Invalid expire value \"{$expire}\""));
    }
    $location = $post->location;

    $data = array(
        'video' => $video,
        'expire' => $formattedExpire,
        'location' => $location,
    );
    /*$rawTicket = http_build_query($data);
    $binaryTicket = $encrypter->encrypt($rawTicket);
    $ticket = bin2hex($binaryTicket);*/
    $linkManager = new Application_Video_LinkManager2($config->directories->vidlinks);
    $random = Application_Factory::random();
    $ticket = $linkManager->create($random, $video, $formattedExpire, $location);


    $link = "http://{$server->SERVER_NAME}show.php/{$ticket}";

    $response->link = $link;
    $response->video = $video;
    $response->expire = $expire;
    $response->formattedExpire = $formattedExpire;
    $response->location = $location;
    exit($response->success('Link created'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, 'Something went wrong'));
}
