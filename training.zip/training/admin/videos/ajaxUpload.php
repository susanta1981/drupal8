<?php
require('../../start.php');

$config = Application_Factory::config();
$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    header("Location: ../index.php");
}
$random = Application_Factory::random();
$response = new Aksman_Response_JsonResponse;

try {
    $uploaddir = $config->directories->videos;
    $file = reset($_FILES);

    // Check for errors
    switch($file['error']) {
        case UPLOAD_ERR_OK:
            break;
        case UPLOAD_ERR_NO_FILE:
            $ex = new Exception('No file sent');
            exit($response->error($ex, 'No file sent'));
            break;
        case UPLOAD_ERR_INI_SIZE:
            //passthru
        case UPLOAD_ERR_FORM_SIZE:
            $ex = new Exception('File exceeded size limit');
            exit($response->error('File exceeded size limit'));
            break;
        default:
            $ex = new Exception('File upload failed due to unknown error');
            exit($response->error('File upload failed due to unknown error'));
    }

    $filenameParts = explode('.', $file['name']);
    $ext = end($filenameParts);
    $newFileName = $random->getRandomString(16) . '.' . $ext;
    $response->uploadedFile = $file['name'];
    $response->filename = $newFileName;

    if (move_uploaded_file($file['tmp_name'], $uploaddir . $newFileName)) {
        $response->file = $newFileName;
    } else {
        $ex = new Exception('Failed to move uploaded file');
        exit($response->error($ex, 'Failed to move uploaded file'));
    }
    exit($response->success('File uploaded successfully'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, 'Something unexpected happened.'));
}
