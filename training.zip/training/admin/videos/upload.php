<?php
require('../../start.php');

$config = Application_Factory::config();
$auth = Application_Factory::auth();
$response = new Aksman_Response_PageResponse($config->directories->templates . 'uploadvideo.phtml');

if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    header("Location: ../index.php");
}

try {
    //$videoDir = $config->directories->videos;
    $lister = new Application_Video_Lister($config->directories->videos);
    $excludes = $lister->listExcludes($config->videos);
    $availableFiles = $lister->listFiles($excludes);
    /*$rawFileList = scandir($videoDir);

    $usedFileList = array();
    $videos = $config->videos;
    foreach($videos as $video) {
        $usedFileList[$video->video] = true;
    }

    $availableFiles = array();
    foreach($rawFileList as $file) {
        if ($file == '.' || $file == '..' 
            || isset($usedFileList[$file])
            || is_dir($videoDir . $file)) {
            continue;
        }
        $availableFiles[] = $file;
    }*/

    $response->availableFiles = $availableFiles;
    exit($response->success('Page created'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, 'Something unexpected happened'));
}
