<?php
require('../../start.php');

$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    header("Location: ../index.php");
}

$config = Application_Factory::config();
$get = new Aksman_Request_Get;
$response = new Aksman_Response_PageResponse($config->directories->templates . 'preview.phtml');

try {
    $videoId = $get->video;
    if (!isset($config->videos->{$videoId})) {
        throw new Exception("Video ID \"{$videoId}\" does not exist");
    }
    $video = $config->videos->{$videoId};

    $response->user = $auth->getUsername();
    $response->video = array(
        'id' => $videoId,
        'title' => $video->title,
        'type' => $video->type,
        'source' => $video->video,
        'poster' => $video->screenshot,
        'width' => $video->width,
        'height' => $video->height,
        'length' => $video->length,
    );
    exit($response->success('Page generated'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, 'Something unexpected happened. Please check the logs.'));
}
