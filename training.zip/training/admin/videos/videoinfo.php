<?php
require('../../start.php');

$auth = Application_Factory::auth();
if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    header("Location: ../index.php");
}

$config = Application_Factory::config();
$get = new Aksman_Request_Get;
$response = new Aksman_Response_PageResponse($config->directories->templates . 'videoinfo.phtml');
if ($config->application->stage == 'development') {
    $response->_reportErrors = true;
}

try {
    $videoLabel = $get->video;
    if (!isset($config->videos->{$videoLabel})) {
        $msg = "Invalid video label \"$videoLabel\"";
        $ex = new Exception($msg);
        exit($response->error($ex, $msg));
    }

    $video = array(
        'label' => $videoLabel,
        'title' => $config->videos->{$videoLabel}->title,
        'screenshot' => $config->webLocations->screenshots.'/'.$config->videos->{$videoLabel}->screenshot,
        'video' => $config->videos->{$videoLabel}->video,
        'type' => $config->videos->{$videoLabel}->type,
        'width' => $config->videos->{$videoLabel}->width,
        'height' => $config->videos->{$videoLabel}->height,
        'length' => $config->videos->{$videoLabel}->length,
        'public' => $config->videos->{$videoLabel}->public,
    );

    $pdo = Application_Factory::pdo();
    $commentsManager = new Application_Video_Comments($pdo, $videoLabel);
    $comments = $commentsManager->getComments(false, true, true);

    $response->video = $video;
    $response->comments = $comments;
    exit($response->success('Success'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, 'Something unexpected happened'));
}
