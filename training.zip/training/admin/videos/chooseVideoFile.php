<?php
require('../../start.php');

$config = Application_Factory::config();
$post = new Aksman_Request_Post;
$response = new Aksman_Response_TextResponse;

try {
    $title = $post->title;
    $file = $post->file_choice;
    $videoDir = $config->directories->videos;

    // Double check if file is valid.
    $lister = new Application_Video_Lister($videoDir);
    $excludes = $lister->listExcludes($config->videos);
    $valids = $lister->listFiles($excludes);
    if (!in_array($file, $valids)) {
        throw new Exception("Invalid file \"$file\" chosen");
    }

    // Keep doing this until we find an unused key. Should be very rare to
    // find a collision, but just in case...
    do {
        $charsAvailable = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.';
        $charsLen = strlen($charsAvailable);
        for($key = ''; strlen($key) < 16;) {
            $choice = mt_rand(0, $charsLen - 1);
            $key .= substr($charsAvailable, $choice, 1);
        }
    } while (isset($config->videos->{$key}));

    $processor = new Application_Video_Processor($config->exe->ffmpeg->command, $config->exe->ffmpeg->directory);
    $processedData = $processor->setVideoFile($config->directories->videos . $file)
        ->setImageFile($config->directories->screenshots . file_replace_ext($file, 'png'))
        ->setTime('0')
        ->process();

    $data = new stdClass;
    $data->title = $title;
    $data->type = crude_video_mime($file);
    $data->video = $processedData['video'];
    $data->screenshot = $processedData['poster'];
    $data->width = $processedData['onscreen-width'];
    $data->height = $processedData['onscreen-height'];
    $data->length = $processedData['length'];
    $config->videos->{$key} = $data;

    $configWriter = $config->createWriter()->useFile(APP_CONFIG_FILE)->exportJson(true);
    header("Location: index.php");

} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, "File choice failed. Please check the logs."));
}

function file_replace_ext($filename, $ext)
{
    $pos = strrpos($filename, '.');
    if ($pos === false) {
        return $filename . '.' . $ext;
    } elseif ($pos == 0) {
        return '.' . $ext;
    } else {
        return substr($filename, 0, $pos) . '.' . $ext;
    }
}

function crude_video_mime($file)
{
    $ext = end(explode('.', $file));
    switch ($ext) {
        case 'mp4':
            return 'video/mp4';
            break;
        case 'wmv':
            return 'video/x-ms-wmv';
            break;
        case 'avi':
            return 'video/avi';
            break;
        case 'mov':
            return 'video/quicktime';
            break;
        default:
            return 'application/octet-stream';
            break;
    }
}