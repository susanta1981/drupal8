<?php
require('../../start.php');

$config = Application_Factory::config();
$post = new Aksman_Request_RawPostJson;
$response = new Aksman_Response_SimpleJsonResponse;

try {
    $auth = Application_Factory::auth();
    if (!$auth->check() || !$auth->hasRole('manage videos')) {
        throw new Exception('User is not logged in.');
    }
    $vidId = $post->video;
    $checked = $post->checked;

    if (!isset($config->videos->{$vidId})) {
        throw new Exception("Video with ID \"{$vidId}\" does not exist");
    }
    if ($checked === 'false' || $checked == false) {
        $toggle = false;
    } else if ($checked === 'toggle') {
        if (empty($config->videos->{$vidId}->public)) {
            $toggle = true;
        } else {
            $toggle = false;
        }
    } else {
        $toggle = true;
    }
    $config->videos->{$vidId}->public = $toggle;
    $writer = $config->createWriter()->useFile(APP_CONFIG_FILE);
    $writer->exportJson(true);

    $response->video = $vidId;
    $response->public = $toggle;
    $response->success();
    exit($response);
} catch (Exception $ex) {
    //$logger->logException($ex);
    $response->error($ex);
    exit($response);
}

