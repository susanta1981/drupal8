<?php
require('../../start.php');
set_time_limit(0);

$config = Application_Factory::config();
$auth = Application_Factory::auth();
$response = new Aksman_Response_JsonResponse;
$response->_reportErrors = true;
$response->_prettyPrint = true;
if (!$auth->check() || !$auth->hasRole('manage videos')) {
    $auth->logoff();
    header("Location: ../index.php");
}
$post = new Aksman_Request_Post;

try {
    $random = Application_Factory::random();
    $parser = new Application_MultiPartFormDataParser($random, $config->directories->videos);
    $parser->setRandomFileNames(false)->setExtWhiteList(array('mp4', 'avi', 'wmv'))->parse();

    $processor = new Application_Video_Processor($config->exe->ffmpeg->command, $config->exe->ffmpeg->directory);

    $post = $parser->getPost();
    $files = $parser->getFiles();
    foreach($files as $fileData) {
        // Keep doing this until we find an unused key. Should be very rare to 
        // find a collision, but just in case...
        do {
            $charsAvailable = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.';
            $charsLen = strlen($charsAvailable);
            for($key = ''; strlen($key) < 16;) {
                $choice = mt_rand(0, $charsLen - 1);
                $key .= substr($charsAvailable, $choice, 1);
            }
        } while (isset($config->videos->{$key}));

        $processedData = $processor->setVideoFile($config->directories->videos . $fileData['real_name'])
            ->setImageFile($config->directories->screenshots . file_replace_ext($fileData['real_name'], 'png'))
            ->setTime('0')
            ->process();

        $data = new stdClass;
        $data->title = $post['title'];
        $data->type = $fileData['type'];
        $data->video = $processedData['video'];
        $data->screenshot = $processedData['poster'];
        $data->width = $processedData['onscreen-width'];
        $data->height = $processedData['onscreen-height'];
        $data->length = $processedData['length'];
        $config->videos->{$key} = $data;
    }

    $configWriter = $config->createWriter()->useFile(APP_CONFIG_FILE)->exportJson(true);
    header("Location: index.php");

    $response->post = $parser->getPost();
    $response->files = $parser->getFiles();
    exit($response->success('File uploaded.'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, 'Something unexpected happened.'));
}

function file_replace_ext($filename, $ext) {
    $pos = strrpos($filename, '.');
    if ($pos === false) {
        return $filename . '.' . $ext;
    } elseif ($pos == 0) {
        return '.' . $ext;
    } else {
        return substr($filename, 0, $pos) . '.' . $ext;
    }
}
/*$patterns = array(
    'begin' => "/^-----------------------------[0-9]+$/",
    'end' => "/^-----------------------------[0-9]+--$/",
    'simple-value' => "/^Content-Disposition: form-data; name=\"([a-zA-Z0-9_\.]+)\"\$/",
    'file-value' => "/^Content-Disposition: form-data; name=\"([a-zA-Z0-9\-_\.]+)\"; filename=\"([a-zA-Z0-9\-_\.]+)\"\$/",
    'content-type' => "/^Content-Type: ([a-zA-Z0-9\-\_\.\/]+)$/",
);
$post = array();
$files = array();

function tempname()
{
    $random = Application_Factory::random();
    return $random->getRandomString(20);
}

function parseValue(&$fh, $beginPattern, $endPattern) {
    $value = '';

    $blankline = fgets($fh);
    $nextLine = fgets($fh);
    $begin = preg_match($beginPattern, trim($nextLine));
    $end = preg_match($endPattern, trim($nextLine));
    while (!$begin && !$end) {
        $value .= $nextLine;
        $numLines++;
        $nextLine = fgets($fh);
        $begin = preg_match($beginPattern, trim($nextLine));
        $end = preg_match($endPattern, trim($nextLine));
    }
    if ($end) {
        fclose($fh);
    }
    return trim($value);
}

function parseFile(&$fh, $file, $beginPattern, $endPattern, $contentTypePattern) {
    $contentTypeLine = fgets($fh);
    if (preg_match($contentTypePattern, trim($contentTypeLine), $matches)) {
        $contentType = $matches[1];
    } else {
        throw new Exception('Invalid file encoding with bad content-type line');
    }

    $blankLine = fgets($fh);
    $output = fopen($file, 'w');
    $nextLine = fgets($fh);
    $begin = preg_match($beginPattern, trim($nextLine));
    $end = preg_match($endPattern, trim($nextLine));
    while(!$begin && !$end) {
        fwrite($output, $nextLine);
        $nextLine = fgets($fh);
        $begin = preg_match($beginPattern, trim($nextLine));
        $end = preg_match($endPattern, trim($nextLine));
    }
    fclose($output);
    if ($end) {
        fclose($fh);
    }
    return $file;
}

try {
    $dir = $config->directories->videos;
    $input = fopen("php://input", 'r');

    $nextLine = fgets($input);
    $reachedSimpleValue = false;
    while (is_resource($input) && (!feof($input) || !preg_match($patterns['end'], trim($nextLine)))) {
        if (preg_match($patterns['simple-value'], trim($nextLine), $matches)) {
            $reachedSimpleValue = true;
            $valName = $matches[1];
            $post[$valName] = parseValue($input, $patterns['begin'], $patterns['end']);
        } elseif (preg_match($patterns['file-value'], trim($nextLine), $matches)) {
            $valName = $matches[1];
            $fileName = $dir . $matches[2];
            $files[$valName] = parseFile($input, $fileName, $patterns['begin'], $patterns['end'], $patterns['content-type']);
        }
        if (is_resource($input)) {
            $nextLine = fgets($input);
        }
    }
    if (is_resource($input)) {
        fclose($input);
    }

    $response->valName = (isset($valName)) ? $valName : 'No value name found';
    $response->reachedSimpleValue = $reachedSimpleValue;
    $response->postVals = $post;
    $response->files = $files;
    exit($response->success('Input processed'));
} catch (Exception $ex) {
    exit($response->error($ex, 'Something unexpected happened'));
}*/
