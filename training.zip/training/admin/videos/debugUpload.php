<?php
require('../../start.php');
set_time_limit(0);

$response = new Aksman_Response_JsonResponse;
$response->_reportErrors = true;
$response->_prettyPrint = true;

try {
    $input = fopen("php://input", 'rb');
    $output = fopen($config->directories->videos . 'debug\\output.txt', 'w');
    while($chunk = fread($input, 8192)) {
        fwrite($output, $chunk);
    }
    fclose($input);
    fclose($output);

    exit($response->success('Raw input should now be available.'));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, 'Something unexpected happened, please check the logs.'));
}