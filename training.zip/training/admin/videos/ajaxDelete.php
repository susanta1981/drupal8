<?php
require('../../start.php');

$config = Application_Factory::config();
$post = new Aksman_Request_RawPostJson;
$response = new Aksman_Response_JsonResponse;

try {
    $auth = Application_Factory::auth();
    if (!$auth->check() || !$auth->hasRole('manage videos')) {
        $response->auth = false;
        throw new Exception('User is not logged in.');
    }
    $response->auth = true;

    $id = $post->id;
    if (!isset($config->videos->{$id})) {
        throw new Exception("Video with ID \"{$id}\" does not exist");
    }

    $vid = $config->videos->{$id};
    $posterFile = $config->directories->screenshots . $vid->screenshot;
    $videoFile = $config->directories->videos . $vid->video;

    unset($config->videos->{$id});
    $writer = $config->createWriter()->useFile(APP_CONFIG_FILE);
    $writer->exportJson(true);

    unlink($posterFile);
    unlink($videoFile);

    exit($response->success("Video deleted"));
} catch (Exception $ex) {
    $logger->logException($ex);
    exit($response->error($ex, $ex->getMessage()));
}


