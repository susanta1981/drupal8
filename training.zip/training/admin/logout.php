<?php
require('../start.php');

$post = new Aksman_Request_Post;
$script = $post->script;

$auth = Application_Factory::auth();
$auth->logout();

header('Location: ' . $script);
