<?php
require('../start.php');

$post = new Aksman_Request_Post;

$user = $post->user;
$password = $post->password;
$script = $post->script;

$auth = Application_Factory::auth();
$loggedin = $auth->logon($user, $password);

header('Location: '.$script);
