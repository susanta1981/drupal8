<?php
require('../start.php');

$config = Application_Factory::config();
$auth = Application_Factory::auth();
$server = new Aksman_Request_Server;
if ($auth->check()) {
    $loggedIn = true;
    $template = 'adminhome.phtml';
    $message = 'Which do you wish to manage?';
} else {
    $loggedIn = false;
    $template = 'login.phtml';
    $message = 'You must log in to access administrative functions.';
}
$response = new Aksman_Response_PageResponse($config->directories->templates . $template);

$response->app = array(
    'name' => $config->application->name,
    'version' => $config->application->version,
);
$response->webdir = array(
    'css' => $config->webLocations->css,
    'img' => $config->webLocations->images,
    'lib' => $config->webLocations->lib,
);
$response->copyright = array(
    'holder' => $config->application->copyright->holder,
    'years' => $config->application->copyright->years,
);
if (!$loggedIn) {
    $response->form = array(
        'user' => '',
        'password' => '',
    );
    $response->loginScript = $config->auth->loginScript;
} else {
    $response->user = $auth->getUsername();
    $response->logoutScript = $config->auth->logoutScript;
}

echo $response->success($message);
