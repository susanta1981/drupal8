<?php
require('start.php');

$get = new Aksman_Request_Get;
$video = $get->video;
$config = Application_Factory::config();

$response = new Aksman_Response_PageResponse($config->directories->templates . 'video.phtml');
$response->app = array(
    'name' => $config->application->name,
    'version' => $config->application->version,
);
$response->webdir = array(
    'lib' => $config->webLocations->lib,
    'css' => $config->webLocations->css,
    'js' => $config->webLocations->js,
    'img' => $config->webLocations->images,
    'screenshots' => $config->webLocations->screenshots,
    'video' => $config->webLocations->videos,
);
$response->copyright = array(
    'holder' => $config->application->copyright->holder,
    'years' => $config->application->copyright->years,
);
if ($video !== null) {
    if (isset($config->videos->{$video}) && !empty($config->videos->{$video}->public)) {
        $response->video = array(
            'title' => $config->videos->{$video}->title,
            'poster' => (isset($config->videos->{$video}->screenshot)) ? $config->videos->{$video}->screenshot : null,
            'source' => $config->videos->{$video}->video,
            'type' => $config->videos->{$video}->type,
            'width' => $config->videos->{$video}->width,
            'height' => $config->videos->{$video}->height,
        );
    }
} else {
    $response->video = false;
}
$vidList = array();
foreach($config->videos as $label => $attrs) {
    if (!empty($attrs->public)) {
        $vidList[$label] = array(
            'title' => $attrs->title,
            'screenshot' => $attrs->screenshot,
            'length' => $attrs->length,
        );
    }
}
$response->vidList = $vidList;

echo $response->success('Page generated.');
