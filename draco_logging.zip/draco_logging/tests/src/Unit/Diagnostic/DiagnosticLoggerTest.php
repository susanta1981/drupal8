<?php

namespace Drupal\Tests\draco_logging\Unit\Diagnostic;

use Drupal\draco_logging\Diagnostic\DiagnosticLoggerChannelFactory;
use Drupal\Tests\UnitTestCase;

/**
 * Test for DiagnosticLogger.
 *
 * @group draco_logging
 *
 * @coversDefaultClass \Drupal\draco_logging\Diagnostic\DiagnosticLoggerChannel
 */
class DiagnosticLoggerTest extends UnitTestCase {

  /**
   * {@inheritdoc}
   */
  public function setUp() {

    $loggerChannelFactory = $this->getMock('Drupal\Core\Logger\LoggerChannelFactoryInterface');

    $this->loggerChannel = $this->getMockBuilder('Drupal\Core\Logger\LoggerChannel')
      ->disableOriginalConstructor()
      ->setMethods(['info'])
      ->getMock();

    $loggerChannelFactory->expects($this->any())->method('get')->willReturn($this->loggerChannel);

    $this->diagLogChanFactory = new DiagnosticLoggerChannelFactory($loggerChannelFactory);

  }

  /**
   * Test that diagnostic data appears in log.
   *
   * @covers ::info
   */
  public function testLogInfoWithDiagnosticData() {

    $this->loggerChannel->expects($this->any())
      ->method('info')
      ->with($this->equalTo("Foo You!!! [color='blue'|name='Mary']"));

    $logger = $this->diagLogChanFactory->get('draco_udi');

    $this->assertNotNull($logger);

    $logger->setDiagnosticData(['color' => 'blue', 'name' => 'Mary']);

    $logger->info('Foo You!!!');

  }

  /**
   * Test that diagnostic data is not in log.
   *
   * @covers ::info
   */
  public function testLogInfoWithoutDiagnosticData() {

    $this->loggerChannel->expects($this->any())
      ->method('info')
      ->with($this->equalTo("Foo You!!!"));

    $logger = $this->diagLogChanFactory->get('draco_udi');

    $this->assertNotNull($logger);

    $logger->info('Foo You!!!');

  }

}
