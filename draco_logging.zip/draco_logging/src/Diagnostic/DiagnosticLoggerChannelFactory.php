<?php

namespace Drupal\draco_logging\Diagnostic;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Psr\Log\LoggerInterface;

/**
 * A factory which yields diagnostic channels.
 *
 * @package Drupal\draco_udi\Logging
 */
class DiagnosticLoggerChannelFactory implements LoggerChannelFactoryInterface {

  /**
   * The wrapped channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerChannelFactory;

  /**
   * A holder for channels.
   *
   * @var array
   */
  protected $channels;

  /**
   * DiagnosticLoggerChannelFactory constructor.
   *
   * @param LoggerChannelFactoryInterface $loggerChannelFactory
   *   A logger channel factory.
   */
  public function __construct(LoggerChannelFactoryInterface $logger_channel_factory) {
    $this->loggerChannelFactory = $logger_channel_factory;
    $this->channels = array();
  }

  /**
   * {@inheritdoc}
   */
  public function get($channel) {
    if (isset($this->channels[$channel]) && ($c = $this->channels[$channel])) {
      return $c;
    }

    $c = $this->loggerChannelFactory->get($channel);
    $dc = new DiagnosticLoggerChannel($c);
    $this->channels[$channel] = $dc;

    return $dc;
  }

  /**
   * {@inheritdoc}
   */
  public function addLogger(LoggerInterface $logger, $priority = 0) {
    $this->loggerChannelFactory->addLogger($logger, $priority);
  }

}
