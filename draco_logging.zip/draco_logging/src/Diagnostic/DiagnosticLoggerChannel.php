<?php

namespace Drupal\draco_logging\Diagnostic;

use Drupal\Core\Logger\LoggerChannelInterface;
use Drupal\Core\Session\AccountInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * A logger channel which holds diagnostic data.
 *
 * @package Drupal\draco_udi\Logging
 */
class DiagnosticLoggerChannel implements LoggerChannelInterface {

  /**
   * The wrapped logger channel.
   *
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  protected $loggerChannel;

  /**
   * Holder for diagnostic data.
   *
   * @var array
   */
  protected $diagnosticData;

  /**
   * DiagnosticLoggerChannel constructor.
   *
   * @param LoggerChannelInterface $loggerChannel
   *   A logger channel.
   */
  public function __construct(LoggerChannelInterface $loggerChannel) {
    $this->loggerChannel = $loggerChannel;
    $this->diagnosticData = array();
  }

  /**
   * {@inheritdoc}
   */
  public function setRequestStack(RequestStack $requestStack = NULL) {
    $this->loggerChannel->setRequestStack($requestStack);
  }

  /**
   * {@inheritdoc}
   */
  public function setCurrentUser(AccountInterface $current_user = NULL) {
    $this->loggerChannel->setCurrentUser($current_user);
  }

  /**
   * {@inheritdoc}
   */
  public function setLoggers(array $loggers) {
    $this->loggerChannel->setLoggers($loggers);
  }

  /**
   * {@inheritdoc}
   */
  public function addLogger(LoggerInterface $logger, $priority = 0) {
    $this->loggerChannel->addLogger($logger, $priority);
  }

  /**
   * {@inheritdoc}
   */
  public function emergency($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->emergency($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function alert($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->alert($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function critical($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->critical($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function error($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->error($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function warning($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->warning($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function notice($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->notice($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function info($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->info($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function debug($message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->debug($newMessage, $context);
  }

  /**
   * {@inheritdoc}
   */
  public function log($level, $message, array $context = array()) {
    $newMessage = $this->addDiagnosticData($message);
    $this->loggerChannel->log($level, $newMessage, $context);
  }

  /**
   * Get DiagnosticData.
   *
   * @return array
   *   The DiagnosticData.
   */
  public function getDiagnosticData() {
    return $this->diagnosticData;
  }

  /**
   * Set DiagnosticData.
   *
   * @param array $diagnosticData
   *   The DiagnosticData.
   */
  public function setDiagnosticData(array $diagnostic_data) {
    $this->diagnosticData = $diagnostic_data;
  }

  /**
   * Adds the serialized diagnostic data to the message.
   *
   * @param string $message
   *   The original message.
   *
   * @return string
   *   The message with the appended data.
   */
  protected function addDiagnosticData($message) {
    $serialized = $this->getSerializedData();
    $newMessage = (empty($serialized)) ? $message : "{$message} [{$serialized}]";
    return $newMessage;
  }

  /**
   * Serialize the diagnostic data in this channel.
   *
   * @return string
   *   The serialized data.
   */
  protected function getSerializedData() {
    if (!empty($this->diagnosticData)) {
      $output = implode('|', array_map(
        function ($v, $k) { return sprintf("%s='%s'", $k, $v); },
        $this->diagnosticData,
        array_keys($this->diagnosticData)
      ));

      return $output;
    }

    return '';
  }
}
